---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Spam-Phish.md]]

### T1020

**technique ID**
[[T1020]]

**technique**
Automated Exfiltration

**technique url**
https://attack.mitre.org/techniques/T1020

**technique description**
Adversaries may exfiltrate data, such as sensitive documents, through the use of automated processing after being gathered during Collection.(Citation: ESET Gamaredon June 2020) 

When automated exfiltration is used, other exfiltration techniques likely apply as well to transfer the information out of the network, such as [Exfiltration Over C2 Channel](https://attack.mitre.org/techniques/T1041) and [Exfiltration Over Alternative Protocol](https://attack.mitre.org/techniques/T1048).

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0010]]

**tactic**
Exfiltration

**software ID**
[[S0600]] [[S0136]] [[S0445]] [[S0643]] [[S0377]] [[S0131]] [[S0050]] [[S0538]] [[S0409]] [[S0438]] [[S1017]] [[S0491]] [[S0395]] [[S0467]] [[S0090]] [[S0363]]

**software**
Empire, TajMahal, OutSteel, Peppy, USBStealer, Rover, Doki, LightNeuron, CosmicDuke, ShimRatReporter, Ebury, Machete, TINYTYPHON, Crutch, StrongPity, Attor

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Network]]

**group ID**
[[G0081]] [[G0121]] [[G0047]] [[G0004]]

**group**
Ke3chang, Gamaredon Group, Sidewinder, Tropic Trooper

**data source ID**
[[DS0029]] [[DS0012]] [[DS0022]] [[DS0017]]

**data source**
Command, Network Traffic, Script, File



