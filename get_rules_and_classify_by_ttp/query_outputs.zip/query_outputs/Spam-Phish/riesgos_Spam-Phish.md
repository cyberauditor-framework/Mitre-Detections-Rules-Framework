---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_Spam-Phish-T1078.003.md]]
[[riesgos_Spam-Phish-T1020.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1020 | Azure Sentinel Hunting Queries | 7 |
| T1020 | Mappings | 5 |
| T1020 | Sigma HQ 1 | 6 |
| T1020 | Sigma HQ 4 | 5 |
| T1020 | UCM Catalog 2024 Qradar | 1 |
| T1020 | UCM Catalog 2024 Sentinel | 13 |
| T1078.003 | Elastic 1 | 9 |
| T1078.003 | Mappings | 4 |
| T1078.003 | Sigma HQ 1 | 5 |
| T1078.003 | Sigma HQ 4 | 5 |
| T1078.003 | UCM Catalog 2024 Qradar | 3 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1078.003 | Elastic 1 | privilege_escalation_sda_disk_mount_non_root.toml |
| T1078.003 | Elastic 1 | privilege_escalation_local_user_added_to_admin.toml |
| T1078.003 | Sigma HQ 1 | proc_creation_macos_sysadminctl_add_user_to_admin_group.yml |
| T1078.003 | Sigma HQ 1 | proc_creation_macos_dsenableroot_enable_root_account.yml |
| T1078.003 | Sigma HQ 1 | proc_creation_macos_dseditgroup_add_to_admin_group.yml |
| T1078.003 | Sigma HQ 1 | proc_creation_macos_dscl_add_user_to_admin_group.yml |
| T1078.003 | UCM Catalog 2024 Qradar | T1078.003 - [CyberProof] - [Windows] - User Added to Security .md |
| T1078.003 | UCM Catalog 2024 Qradar | T1078.003 - [CyberProof] - [Windows] - User Added Themselves t.md |
| T1078.003 | UCM Catalog 2024 Qradar | T1078.003 - [CyberProof] - [Windows] - New User Account Create.md |
| T1078.003 | Sigma HQ 4 | proc_creation_macos_dscl_add_user_to_admin_group.yml |
| T1078.003 | Mappings | IdentityPlatform.yaml |
| T1078.003 | Mappings | AzureSentinel.yaml |
| T1078.003 | Mappings | AzureADIdentitySecureScore.yaml |
| T1078.003 | Mappings | AlertsForWindowsMachines.yaml |
| T1078.003 | Sigma HQ 1 | win_security_admin_rdp_login.yml |
| T1078.003 | Elastic 1 | persistence_enable_root_account.toml |
| T1078.003 | Elastic 1 | persistence_account_creation_hide_at_logon.toml |
| T1078.003 | Elastic 1 | lateral_movement_mount_hidden_or_webdav_share_net.toml |
| T1078.003 | Elastic 1 | initial_access_ml_windows_anomalous_user_name.toml |
| T1078.003 | Elastic 1 | initial_access_ml_auth_rare_user_logon.toml |
| T1078.003 | Elastic 1 | discovery_command_system_account.toml |
| T1078.003 | Elastic 1 | credential_access_ml_auth_spike_in_logon_events_from_a_source_ip.toml |
| T1078.003 | Sigma HQ 4 | proc_creation_macos_dseditgroup_add_to_admin_group.yml |
| T1078.003 | Sigma HQ 4 | proc_creation_macos_dsenableroot_enable_root_account.yml |
| T1078.003 | Sigma HQ 4 | proc_creation_macos_sysadminctl_add_user_to_admin_group.yml |
| T1078.003 | Sigma HQ 4 | win_security_admin_rdp_login.yml |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - AUTO DISABLED Multiple users email forwarded to sa.md |
| T1020 | UCM Catalog 2024 Qradar | T1020 - [CyberProof] - [AWS] - Restore Public AWS RDS Inst.md |
| T1020 | Sigma HQ 4 | posh_ps_script_with_upload_capabilities.yml |
| T1020 | Azure Sentinel Hunting Queries | AzureStorageFileCreatedQuicklyDeleted.yaml |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - CyberProof - Office Activity - NRT Multiple users .md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - Custom - OfficeActivity - Multiple emails forwarde.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - CyberProof - Azure Storage - Azure Storage File Cr.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - CyberProof - Office Activity - Mail redirect via E.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - CyberProof - Office Activity - Multiple users emai.md |
| T1020 | Sigma HQ 4 | microsoft365_susp_inbox_forwarding.yml |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - CyberProof - Threat Essentials - Mail redirect via.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - Mail redirect via ExO transport rule.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - Multiple users email forwarded to same destination.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - NRT Multiple users email forwarded to same destina.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - Office365 Sharepoint File transfer above threshold.md |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - SFTP File transfer above threshold.md |
| T1020 | Sigma HQ 4 | posh_ps_resolve_list_of_ip_from_file.yml |
| T1020 | Sigma HQ 1 | aws_rds_public_db_restore.yml |
| T1020 | Sigma HQ 4 | aws_rds_public_db_restore.yml |
| T1020 | Mappings | AWSIOTDeviceDefender.yaml |
| T1020 | Azure Sentinel Hunting Queries | MailForwardingActivityFromNewLocation.yaml |
| T1020 | Azure Sentinel Hunting Queries | mass-downloads.yaml |
| T1020 | Azure Sentinel Hunting Queries | NewClientRunningQueries.yaml |
| T1020 | Azure Sentinel Hunting Queries | NewServicePrincipalRunningQueries.yaml |
| T1020 | Azure Sentinel Hunting Queries | UserRunningMultipleQueriesThatFail.yaml |
| T1020 | Mappings | AmazonGuardDuty.yaml |
| T1020 | Mappings | AWSConfig.yaml |
| T1020 | Mappings | Chronicle.yaml |
| T1020 | Sigma HQ 4 | aws_rds_change_master_password.yml |
| T1020 | Mappings | CloudIDS.yaml |
| T1020 | Sigma HQ 1 | aws_rds_change_master_password.yml |
| T1020 | Azure Sentinel Hunting Queries | CrossWorkspaceQueryAnomolies.yaml |
| T1020 | Sigma HQ 1 | microsoft365_susp_email_forwarding_activity.yml |
| T1020 | Sigma HQ 1 | microsoft365_susp_inbox_forwarding.yml |
| T1020 | Sigma HQ 1 | posh_ps_resolve_list_of_ip_from_file.yml |
| T1020 | Sigma HQ 1 | posh_ps_script_with_upload_capabilities.yml |
| T1020 | UCM Catalog 2024 Sentinel | T1020 - SFTP File transfer folder count above threshold.md |


