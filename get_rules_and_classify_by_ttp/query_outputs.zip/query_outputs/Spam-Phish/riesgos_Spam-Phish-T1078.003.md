---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Spam-Phish.md]]

### T1078.003

**technique ID**
[[T1078.003]]

**technique**
Local Accounts

**technique url**
https://attack.mitre.org/techniques/T1078/003

**technique description**
Adversaries may obtain and abuse credentials of a local account as a means of gaining Initial Access, Persistence, Privilege Escalation, or Defense Evasion. Local accounts are those configured by an organization for use by users, remote support, services, or for administration on a single system or service.

Local Accounts may also be abused to elevate privileges and harvest credentials through [OS Credential Dumping](https://attack.mitre.org/techniques/T1003). Password reuse may allow the abuse of local accounts across a set of machines on a network for the purposes of Privilege Escalation and Lateral Movement. 

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0005]] [[TA0001]] [[TA0004]] [[TA0003]]

**tactic**
Privilege Escalation, Persistence, Initial Access, Defense Evasion

**software ID**
[[S0221]] [[S0368]] [[S0367]] [[S0154]]

**software**
NotPetya, Umbreon, Cobalt Strike, Emotet

**platform**
[[Windows]] [[Linux]] [[Network]] [[macOS]] [[Containers]]

**group ID**
[[G0056]] [[G0010]] [[G0016]] [[G0050]] [[G0094]] [[G0081]] [[G0046]] [[G0125]] [[G0051]]

**group**
APT29, Turla, HAFNIUM, Tropic Trooper, PROMETHIUM, FIN7, Kimsuky, APT32, FIN10

**data source ID**
[[DS0002]] [[DS0028]]

**data source**
Logon Session, User Account



