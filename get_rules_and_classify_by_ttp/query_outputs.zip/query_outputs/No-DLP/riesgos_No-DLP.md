---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_No-DLP-T1486.md]]
[[riesgos_No-DLP-T1114.md]]
[[riesgos_No-DLP-T1048.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1048 | Atomic | 3 |
| T1048 | Azure Sentinel Hunting Queries | 1 |
| T1048 | Elastic 1 | 7 |
| T1048 | Mappings | 16 |
| T1048 | Sigma HQ 1 | 7 |
| T1048 | Sigma HQ 2 | 3 |
| T1048 | Sigma HQ 4 | 7 |
| T1048 | Sigma HQ 9 | 3 |
| T1048 | UCM Catalog 2024 Sentinel | 4 |
| T1114 | Atomic | 3 |
| T1114 | Azure Sentinel Hunting Queries | 3 |
| T1114 | Elastic 1 | 6 |
| T1114 | Elastic 2 | 1 |
| T1114 | Mappings | 2 |
| T1114 | Sigma HQ 1 | 4 |
| T1114 | Sigma HQ 2 | 2 |
| T1114 | Sigma HQ 4 | 4 |
| T1114 | Sigma HQ 9 | 2 |
| T1114 | UCM Catalog 2024 Sentinel | 25 |
| T1486 | Atomic | 2 |
| T1486 | Azure Sentinel Hunting Queries | 1 |
| T1486 | Elastic 1 | 4 |
| T1486 | Mappings | 10 |
| T1486 | Sigma HQ 1 | 14 |
| T1486 | Sigma HQ 2 | 3 |
| T1486 | Sigma HQ 4 | 10 |
| T1486 | Sigma HQ 9 | 3 |
| T1486 | UCM Catalog 2024 Sentinel | 5 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1486 | Sigma HQ 1 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Mappings | ActifioGo.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_wannacry.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_lockergoga_ransomware.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_conti_ransomware_commands.yml |
| T1486 | Sigma HQ 1 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 1 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 1 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 1 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 1 | av_ransomware.yml |
| T1486 | Mappings | SecurityCenterRecommendations.yaml |
| T1486 | Mappings | CloudAppSecurity.yaml |
| T1486 | Mappings | Chronicle.yaml |
| T1486 | Mappings | AzureSentinel.yaml |
| T1486 | Mappings | AzureBackup.yaml |
| T1486 | Mappings | AWSRDS.yaml |
| T1486 | Mappings | AWSConfig.yaml |
| T1486 | Mappings | AWSCloudEndure.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 1 | win_security_malware_bluesky_ransomware_files_indicators.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 4 | proc_creation_win_reg_bitlocker.yml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - Suspicious over.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - S3 bucket suspi.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - Office 365  - Suspicious file renaming activity (C.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - CyberProof - CiscoAMP - Ransomware Activity.md |
| T1486 | Sigma HQ 9 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 4 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 4 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 4 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 4 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 4 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 4 | av_ransomware.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Mappings | AmazonGuardDuty.yaml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - UC491 - Azure ATP - Ransomware Infection Attempt.md |
| T1486 | Elastic 1 | impact_data_encrypted_via_openssl.toml |
| T1486 | Atomic | T1490.md |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_file_encryption.toml |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_note_detected.toml |
| T1486 | Atomic | T1489.md |
| T1486 | Elastic 1 | impact_microsoft_365_potential_ransomware_activity.toml |
| T1486 | Azure Sentinel Hunting Queries | ASR--Rule-Ransomware-triggered.yaml |
| T1114 | Elastic 1 | collection_email_powershell_exchange_mailbox.toml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Malicious Emai.md |
| T1114 | Azure Sentinel Hunting Queries | MailForwardingActivityFromNewLocation.yaml |
| T1114 | Azure Sentinel Hunting Queries | RareDomainsInCloudLogs.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Emails Remedia.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Email Threats .md |
| T1114 | Sigma HQ 2 | azure-exchange-email rule breach (on behalf).yaml |
| T1114 | Sigma HQ 2 | azure-exchange-email rule disapearence.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Email Analysis.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Mimecast - User with Increase in Outg.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Mimecast - Emails from Outside the Or.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Fortinet - High Severity Events.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Custom - OfficeActivity - Multiple emails forwarde.md |
| T1114 | Elastic 1 | collection_google_workspace_custom_gmail_route_created_or_modified.toml |
| T1114 | Sigma HQ 4 | microsoft365_pst_export_alert.yml |
| T1114 | Sigma HQ 4 | microsoft365_pst_export_alert_using_new_compliancesearchaction.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Exchange workflow M.md |
| T1114 | Sigma HQ 4 | win_security_alert_ruler.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Custom - Anomaly - Exchange workflow MailItemsAcce.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - AUTO DISABLED Multiple users email forwarded to sa.md |
| T1114 | Elastic 1 | collection_email_outlook_mailbox_via_com.toml |
| T1114 | Azure Sentinel Hunting Queries | imProcess_HostExportingMailboxAndRemovingExport.yaml |
| T1114 | Elastic 1 | collection_posh_mailbox.toml |
| T1114 | Elastic 1 | collection_microsoft_365_new_inbox_rule.toml |
| T1114 | Elastic 1 | collection_mailbox_export_winlog.toml |
| T1114 | Sigma HQ 4 | proc_creation_win_powershell_snapins_hafnium.yml |
| T1114 | Atomic | T1114.md |
| T1114 | Sigma HQ 9 | azure-exchange-email rule disapearence.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Mail redirect via ExO transport rule.md |
| T1114 | Atomic | win_alert_ruler.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Rare and potentially high-risk Office operations.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - OfficeActivity - Known Manganese IP and UserAgent .md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - NRT Multiple users email forwarded to same destina.md |
| T1114 | Atomic | win_alert_hacktool_use.md |
| T1114 | Sigma HQ 1 | microsoft365_pst_export_alert_using_new_compliancesearchaction.yml |
| T1114 | Sigma HQ 1 | proc_creation_win_powershell_snapins_hafnium.yml |
| T1114 | Sigma HQ 1 | win_security_alert_ruler.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Multiple users email forwarded to same destination.md |
| T1114 | Sigma HQ 1 | microsoft365_pst_export_alert.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Exchange workflow MailItemsAccessed operation anom.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Mail redirect via E.md |
| T1114 | Elastic 2 | collection_outlook_email_archive.toml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Threat Essentials - Mail redirect via.md |
| T1114 | Mappings | AzureSentinel.yaml |
| T1114 | Mappings | AdvancedProtectionProgram.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Multiple users emai.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - NRT Multiple users .md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Rare and potentiall.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - OfficeActivity - Multiple emails forw.md |
| T1114 | Sigma HQ 9 | azure-exchange-email rule breach (on behalf).yaml |
| T1048 | Sigma HQ 9 | win-os-BITS high volume file downloaded (native).yaml |
| T1048 | Sigma HQ 9 | win-os-BITS abuse for payload download (PowerShell).yaml |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - Azure Firewall - DNS events related to ToR proxies.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - DNS events related to ToR proxies.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - UC121 - IPS - Non Compliant DNS from Internal Netw.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - UC483 - Azure ATP - Data Exfiltration.md |
| T1048 | Atomic | T1197.md |
| T1048 | Atomic | T1048.md |
| T1048 | Sigma HQ 9 | win-os-BITS abuse for payload download (command).yaml |
| T1048 | Atomic | T1022.md |
| T1048 | Mappings | CloudIDS.yaml |
| T1048 | Azure Sentinel Hunting Queries | RareDNSLookupWithDataTransfer.yaml |
| T1048 | Sigma HQ 4 | zeek_dns_torproxy.yml |
| T1048 | Sigma HQ 1 | win_security_tap_driver_installation.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_tapinstall_execution.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_susp_redirect_local_admin_share.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_susp_copy_lateral_movement.yml |
| T1048 | Sigma HQ 1 | posh_ps_invoke_dnsexfiltration.yml |
| T1048 | Mappings | AmazonGuardDuty.yaml |
| T1048 | Mappings | AmazonVirtualPrivateCloud.yaml |
| T1048 | Mappings | AWSIOTDeviceDefender.yaml |
| T1048 | Mappings | AWSNetworkFirewall.yaml |
| T1048 | Mappings | AzureDNSAnalytics.yaml |
| T1048 | Mappings | AzureFirewall.yaml |
| T1048 | Mappings | AzureSentinel.yaml |
| T1048 | Mappings | AzureTrafficAnalytics.yaml |
| T1048 | Mappings | BeyondCorpEnterprise.yaml |
| T1048 | Mappings | Chronicle.yaml |
| T1048 | Mappings | NetworkSecurityGroups.yaml |
| T1048 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1048 | Sigma HQ 1 | win_system_service_install_tap_driver.yml |
| T1048 | Sigma HQ 1 | zeek_dns_torproxy.yml |
| T1048 | Mappings | AlertsForWindowsMachines.yaml |
| T1048 | Elastic 1 | command_and_control_irc_internet_relay_chat_protocol_activity_to_the_internet.toml |
| T1048 | Sigma HQ 4 | win_system_service_install_tap_driver.yml |
| T1048 | Mappings | Firewalls.yaml |
| T1048 | Sigma HQ 4 | proc_creation_win_tapinstall_execution.yml |
| T1048 | Sigma HQ 4 | proc_creation_win_susp_redirect_local_admin_share.yml |
| T1048 | Sigma HQ 4 | proc_creation_win_susp_copy_lateral_movement.yml |
| T1048 | Sigma HQ 4 | posh_ps_invoke_dnsexfiltration.yml |
| T1048 | Elastic 1 | command_and_control_ftp_file_transfer_protocol_activity_to_the_internet.toml |
| T1048 | Elastic 1 | command_and_control_port_26_activity.toml |
| T1048 | Mappings | AlertsForDNS.yaml |
| T1048 | Sigma HQ 2 | win-os-BITS high volume file downloaded (native).yaml |
| T1048 | Sigma HQ 2 | win-os-BITS abuse for payload download (PowerShell).yaml |
| T1048 | Sigma HQ 2 | win-os-BITS abuse for payload download (command).yaml |
| T1048 | Elastic 1 | command_and_control_smtp_to_the_internet.toml |
| T1048 | Elastic 1 | exfiltration_smb_rare_destination.toml |
| T1048 | Elastic 1 | initial_access_rdp_remote_desktop_protocol_to_the_internet.toml |
| T1048 | Elastic 1 | initial_access_smb_windows_file_sharing_activity_to_the_internet.toml |
| T1048 | Sigma HQ 4 | win_security_tap_driver_installation.yml |


