---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_No-DLP.md]]

### T1486

**technique ID**
[[T1486]]

**technique**
Data Encrypted for Impact

**technique url**
https://attack.mitre.org/techniques/T1486

**technique description**
Adversaries may encrypt data on target systems or on large numbers of systems in a network to interrupt availability to system and network resources. They can attempt to render stored data inaccessible by encrypting files or data on local and remote drives and withholding access to a decryption key. This may be done in order to extract monetary compensation from a victim in exchange for decryption or a decryption key (ransomware) or to render data permanently inaccessible in cases where the key is not saved or transmitted.(Citation: US-CERT Ransomware 2016)(Citation: FireEye WannaCry 2017)(Citation: US-CERT NotPetya 2017)(Citation: US-CERT SamSam 2018)

In the case of ransomware, it is typical that common user files like Office documents, PDFs, images, videos, audio, text, and source code files will be encrypted (and often renamed and/or tagged with specific file markers). Adversaries may need to first employ other behaviors, such as [File and Directory Permissions Modification](https://attack.mitre.org/techniques/T1222) or [System Shutdown/Reboot](https://attack.mitre.org/techniques/T1529), in order to unlock and/or gain access to manipulate these files.(Citation: CarbonBlack Conti July 2020) In some cases, adversaries may encrypt critical system files, disk partitions, and the MBR.(Citation: US-CERT NotPetya 2017) 

To maximize impact on the target organization, malware designed for encrypting data may have worm-like features to propagate across a network by leveraging other attack techniques like [Valid Accounts](https://attack.mitre.org/techniques/T1078), [OS Credential Dumping](https://attack.mitre.org/techniques/T1003), and [SMB/Windows Admin Shares](https://attack.mitre.org/techniques/T1021/002).(Citation: FireEye WannaCry 2017)(Citation: US-CERT NotPetya 2017) Encryption malware may also leverage [Internal Defacement](https://attack.mitre.org/techniques/T1491/001), such as changing victim wallpapers, or otherwise intimidate victims by sending ransom notes or other messages to connected printers (known as "print bombing").(Citation: NHS Digital Egregor Nov 2020)

In cloud environments, storage objects within compromised accounts may also be encrypted.(Citation: Rhino S3 Ransomware Part 1)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0040]]

**tactic**
Impact

**software ID**
[[S0595]] [[S1053]] [[S1111]] [[S0583]] [[S0576]] [[S1058]] [[S0612]] [[S0618]] [[S0389]] [[S0481]] [[S0606]] [[S0496]] [[S1068]] [[S0658]] [[S0607]] [[S0639]] [[S1073]] [[S0654]] [[S0366]] [[S0605]] [[S0341]] [[S0556]] [[S0617]] [[S0242]] [[S0554]] [[S0449]] [[S0446]] [[S0370]] [[S0575]] [[S0570]] [[S0659]] [[S0368]] [[S1033]] [[S0616]] [[S0372]] [[S0638]] [[S1070]] [[S0625]] [[S0457]] [[S1096]] [[S0140]] [[S0611]] [[S1129]] [[S0400]] [[S0640]]

**software**
BitPaymer, Akira, RobbinHood, ThiefQuest, Egregor, Babuk, DCSrv, WannaCry, DarkGate, Royal, Netwalker, ProLock, SamSam, Avaddon, XCSSET, Bad Rabbit, SynAck, Black Basta, BlackCat, KillDisk, Maze, DEATHRANSOM, MegaCortex, WastedLocker, JCry, Seth-Locker, Ryuk, Diavol, Pay2Key, Ragnar Locker, Cheerscrypt, Conti, FIVEHANDS, EKANS, Pysa, Prestige, HELLOKITTY, Cuba, REvil, AvosLocker, NotPetya, Xbash, Shamoon, Clop, LockerGoga

**platform**
[[Windows]] [[Linux]] [[macOS]] [[IaaS]]

**group ID**
[[G1015]] [[G0096]] [[G0061]] [[G0059]] [[G1024]] [[G0046]] [[G0119]] [[G0082]] [[G0092]] [[G0034]]

**group**
Akira, APT41, FIN8, Scattered Spider, Magic Hound, FIN7, Indrik Spider, TA505, APT38, Sandworm Team

**data source ID**
[[DS0017]] [[DS0009]] [[DS0033]] [[DS0010]] [[DS0022]]

**data source**
File, Command, Cloud Storage, Network Share, Process



