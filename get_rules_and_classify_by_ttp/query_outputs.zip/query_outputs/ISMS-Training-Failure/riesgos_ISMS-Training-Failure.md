---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_ISMS-Training-Failure-T1566.md]]
[[riesgos_ISMS-Training-Failure-T1486.md]]
[[riesgos_ISMS-Training-Failure-T1113.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1113 | Atomic | 1 |
| T1113 | Elastic 1 | 1 |
| T1113 | Mappings | 3 |
| T1113 | Sigma HQ 1 | 9 |
| T1113 | Sigma HQ 2 | 3 |
| T1113 | Sigma HQ 4 | 8 |
| T1113 | Sigma HQ 9 | 3 |
| T1113 | UCM Catalog 2024 Sentinel | 2 |
| T1486 | Atomic | 2 |
| T1486 | Azure Sentinel Hunting Queries | 1 |
| T1486 | Elastic 1 | 4 |
| T1486 | Mappings | 10 |
| T1486 | Sigma HQ 1 | 14 |
| T1486 | Sigma HQ 2 | 3 |
| T1486 | Sigma HQ 4 | 10 |
| T1486 | Sigma HQ 9 | 3 |
| T1486 | UCM Catalog 2024 Sentinel | 5 |
| T1566 | Azure Sentinel Hunting Queries | 2 |
| T1566 | Elastic 1 | 25 |
| T1566 | Elastic 2 | 3 |
| T1566 | Mappings | 9 |
| T1566 | Sigma HQ 1 | 13 |
| T1566 | Sigma HQ 2 | 2 |
| T1566 | Sigma HQ 4 | 10 |
| T1566 | Sigma HQ 9 | 2 |
| T1566 | UCM Catalog 2024 Sentinel | 41 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1566 | Sigma HQ 1 | file_event_win_initial_access_dll_search_order_hijacking.yml |
| T1566 | Sigma HQ 1 | proxy_download_susp_tlds_whitelist.yml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 Reported Emails - Volumetric reporte.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365- Bazarcall Campaign Monitoring.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - Palo Alto Phishing Detection.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - Phishing activity detected.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Fortinet - High Severity Events.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - McAfee ePO - Spam Email detected.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Mimecast - Binary File in Attachment.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Mimecast - Multiple Archived Attachme.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Mimecast - Threat Intelligence map to.md |
| T1566 | Sigma HQ 1 | registry_set_cve_2021_31979_cve_2021_33771_exploits.yml |
| T1566 | Sigma HQ 1 | proxy_webdav_external_execution.yml |
| T1566 | Sigma HQ 1 | proxy_download_susp_tlds_blacklist.yml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 Fusion - Qakbot C2 Callout.md |
| T1566 | Sigma HQ 1 | proc_creation_win_susp_archiver_iso_phishing.yml |
| T1566 | Sigma HQ 1 | proc_creation_win_office_onenote_susp_child_processes.yml |
| T1566 | Sigma HQ 1 | proc_creation_win_hh_susp_execution.yml |
| T1566 | Sigma HQ 1 | proc_creation_win_hh_html_help_susp_child_process.yml |
| T1566 | Sigma HQ 1 | proc_creation_macos_susp_execution_macos_script_editor.yml |
| T1566 | Sigma HQ 1 | okta_fastpass_phishing_detection.yml |
| T1566 | Sigma HQ 1 | file_event_win_webdav_tmpfile_creation.yml |
| T1566 | Sigma HQ 1 | file_event_win_cve_2021_31979_cve_2021_33771_exploits.yml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Network - Phishing link click observe.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Network - Possible Phishing with CSL .md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - O365 - Reported Mimecast link volumet.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 Reported Emails - Reported email pat.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Voicemail pdf phishing suspicion.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Office Activity - Accessed files shar.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - Cisco Umbrella - Volumetric phishing dete.md |
| T1566 | Sigma HQ 4 | proxy_download_susp_tlds_blacklist.yml |
| T1566 | Sigma HQ 4 | proc_creation_win_susp_archiver_iso_phishing.yml |
| T1566 | Sigma HQ 4 | proc_creation_win_office_onenote_susp_child_processes.yml |
| T1566 | Sigma HQ 4 | proc_creation_win_hh_susp_execution.yml |
| T1566 | Sigma HQ 4 | proc_creation_win_hh_html_help_susp_child_process.yml |
| T1566 | Sigma HQ 4 | proc_creation_macos_susp_execution_macos_script_editor.yml |
| T1566 | Sigma HQ 4 | okta_fastpass_phishing_detection.yml |
| T1566 | Sigma HQ 4 | file_event_win_initial_access_dll_search_order_hijacking.yml |
| T1566 | Sigma HQ 9 | azure-exchange-email rule disapearence.yaml |
| T1566 | Sigma HQ 9 | azure-exchange-email rule breach (on behalf).yaml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Accessed files shared by temporary external user.md |
| T1566 | Sigma HQ 2 | azure-exchange-email rule disapearence.yaml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - suspicious user email received bas.md |
| T1566 | Sigma HQ 2 | azure-exchange-email rule breach (on behalf).yaml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - Fastly PX phishing suspicious oauth reque.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - M365 - Suspicious link click observed.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - MNA (O365) - File sharing phishing suspic.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Cloud service phishing abuse suspi.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - File sharing phishing suspicion.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Google file sharing suspicion.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Multi-Function Printer phishing su.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Outbound Volumetric Mail Anomaly.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Reported Mimecast link volumetric .md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Custom - O365 - Suspicious allowed onenote documen.md |
| T1566 | Sigma HQ 4 | proxy_webdav_external_execution.yml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - O365 Reported Emails - Email Threats .md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Okta - Fast Pass phishing Detection.md |
| T1566 | Elastic 1 | initial_access_execution_via_office_addins.toml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - OKTA - Okta Fast Pass phishing Detect.md |
| T1566 | Elastic 1 | initial_access_suspicious_ms_office_child_process.toml |
| T1566 | Elastic 1 | initial_access_suspicious_mac_ms_office_child_process.toml |
| T1566 | Elastic 1 | initial_access_script_executing_powershell.toml |
| T1566 | Elastic 1 | initial_access_scripts_process_started_via_wmi.toml |
| T1566 | Elastic 1 | initial_access_okta_fastpass_phishing.toml |
| T1566 | Elastic 1 | initial_access_o365_user_reported_phish_malware.toml |
| T1566 | Elastic 1 | initial_access_microsoft_365_exchange_safelinks_disabled.toml |
| T1566 | Elastic 1 | initial_access_microsoft_365_exchange_anti_phish_rule_mod.toml |
| T1566 | Elastic 1 | initial_access_microsoft_365_exchange_anti_phish_policy_deletion.toml |
| T1566 | Elastic 1 | initial_access_external_guest_user_invite.toml |
| T1566 | Elastic 1 | initial_access_execution_remote_via_msiexec.toml |
| T1566 | Elastic 1 | initial_access_via_system_manager.toml |
| T1566 | Elastic 1 | initial_access_execution_from_inetcache.toml |
| T1566 | Elastic 1 | initial_access_evasion_suspicious_htm_file_creation.toml |
| T1566 | Elastic 1 | initial_access_consent_grant_attack_via_azure_registered_application.toml |
| T1566 | Elastic 1 | execution_suspicious_pdf_reader.toml |
| T1566 | Elastic 1 | execution_pdf_written_file.toml |
| T1566 | Elastic 1 | execution_ms_office_written_file.toml |
| T1566 | Elastic 1 | execution_initial_access_via_msc_file.toml |
| T1566 | Elastic 1 | execution_downloaded_url_file.toml |
| T1566 | Elastic 1 | execution_downloaded_shortcut_files.toml |
| T1566 | Azure Sentinel Hunting Queries | User navigation to redirected URL.yaml |
| T1566 | Azure Sentinel Hunting Queries | StarBlizzardDomainIOCsAug2022.yaml |
| T1566 | Elastic 1 | initial_access_via_explorer_suspicious_child_parent_args.toml |
| T1566 | Elastic 1 | initial_access_suspicious_ms_outlook_child_process.toml |
| T1566 | Elastic 1 | initial_access_xsl_script_execution_via_com.toml |
| T1566 | Mappings | BeyondCorpEnterprise.yaml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - ProofPointPOD - Anomalous Inbound for.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - ProofpointPOD - High risk message not.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - ProofpointPOD - Suspicious attachment.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Cyberproof - Zscaler - Phishing Domain Navigation .md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - CyberProof - Zscaler ZIA - Reputation block outbou.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - OpCanada IOC Successful Login.md |
| T1566 | Mappings | WebRisk.yaml |
| T1566 | Mappings | VirusTotal.yaml |
| T1566 | Mappings | MicrosoftAntimalwareForAzure.yaml |
| T1566 | Mappings | CloudIDS.yaml |
| T1566 | Mappings | TitanSecurityKey.yaml |
| T1566 | Mappings | AzureDNSAnalytics.yaml |
| T1566 | Elastic 2 | defense_evasion_injection_from_msoffice.toml |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - UC473 - Email - Successful Delivery of Malicious E.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Proofpoint TAP - Malware Phish.md |
| T1566 | UCM Catalog 2024 Sentinel | T1566 - Possible Phishing with CSL and Network Sessions.md |
| T1566 | Mappings | AzureDefenderForAppService.yaml |
| T1566 | Elastic 2 | defense_evasion_download_susp_extension.toml |
| T1566 | Elastic 2 | execution_settingcontent_ms_file_creation.toml |
| T1566 | Mappings | AmazonGuardDuty.yaml |
| T1566 | Sigma HQ 4 | proxy_download_susp_tlds_whitelist.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 4 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 4 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 4 | aws_ec2_disable_encryption.yml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - CyberProof - CiscoAMP - Ransomware Activity.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - Office 365  - Suspicious file renaming activity (C.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - S3 bucket suspi.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - Suspicious over.md |
| T1486 | Sigma HQ 4 | file_event_win_susp_desktop_txt.yml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - UC491 - Azure ATP - Ransomware Infection Attempt.md |
| T1486 | Sigma HQ 4 | av_ransomware.yml |
| T1486 | Mappings | SecurityCenterRecommendations.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_lockergoga_ransomware.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_conti_ransomware_commands.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 1 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 1 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 1 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 1 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 1 | av_ransomware.yml |
| T1486 | Mappings | AmazonGuardDuty.yaml |
| T1486 | Mappings | AWSCloudEndure.yaml |
| T1486 | Mappings | AWSConfig.yaml |
| T1486 | Mappings | AWSRDS.yaml |
| T1486 | Mappings | AzureBackup.yaml |
| T1486 | Mappings | AzureSentinel.yaml |
| T1486 | Mappings | Chronicle.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_wannacry.yml |
| T1486 | Atomic | T1489.md |
| T1486 | Sigma HQ 1 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_note_detected.toml |
| T1486 | Atomic | T1490.md |
| T1486 | Azure Sentinel Hunting Queries | ASR--Rule-Ransomware-triggered.yaml |
| T1486 | Elastic 1 | impact_data_encrypted_via_openssl.toml |
| T1486 | Elastic 1 | impact_microsoft_365_potential_ransomware_activity.toml |
| T1486 | Sigma HQ 2 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 1 | win_security_malware_bluesky_ransomware_files_indicators.yml |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_file_encryption.toml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Mappings | ActifioGo.yaml |
| T1486 | Mappings | CloudAppSecurity.yaml |
| T1113 | Mappings | AzureDefenderForAppService.yaml |
| T1113 | UCM Catalog 2024 Sentinel | T1113 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1113 | UCM Catalog 2024 Sentinel | T1113 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1113 | Mappings | AzureSentinel.yaml |
| T1113 | Elastic 1 | collection_posh_screen_grabber.toml |
| T1113 | Mappings | LinuxAuditdAndLogAnalytics.yaml |
| T1113 | Sigma HQ 1 | registry_set_enable_windows_recall.yml |
| T1113 | Sigma HQ 1 | image_load_dll_system_drawing_load.yml |
| T1113 | Sigma HQ 9 | win-rdp-shadow session started (native).yaml |
| T1113 | Sigma HQ 4 | registry_delete_enable_windows_recall.yml |
| T1113 | Sigma HQ 4 | proc_creation_win_reg_enable_windows_recall.yml |
| T1113 | Sigma HQ 4 | proc_creation_win_psr_capture_screenshots.yml |
| T1113 | Sigma HQ 4 | proc_creation_macos_screencapture.yml |
| T1113 | Sigma HQ 4 | posh_ps_capture_screenshots.yml |
| T1113 | Sigma HQ 4 | lnx_auditd_screencaputre_xwd.yml |
| T1113 | Sigma HQ 4 | lnx_auditd_screencapture_import.yml |
| T1113 | Sigma HQ 9 | win-rdp-shadow configuration enabled (Reg via Sysmon).yaml |
| T1113 | Sigma HQ 9 | win-rdp-shadow session started (command).yaml |
| T1113 | Sigma HQ 2 | win-rdp-shadow session started (native).yaml |
| T1113 | Sigma HQ 1 | lnx_auditd_screencapture_import.yml |
| T1113 | Sigma HQ 2 | win-rdp-shadow session started (command).yaml |
| T1113 | Sigma HQ 2 | win-rdp-shadow configuration enabled (Reg via Sysmon).yaml |
| T1113 | Sigma HQ 4 | registry_set_enable_windows_recall.yml |
| T1113 | Sigma HQ 1 | registry_delete_enable_windows_recall.yml |
| T1113 | Sigma HQ 1 | proc_creation_win_reg_enable_windows_recall.yml |
| T1113 | Sigma HQ 1 | proc_creation_win_psr_capture_screenshots.yml |
| T1113 | Sigma HQ 1 | proc_creation_macos_screencapture.yml |
| T1113 | Sigma HQ 1 | posh_ps_capture_screenshots.yml |
| T1113 | Sigma HQ 1 | lnx_auditd_screencaputre_xwd.yml |
| T1113 | Atomic | T1113.md |


