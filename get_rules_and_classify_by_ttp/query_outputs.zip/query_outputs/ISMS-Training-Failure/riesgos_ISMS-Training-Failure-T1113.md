---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_ISMS-Training-Failure.md]]

### T1113

**technique ID**
[[T1113]]

**technique**
Screen Capture

**technique url**
https://attack.mitre.org/techniques/T1113

**technique description**
Adversaries may attempt to take screen captures of the desktop to gather information over the course of an operation. Screen capturing functionality may be included as a feature of a remote access tool used in post-compromise operations. Taking a screenshot is also typically possible through native utilities or API calls, such as <code>CopyFromScreen</code>, <code>xwd</code>, or <code>screencapture</code>.(Citation: CopyFromScreen .NET)(Citation: Antiquated Mac Malware)


**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0009]]

**tactic**
Collection

**software ID**
[[S0356]] [[S1016]] [[S0438]] [[S0386]] [[S0582]] [[S0251]] [[S0088]] [[S0203]] [[S0154]] [[S0261]] [[S0398]] [[S0260]] [[S0591]] [[S0152]] [[S0344]] [[S0223]] [[S0633]] [[S0021]] [[S1065]] [[S0692]] [[S0663]] [[S0187]] [[S0644]] [[S0476]] [[S0044]] [[S0153]] [[S0330]] [[S0592]] [[S0271]] [[S0257]] [[S0456]] [[S0337]] [[S0213]] [[S0282]] [[S0115]] [[S0182]] [[S1122]] [[S0128]] [[S0062]] [[S0339]] [[S0013]] [[S0662]] [[S1063]] [[S0622]] [[S1060]] [[S0338]] [[S0086]] [[S0409]] [[S0458]] [[S0428]] [[S0332]] [[S0240]] [[S0593]] [[S0234]] [[S0454]] [[S0113]] [[S1034]] [[S1081]] [[S0143]] [[S0199]] [[S0161]] [[S1044]] [[S0017]] [[S0375]] [[S0270]] [[S0658]] [[S0148]] [[S0348]] [[S0279]] [[S0533]] [[S0184]] [[S0283]] [[S0680]] [[S0363]] [[S1050]] [[S0248]] [[S0094]] [[S0192]] [[S0681]] [[S0495]] [[S0277]] [[S0151]] [[S0198]] [[S0163]] [[S0647]] [[S0431]] [[S0167]] [[S0546]] [[S0004]] [[S1107]] [[S0098]] [[S0194]] [[S0381]] [[S0147]] [[S0629]] [[S0643]] [[S0674]] [[S1090]] [[S0023]] [[S0631]] [[S0455]] [[S0050]] [[S0275]] [[S0235]] [[S0437]] [[S0089]] [[S0331]] [[S0412]] [[S0686]] [[S0660]] [[S1059]] [[S0030]] [[S0351]] [[S0385]] [[S0667]] [[S0657]] [[S0265]] [[S0380]] [[S1087]] [[S0273]] [[S0032]] [[S0217]] [[S0379]] [[S0340]] [[S0387]] [[S0467]] [[S0090]] [[S0649]] [[S0484]] [[S0417]] [[S0216]] [[S1064]] [[S0652]]

**software**
CHOPSTICK, SLOTHFULMEDIA, NightClub, Derusbi, Cadelspy, LitePower, EvilGrab, StoneDrill, PlugX, POORAIM, Matryoshka, TinyZBot, Azorult, Metamorfo, Kazuar, Hydraq, ECCENTRICBANDWAGON, DustySky, AsyncRAT, PoetRAT, FunnyDream, Flame, metaMain, LookBack, Lizar, SILENTTRINITY, Valak, Pupy, Daserf, gh0st RAT, Ramsay, BadPatch, FinFisher, Proton, JHUHUGIT, Zeus Panda, MacSpy, XAgentOSX, BISCUIT, njRAT, RainyDay, HALFBAKED, GRIFFON, Trojan.Karagany, Carbanak, VERMIN, FruitFly, Janicab, Brute Ratel C4, Kivars, Empire, TajMahal, RemoteUtilities, Catchamas, BlackEnergy, DOGCALL, ObliqueRAT, Carberp, UPPERCUT, Aria-body, Pteranodon, StrifeWater, SharpStage, Zebrocy, Cobian RAT, SVCReady, Turian, MacMa, POWERSTATS, CrossRAT, PowerSploit, POWRUNER, Remcos, BADHATCH, Kasidet, Cobalt Strike, Clambling, HotCroissant, Rover, Bandook, Revenge RAT, Remexi, ZxShell, Ursnif, Micropsia, RedLeaves, CharmPower, ROKRAT, CosmicDuke, RDAT, Woody RAT, ZLib, Chrommme, HyperBro, KeyBoy, MarkiRAT, KEYMARBLE, T9000, Cardinal RAT, FlawedAmmyy, jRAT, TURNEDUP, Socksbot, NKAbuse, Mispadu, Prikormka, SMOKEDHAM, Agent Tesla, XCSSET, yty, InvisiMole, RogueRobin, RCSession, BLUELIGHT, QuietSieve, SHUTTERSPEED, Cannon, PcShare, RTM, Chaes, Machete, ConnectWise, Sliver, KONNI, Mafalda, NETWIRE, AppleSeed, BADNEWS, Peppy, SysUpdate, Crimson, Octopus, Attor

**platform**
[[Windows]] [[Linux]] [[macOS]]

**group ID**
[[G0049]] [[G0087]] [[G0007]] [[G0060]] [[G0047]] [[G0043]] [[G0059]] [[G0046]] [[G0035]] [[G0070]] [[G0115]] [[G1019]] [[G0091]] [[G0069]]

**group**
APT28, Gamaredon Group, Dragonfly, OilRig, BRONZE BUTLER, GOLD SOUTHFIELD, Magic Hound, Silence, FIN7, Group5, APT39, MuddyWater, MoustachedBouncer, Dark Caracal

**data source ID**
[[DS0009]] [[DS0017]]

**data source**
Command, Process



