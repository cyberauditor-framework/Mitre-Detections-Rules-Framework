---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_DEV-OPS-Customer-Separation.md]]

### T1190

**technique ID**
[[T1190]]

**technique**
Exploit Public-Facing Application

**technique url**
https://attack.mitre.org/techniques/T1190

**technique description**
Adversaries may attempt to exploit a weakness in an Internet-facing host or system to initially access a network. The weakness in the system can be a software bug, a temporary glitch, or a misconfiguration.

Exploited applications are often websites/web servers, but can also include databases (like SQL), standard services (like SMB or SSH), network device administration and management protocols (like SNMP and Smart Install), and any other system with Internet accessible open sockets.(Citation: NVD CVE-2016-6662)(Citation: CIS Multiple SMB Vulnerabilities)(Citation: US-CERT TA18-106A Network Infrastructure Devices 2018)(Citation: Cisco Blog Legacy Device Attacks)(Citation: NVD CVE-2014-7169) Depending on the flaw being exploited this may also involve [Exploitation for Defense Evasion](https://attack.mitre.org/techniques/T1211) or [Exploitation for Client Execution](https://attack.mitre.org/techniques/T1203).

If an application is hosted on cloud-based infrastructure and/or is containerized, then exploiting it may lead to compromise of the underlying instance or container. This can allow an adversary a path to access the cloud or container APIs, exploit container host access via [Escape to Host](https://attack.mitre.org/techniques/T1611), or take advantage of weak identity and access management policies.

Adversaries may also exploit edge network infrastructure and related appliances, specifically targeting devices that do not support robust host-based defenses.(Citation: Mandiant Fortinet Zero Day)(Citation: Wired Russia Cyberwar)

For websites and databases, the OWASP top 10 and CWE top 25 highlight the most common web-based vulnerabilities.(Citation: OWASP Top 10)(Citation: CWE top 25)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0001]]

**tactic**
Initial Access

**software ID**
[[S1105]] [[S0412]] [[S0623]] [[S0224]] [[S0225]] [[S0516]]

**software**
COATHANGER, SoreFang, Siloscape, ZxShell, sqlmap, Havij

**platform**
[[Windows]] [[IaaS]] [[Linux]] [[Network]] [[macOS]] [[Containers]]

**group ID**
[[G0087]] [[G0123]] [[G0135]] [[G0035]] [[G0115]] [[G0069]] [[G1009]] [[G0016]] [[G0027]] [[G1022]] [[G0094]] [[G0001]] [[G0093]] [[G0046]] [[G0108]] [[G0059]] [[G1017]] [[G0117]] [[G0004]] [[G0106]] [[G0098]] [[G1023]] [[G0007]] [[G0096]] [[G0125]] [[G0045]] [[G0034]] [[G1021]] [[G1016]] [[G1006]]

**group**
Ke3chang, GOLD SOUTHFIELD, FIN7, BlackTech, Volt Typhoon, Sandworm Team, Dragonfly, APT29, HAFNIUM, Axiom, Magic Hound, FIN13, Kimsuky, ToddyCat, APT28, BackdoorDiplomacy, APT5, Moses Staff, Rocke, APT41, Cinnamon Tempest, Threat Group-3390, Earth Lusca, menuPass, Blue Mockingbird, Volatile Cedar, GALLIUM, APT39, Fox Kitten, MuddyWater

**data source ID**
[[DS0029]] [[DS0015]]

**data source**
Network Traffic, Application Log



