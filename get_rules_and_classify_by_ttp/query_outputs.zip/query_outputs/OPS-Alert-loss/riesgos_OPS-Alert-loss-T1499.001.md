---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_OPS-Alert-loss.md]]

### T1499.001

**technique ID**
[[T1499.001]]

**technique**
OS Exhaustion Flood

**technique url**
https://attack.mitre.org/techniques/T1499/001

**technique description**
Adversaries may launch a denial of service (DoS) attack targeting an endpoints operating system (OS). A systems OS is responsible for managing the finite resources as well as preventing the entire system from being overwhelmed by excessive demands on its capacity. These attacks do not need to exhaust the actual resources on a system; the attacks may simply exhaust the limits and available resources that an OS self-imposes.

Different ways to achieve this exist, including TCP state-exhaustion attacks such as SYN floods and ACK floods.(Citation: Arbor AnnualDoSreport Jan 2018) With SYN floods, excessive amounts of SYN packets are sent, but the 3-way TCP handshake is never completed. Because each OS has a maximum number of concurrent TCP connections that it will allow, this can quickly exhaust the ability of the system to receive new requests for TCP connections, thus preventing access to any TCP service provided by the server.(Citation: Cloudflare SynFlood)

ACK floods leverage the stateful nature of the TCP protocol. A flood of ACK packets are sent to the target. This forces the OS to search its state table for a related TCP connection that has already been established. Because the ACK packets are for connections that do not exist, the OS will have to search the entire state table to confirm that no match exists. When it is necessary to do this for a large flood of packets, the computational requirements can cause the server to become sluggish and/or unresponsive, due to the work it must do to eliminate the rogue ACK packets. This greatly reduces the resources available for providing the targeted service.(Citation: Corero SYN-ACKflood)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0040]]

**tactic**
Impact

**software ID**
nan

**software**
nan

**platform**
[[Windows]] [[Linux]] [[macOS]]

**group ID**
nan

**group**
nan

**data source ID**
[[DS0029]] [[DS0013]]

**data source**
Network Traffic, Sensor Health



