---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_OPS-Alert-loss-T1499.001.md]]
[[riesgos_OPS-Alert-loss-T1133.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1133 | Atomic | 1 |
| T1133 | Azure Sentinel Hunting Queries | 1 |
| T1133 | Elastic 1 | 6 |
| T1133 | Mappings | 20 |
| T1133 | Sigma HQ 1 | 15 |
| T1133 | Sigma HQ 4 | 15 |
| T1133 | UCM Catalog 2024 Sentinel | 25 |
| T1499.001 | Mappings | 9 |
| T1499.001 | Sigma HQ 1 | 1 |
| T1499.001 | Sigma HQ 4 | 1 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1499.001 | Sigma HQ 1 | win_system_ntfs_vuln_exploit.yml |
| T1499.001 | Sigma HQ 4 | win_system_ntfs_vuln_exploit.yml |
| T1499.001 | Mappings | AmazonVirtualPrivateCloud.yaml |
| T1499.001 | Mappings | AWSConfig.yaml |
| T1499.001 | Mappings | AWSNetworkFirewall.yaml |
| T1499.001 | Mappings | AWSShield.yaml |
| T1499.001 | Mappings | AzureDDOS.yaml |
| T1499.001 | Mappings | AzurePrivateLink.yaml |
| T1499.001 | Mappings | AzureTrafficAnalytics.yaml |
| T1499.001 | Mappings | NetworkSecurityGroups.yaml |
| T1499.001 | Mappings | SecurityCenterRecommendations.yaml |
| T1133 | Sigma HQ 4 | win_security_susp_failed_logon_source.yml |
| T1133 | Sigma HQ 4 | win_security_successful_external_remote_smb_login.yml |
| T1133 | Atomic | T1056.md |
| T1133 | Sigma HQ 4 | registry_set_chrome_extension.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_susp_add_user_remote_desktop_group.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_remote_access_tools_screenconnect_installation_cli_param.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_dns_susp_child_process.yml |
| T1133 | Sigma HQ 4 | proc_creation_macos_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | proc_creation_lnx_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | opencanary_telnet_login_attempt.yml |
| T1133 | Sigma HQ 4 | opencanary_ssh_new_connection.yml |
| T1133 | Sigma HQ 4 | opencanary_ssh_login_attempt.yml |
| T1133 | Sigma HQ 4 | file_delete_win_unusual_deletion_by_dns_exe.yml |
| T1133 | Sigma HQ 4 | win_security_successful_external_remote_rdp_login.yml |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Client request from country in blockl.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Empty user agent.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Multiple error requests from single s.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC489 - Azure ATP - Unusual VPN Connection.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC1182 - OneAccount - Successful Authentication fr.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC1181 - OneAccount - Unusual sign-In activity.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - SOC - FW - Inbound Traffic on Sensitive Ports.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - OfficeActivity - Known Manganese IP and UserAgent .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - ZPA connections from ne.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Unexpected ZPA session .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Unexpected event count .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Shared ZPA session.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - BL countries.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - CiscoAMP - Malware outbreak.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - CheckPoint - Inbound Traffic on Sensi.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Azure - Anonymous IP address.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - AvosLocker Ransomware Detection.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - CTP forensics storage blob acce.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - CTP cpioc artifact storage blob.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - Anonymous storage blob access.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - XSS probing pattern in request.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Unexpected URI.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Unexpected client request.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Multiple user agents for single sourc.md |
| T1133 | Sigma HQ 4 | file_change_win_unusual_modification_by_dns_exe.yml |
| T1133 | Sigma HQ 1 | proc_creation_win_susp_add_user_remote_desktop_group.yml |
| T1133 | Sigma HQ 1 | win_security_susp_failed_logon_source.yml |
| T1133 | Mappings | AmazonVirtualPrivateCloud.yaml |
| T1133 | Mappings | CloudAppSecurity.yaml |
| T1133 | Mappings | BeyondCorpEnterprise.yaml |
| T1133 | Mappings | AzureTrafficAnalytics.yaml |
| T1133 | Mappings | AzurePolicy.yaml |
| T1133 | Mappings | AzureFirewall.yaml |
| T1133 | Mappings | AzureADIdentitySecureScore.yaml |
| T1133 | Mappings | AWSSSO.yaml |
| T1133 | Mappings | AWSNetworkFirewall.yaml |
| T1133 | Mappings | AmazonInspector.yaml |
| T1133 | Sigma HQ 1 | win_security_successful_external_remote_smb_login.yml |
| T1133 | Mappings | AlertsNetworkLayer.yaml |
| T1133 | Mappings | AdvancedProtectionProgram.yaml |
| T1133 | Elastic 1 | persistence_exposed_service_created_with_type_nodeport.toml |
| T1133 | Elastic 1 | persistence_ec2_security_group_configuration_change_detection.toml |
| T1133 | Elastic 1 | persistence_ec2_network_acl_creation.toml |
| T1133 | Elastic 1 | lateral_movement_ssh_process_launched_inside_a_container.toml |
| T1133 | Elastic 1 | initial_access_ssh_connection_established_inside_a_container.toml |
| T1133 | Elastic 1 | initial_access_first_occurrence_user_session_started_via_proxy.toml |
| T1133 | Mappings | CloudIdentity.yaml |
| T1133 | Mappings | CloudVPN.yaml |
| T1133 | Mappings | Firewalls.yaml |
| T1133 | Mappings | JustInTimeVMAccess.yaml |
| T1133 | Sigma HQ 1 | win_security_successful_external_remote_rdp_login.yml |
| T1133 | Sigma HQ 1 | registry_set_chrome_extension.yml |
| T1133 | Azure Sentinel Hunting Queries | PotentialSSHTunneltoAADConnectHost.yaml |
| T1133 | Sigma HQ 1 | proc_creation_win_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 1 | proc_creation_win_remote_access_tools_screenconnect_installation_cli_param.yml |
| T1133 | Sigma HQ 1 | proc_creation_win_dns_susp_child_process.yml |
| T1133 | Sigma HQ 1 | proc_creation_macos_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 1 | proc_creation_lnx_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 1 | opencanary_telnet_login_attempt.yml |
| T1133 | Sigma HQ 1 | opencanary_ssh_new_connection.yml |
| T1133 | Sigma HQ 1 | opencanary_ssh_login_attempt.yml |
| T1133 | Sigma HQ 1 | file_delete_win_unusual_deletion_by_dns_exe.yml |
| T1133 | Sigma HQ 1 | file_change_win_unusual_modification_by_dns_exe.yml |
| T1133 | Mappings | SecurityCenterRecommendations.yaml |
| T1133 | Mappings | SCC.yaml |
| T1133 | Mappings | NetworkSecurityGroups.yaml |
| T1133 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC980 - Netscaler - Failed Password brute force.md |


