---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_Compromise-Wide-T1485.md]]
[[riesgos_Compromise-Wide-T1078.md]]
[[riesgos_Compromise-Wide-T1059.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1059 | Atomic | 10 |
| T1059 | Azure Sentinel Hunting Queries | 3 |
| T1059 | Elastic 1 | 131 |
| T1059 | Elastic 2 | 8 |
| T1059 | Mappings | 9 |
| T1059 | Netevert sentinel-attack | 1 |
| T1059 | Sigma HQ 1 | 77 |
| T1059 | Sigma HQ 4 | 65 |
| T1059 | UCM Catalog 2024 Qradar | 3 |
| T1059 | UCM Catalog 2024 Sentinel | 49 |
| T1078 | Atomic | 10 |
| T1078 | Azure Sentinel Hunting Queries | 39 |
| T1078 | Elastic 1 | 52 |
| T1078 | Elastic 2 | 5 |
| T1078 | Mappings | 39 |
| T1078 | Sigma HQ 1 | 56 |
| T1078 | Sigma HQ 2 | 7 |
| T1078 | Sigma HQ 4 | 50 |
| T1078 | Sigma HQ 7 | 1 |
| T1078 | Sigma HQ 9 | 7 |
| T1078 | UCM Catalog 2024 Qradar | 13 |
| T1078 | UCM Catalog 2024 Sentinel | 220 |
| T1078 | UCM Catalog 2024 Splunk | 1 |
| T1485 | Atomic | 3 |
| T1485 | Azure Sentinel Hunting Queries | 3 |
| T1485 | Elastic 1 | 18 |
| T1485 | Mappings | 13 |
| T1485 | Sigma HQ 1 | 12 |
| T1485 | Sigma HQ 4 | 11 |
| T1485 | UCM Catalog 2024 Qradar | 1 |
| T1485 | UCM Catalog 2024 Sentinel | 20 |
| T1485 | UCM Catalog 2024 Splunk | 1 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1485 | UCM Catalog 2024 Splunk | T1485 - CyberProof - All - Logs Not Being Indexed.md |
| T1485 | Mappings | AWSCloudEndure.yaml |
| T1485 | Elastic 1 | impact_ec2_disable_ebs_encryption.toml |
| T1485 | Elastic 1 | impact_deleting_backup_catalogs_with_wbadmin.toml |
| T1485 | Elastic 1 | impact_cloudwatch_log_stream_deletion.toml |
| T1485 | Elastic 1 | impact_cloudwatch_log_group_deletion.toml |
| T1485 | Elastic 1 | impact_backup_file_deletion.toml |
| T1485 | Elastic 1 | defense_evasion_sdelete_like_filename_rename.toml |
| T1485 | UCM Catalog 2024 Qradar | T1485 - [CyberProof] - [Global] - Single Host Deleted Mult.md |
| T1485 | Mappings | ActifioGo.yaml |
| T1485 | Mappings | AmazonGuardDuty.yaml |
| T1485 | Mappings | AWSConfig.yaml |
| T1485 | Azure Sentinel Hunting Queries | AzureStorageMassDeletion.yaml |
| T1485 | Mappings | AWSRDS.yaml |
| T1485 | Mappings | AWSS3.yaml |
| T1485 | Mappings | AWSSecurityHub.yaml |
| T1485 | Mappings | AzureBackup.yaml |
| T1485 | Mappings | AzureDefenderForStorage.yaml |
| T1485 | Mappings | AzurePolicy.yaml |
| T1485 | Mappings | AzureSentinel.yaml |
| T1485 | Mappings | CloudAppSecurity.yaml |
| T1485 | Mappings | SecurityCenterRecommendations.yaml |
| T1485 | Elastic 1 | impact_efs_filesystem_or_mount_deleted.toml |
| T1485 | Elastic 1 | impact_github_repository_deleted.toml |
| T1485 | Elastic 1 | impact_high_freq_file_renames_by_kernel.toml |
| T1485 | Elastic 1 | impact_iam_deactivate_mfa_device.toml |
| T1485 | Sigma HQ 4 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_fsutil_usage.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Sigma HQ 4 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | Sigma HQ 4 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Sigma HQ 4 | lnx_auditd_dd_delete_file.yml |
| T1485 | Sigma HQ 4 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 4 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 4 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | Elastic 1 | impact_s3_bucket_object_uploaded_with_ransom_extension.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_stoppage.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_deletion.toml |
| T1485 | Elastic 1 | impact_rds_group_deletion.toml |
| T1485 | Elastic 1 | impact_ransomware_note_file_over_smb.toml |
| T1485 | Elastic 1 | impact_ransomware_file_rename_smb.toml |
| T1485 | Elastic 1 | impact_microsoft_365_unusual_volume_of_file_deletion.toml |
| T1485 | Elastic 1 | impact_kms_cmk_disabled_or_scheduled_for_deletion.toml |
| T1485 | Azure Sentinel Hunting Queries | Mass Deletion of Repositories .yaml |
| T1485 | Azure Sentinel Hunting Queries | User First Time Repository Delete Activity.yaml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - CyberArk - Safe Deletion.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Storage - Azure Storage Mass Fi.md |
| T1485 | Sigma HQ 1 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_malware_blackbyte_ransomware.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_fsutil_usage.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Sigma HQ 1 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | Sigma HQ 1 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Sigma HQ 1 | lnx_auditd_dd_delete_file.yml |
| T1485 | Sigma HQ 1 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 1 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 1 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - Sensitive Azure Key.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - NRT Sensitive Azure.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Backup Services - Anomalous Bac.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Activity - Mass Cloud resource .md |
| T1485 | Atomic | T1485.md |
| T1485 | Atomic | T1489.md |
| T1485 | Atomic | T1490.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - ALPHV BlackCat Ransomware Detection.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Azure Managed Services - Mass resource deletions b.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure SQL Databases - Affected rows s.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - AV detections related to Ukraine threats.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Multiple Teams deleted by a single user.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Office Activity - Multiple Teams dele.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Sophos EDR - Detect Malware Outbreak..md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Threat Essentials - Mass Cloud resour.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Mass Cloud resource deletions Time Series Anomaly.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - TEST CyberProof - AWS CloudTrail - Creating keys w.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - NRT Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Potential re-named sdelete usage.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sdelete deployed via GPO and run recursively.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [ADFS] - Federation Settings Change.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [AD] - Service Account Locked Out.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Cisco ASA] - Login to SSH Interfac.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Entra ID] - Federation Settings Ch.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Entra ID] - Impossible Travel - En.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Application .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Anomalous lo.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - Sensitive User password.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Entra ID] - Impossible Travel - Pa.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - Interactive Use Of Serv.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - Power User Logged in Af.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - RDP Sessions by Service.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - Same user login from mu.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - Sensitive User Locked O.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - At risk accounts - Henry Schein invol.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure - Anonymous IP address.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Admin promot.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - AWS - Failed AWS Console logons but s.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Changes to Amazon VPC settings.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Cisco - firewall block but success logon to Azure .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Correlate Unfamiliar sign-in properties & atypical.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Correlate Unfamiliar sign-in properties and atypic.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Cross-tenant Access Settings Organization Added.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Cross-tenant Access Settings Organization Deleted.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Cross-tenant Access Settings Organization Inbound .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Cross-tenant Access Settings Organization Outbound.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Custom - Azure - User MFA fraud reported.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof -  Microsoft Entra ID - Microsoft Entra.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Active Directory + CyberArk - User ac.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Active Directory - User account added.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Active Directory - User account creat.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Active Directory - User account enabl.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Active Directory - User Added to Admi.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Bulk Changes to Privileged Account Permissions.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - AWS - Root Credentials.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Account Crea.md |
| T1078 | Sigma HQ 9 | win-os-OpenSSH success login.yaml |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure - User MFA fraud reported.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure - Connections From Russia - Suc.md |
| T1078 | UCM Catalog 2024 Qradar | T1078 - [CyberProof] - [Windows] - User Added to Sensitive.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - ActiveDirectory - Group created then .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Account added and removed from privileged groups.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Account Created and Deleted in Short Timeframe.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Account created or deleted by non-approved user.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - AWS -Failed AzureAD logons but succes.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Account Elevated to New Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Admin promotion after Role Management Application .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Anomalous sign-in location by user account and aut.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Attempt to bypass conditional access rule in Azure.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Attempt to bypass conditional access rule in Micro.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Attempts to sign in to disabled accounts.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - BEC - Account Elevated to New Role.md |
| T1078 | Sigma HQ 9 | win-rdp-reconnaissance with valid credentials performed to multiple hosts.yaml |
| T1078 | Sigma HQ 4 | opencanary_ssh_login_attempt.yml |
| T1078 | Sigma HQ 9 | win-os-login via Azure serial console.yaml |
| T1078 | Sigma HQ 9 | win-os-login authenticated on multiple hosts.yaml |
| T1078 | Sigma HQ 4 | azure_ad_auth_sucess_increase.yml |
| T1078 | Sigma HQ 4 | azure_ad_auth_to_important_apps_using_single_factor_auth.yml |
| T1078 | Sigma HQ 4 | azure_ad_guest_users_invited_to_tenant_by_non_approved_inviters.yml |
| T1078 | Sigma HQ 4 | azure_ad_risky_sign_ins_with_singlefactorauth_from_unknown_devices.yml |
| T1078 | Sigma HQ 4 | azure_ad_user_added_to_admin_role.yml |
| T1078 | Sigma HQ 4 | azure_app_device_code_authentication.yml |
| T1078 | Sigma HQ 4 | azure_app_ropc_authentication.yml |
| T1078 | Sigma HQ 4 | azure_federation_modified.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_anonymous_ip_activity.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_atypical_travel.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_impossible_travel.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_new_coutry_region.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_suspicious_browser.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_threat_intel.yml |
| T1078 | Sigma HQ 4 | azure_identity_protection_unfamilar_sign_in.yml |
| T1078 | Sigma HQ 4 | azure_ad_auth_failure_increase.yml |
| T1078 | Sigma HQ 4 | azure_ad_account_created_deleted.yml |
| T1078 | Sigma HQ 4 | aws_susp_saml_activity.yml |
| T1078 | Sigma HQ 1 | win_security_user_added_to_local_administrators.yml |
| T1078 | Sigma HQ 1 | win_security_successful_external_remote_smb_login.yml |
| T1078 | Sigma HQ 1 | win_security_susp_computer_name.yml |
| T1078 | Sigma HQ 1 | win_security_susp_failed_logon_reasons.yml |
| T1078 | Sigma HQ 1 | win_security_susp_failed_logon_source.yml |
| T1078 | Sigma HQ 1 | win_security_susp_interactive_logons.yml |
| T1078 | Sigma HQ 1 | win_security_susp_logon_explicit_credentials.yml |
| T1078 | Atomic | T1077.md |
| T1078 | Sigma HQ 2 | win-rdp-reconnaissance with valid credentials performed to multiple hosts.yaml |
| T1078 | Sigma HQ 2 | sql_server-failed login with disabled user.yaml |
| T1078 | Sigma HQ 2 | win-os-brutforce with denied access due to account restrictions.yaml |
| T1078 | Sigma HQ 2 | win-os-lateral movement detection (special groups).yaml |
| T1078 | Sigma HQ 2 | win-os-login authenticated on multiple hosts.yaml |
| T1078 | Sigma HQ 2 | win-os-login via Azure serial console.yaml |
| T1078 | Sigma HQ 2 | win-os-OpenSSH success login.yaml |
| T1078 | Sigma HQ 4 | azure_kubernetes_admission_controller.yml |
| T1078 | Sigma HQ 4 | azure_pim_account_stale.yml |
| T1078 | Sigma HQ 4 | azure_pim_alerts_disabled.yml |
| T1078 | Sigma HQ 4 | win_security_susp_failed_logon_reasons.yml |
| T1078 | Sigma HQ 4 | proc_creation_macos_dsenableroot_enable_root_account.yml |
| T1078 | Sigma HQ 4 | proc_creation_macos_sysadminctl_enable_guest_account.yml |
| T1078 | Sigma HQ 4 | proc_creation_win_net_use_password_plaintext.yml |
| T1078 | Sigma HQ 4 | win_security_successful_external_remote_rdp_login.yml |
| T1078 | Sigma HQ 4 | win_security_successful_external_remote_smb_login.yml |
| T1078 | Sigma HQ 4 | win_security_susp_computer_name.yml |
| T1078 | Sigma HQ 4 | win_security_susp_failed_logon_source.yml |
| T1078 | Sigma HQ 4 | opencanary_telnet_login_attempt.yml |
| T1078 | Sigma HQ 4 | win_security_susp_logon_explicit_credentials.yml |
| T1078 | Sigma HQ 4 | win_security_user_added_to_local_administrators.yml |
| T1078 | Sigma HQ 7 | win_user_added_to_local_administration.md |
| T1078 | Sigma HQ 9 | sql_server-failed login with disabled user.yaml |
| T1078 | Sigma HQ 9 | win-os-brutforce with denied access due to account restrictions.yaml |
| T1078 | Sigma HQ 9 | win-os-lateral movement detection (special groups).yaml |
| T1078 | Sigma HQ 4 | posh_pm_susp_reset_computermachinepassword.yml |
| T1078 | Sigma HQ 4 | opencanary_ssh_new_connection.yml |
| T1078 | Sigma HQ 4 | azure_pim_invalid_license.yml |
| T1078 | Sigma HQ 4 | azure_unusual_authentication_interruption.yml |
| T1078 | Sigma HQ 4 | azure_pim_role_assigned_outside_of_pim.yml |
| T1078 | Sigma HQ 4 | azure_pim_role_frequent_activation.yml |
| T1078 | Sigma HQ 4 | azure_pim_role_not_used.yml |
| T1078 | Sigma HQ 4 | azure_pim_role_no_mfa_required.yml |
| T1078 | Sigma HQ 4 | azure_pim_too_many_global_admins.yml |
| T1078 | Sigma HQ 4 | azure_subscription_permissions_elevation_via_auditlogs.yml |
| T1078 | Sigma HQ 4 | cisco_bgp_md5_auth_failed.yml |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Bulk Changes.md |
| T1078 | Sigma HQ 4 | cisco_ldp_md5_auth_failed.yml |
| T1078 | Sigma HQ 4 | gcp_kubernetes_admission_controller.yml |
| T1078 | Sigma HQ 4 | huawei_bgp_auth_failed.yml |
| T1078 | Sigma HQ 4 | juniper_bgp_missing_md5.yml |
| T1078 | Sigma HQ 4 | microsoft365_impossible_travel_activity.yml |
| T1078 | Sigma HQ 4 | microsoft365_logon_from_risky_ip_address.yml |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Attempts to .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - NRT PIM Elev.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Cisco - fire.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Microsoft Entra ID Role Management Permission Gran.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Multiple - Failed host logons but success logon to.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Multiple Password Reset by user.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - New PA, PCA, or PCAS added to Azure DevOps.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - New User Assigned to Privileged Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - NRT Malicious Inbox Rule.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - NRT MFA Rejected by User.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - NRT PIM Elevation Request Rejected.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - NRT Privileged Role Assigned Outside PIM.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - NRT User added to Microsoft Entra ID Privileged Gr.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Office 365 - Same User Shared Multiple Files Anony.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - PIM Elevation Request Rejected.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Possible AiTM Phishing Attempt Against Microsoft E.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Privileged Account Permissions Changed.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Privileged Accounts - Sign in Failure Spikes.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Privileged Role Assigned Outside PIM.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - ProofpointPOD - Email sender in TI list.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - ProofpointPOD - Email sender IP in TI list.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SecurityEvent - Account added and removed from pri.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SecurityEvent - Group added to built in domain loc.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Multiple - Failed AzureAD logons but success logon.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Microsoft Entra ID PowerShell accessing non-Entra .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SecurityEvent - User account added to built in dom.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - MFA Rejected by User.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZPA - Unexpected ZPA session .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZPA - ZPA connections from ne.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof – Azure Active Directory - Detected Ris.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof – Microsoft Entra ID - Detected Risky U.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - External guest invitation followed by Microsoft En.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Failed AWS Console logons but success logon to Azu.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Failed AzureAD logons but success logon to AWS Con.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Failed AzureAD logons but success logon to host.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - An enterprise admin is added removed.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - Deletion of an organization.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - Single sign on is disabled (enterprise).md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - Single sign on is disabled (org).md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - Two factor authentication is disabled (en.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - Two factor authentication is disabled (or.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Github - User promoted to org admin.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Guest accounts added in Entra ID Groups other than.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Login to AWS Management Console without MFA.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Malicious BEC Inbox Rule.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Malicious Inbox Rule.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SecurityEvent - New user created and added to the .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SecurityEvent - User account created and deleted w.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Conditional .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC291 - Windows - Local Account Created.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC452 - Windows - Local Account Deleted.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC465 - Windows - Successful Connection from Inact.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC564 - Oracle - Account Created And Deleted Withi.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC565 - SQL - Account Created And Deleted Within 2.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC568 - SQL - Audit Policy Disabled.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC632 - SAP HANA - Account Created And Deleted Wit.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC976 - Account Created and Deleted in Short Timef.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC981 - Netscaler - Successful login from known ba.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC982 - Netscaler - Failed login attempts for a lo.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC988 - AWS - Root Credentials Usage Detected.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User account created and deleted within 10 mins.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User account enabled and disabled within 10 mins.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User Accounts - Sign in Failure due to CA Spikes.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User Added to Admin Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User added to Microsoft Entra ID Privileged Groups.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User Assigned New Privileged Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - User Login from Different Countries within 3 hours.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Workspace deletion attempt from an infected device.md |
| T1078 | UCM Catalog 2024 Splunk | T1078 - CyberProof - WinEventLog - Active Directory Disabl.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC385 - AD - Brute Force Logon Attempt on PKI Serv.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC2 - Windows - Interactive Logon with Service Acc.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Sign-ins from IPs that attempt sign-ins to disable.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC19 - Windows - Account Added to Security-Enabled.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SigninLogs - Anomalous sign-in location by user ac.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SigninLogs - Attempts to sign in to disabled accou.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SigninLogs - Sign-ins from IPs that attempt sign-i.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SigninLogs - Successful logon from IP and failure .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - SOC - Logstash - Syslog - New internet-exposed SSH.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Successful logon from IP and failure from a differ.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Suspicious Service Principal creation activity.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Suspicious Sign In Followed by MFA Modification.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Syslog - SSH newly internet-exposed endpoints.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - TEST CyberProof - AWS CloudTrail - Changes to Amaz.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - TEST CyberProof - AWS CloudTrail - NRT Login to AW.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - TEST CyberProof - AWS CloudTrail - Policy version .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - TEST CyberProof - AWS CloudTrail - SAML update ide.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - Threat Essentials - NRT User added to Microsoft En.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC1181 - OneAccount - Unusual sign-In activity.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC1182 - OneAccount - Successful Authentication fr.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC1183 - OneAccount - Unexpected change to One Acc.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC17 - AD - Group Created by non-Security Admin.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - UC18 - AD - Group Deleted by non-Security Admin.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZPA - Unexpected event count .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZPA - Shared ZPA session.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZPA - New ZPA connection.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - BEC - Malicious BEC Inbox Rule.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - BEC - User Added to Admin Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Cisco ASA - User Account Modification.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - CyberArk - FETTJA Account Usage.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - CyberArk - Monitoring session has bee.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - CyberArk - Station Time Limits.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - CyberArk - Usage of Disabled or Expir.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - CyberArk - User Time Limit Restrictio.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - EventID 4776 - The domain controller .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - FortiGate - Failed Admin Login.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Account created .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Admin promotion .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Anomalous login .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Anomalous sign-i.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Application ID U.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Application Redi.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Attempt to bypas.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Attempts to sign.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Bulk Changes to .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Conditional Acce.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - BEC - Privileged Account Permissions .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Backup Services - Policy Delete.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Zscaler ZIA - Multiple outbound conne.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Backup Services - Excessive Vau.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Correlate Un.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Detect PIM A.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Detected Ris.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Detecting Im.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - External gue.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Failed Azure.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Failed host .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - IP with mult.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Multiple Pas.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - New User Ass.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - NRT - MFA Re.md |
| T1078 | Sigma HQ 1 | proc_creation_win_net_use_password_plaintext.yml |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Privileged A.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Sign-ins fro.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Suspicious L.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - Suspicious S.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Active Directory - User Account.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Activity - Workspace deletion a.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Azure Backup Services - Config change.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - External guest i.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Failed AzureAD l.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Failed host logo.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - IP with multiple.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - User Removed from cloud-platfo.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - User Success Login From TOR Ex.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Palo Alto - IP with multiple failed A.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - PCI - Windows Security Events - Exces.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - PIM - Changes to PIM Settings.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - ProofpointPOD - Possible data exfiltr.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Risky account detections - Henry Sche.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - RSASecurID - Source IP coming from em.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - RSASecurID - TI map IP entity to RSAS.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - SQL - Audit Policy Changes - Failure .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - SQL - Audit Policy Changes - Success .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - SQL - Failed Logon Attempts on SQL Se.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Threat Essentials - Possible AiTM Phi.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Threat Essentials - User Assigned Pri.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Windows Security Event - Account Adde.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Windows Security Event - Multiple Pas.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Windows Security Event - User account.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Windows Security Events - Excessive U.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Windows Security Events - Multiple Pa.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - User Login from Different Coun.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - User Login from 3 Different Co.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - Spray Same User Multiple IP.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Multiple -  Multiple Password Reset b.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Microsoft Entra .md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - New User Assigne.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - NRT Privileged R.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - NRT User added t.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - PIM - Changes to.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Successful logon.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - Suspicious Servi.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Microsoft Entra ID - User MFA fraud r.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Nutanix - Failed login attempt to Nut.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - Sensitive User Login To Okta.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Nutanix - Failed login attempt to the.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Office Activity - Malicious Inbox Rul.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Office Activity - NRT Malicious Inbox.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Office Activity - NRT Privileged Role.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA -  Login from blacklisted countr.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - Admin Log In During Non-Busine.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - OKTA - Admin privilege granted.md |
| T1078 | UCM Catalog 2024 Sentinel | T1078 - CyberProof - Okta - New Device Location sign-in al.md |
| T1078 | Sigma HQ 1 | win_security_successful_external_remote_rdp_login.yml |
| T1078 | Atomic | T1056.md |
| T1078 | Sigma HQ 1 | proc_creation_macos_sysadminctl_enable_guest_account.yml |
| T1078 | Azure Sentinel Hunting Queries | UserGrantedAccess_CreatesResources.yaml |
| T1078 | Azure Sentinel Hunting Queries | riskSignInWithDeviceRegistration.yaml |
| T1078 | Azure Sentinel Hunting Queries | SpikeInFailedSignInAttempts.yaml |
| T1078 | Azure Sentinel Hunting Queries | SQLAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1078 | Azure Sentinel Hunting Queries | StorageAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1078 | Azure Sentinel Hunting Queries | SuccessfulAccount-SigninAttemptsByIPviaDisabledAccounts.yaml |
| T1078 | Azure Sentinel Hunting Queries | TrackingPasswordChanges.yaml |
| T1078 | Azure Sentinel Hunting Queries | TrackingPrivAccounts.yaml |
| T1078 | Azure Sentinel Hunting Queries | UnauthUser_AzurePortal.yaml |
| T1078 | Azure Sentinel Hunting Queries | UnfamiliarsignincorrelationwithPortalSigninandAuditlogs.yaml |
| T1078 | Azure Sentinel Hunting Queries | User Grant Access and Grants Other Access.yaml |
| T1078 | Azure Sentinel Hunting Queries | UserAccounts-BlockedAccounts.yaml |
| T1078 | Azure Sentinel Hunting Queries | UserAccountsMeasurableincreaseofsuccessfulsignins.yaml |
| T1078 | Azure Sentinel Hunting Queries | UserGrantedAccess_AllAuditActivity.yaml |
| T1078 | Azure Sentinel Hunting Queries | UsersAuthenticatingtoOtherAzureADTenants.yaml |
| T1078 | Elastic 1 | initial_access_gcp_iam_custom_role_creation.toml |
| T1078 | Elastic 1 | credential_access_dcsync_newterm_subjectuser.toml |
| T1078 | Elastic 1 | credential_access_dcsync_replication_rights.toml |
| T1078 | Elastic 1 | credential_access_disable_kerberos_preauth.toml |
| T1078 | Elastic 1 | credential_access_ldap_attributes.toml |
| T1078 | Elastic 1 | credential_access_ml_auth_spike_in_logon_events_from_a_source_ip.toml |
| T1078 | Elastic 1 | defense_evasion_escalation_aws_suspicious_saml_activity.toml |
| T1078 | Elastic 1 | defense_evasion_google_workspace_new_oauth_login_from_third_party_application.toml |
| T1078 | Elastic 1 | defense_evasion_suspicious_okta_user_password_reset_or_unlock_attempts.toml |
| T1078 | Elastic 1 | discovery_command_system_account.toml |
| T1078 | Elastic 1 | initial_access_azure_active_directory_high_risk_signin.toml |
| T1078 | Elastic 1 | initial_access_azure_active_directory_high_risk_signin_atrisk_or_confirmed.toml |
| T1078 | Elastic 1 | initial_access_azure_active_directory_powershell_signin.toml |
| T1078 | Elastic 1 | initial_access_console_login_root.toml |
| T1078 | Azure Sentinel Hunting Queries | RIDHijacking.yaml |
| T1078 | Azure Sentinel Hunting Queries | ReconActivitywithInteractiveLogonCorrelation.yaml |
| T1078 | Azure Sentinel Hunting Queries | PrivilegedAccountsLockedOut.yaml |
| T1078 | Azure Sentinel Hunting Queries | PrivilegedAccountPasswordChanges.yaml |
| T1078 | Azure Sentinel Hunting Queries | MFASpamming.yaml |
| T1078 | Azure Sentinel Hunting Queries | MFAUserBlocked.yaml |
| T1078 | Azure Sentinel Hunting Queries | MultipleRegistrationDenies.yaml |
| T1078 | Azure Sentinel Hunting Queries | NewTZ.yaml |
| T1078 | Azure Sentinel Hunting Queries | NonCompliantSigninwithBulkDownload.yaml |
| T1078 | Azure Sentinel Hunting Queries | NonredeemedGuesUserInvites.yaml |
| T1078 | Mappings | VPCServiceControls.yaml |
| T1078 | Mappings | SQLVulnerabilityAssessment.yaml |
| T1078 | Mappings | SecurityCenterRecommendations.yaml |
| T1078 | Mappings | SCC.yaml |
| T1078 | Mappings | ResourceManager.yaml |
| T1078 | Mappings | ReCAPTCHAEnterprise.yaml |
| T1078 | Mappings | PrivilegedIdentityManagement.yaml |
| T1078 | Mappings | PolicyIntelligence.yaml |
| T1078 | Mappings | IdentyAccessManagement.yaml |
| T1078 | Mappings | IdentityProtection.yaml |
| T1078 | Mappings | IdentityPlatform.yaml |
| T1078 | Mappings | IdentityAwareProxy.yaml |
| T1078 | Mappings | EndpointManagement.yaml |
| T1078 | Mappings | ContinuousAccessEvaluation.yaml |
| T1078 | Mappings | ContainerRegistry.yaml |
| T1078 | Mappings | ConditionalAccess.yaml |
| T1078 | Mappings | CloudIdentity.yaml |
| T1078 | Mappings | CloudAssetInventory.yaml |
| T1078 | Mappings | CloudAppSecurity.yaml |
| T1078 | Mappings | Chronicle.yaml |
| T1078 | Mappings | AzureSentinel.yaml |
| T1078 | Elastic 1 | initial_access_external_user_added_to_google_workspace_group.toml |
| T1078 | Elastic 1 | initial_access_google_workspace_suspended_user_renewed.toml |
| T1078 | Azure Sentinel Hunting Queries | LowAndSlowPasswordAttempt.yaml |
| T1078 | Elastic 1 | privilege_escalation_cyberarkpas_recommended_events_to_monitor_promotion.toml |
| T1078 | Mappings | AWSSecurityHub.yaml |
| T1078 | Mappings | AWSOrganizations.yaml |
| T1078 | Mappings | AWSIOTDeviceDefender.yaml |
| T1078 | Mappings | AWSIAM.yaml |
| T1078 | Mappings | AWSConfig.yaml |
| T1078 | Mappings | ATPForAzureSQLDatabase.yaml |
| T1078 | Mappings | AnthosConfigManagement.yaml |
| T1078 | Mappings | AmazonGuardDuty.yaml |
| T1078 | Mappings | AmazonCognito.yaml |
| T1078 | Mappings | AlertsForWindowsMachines.yaml |
| T1078 | Mappings | AlertsForAzureCosmosDB.yaml |
| T1078 | Mappings | AdvancedProtectionProgram.yaml |
| T1078 | Elastic 1 | privilege_escalation_cyberarkpas_error_audit_event_promotion.toml |
| T1078 | Elastic 1 | privilege_escalation_explicit_creds_via_scripting.toml |
| T1078 | Elastic 1 | initial_access_login_failures.toml |
| T1078 | Elastic 1 | privilege_escalation_local_user_added_to_admin.toml |
| T1078 | Elastic 1 | privilege_escalation_root_login_without_mfa.toml |
| T1078 | Elastic 1 | privilege_escalation_samaccountname_spoofing_attack.toml |
| T1078 | Elastic 1 | privilege_escalation_sda_disk_mount_non_root.toml |
| T1078 | Elastic 1 | privilege_escalation_suspicious_assignment_of_controller_service_account.toml |
| T1078 | Elastic 2 | persistence_aws_iam_login_profile_added_to_user.toml |
| T1078 | Elastic 2 | initial_access_github_new_user_agent_for_user.toml |
| T1078 | Elastic 2 | initial_access_github_new_user_agent_for_pat.toml |
| T1078 | Elastic 2 | initial_access_github_new_ip_address_for_user.toml |
| T1078 | Elastic 2 | initial_access_github_new_ip_address_for_pat.toml |
| T1078 | Elastic 1 | privilege_escalation_suspicious_dnshostname_update.toml |
| T1078 | Elastic 1 | privilege_escalation_updateassumerolepolicy.toml |
| T1078 | Sigma HQ 1 | proc_creation_macos_dsenableroot_enable_root_account.yml |
| T1078 | Mappings | AWSSSO.yaml |
| T1078 | Mappings | AzureADIdentitySecureScore.yaml |
| T1078 | Mappings | AzureADMultiFactorAuthentication.yaml |
| T1078 | Mappings | AzureADRoleBasedAccessControl.yaml |
| T1078 | Elastic 1 | initial_access_login_location.toml |
| T1078 | Elastic 1 | initial_access_login_sessions.toml |
| T1078 | Elastic 1 | initial_access_login_time.toml |
| T1078 | Elastic 1 | initial_access_microsoft_365_abnormal_clientappid.toml |
| T1078 | Elastic 1 | initial_access_microsoft_365_impossible_travel_activity.toml |
| T1078 | Elastic 1 | initial_access_microsoft_365_user_restricted_from_sending_email.toml |
| T1078 | Elastic 1 | initial_access_ml_auth_rare_hour_for_a_user_to_logon.toml |
| T1078 | Elastic 1 | initial_access_ml_auth_rare_source_ip_for_a_user.toml |
| T1078 | Elastic 1 | initial_access_ml_auth_rare_user_logon.toml |
| T1078 | Elastic 1 | initial_access_ml_linux_anomalous_user_name.toml |
| T1078 | Elastic 1 | initial_access_ml_windows_anomalous_user_name.toml |
| T1078 | Elastic 1 | initial_access_ml_windows_rare_user_type10_remote_login.toml |
| T1078 | Elastic 1 | initial_access_okta_user_attempted_unauthorized_access.toml |
| T1078 | Elastic 1 | initial_access_okta_user_sessions_started_from_different_geolocations.toml |
| T1078 | Elastic 1 | initial_access_password_recovery.toml |
| T1078 | Elastic 1 | initial_access_suspicious_activity_reported_by_okta_user.toml |
| T1078 | Elastic 1 | lateral_movement_mount_hidden_or_webdav_share_net.toml |
| T1078 | Elastic 1 | persistence_account_creation_hide_at_logon.toml |
| T1078 | Elastic 1 | persistence_ad_adminsdholder.toml |
| T1078 | Elastic 1 | persistence_azure_automation_account_created.toml |
| T1078 | Elastic 1 | persistence_azure_privileged_identity_management_role_modified.toml |
| T1078 | Elastic 1 | persistence_enable_root_account.toml |
| T1078 | Elastic 1 | persistence_gcp_iam_service_account_key_deletion.toml |
| T1078 | Elastic 1 | persistence_sdprop_exclusion_dsheuristics.toml |
| T1078 | Elastic 1 | privilege_escalation_applescript_with_admin_privs.toml |
| T1078 | Mappings | AzurePolicy.yaml |
| T1078 | Mappings | AzureDefenderForStorage.yaml |
| T1078 | Azure Sentinel Hunting Queries | MailForwardingActivityFromNewLocation.yaml |
| T1078 | Azure Sentinel Hunting Queries | SmartLockouts.yaml |
| T1078 | Azure Sentinel Hunting Queries | LogonwithExpiredAccount.yaml |
| T1078 | Sigma HQ 1 | opencanary_telnet_login_attempt.yml |
| T1078 | Sigma HQ 1 | azure_subscription_permissions_elevation_via_auditlogs.yml |
| T1078 | Sigma HQ 1 | azure_unusual_authentication_interruption.yml |
| T1078 | Sigma HQ 1 | cisco_bgp_md5_auth_failed.yml |
| T1078 | Sigma HQ 1 | cisco_ldp_md5_auth_failed.yml |
| T1078 | Sigma HQ 1 | gcp_kubernetes_admission_controller.yml |
| T1078 | Sigma HQ 1 | huawei_bgp_auth_failed.yml |
| T1078 | Azure Sentinel Hunting Queries | InactiveAccounts.yaml |
| T1078 | Azure Sentinel Hunting Queries | CriticalOperationsWithSystemrestore.yaml |
| T1078 | Azure Sentinel Hunting Queries | AnomolousSignInsBasedonTime.yaml |
| T1078 | Azure Sentinel Hunting Queries | anomalous_app_azuread_signin.yaml |
| T1078 | Azure Sentinel Hunting Queries | AnomalousUserAppSigninLocationIncreaseDetail.yaml |
| T1078 | Sigma HQ 1 | opencanary_ssh_new_connection.yml |
| T1078 | Sigma HQ 1 | opencanary_ssh_login_attempt.yml |
| T1078 | Sigma HQ 1 | microsoft365_logon_from_risky_ip_address.yml |
| T1078 | Sigma HQ 1 | microsoft365_impossible_travel_activity.yml |
| T1078 | Sigma HQ 1 | juniper_bgp_missing_md5.yml |
| T1078 | Atomic | T1112.md |
| T1078 | Atomic | T1485.md |
| T1078 | Atomic | win_admin_rdp_login.md |
| T1078 | Atomic | win_alert_active_directory_user_control.md |
| T1078 | Atomic | win_susp_failed_logons_single_source.md |
| T1078 | Atomic | win_susp_failed_logon_reasons.md |
| T1078 | Atomic | win_susp_interactive_logons.md |
| T1078 | Atomic | win_user_added_to_local_administrators.md |
| T1078 | Azure Sentinel Hunting Queries | AADPrivilegedAccountsFailedMFA.yaml |
| T1078 | Azure Sentinel Hunting Queries | AdministratorsAuthenticatingtoAnotherAzureADTenant.yaml |
| T1078 | Azure Sentinel Hunting Queries | AnomalousUserAppSigninLocationIncrease.yaml |
| T1078 | Azure Sentinel Hunting Queries | LoginSpikeWithIncreaseFailureRate.yaml |
| T1078 | Sigma HQ 1 | posh_pm_susp_reset_computermachinepassword.yml |
| T1078 | Sigma HQ 1 | azure_privileged_account_signin_outside_hours.yml |
| T1078 | Azure Sentinel Hunting Queries | AzureRunCommandMDELinked.yaml |
| T1078 | Sigma HQ 1 | azure_privileged_account_sigin_expected_controls.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_atypical_travel.yml |
| T1078 | Sigma HQ 1 | aws_susp_saml_activity.yml |
| T1078 | Sigma HQ 1 | azure_ad_account_created_deleted.yml |
| T1078 | Sigma HQ 1 | azure_ad_account_created_deleted_nonapproved_user.yml |
| T1078 | Sigma HQ 1 | azure_ad_account_signin_outside_hours.yml |
| T1078 | Sigma HQ 1 | azure_ad_auth_failure_increase.yml |
| T1078 | Sigma HQ 1 | azure_privileged_account_no_saw_paw.yml |
| T1078 | Sigma HQ 1 | azure_ad_auth_to_important_apps_using_single_factor_auth.yml |
| T1078 | Sigma HQ 1 | azure_ad_guest_users_invited_to_tenant_by_non_approved_inviters.yml |
| T1078 | Sigma HQ 1 | azure_ad_risky_sign_ins_with_singlefactorauth_from_unknown_devices.yml |
| T1078 | Sigma HQ 1 | azure_ad_user_added_to_admin_role.yml |
| T1078 | Sigma HQ 1 | azure_app_device_code_authentication.yml |
| T1078 | Sigma HQ 1 | azure_app_ropc_authentication.yml |
| T1078 | Sigma HQ 1 | azure_federation_modified.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_anonymous_ip_activity.yml |
| T1078 | Sigma HQ 1 | azure_ad_auth_sucess_increase.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_impossible_travel.yml |
| T1078 | Sigma HQ 1 | azure_pim_alerts_disabled.yml |
| T1078 | Sigma HQ 1 | azure_pim_role_frequent_activation.yml |
| T1078 | Sigma HQ 1 | azure_pim_role_assigned_outside_of_pim.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_new_coutry_region.yml |
| T1078 | Sigma HQ 1 | azure_pim_role_no_mfa_required.yml |
| T1078 | Sigma HQ 1 | azure_pim_invalid_license.yml |
| T1078 | Sigma HQ 1 | azure_pim_too_many_global_admins.yml |
| T1078 | Sigma HQ 1 | azure_pim_account_stale.yml |
| T1078 | Sigma HQ 1 | azure_kubernetes_admission_controller.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_unfamilar_sign_in.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_threat_intel.yml |
| T1078 | Sigma HQ 1 | azure_identity_protection_suspicious_browser.yml |
| T1078 | Sigma HQ 1 | azure_pim_role_not_used.yml |
| T1059 | Elastic 1 | defense_evasion_posh_assembly_load.toml |
| T1059 | Elastic 1 | defense_evasion_execution_msbuild_started_by_script.toml |
| T1059 | Elastic 1 | credential_access_posh_veeam_sql.toml |
| T1059 | Elastic 1 | defense_evasion_dotnet_compiler_parent_process.toml |
| T1059 | Elastic 1 | defense_evasion_disabling_windows_defender_powershell.toml |
| T1059 | Elastic 1 | defense_evasion_defender_exclusion_via_powershell.toml |
| T1059 | Elastic 1 | defense_evasion_clearing_windows_console_history.toml |
| T1059 | Elastic 1 | credential_access_veeam_commands.toml |
| T1059 | Elastic 1 | credential_access_veeam_backup_dll_imageload.toml |
| T1059 | Elastic 1 | credential_access_posh_minidump.toml |
| T1059 | Elastic 1 | credential_access_posh_request_ticket.toml |
| T1059 | Elastic 1 | credential_access_posh_relay_tools.toml |
| T1059 | Elastic 1 | credential_access_posh_kerb_ticket_dump.toml |
| T1059 | Elastic 1 | credential_access_posh_invoke_ninjacopy.toml |
| T1059 | Elastic 1 | command_and_control_remote_file_copy_scripts.toml |
| T1059 | Elastic 1 | command_and_control_remote_file_copy_powershell.toml |
| T1059 | Elastic 1 | collection_posh_webcam_video_capture.toml |
| T1059 | Elastic 1 | collection_posh_screen_grabber.toml |
| T1059 | Elastic 1 | collection_posh_mailbox.toml |
| T1059 | Elastic 1 | collection_posh_keylogger.toml |
| T1059 | Elastic 1 | defense_evasion_posh_process_injection.toml |
| T1059 | Elastic 1 | defense_evasion_posh_compressed.toml |
| T1059 | Elastic 1 | execution_file_execution_followed_by_deletion.toml |
| T1059 | Elastic 1 | defense_evasion_powershell_windows_firewall_disabled.toml |
| T1059 | Elastic 1 | defense_evasion_suspicious_execution_from_mounted_device.toml |
| T1059 | Elastic 1 | collection_posh_audio_capture.toml |
| T1059 | Elastic 1 | execution_file_made_executable_via_chmod_inside_a_container.toml |
| T1059 | Elastic 1 | execution_file_transfer_or_listener_established_via_netcat.toml |
| T1059 | Elastic 1 | execution_find_binary.toml |
| T1059 | Elastic 1 | execution_flock_binary.toml |
| T1059 | Elastic 1 | execution_from_unusual_path_cmdline.toml |
| T1059 | Elastic 1 | execution_gcc_binary.toml |
| T1059 | Elastic 1 | execution_installer_package_spawned_network_event.toml |
| T1059 | Elastic 1 | execution_interactive_exec_to_container.toml |
| T1059 | Elastic 1 | execution_interactive_shell_spawned_from_inside_a_container.toml |
| T1059 | Elastic 1 | execution_interpreter_tty_upgrade.toml |
| T1059 | Elastic 1 | execution_ml_windows_anomalous_script.toml |
| T1059 | Elastic 1 | execution_mysql_binary.toml |
| T1059 | Elastic 1 | execution_nc_listener_via_rlwrap.toml |
| T1059 | Elastic 1 | execution_netcat_listener_established_inside_a_container.toml |
| T1059 | Elastic 1 | execution_netcon_from_rwx_mem_region_binary.toml |
| T1059 | Elastic 1 | execution_network_event_post_compilation.toml |
| T1059 | Elastic 1 | execution_expect_binary.toml |
| T1059 | Elastic 1 | execution_env_binary.toml |
| T1059 | Elastic 1 | execution_delayed_via_ping_lolbas_unsigned.toml |
| T1059 | Elastic 1 | execution_c89_c99_binary.toml |
| T1059 | Elastic 1 | defense_evasion_wsl_bash_exec.toml |
| T1059 | Elastic 1 | discovery_posh_invoke_sharefinder.toml |
| T1059 | Elastic 1 | discovery_posh_suspicious_api_functions.toml |
| T1059 | Elastic 1 | execution_apt_binary.toml |
| T1059 | Elastic 1 | execution_apt_solarwinds_backdoor_child_cmd_powershell.toml |
| T1059 | Elastic 1 | execution_awk_binary_shell.toml |
| T1059 | Elastic 1 | execution_busybox_binary.toml |
| T1059 | Elastic 1 | execution_command_prompt_connecting_to_the_internet.toml |
| T1059 | Elastic 1 | execution_defense_evasion_electron_app_childproc_node_js.toml |
| T1059 | Elastic 1 | execution_command_shell_started_by_powershell.toml |
| T1059 | Elastic 1 | execution_command_shell_started_by_svchost.toml |
| T1059 | Elastic 1 | execution_command_shell_started_by_unusual_process.toml |
| T1059 | Elastic 1 | execution_command_shell_via_rundll32.toml |
| T1059 | Elastic 1 | execution_command_virtual_machine.toml |
| T1059 | Elastic 1 | execution_cpulimit_binary.toml |
| T1059 | Elastic 1 | execution_crash_binary.toml |
| T1059 | Elastic 1 | collection_posh_clipboard_capture.toml |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC830 - Cybereason - Windows Suspicious Certutl Co.md |
| T1059 | Elastic 1 | collection_email_powershell_exchange_mailbox.toml |
| T1059 | Atomic | T1005.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - NRT Process executed from binary hidden in Base64 .md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - NRT Base64 Encoded Windows Process Command-lines.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - New CloudShell User.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Network Session Essentials - Detect port misuse by.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Front Door Premium WAF - SQLi Detection.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Detect port misuse by static threshold (ASIM Netwo.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Detect port misuse by anomaly based detection (ASI.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Windows Security Event - Process Exec.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Windows Security Event - NRT Process .md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Windows Security Event - NRT Base64 e.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Network - Detect port misuse by stati.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Network - Detect port misuse by anoma.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Cyberproof - Linux - Looking for passwords in Linu.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Fortinet - New Events Detected [IMPOR.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Detect port misuse by static threshol.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - CVE-2023-36884 - Commands executed by.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Azure WAF - Front Door Premium WAF - .md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Azure Activity- Azure VM Run Command .md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Azure Activity - New CloudShell User.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Azure Activity - Azure VM Run Command.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Azure Active Directory - New CloudShe.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - AvosLocker Ransomware Detection.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - CyberProof - Application Gateway WAF - SQLi Detect.md |
| T1059 | Azure Sentinel Hunting Queries | redmenshen-bpfdoor-backdoor.yaml |
| T1059 | Azure Sentinel Hunting Queries | imProcess_Suspicious_enumeration_using_adfind.yaml |
| T1059 | Azure Sentinel Hunting Queries | Azure-CloudShell-Usage.yaml |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Base64 encoded Windows process command-lines.md |
| T1059 | Elastic 1 | execution_perl_tty_shell.toml |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Process executed from binary hidden in Base64 enco.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Process Execution Frequency Anomaly.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC828 - Cybereason - Windows Scheduled Task Creati.md |
| T1059 | Atomic | T1027.md |
| T1059 | Atomic | T1059.md |
| T1059 | Atomic | T1202.md |
| T1059 | Atomic | win_alert_hacktool_use.md |
| T1059 | Atomic | win_alert_ruler.md |
| T1059 | Atomic | win_office_shell.md |
| T1059 | Atomic | win_office_spawn_exe_from_users_directory.md |
| T1059 | Atomic | win_susp_cmd_http_appdata.md |
| T1059 | Atomic | win_susp_outlook.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Windows Binaries Lolbins Renamed.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - Windows Binaries Executed from Non-Default Directo.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC983 - Windows - Process executed from binary hid.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC829 - Cybereason - Windows Connection to frequen.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC827 - Cybereason - Windows Suspicious Activity b.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SecurityEvent - Base64 encoded Windows process com.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC826 - Cybereason - Windows Multiple Process Enum.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC802 - CyberReason - Remote Shell Execution.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC591 - Windows - Suspicious rundll32 execution.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC590 - Windows - command-line looking like mimika.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC587 - Windows - Netsh Port Forwarding.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC46 - Windows - Firewall Stopped.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC453 - Windows - Suspicious Powershell Activity.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - UC453 - Windows - Suspicious Powershell Activity v.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SUNBURST network beacons.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SUNBURST and SUPERNOVA backdoor hashes.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SOC - CTI - ID0114  Spring4Shell - CVE-2022-22965.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SecurityEvent - Process execution frequency anomal.md |
| T1059 | UCM Catalog 2024 Sentinel | T1059 - SecurityEvent - Process executed from binary hidde.md |
| T1059 | Elastic 1 | execution_pentest_eggshell_remote_admin_tool.toml |
| T1059 | Elastic 1 | initial_access_suspicious_ms_office_child_process.toml |
| T1059 | Elastic 1 | execution_posh_hacktool_authors.toml |
| T1059 | Sigma HQ 1 | proc_creation_win_renamed_nircmd.yml |
| T1059 | Mappings | Chronicle.yaml |
| T1059 | Mappings | LinuxAuditdAndLogAnalytics.yaml |
| T1059 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1059 | Mappings | SCC.yaml |
| T1059 | Mappings | VirusTotal.yaml |
| T1059 | Netevert sentinel-attack | T1059_Command_Line_Interface.txt |
| T1059 | Sigma HQ 1 | win_security_alert_ruler.yml |
| T1059 | Sigma HQ 1 | win_defender_threat.yml |
| T1059 | Sigma HQ 1 | win_defender_malware_detected_amsi_source.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_winget_local_install_via_manifest.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_winget_add_susp_custom_source.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_winget_add_insecure_custom_source.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_winget_add_custom_source.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_vmware_toolbox_cmd_persistence_susp.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_vmware_toolbox_cmd_persistence.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_sysprep_appdata.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_script_exec_from_temp.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_script_exec_from_env_folder.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_progname.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_network_scan_loop.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_hiding_malware_in_fonts_folder.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_execution_from_public_folder_as_parent.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_elevated_system_shell_uncommon_parent.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_susp_elevated_system_shell.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_ruby_inline_command_execution.yml |
| T1059 | Mappings | AzureSentinel.yaml |
| T1059 | Mappings | AzureDefenderForAppService.yaml |
| T1059 | Mappings | AWSWebApplicationFirewall.yaml |
| T1059 | Sigma HQ 4 | proc_creation_lnx_xterm_reverse_shell.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_ftp_arbitrary_command_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_fsutil_symlinkevaluation.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_fsi_fsharp_code_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_forfiles_proxy_execution_.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_conhost_uncommon_parent.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_cmd_unusual_parent.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_cmd_dosfuscation.yml |
| T1059 | Sigma HQ 4 | proc_creation_macos_susp_execution_macos_script_editor.yml |
| T1059 | Sigma HQ 4 | proc_creation_macos_susp_browser_child_process.yml |
| T1059 | Sigma HQ 4 | proc_creation_macos_payload_decoded_and_decrypted.yml |
| T1059 | Sigma HQ 4 | proc_creation_macos_installer_susp_child_process.yml |
| T1059 | Sigma HQ 4 | proc_creation_lnx_susp_java_children.yml |
| T1059 | Mappings | AlertsForWindowsMachines.yaml |
| T1059 | Sigma HQ 4 | proc_creation_lnx_python_pty_spawn.yml |
| T1059 | Sigma HQ 4 | proc_creation_lnx_netcat_reverse_shell.yml |
| T1059 | Sigma HQ 4 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1059 | Sigma HQ 4 | posh_ps_win_defender_exclusions_added.yml |
| T1059 | Sigma HQ 4 | lnx_auditd_bpfdoor_file_accessed.yml |
| T1059 | Sigma HQ 4 | image_load_side_load_abused_dlls_susp_paths.yml |
| T1059 | Sigma HQ 4 | image_load_dll_pcre_dotnet_dll_load.yml |
| T1059 | Sigma HQ 4 | file_event_win_shell_write_susp_directory.yml |
| T1059 | Sigma HQ 4 | file_event_win_perflogs_susp_files.yml |
| T1059 | Sigma HQ 4 | file_event_win_pcre_net_temp_file.yml |
| T1059 | Sigma HQ 4 | azure_new_cloudshell_created.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_renamed_pingcastle.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_renamed_ftp.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_hktl_sliver_c2_execution_pattern.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_renamed_curl.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_cmd_unusual_parent.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_cmd_dosfuscation.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_apt_turla_commands_critical.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_apt_revil_kaseya.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_apt_lazarus_group_activity.yml |
| T1059 | Sigma HQ 1 | proc_creation_macos_susp_execution_macos_script_editor.yml |
| T1059 | Sigma HQ 1 | proc_creation_macos_susp_browser_child_process.yml |
| T1059 | Sigma HQ 1 | proc_creation_macos_payload_decoded_and_decrypted.yml |
| T1059 | Sigma HQ 1 | proc_creation_macos_installer_susp_child_process.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_xterm_reverse_shell.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_susp_java_children.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_python_pty_spawn.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_netcat_reverse_shell.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_exploit_cve_2023_22518_confluence_java_child_proc.yml |
| T1059 | Sigma HQ 1 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1059 | Sigma HQ 1 | posh_ps_win_defender_exclusions_added.yml |
| T1059 | Sigma HQ 1 | lnx_auditd_bpfdoor_file_accessed.yml |
| T1059 | Sigma HQ 1 | image_load_side_load_abused_dlls_susp_paths.yml |
| T1059 | Sigma HQ 1 | image_load_dll_pcre_dotnet_dll_load.yml |
| T1059 | Sigma HQ 1 | file_event_win_shell_write_susp_directory.yml |
| T1059 | Sigma HQ 1 | file_event_win_perflogs_susp_files.yml |
| T1059 | Sigma HQ 1 | file_event_win_pcre_net_temp_file.yml |
| T1059 | Sigma HQ 1 | file_event_win_malware_darkgate_autoit3_save_temp.yml |
| T1059 | Sigma HQ 1 | file_event_win_malware_darkgate_autoit3_binary_creation.yml |
| T1059 | Sigma HQ 1 | azure_new_cloudshell_created.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_conhost_uncommon_parent.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_exploit_cve_2021_26084_atlassian_confluence.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_exploit_cve_2021_40444.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_mshta_inline_vbscript.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_rasdial_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_rar_susp_greedy_compression.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_python_pty_spawn.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_python_inline_command_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_pua_wsudo_susp_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_powershell_run_script_from_input_stream.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_powershell_download_iex.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_php_inline_command_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_perl_inline_command_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_office_outlook_susp_child_processes_remote.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_office_outlook_enable_unsafe_client_mail_rules.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_malware_kamikakabot_lnk_lure_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_exploit_cve_2023_22518_confluence_tomcat_child_proc.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_malware_darkgate_autoit3_from_susp_parent_and_location.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_lolbin_runscripthelper.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_lolbin_pcalua.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_lolbin_openconsole.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_hktl_stracciatella_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_hktl_sliver_c2_execution_pattern.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_hktl_cobaltstrike_process_patterns.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_ftp_arbitrary_command_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_fsutil_symlinkevaluation.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_fsi_fsharp_code_execution.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_forfiles_proxy_execution_.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_hktl_cobaltstrike_process_patterns.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_hktl_stracciatella_execution.yml |
| T1059 | Elastic 1 | execution_posh_hacktool_functions.toml |
| T1059 | Elastic 1 | persistence_via_xp_cmdshell_mssql_stored_procedure.toml |
| T1059 | Elastic 1 | execution_suspicious_mining_process_creation_events.toml |
| T1059 | Elastic 1 | execution_suspicious_powershell_imgload.toml |
| T1059 | Elastic 1 | execution_sus_extraction_or_decrompression_via_funzip.toml |
| T1059 | Elastic 1 | execution_tc_bpf_filter.toml |
| T1059 | Elastic 1 | execution_unknown_rwx_mem_region_binary_executed.toml |
| T1059 | Elastic 1 | execution_via_hidden_shell_conhost.toml |
| T1059 | Elastic 1 | execution_via_mmc_console_file_unusual_path.toml |
| T1059 | Elastic 1 | execution_vi_binary.toml |
| T1059 | Elastic 1 | exfiltration_rds_snapshot_export.toml |
| T1059 | Elastic 1 | impact_volume_shadow_copy_deletion_via_powershell.toml |
| T1059 | Elastic 1 | initial_access_exploit_jetbrains_teamcity.toml |
| T1059 | Elastic 1 | initial_access_scripts_process_started_via_wmi.toml |
| T1059 | Elastic 1 | initial_access_script_executing_powershell.toml |
| T1059 | Elastic 1 | initial_access_suspicious_ms_exchange_worker_child_process.toml |
| T1059 | Elastic 1 | initial_access_suspicious_ms_outlook_child_process.toml |
| T1059 | Elastic 1 | initial_access_via_explorer_suspicious_child_parent_args.toml |
| T1059 | Elastic 1 | initial_access_webshell_screenconnect_server.toml |
| T1059 | Elastic 1 | lateral_movement_powershell_remoting_target.toml |
| T1059 | Elastic 1 | persistence_apt_package_manager_execution.toml |
| T1059 | Elastic 1 | persistence_creation_hidden_login_item_osascript.toml |
| T1059 | Elastic 1 | persistence_folder_action_scripts_runtime.toml |
| T1059 | Elastic 1 | persistence_git_hook_file_creation.toml |
| T1059 | Elastic 1 | persistence_git_hook_process_execution.toml |
| T1059 | Elastic 1 | persistence_local_scheduled_task_scripting.toml |
| T1059 | Elastic 1 | persistence_powershell_exch_mailbox_activesync_add_device.toml |
| T1059 | Elastic 1 | execution_suspicious_java_netcon_childproc.toml |
| T1059 | Elastic 1 | execution_suspicious_jar_child_process.toml |
| T1059 | Elastic 1 | execution_suspicious_executable_running_system_commands.toml |
| T1059 | Elastic 1 | execution_script_via_automator_workflows.toml |
| T1059 | Elastic 1 | execution_posh_portable_executable.toml |
| T1059 | Elastic 1 | execution_posh_psreflect.toml |
| T1059 | Elastic 1 | execution_process_started_from_process_id_file.toml |
| T1059 | Elastic 1 | execution_process_started_in_shared_memory_directory.toml |
| T1059 | Elastic 1 | execution_python_script_in_cmdline.toml |
| T1059 | Elastic 1 | execution_python_tty_shell.toml |
| T1059 | Elastic 1 | execution_remote_code_execution_via_postgresql.toml |
| T1059 | Elastic 1 | execution_reverse_shell_via_named_pipe.toml |
| T1059 | Elastic 1 | execution_revershell_via_shell_cmd.toml |
| T1059 | Elastic 1 | execution_scheduled_task_powershell_source.toml |
| T1059 | Elastic 1 | execution_scripting_osascript_exec_followed_by_netcon.toml |
| T1059 | Elastic 1 | execution_shell_evasion_linux_binary.toml |
| T1059 | Elastic 1 | execution_suspicious_cmd_wmi.toml |
| T1059 | Elastic 1 | execution_shell_execution_via_apple_scripting.toml |
| T1059 | Elastic 1 | execution_shell_suspicious_parent_child_revshell_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_background_process.toml |
| T1059 | Elastic 1 | execution_shell_via_child_tcp_utility_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_java_revshell_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_lolbin_interpreter_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_meterpreter_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_suspicious_binary.toml |
| T1059 | Elastic 1 | execution_shell_via_tcp_cli_utility_linux.toml |
| T1059 | Elastic 1 | execution_shell_via_udp_cli_utility_linux.toml |
| T1059 | Elastic 1 | execution_ssh_binary.toml |
| T1059 | Elastic 1 | persistence_system_shells_via_services.toml |
| T1059 | Elastic 1 | persistence_webshell_detection.toml |
| T1059 | Sigma HQ 4 | proc_creation_win_lolbin_openconsole.yml |
| T1059 | Elastic 1 | privilege_escalation_applescript_with_admin_privs.toml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_script_exec_from_env_folder.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_progname.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_network_scan_loop.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_hiding_malware_in_fonts_folder.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_execution_from_public_folder_as_parent.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_elevated_system_shell_uncommon_parent.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_ruby_inline_command_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_renamed_pingcastle.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_renamed_nircmd.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_renamed_ftp.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_renamed_curl.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_rasdial_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_rar_susp_greedy_compression.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_python_pty_spawn.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_python_inline_command_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_pua_wsudo_susp_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_powershell_run_script_from_input_stream.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_powershell_download_iex.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_php_inline_command_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_perl_inline_command_execution.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_office_outlook_susp_child_processes_remote.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_office_outlook_enable_unsafe_client_mail_rules.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_mshta_inline_vbscript.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_lolbin_runscripthelper.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_lolbin_pcalua.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_susp_script_exec_from_temp.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_sysprep_appdata.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_vmware_toolbox_cmd_persistence.yml |
| T1059 | Elastic 2 | discovery_files_dir_systeminfo_via_cmd.toml |
| T1059 | Elastic 1 | privilege_escalation_explicit_creds_via_scripting.toml |
| T1059 | Elastic 1 | privilege_escalation_gdb_sys_ptrace_netcon.toml |
| T1059 | Elastic 1 | privilege_escalation_posh_token_impersonation.toml |
| T1059 | Elastic 1 | privilege_escalation_potential_wildcard_shell_spawn.toml |
| T1059 | UCM Catalog 2024 Qradar | T1059 - [CyberProof] - [AWS] - IAM S3Browser User or Acces.md |
| T1059 | UCM Catalog 2024 Qradar | T1059 - [CyberProof] - [AWS] - IAM S3Browser LoginProfile .md |
| T1059 | UCM Catalog 2024 Qradar | T1059 - [AtomicRedTeam] - [SocGholish #1]  - WScript CScri.md |
| T1059 | Elastic 1 | privilege_escalation_service_control_spawned_script_int.toml |
| T1059 | Elastic 2 | collection_posh_compression.toml |
| T1059 | Elastic 2 | defense_evasion_cmd_copy_binary_contents.toml |
| T1059 | Elastic 2 | defense_evasion_powershell_clear_logs_script.toml |
| T1059 | Elastic 2 | discovery_posh_generic.toml |
| T1059 | Sigma HQ 4 | proc_creation_win_vmware_toolbox_cmd_persistence_susp.yml |
| T1059 | Elastic 2 | discovery_posh_password_policy.toml |
| T1059 | Elastic 2 | lateral_movement_posh_winrm_activity.toml |
| T1059 | Elastic 2 | persistence_transport_agent_exchange.toml |
| T1059 | Sigma HQ 4 | win_security_alert_ruler.yml |
| T1059 | Sigma HQ 4 | win_defender_threat.yml |
| T1059 | Sigma HQ 4 | win_defender_malware_detected_amsi_source.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_winget_local_install_via_manifest.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_winget_add_susp_custom_source.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_winget_add_insecure_custom_source.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_winget_add_custom_source.yml |
| T1059 | Sigma HQ 4 | proc_creation_win_vmware_vmtoolsd_susp_child_process.yml |
| T1059 | Sigma HQ 1 | proc_creation_win_vmware_vmtoolsd_susp_child_process.yml |


