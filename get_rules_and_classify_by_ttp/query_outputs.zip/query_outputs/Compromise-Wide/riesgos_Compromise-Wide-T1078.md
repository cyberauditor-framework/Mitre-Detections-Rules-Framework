---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Compromise-Wide.md]]

### T1078

**technique ID**
[[T1078]]

**technique**
Valid Accounts

**technique url**
https://attack.mitre.org/techniques/T1078

**technique description**
Adversaries may obtain and abuse credentials of existing accounts as a means of gaining Initial Access, Persistence, Privilege Escalation, or Defense Evasion. Compromised credentials may be used to bypass access controls placed on various resources on systems within the network and may even be used for persistent access to remote systems and externally available services, such as VPNs, Outlook Web Access, network devices, and remote desktop.(Citation: volexity_0day_sophos_FW) Compromised credentials may also grant an adversary increased privilege to specific systems or access to restricted areas of the network. Adversaries may choose not to use malware or tools in conjunction with the legitimate access those credentials provide to make it harder to detect their presence.

In some cases, adversaries may abuse inactive accounts: for example, those belonging to individuals who are no longer part of an organization. Using these accounts may allow the adversary to evade detection, as the original account user will not be present to identify any anomalous activity taking place on their account.(Citation: CISA MFA PrintNightmare)

The overlap of permissions for local, domain, and cloud accounts across a network of systems is of concern because the adversary may be able to pivot across accounts and systems to reach a high level of access (i.e., domain or enterprise administrator) to bypass access controls set within the enterprise.(Citation: TechNet Credential Theft)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0005]] [[TA0001]] [[TA0004]] [[TA0003]]

**tactic**
Privilege Escalation, Persistence, Initial Access, Defense Evasion

**software ID**
[[S0038]] [[S0604]] [[S0599]] [[S0567]] [[S0362]] [[S0053]]

**software**
Kinsing, Duqu, SeaDuke, Dtrack, Linux Rabbit, Industroyer

**platform**
[[Azure AD]] [[Windows]] [[IaaS]] [[SaaS]] [[Linux]] [[Google Workspace]] [[Network]] [[macOS]] [[Office 365]] [[Containers]]

**group ID**
[[G0026]] [[G0087]] [[G0102]] [[G1024]] [[G0114]] [[G0085]] [[G0035]] [[G1005]] [[G0065]] [[G0008]] [[G0051]] [[G0049]] [[G0016]] [[G0027]] [[G1004]] [[G0001]] [[G0093]] [[G0046]] [[G0064]] [[G0117]] [[G0004]] [[G0091]] [[G0007]] [[G0096]] [[G0122]] [[G0061]] [[G0011]] [[G0037]] [[G0045]] [[G0034]] [[G0053]] [[G1021]] [[G0039]] [[G0032]]

**group**
Ke3chang, Leviathan, APT18, Lazarus Group, Akira, FIN7, FIN5, Sandworm Team, Dragonfly, APT29, Axiom, Suckfly, Wizard Spider, Silence, FIN10, APT28, APT41, APT33, FIN8, FIN4, Carbanak, Cinnamon Tempest, Chimera, Threat Group-3390, OilRig, menuPass, Silent Librarian, POLONIUM, FIN6, GALLIUM, APT39, Fox Kitten, PittyTiger, LAPSUS$

**data source ID**
[[DS0002]] [[DS0028]]

**data source**
Logon Session, User Account



