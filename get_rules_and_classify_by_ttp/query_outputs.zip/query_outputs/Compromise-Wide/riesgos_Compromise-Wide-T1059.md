---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Compromise-Wide.md]]

### T1059

**technique ID**
[[T1059]]

**technique**
Command and Scripting Interpreter

**technique url**
https://attack.mitre.org/techniques/T1059

**technique description**
Adversaries may abuse command and script interpreters to execute commands, scripts, or binaries. These interfaces and languages provide ways of interacting with computer systems and are a common feature across many different platforms. Most systems come with some built-in command-line interface and scripting capabilities, for example, macOS and Linux distributions include some flavor of [Unix Shell](https://attack.mitre.org/techniques/T1059/004) while Windows installations include the [Windows Command Shell](https://attack.mitre.org/techniques/T1059/003) and [PowerShell](https://attack.mitre.org/techniques/T1059/001).

There are also cross-platform interpreters such as [Python](https://attack.mitre.org/techniques/T1059/006), as well as those commonly associated with client applications such as [JavaScript](https://attack.mitre.org/techniques/T1059/007) and [Visual Basic](https://attack.mitre.org/techniques/T1059/005).

Adversaries may abuse these technologies in various ways as a means of executing arbitrary commands. Commands and scripts can be embedded in [Initial Access](https://attack.mitre.org/tactics/TA0001) payloads delivered to victims as lure documents or as secondary payloads downloaded from an existing C2. Adversaries may also execute commands through interactive terminals/shells, as well as utilize various [Remote Services](https://attack.mitre.org/techniques/T1021) in order to achieve remote Execution.(Citation: Powershell Remote Commands)(Citation: Cisco IOS Software Integrity Assurance - Command History)(Citation: Remote Shell Execution in Python)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0002]]

**tactic**
Execution

**software ID**
[[S0219]] [[S0374]] [[S0598]] [[S1110]] [[S0695]] [[S0434]] [[S0334]] [[S0234]] [[S0167]] [[S0486]] [[S0023]] [[S0487]] [[S0618]] [[S0428]] [[S0330]] [[S0460]] [[S0363]] [[S0032]]

**software**
Bonadan, Empire, CHOPSTICK, Get2, Zeus Panda, gh0st RAT, Bandook, Matryoshka, Kessel, FIVEHANDS, P.A.S. Webshell, Donut, SpeakUp, PoetRAT, Imminent Monitor, SLIGHTPULSE, DarkComet, WINERACK

**platform**
[[Azure AD]] [[Windows]] [[IaaS]] [[Linux]] [[Google Workspace]] [[Network]] [[macOS]] [[Office 365]]

**group ID**
[[G0107]] [[G0053]] [[G0049]] [[G0087]] [[G0124]] [[G0038]] [[G0050]] [[G0067]] [[G0046]] [[G0073]] [[G0035]] [[G0037]] [[G0117]] [[G0004]]

**group**
Ke3chang, Stealth Falcon, OilRig, Dragonfly, APT19, FIN6, Windigo, FIN7, APT37, Whitefly, FIN5, APT39, Fox Kitten, APT32

**data source ID**
[[DS0011]] [[DS0012]] [[DS0009]] [[DS0017]]

**data source**
Module, Process, Command, Script



