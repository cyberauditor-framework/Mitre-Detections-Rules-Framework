**technique_id**
T1486

**title**
CyberProof - CiscoAMP - Ransomware Activity

**query**
CiscoAMP_CL
| where event has "Suspected ransomware" or event_type has "Suspected ransomware"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

