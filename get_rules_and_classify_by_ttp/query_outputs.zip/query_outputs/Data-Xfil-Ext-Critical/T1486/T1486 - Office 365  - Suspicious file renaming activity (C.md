**technique_id**
T1486

**title**
Office 365  - Suspicious file renaming activity (COPS)

**query**
let threshold = 100;
OfficeActivity
| where OfficeWorkload =~ "SharePoint" or OfficeWorkload =~ "OneDrive"
| where Operation =~ "FileRenamed"
| where DestinationFileExtension != SourceFileExtension
| where isnotempty(DestinationFileExtension) and isnotempty(SourceFileExtension)
| summarize Start_Time = min(TimeGenerated),End_Time = max(TimeGenerated),makelist(SourceFileName),makelist(DestinationFileName),dcount(SourceFileName), makelist(SourceFileExtension) by DestinationFileExtension,UserId,ClientIP,UserAgent
| where dcount_SourceFileName >= threshold

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

