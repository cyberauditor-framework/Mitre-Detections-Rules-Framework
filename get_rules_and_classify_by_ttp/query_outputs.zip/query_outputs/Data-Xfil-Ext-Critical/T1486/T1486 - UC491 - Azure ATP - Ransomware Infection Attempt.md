**technique_id**
T1486

**title**
UC491 - Azure ATP - Ransomware Infection Attempt

**query**
// UC491 - Azure ATP - Ransomware Infection Attempt
// This rule detects when there is a ATP event
// Mitre Tactic: TA0040
// Mitre Technique: T1486
let USE_CASE_NAME = "Azure ATP - Ransomware Infection Attempt";
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Azure ATP"
| where externalId_s == "2035"
| join kind=inner atpRulesEnrichmentFunc
  on $left.externalId_s == $right.ExternalId
| where Onboarded == "TRUE"
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      (strcat (USE_CASE_NAME, " [3rd Party]")),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    customerURI_s,
    sourceUserName_s,
    sourceAddress_s,
    sourceNtDomain_s,
    sourceHostName_s,
    destinationAddress_s,
    destinationUserName_s,
    destinationHostName_s,
    destinationNtDomain_s,
    name_s,
    Attack_Type = CategoryCustomFormatField,
    Link_to_Azure_Alert = deviceCustomString1_s,
    ATPAlertName,
    CategoryBehavior,
    CategorySignificance,
    message = strcat("On ", TimeGenerated, " the SOC Security Monitoring Service detected an Event of Interest"),
    deviceVendor_s,
    deviceProduct_s,
    TimeGenerated,
    galaxyListName_s,
    galaxyListReference_s,
    externalId_s,
    endTime_s,
    deviceEventClassId_s,
    deviceHostName_s,
    CategoryTechnique,
    CategoryDeviceType,
    categoryOutcome_s

**source**
Sentinel

**type_source**
ttp from Sentinel - description

