**technique_id**
T1048

**title**
UC121 - IPS - Non Compliant DNS from Internal Network

**query**
// UC121 - IPS - Non Compliant DNS from Internal Network
// This rule is to detect data exfiltration using the DNS protocol. DNS helps in providing information
// about different resource records few of those types (like txt and query records) can be used for data exfiltration.
// And this detection is based on the checkpoint IPS signatures related to it.
// Mitre Tactic: TA0010
// Mitre Technique: T1048.003
let USE_CASE_NAME = "IPS - Non Compliant DNS from Internal Network";
let signature_names = dynamic(
    [
      "High Tkey request - from untrusted DNS source - Potential DNS Tunneling",
      "High TXT request - from untrusted DNS source - Potential DNS Tunneling",
      "High TXT requests - from fake DNS servers like mooo.com",
      "MALWARE-OTHER dns request with long host name segment - possible data exfiltration attempt",
      "DNS_EVENT_OBSOLETE_TYPES",
      "DNS_EVENT_EXPERIMENTAL_TYPES",
      "PROTOCOL-DNS Malformed DNS query with HTTP content",
      "High TXT requests - from untrusted DNS - Potential DNS Tunneling",
      "High TXT requests - Potential DNS Tunneling",
      "High CNAME requests - not senderbase.org - Potential DNS Tunneling",
      "High SRV requests - not senderbase.org - Potential DNS Tunneling",
      "High CNAME requests - Potential DNS Tunneling",
      "High SRV requests - Potential DNS Tunneling",
      "High TXT requests - from fake DNS servers like mooo.com",
      "High TXT requests - from untrusted DNS sources - Potential DNS Tunneling",
      "High TXT requests - for access.network - test",
      "High Tkey requests - from untrusted DNS sources - Potential DNS Tunneling"
    ]
  );
let CheckPointTable = AxALiveStream_CL
  | where TimeGenerated >= ago(5m)
  | where deviceVendor_s == "Check Point"
    and deviceProduct_s == "SmartDefense"
    and name_s == "Non Compliant DNS"
  ;
let SourceFireTable = AxALiveStream_CL
  | where TimeGenerated >= ago(5m)
  | where deviceVendor_s == "Sourcefire"
    and deviceProduct_s == "Sourcefire Management Console eStreamer"
    and name_s in (signature_names)
    and not(
      deviceCustomString6_s == "1000383"
      and (
        eventOutcome_s == "0"
        or deviceAction_s =~ "Intrusion event not blocked"
      )
    )
  ;
let CiscoTable = AxALiveStream_CL
  | where TimeGenerated >= ago(5m)
  | where deviceVendor_s == "Cisco"
    and deviceProduct_s == "Firepower"
    and name_s in (signature_names)
  ;
union
  CheckPointTable,
  SourceFireTable,
  CiscoTable
| where ipv4_is_private(sourceAddress_s)
| where not(
    uc121MainFilteringOut(
      source_ip = sourceAddress_s,
      entity = customerURI_s,
      source_hostname = sourceHostName_s,
      destination_ip = destinationAddress_s,
      logon_type = name_s,
      message = Message,
      protocol = transportProtocol_s,
      port = destinationPort_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| extend
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )
// Add suppression
| where not(
    isSuppressedFunc(
      suppressed_entities = strcat(sourceHostName_s, sourceAddress_s, URL),
      lookback_from = 1d,
      lookback_to = 1tick
    )
  )
| project
    URL,
    categoryBehavior = "Suspicious connection",
    categorySignificance = "Suspicious Activity",
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationPort_s,
    deviceAction_s,
    deviceAddress_s,
    message = strcat(
      "DNS protocol can be used for data exfiltration through queries/responses to records",
      "that carry more information like TXT, key queries,ANY etc.packets sent by the source",
      "are matching the checkpoint IPS signature for DNS tunnel detection.So please investigate if this is TP or FP"
    ),
    Protocol = transportProtocol_s,
    sourceAddress_s,
    sourceHostName_s,
    sourcePort_s,
    name_s,
    deviceVendor_s,
    deviceProduct_s,
    ["Signature Category"] = iff(
      (
        deviceVendor_s == "Check Point"
        and deviceProduct_s == "SmartDefense"
        and name_s == "Non Compliant DNS"
      ),
      Message,
      Message
    ),
    Signature = iff(
      deviceVendor_s == "Check Point"
      and deviceProduct_s == "SmartDefense",
      Message,
      name_s
    ),
    galaxyListReference_s,
    galaxyListName_s

**source**
Sentinel

**type_source**
ttp from Sentinel - description

