**technique_id**
T1048

**title**
DNS events related to ToR proxies

**query**
DnsEvents
| where Name contains "."
| where Name has_any ("tor2web.org", "tor2web.com", "torlink.co", "onion.to", "onion.ink", "onion.cab", "onion.nu", "onion.link",
"onion.it", "onion.city", "onion.direct", "onion.top", "onion.casa", "onion.plus", "onion.rip", "onion.dog", "tor2web.fi",
"tor2web.blutmagie.de", "onion.sh", "onion.lu", "onion.pet", "t2w.pw", "tor2web.ae.org", "tor2web.io", "tor2web.xyz", "onion.lt",
"s1.tor-gateways.de", "s2.tor-gateways.de", "s3.tor-gateways.de", "s4.tor-gateways.de", "s5.tor-gateways.de", "hiddenservice.net")
| extend HostName = iff(Computer has '.', substring(Computer,0,indexof(Computer,'.')),Computer)
| extend DnsDomain = iff(Computer has '.', substring(Computer,indexof(Computer,'.')+1),"")

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

