**technique_id**
T1114

**title**
AUTO DISABLED Multiple users email forwarded to same destination

**query**
let watchlistDomain = (_GetWatchlist('Schindler email domains') | project Domain);
OfficeActivity
| where Operation =~ "Set-Mailbox"
| where Parameters has "ForwardingSmtpAddress"
| extend parsed = parse_json(Parameters)
| mv-expand parsed
| where parsed.Name == "ForwardingSmtpAddress"
| extend parameterName = tostring(parsed.Name), fwdingDestination = tostring(parsed.Value)
| where isnotempty(fwdingDestination)
| extend ClientIPOnly = case( 
    ClientIP has "." and ClientIP has ':', tostring(split(ClientIP, ":")[0]), 
    ClientIP has "." and ClientIP has '-', tostring(split(ClientIP, "-")[0]), 
    ClientIP has ']-', tostring(trim_start(@'[[]', tostring(split(ClientIP, "]")[0]))),
    ClientIP has ']:', tostring(trim_start(@'[[]', tostring(split(ClientIP, "]")[0]))),
    isempty(ClientIP) and ClientIP_ has "." and ClientIP_ has ':', tostring(split(ClientIP_, ":")[0]), 
    isempty(ClientIP) and ClientIP_ has "." and ClientIP_ has '-', tostring(split(ClientIP_, "-")[0]), 
    isempty(ClientIP) and ClientIP_ has ']-', tostring(trim_start(@'[[]', tostring(split(ClientIP_, "]")[0]))),
    isempty(ClientIP) and ClientIP_ has ']:', tostring(trim_start(@'[[]', tostring(split(ClientIP_, "]")[0]))),
    isnotempty(ClientIP), ClientIP,
    isnotempty(ClientIP_), ClientIP_,
    "IP Not Available"
    )  
| extend Port = case(
    ClientIP has "." and ClientIP has ':', tostring(split(ClientIP, ":")[1]), 
    ClientIP has "." and ClientIP has '-', tostring(split(ClientIP, "-")[1]), 
    ClientIP has ']-', tostring(split(ClientIP, "]-")[1]), 
    ClientIP has ']:', tostring(split(ClientIP, "]:")[1]), 
    isempty(ClientIP) and ClientIP_ has "." and ClientIP_ has ':', tostring(split(ClientIP_, ":")[1]), 
    isempty(ClientIP) and ClientIP_ has "." and ClientIP_ has '-', tostring(split(ClientIP_, "-")[1]), 
    isempty(ClientIP) and ClientIP_ has ']-', tostring(split(ClientIP_, "]-")[1]),
    isempty(ClientIP) and ClientIP_ has ']:', tostring(split(ClientIP_, "]:")[1]),
    isnotempty(ClientIP), ClientIP,
    isnotempty(ClientIP_), ClientIP_,
    "IP Not Available"
    )
| extend UserId = iff(isempty(UserId), UserId_, UserId)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), DistinctUserCount = dcount(UserId), UserId = make_set(UserId), 
    Ports = make_set(Port), EventCount = count()
    by fwdingDestination, ClientIP = ClientIPOnly 
| where DistinctUserCount > 1
| mv-expand UserId
| extend UserId = tostring(UserId), Ports = tostring(Ports)
| distinct StartTimeUtc, EndTimeUtc, UserId, DistinctUserCount, ClientIP, Ports, fwdingDestination, EventCount
| extend timestamp = StartTimeUtc, AccountCustomEntity = UserId, IPCustomEntity = ClientIP
| extend dstdomain = extract("@(.+)", 1, fwdingDestination)
| where not (dstdomain in (watchlistDomain))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

