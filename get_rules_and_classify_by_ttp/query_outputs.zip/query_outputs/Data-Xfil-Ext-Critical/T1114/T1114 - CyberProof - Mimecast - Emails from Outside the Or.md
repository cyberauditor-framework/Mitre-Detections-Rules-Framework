**technique_id**
T1114

**title**
CyberProof - Mimecast - Emails from Outside the Organization with Company Domains

**query**
CLCMimecast_CL
| where Direction_s == "Inbound"
| where SenderAddress_s contains "septodont.com"
| where Sender_s !contains "salesforce.com"
    and Sender_s !contains "sendgrid.net"
    and Sender_s !contains "hubspotemail.net"
    and Sender_s !contains "email.cloud4j.com"
    and Sender_s !contains "bounces.eskerondemand.com"
    and Sender_s !contains "mandrillapp.com"
    and Sender_s !contains "showpad.septodont.com"
    and Sender_s !contains "septodont.com.pl"
    and Sender_s !contains "cseseptodont.com"
    and Sender_s !contains "Dentapenbyseptodont"
    and Sender_s !contains "septodont.eu"
    and Sender_s !contains "talent-soft.com"
    and Sender_s !contains "centreon-azu.septodont.com"
    and Sender_s !contains "centreon-cam.septodont.com"
    and Sender_s !contains "psm.knowbe4.com"
    and Sender_s !contains "ogicom.net"
| where Recipient_s !contains "centreon-engine@centreon.septodont.com" and SenderAddress_s !contains "postmaster@septodont.com"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

