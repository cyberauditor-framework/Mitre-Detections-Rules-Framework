**technique_id**
T1114

**title**
Custom - OfficeActivity - Multiple emails forwarded to same destination

**query**
// Custom - OfficeActivity - Multiple emails forwarded to same destination
let TimeFrame = 1d;
OfficeActivity
| where TimeGenerated >= ago(TimeFrame) 
// Exlude Admin activity
| where UserType != "Admin"
| where Operation =~ "Set-InboxRule" or Operation =~ "New-InboxRule" or Operation =~ "Set-Mailbox"
| where Parameters contains "Forward" or Parameters contains "Redirect"
| extend parsed = parse_json(Parameters)
| mv-expand parsed
| extend parameterName = parsed.Name
| where parameterName contains "Forward" or parameterName contains "Redirect"
// Removes dupilicate events with no forwarding destination
| where parameterName !contains "DeliverToMailbox"
| extend fwdingDestination = tostring(parsed.Value)
| extend fwdingDestination = split(fwdingDestination,";")
| mv-expand fwdingDestination
| extend fwdingDestination = tostring(fwdingDestination)
| where isnotempty(fwdingDestination)
// Split IP and Port Number
| extend ClientIPOnly = case( 
ClientIP has ".", tostring(split(ClientIP,":")[0]), 
ClientIP has "[", tostring(trim_start(@'[[]',tostring(split(ClientIP,"]")[0]))),
ClientIP
)  
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), DistinctUserCount = dcount(UserId), UserId = makeset(UserId), ClientIPs= make_set(ClientIPOnly), EventCount = count() by fwdingDestination
| where DistinctUserCount > 1
| mv-expand UserId
| extend UserId = tostring(UserId), ClientIPs = tostring(ClientIPs)
| distinct StartTimeUtc, EndTimeUtc, UserId, DistinctUserCount, ClientIPs, fwdingDestination, EventCount
| extend ipAddress = extract("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}):.*", 1, ClientIPs)
| extend timestamp = StartTimeUtc, AccountCustomEntity = UserId, IPCustomEntity = ipAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

