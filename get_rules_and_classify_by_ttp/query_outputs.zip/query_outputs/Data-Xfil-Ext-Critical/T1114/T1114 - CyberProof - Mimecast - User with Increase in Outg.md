**technique_id**
T1114

**title**
CyberProof - Mimecast - User with Increase in Outgoing Email

**query**
let whitelist = (_GetWatchlist('Out_mail_users') | project account);
CLCMimecast_CL
| where Direction_s == "Outbound"
| where Error_s == "Exceeded max recipients - set to 100"
| project Direction_s, SourceIP, Error_s, Sender_s, Recipient_s, Subject_s
| where Sender_s !in (whitelist)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

