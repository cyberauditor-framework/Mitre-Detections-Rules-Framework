**technique_id**
T1114

**title**
CyberProof - O365 Reported Emails - Email Analysis Failed

**query**
SecurityAlert
| where TimeGenerated >= ago(30d)
| where ProviderName == "OATP"
| extend parsed = parsejson(ExtendedProperties)
| extend Status = parsed.Status, ProcessedBySentinel = parsed.ProcessedBySentinel, InvestigationName = parsed.InvestigationName
| where Status == "Failed"
| extend InvestigationLink = parsejson(ExtendedLinks).[1].Href
| project TimeGenerated, Status, ProcessedBySentinel, InvestigationName, Entities, InvestigationLink

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

