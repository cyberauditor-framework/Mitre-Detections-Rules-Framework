**technique_id**
T1114

**title**
OfficeActivity - Known Manganese IP and UserAgent activity

**query**
let timeframe = 1d;
let IPList = dynamic(["45.63.52.41","140.82.17.161","207.148.101.95","45.32.87.51","66.42.98.156","45.76.144.105","217.163.28.35","45.32.141.174","149.28.165.249","209.250.225.247","45.63.100.115","95.179.229.230","209.250.233.247","45.77.121.232","45.76.175.65","104.238.160.237","45.77.181.97","95.179.192.125","149.28.93.184","140.82.16.81","45.76.173.103","45.77.255.22","45.32.11.71","149.28.77.26","45.32.54.50","104.156.233.156","45.32.21.118","45.63.62.109","45.77.244.202","149.248.11.205","104.238.190.244"]);
let IOCTerms = "\\?lang=[/..]*/dev/cmdb/sslvpn_websession|/dana-na/jam/[/..]*home/webserver/htdocs/dana/html5acc/guacamole[/..]*etc/passwd\\?";
(union isfuzzy=true
(CommonSecurityLog
| where TimeGenerated >= ago(1d) 
| where isnotempty(SourceIP) or isnotempty(DestinationIP)
| where SourceIP in (IPList) or DestinationIP in (IPList) or Message has_any (IPList)
| extend IPMatch = case(
SourceIP in (IPList), "SourceIP", 
DestinationIP in (IPList), "DestinationIP",
"Message") 
| where Message matches regex IOCTerms
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated) by SourceIP, DestinationIP, DeviceProduct, DeviceAction, Message, Protocol, SourcePort, DestinationPort, DeviceAddress, DeviceName, IPMatch
| extend timestamp = StartTimeUtc, IPCustomEntity = case(IPMatch == "SourceIP", SourceIP, IPMatch == "DestinationIP", DestinationIP, "IP in Message Field") 
),
(OfficeActivity
| where TimeGenerated >= ago(1d) 
| where isnotempty(UserAgent) and ClientIP in (IPList)
| where UserAgent contains "ExchangeServicesClient/0.0.0.0"
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated) by SourceIP = ClientIP, Account = UserId, Type, RecordType, OfficeWorkload, UserAgent, OfficeObjectId, IPMatch = "ClientIP"
| extend timestamp = StartTimeUtc, AccountCustomEntity = Account, IPCustomEntity = SourceIP
)
)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

