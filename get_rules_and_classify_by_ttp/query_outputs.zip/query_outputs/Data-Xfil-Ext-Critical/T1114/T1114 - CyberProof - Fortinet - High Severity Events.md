**technique_id**
T1114

**title**
CyberProof - Fortinet - High Severity Events

**query**
CLCFortinet_CL
| where isnotempty(Message)
| where not(name_s has_any("deny", "event:system", "utm:webfilter ftgd_allow passthrough")) 
| where not(Message has_any("qualys", "applications3: SSL.Anonymous.Ciphers.Negotiation", "tools: Censys.io.Scanner", "Network.Service: SMB"))
| where FTNTFGTeventtype_s != "dns-response"
| where Message has_any ("malware", "log4j", "backdoor", "trojan", "file", "infected", "injection", "jakarta", "xss", "xxe", "cve", "nmap", "netcat", "scan", "scanning", "scanner", "pager", "vulnerability", "insecure", "bot", "botnet", "unauthorized", "Heartbleed", "Information.Disclosure", "elevation","priviledge")
| where sourceAddress_s <> "172.25.14.196"//Qualys scanner
| where sourceAddress_s <> "10.0.53.10" //Qualys scanner
| where sourceAddress_s <> "10.102.1.6" //Qualys scanner
| summarize
    count(),
    AppProtocol = make_set(applicationProtocol_s),
    SourcePorts = make_set(sourcePort_d),
    DestinationPorts = make_set(destinationPort_d),
    URLs = make_set(requestUrl_s)
    by bin(TimeGenerated, 15m), name_s, Message, sourceAddress_s, destinationAddress_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

