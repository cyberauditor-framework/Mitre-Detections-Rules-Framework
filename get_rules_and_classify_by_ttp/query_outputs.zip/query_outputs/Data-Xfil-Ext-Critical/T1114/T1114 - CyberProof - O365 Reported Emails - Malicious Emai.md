**technique_id**
T1114

**title**
CyberProof - O365 Reported Emails - Malicious Emails Pending Action

**query**
SecurityAlert
| where ProviderName == "OATP"
| extend parsed = parsejson(ExtendedProperties)
| extend Status = parsed.Status, ProcessedBySentinel = parsed.ProcessedBySentinel, InvestigationName = parsed.InvestigationName
| where Status == "Pending Action"
| extend InvestigationLink = parsejson(ExtendedLinks).[1].Href
| project TimeGenerated, Status, ProcessedBySentinel, InvestigationName, Entities, InvestigationLink

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

