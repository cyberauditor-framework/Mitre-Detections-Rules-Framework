**technique_id**
T1114

**title**
CyberProof - OfficeActivity - Multiple emails forwarded to same destination (New-InboxRule)

**query**
let TimeFrame = 1d;
OfficeActivity
| where TimeGenerated >= ago(TimeFrame) 
| where Operation =~ "New-InboxRule"
| where Parameters contains "ForwardTo" or Parameters contains "ForwardAsAttachmentTo" or Parameters contains "RedirectTo"
| extend parsed = parse_json(Parameters)
| mv-expand parsed
| extend parameterName = parsed.Name
| where parameterName contains "ForwardTo" or parameterName contains "ForwardAsAttachmentTo" or parameterName contains "RedirectTo"
| extend fwdingDestination = tostring(parsed.Value)
| extend fwdingDestination = split(fwdingDestination,";")
| mv-expand fwdingDestination
| extend fwdingDestination = tostring(fwdingDestination)
| where fwdingDestination != ""
// Split IP and Port Number
| extend ClientIPOnly = case( 
ClientIP has ".", tostring(split(ClientIP,":")[0]), 
ClientIP has "[", tostring(trim_start(@'[[]',tostring(split(ClientIP,"]")[0]))),
ClientIP
)  
| extend Port = case(
ClientIP has ".", (split(ClientIP,":")[1]),
ClientIP has "[", tostring(split(ClientIP,"]:")[1]),
ClientIP
)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), DistinctUserCount = dcount(UserId), UserId = makeset(UserId), 
Ports = makeset(Port),ClientIPs= make_set(ClientIPOnly), EventCount = count() by fwdingDestination
| where DistinctUserCount > 1
| mv-expand UserId
| mv-expand ClientIPs
| mv-expand Ports
| extend UserId = tostring(UserId), Ports = tostring(Ports), ClientIPs = tostring(ClientIPs)
| distinct StartTimeUtc, EndTimeUtc, UserId, DistinctUserCount, ClientIPs, Ports, fwdingDestination, EventCount
| extend ipAddress = extract("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}).*", 1, ClientIPs)
| extend timestamp = StartTimeUtc, AccountCustomEntity = UserId, IPCustomEntity = ipAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

