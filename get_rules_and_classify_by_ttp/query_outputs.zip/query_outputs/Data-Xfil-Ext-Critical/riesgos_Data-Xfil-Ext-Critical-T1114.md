---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Data-Xfil-Ext-Critical.md]]

### T1114

**technique ID**
[[T1114]]

**technique**
Email Collection

**technique url**
https://attack.mitre.org/techniques/T1114

**technique description**
Adversaries may target user email to collect sensitive information. Emails may contain sensitive data, including trade secrets or personal information, that can prove valuable to adversaries. Adversaries can collect or forward email from mail servers or clients. 

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0009]]

**tactic**
Collection

**software ID**
[[S0367]]

**software**
Emotet

**platform**
[[Windows]] [[Linux]] [[Google Workspace]] [[macOS]] [[Office 365]]

**group ID**
[[G0122]] [[G0059]]

**group**
Silent Librarian, Magic Hound

**data source ID**
[[DS0029]] [[DS0017]] [[DS0028]] [[DS0015]] [[DS0022]]

**data source**
Logon Session, File, Command, Network Traffic, Application Log



