### Resumen reglas de detección:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1486 | Sigma HQ 1 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Mappings | ActifioGo.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_wannacry.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_lockergoga_ransomware.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_conti_ransomware_commands.yml |
| T1486 | Sigma HQ 1 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 1 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 1 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 1 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 1 | av_ransomware.yml |
| T1486 | Mappings | SecurityCenterRecommendations.yaml |
| T1486 | Mappings | CloudAppSecurity.yaml |
| T1486 | Mappings | Chronicle.yaml |
| T1486 | Mappings | AzureSentinel.yaml |
| T1486 | Mappings | AzureBackup.yaml |
| T1486 | Mappings | AWSRDS.yaml |
| T1486 | Mappings | AWSConfig.yaml |
| T1486 | Mappings | AWSCloudEndure.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 1 | win_security_malware_bluesky_ransomware_files_indicators.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 4 | proc_creation_win_reg_bitlocker.yml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - Suspicious over.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - S3 bucket suspi.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - Office 365  - Suspicious file renaming activity (C.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - CyberProof - CiscoAMP - Ransomware Activity.md |
| T1486 | Sigma HQ 9 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 4 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 4 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 4 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 4 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 4 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 4 | av_ransomware.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Mappings | AmazonGuardDuty.yaml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - UC491 - Azure ATP - Ransomware Infection Attempt.md |
| T1486 | Elastic 1 | impact_data_encrypted_via_openssl.toml |
| T1486 | Atomic | T1490.md |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_file_encryption.toml |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_note_detected.toml |
| T1486 | Atomic | T1489.md |
| T1486 | Elastic 1 | impact_microsoft_365_potential_ransomware_activity.toml |
| T1486 | Azure Sentinel Hunting Queries | ASR--Rule-Ransomware-triggered.yaml |
| T1114 | Elastic 1 | collection_email_powershell_exchange_mailbox.toml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Malicious Emai.md |
| T1114 | Azure Sentinel Hunting Queries | MailForwardingActivityFromNewLocation.yaml |
| T1114 | Azure Sentinel Hunting Queries | RareDomainsInCloudLogs.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Emails Remedia.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Email Threats .md |
| T1114 | Sigma HQ 2 | azure-exchange-email rule breach (on behalf).yaml |
| T1114 | Sigma HQ 2 | azure-exchange-email rule disapearence.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - O365 Reported Emails - Email Analysis.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Mimecast - User with Increase in Outg.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Mimecast - Emails from Outside the Or.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Fortinet - High Severity Events.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Custom - OfficeActivity - Multiple emails forwarde.md |
| T1114 | Elastic 1 | collection_google_workspace_custom_gmail_route_created_or_modified.toml |
| T1114 | Sigma HQ 4 | microsoft365_pst_export_alert.yml |
| T1114 | Sigma HQ 4 | microsoft365_pst_export_alert_using_new_compliancesearchaction.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Exchange workflow M.md |
| T1114 | Sigma HQ 4 | win_security_alert_ruler.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Custom - Anomaly - Exchange workflow MailItemsAcce.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - AUTO DISABLED Multiple users email forwarded to sa.md |
| T1114 | Elastic 1 | collection_email_outlook_mailbox_via_com.toml |
| T1114 | Azure Sentinel Hunting Queries | imProcess_HostExportingMailboxAndRemovingExport.yaml |
| T1114 | Elastic 1 | collection_posh_mailbox.toml |
| T1114 | Elastic 1 | collection_microsoft_365_new_inbox_rule.toml |
| T1114 | Elastic 1 | collection_mailbox_export_winlog.toml |
| T1114 | Sigma HQ 4 | proc_creation_win_powershell_snapins_hafnium.yml |
| T1114 | Atomic | T1114.md |
| T1114 | Sigma HQ 9 | azure-exchange-email rule disapearence.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Mail redirect via ExO transport rule.md |
| T1114 | Atomic | win_alert_ruler.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Rare and potentially high-risk Office operations.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - OfficeActivity - Known Manganese IP and UserAgent .md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - NRT Multiple users email forwarded to same destina.md |
| T1114 | Atomic | win_alert_hacktool_use.md |
| T1114 | Sigma HQ 1 | microsoft365_pst_export_alert_using_new_compliancesearchaction.yml |
| T1114 | Sigma HQ 1 | proc_creation_win_powershell_snapins_hafnium.yml |
| T1114 | Sigma HQ 1 | win_security_alert_ruler.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Multiple users email forwarded to same destination.md |
| T1114 | Sigma HQ 1 | microsoft365_pst_export_alert.yml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - Exchange workflow MailItemsAccessed operation anom.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Mail redirect via E.md |
| T1114 | Elastic 2 | collection_outlook_email_archive.toml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Threat Essentials - Mail redirect via.md |
| T1114 | Mappings | AzureSentinel.yaml |
| T1114 | Mappings | AdvancedProtectionProgram.yaml |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Multiple users emai.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - NRT Multiple users .md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - Office Activity - Rare and potentiall.md |
| T1114 | UCM Catalog 2024 Sentinel | T1114 - CyberProof - OfficeActivity - Multiple emails forw.md |
| T1114 | Sigma HQ 9 | azure-exchange-email rule breach (on behalf).yaml |
| T1048 | Sigma HQ 9 | win-os-BITS high volume file downloaded (native).yaml |
| T1048 | Sigma HQ 9 | win-os-BITS abuse for payload download (PowerShell).yaml |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - Azure Firewall - DNS events related to ToR proxies.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - DNS events related to ToR proxies.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - UC121 - IPS - Non Compliant DNS from Internal Netw.md |
| T1048 | UCM Catalog 2024 Sentinel | T1048 - UC483 - Azure ATP - Data Exfiltration.md |
| T1048 | Atomic | T1197.md |
| T1048 | Atomic | T1048.md |
| T1048 | Sigma HQ 9 | win-os-BITS abuse for payload download (command).yaml |
| T1048 | Atomic | T1022.md |
| T1048 | Mappings | CloudIDS.yaml |
| T1048 | Azure Sentinel Hunting Queries | RareDNSLookupWithDataTransfer.yaml |
| T1048 | Sigma HQ 4 | zeek_dns_torproxy.yml |
| T1048 | Sigma HQ 1 | win_security_tap_driver_installation.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_tapinstall_execution.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_susp_redirect_local_admin_share.yml |
| T1048 | Sigma HQ 1 | proc_creation_win_susp_copy_lateral_movement.yml |
| T1048 | Sigma HQ 1 | posh_ps_invoke_dnsexfiltration.yml |
| T1048 | Mappings | AmazonGuardDuty.yaml |
| T1048 | Mappings | AmazonVirtualPrivateCloud.yaml |
| T1048 | Mappings | AWSIOTDeviceDefender.yaml |
| T1048 | Mappings | AWSNetworkFirewall.yaml |
| T1048 | Mappings | AzureDNSAnalytics.yaml |
| T1048 | Mappings | AzureFirewall.yaml |
| T1048 | Mappings | AzureSentinel.yaml |
| T1048 | Mappings | AzureTrafficAnalytics.yaml |
| T1048 | Mappings | BeyondCorpEnterprise.yaml |
| T1048 | Mappings | Chronicle.yaml |
| T1048 | Mappings | NetworkSecurityGroups.yaml |
| T1048 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1048 | Sigma HQ 1 | win_system_service_install_tap_driver.yml |
| T1048 | Sigma HQ 1 | zeek_dns_torproxy.yml |
| T1048 | Mappings | AlertsForWindowsMachines.yaml |
| T1048 | Elastic 1 | command_and_control_irc_internet_relay_chat_protocol_activity_to_the_internet.toml |
| T1048 | Sigma HQ 4 | win_system_service_install_tap_driver.yml |
| T1048 | Mappings | Firewalls.yaml |
| T1048 | Sigma HQ 4 | proc_creation_win_tapinstall_execution.yml |
| T1048 | Sigma HQ 4 | proc_creation_win_susp_redirect_local_admin_share.yml |
| T1048 | Sigma HQ 4 | proc_creation_win_susp_copy_lateral_movement.yml |
| T1048 | Sigma HQ 4 | posh_ps_invoke_dnsexfiltration.yml |
| T1048 | Elastic 1 | command_and_control_ftp_file_transfer_protocol_activity_to_the_internet.toml |
| T1048 | Elastic 1 | command_and_control_port_26_activity.toml |
| T1048 | Mappings | AlertsForDNS.yaml |
| T1048 | Sigma HQ 2 | win-os-BITS high volume file downloaded (native).yaml |
| T1048 | Sigma HQ 2 | win-os-BITS abuse for payload download (PowerShell).yaml |
| T1048 | Sigma HQ 2 | win-os-BITS abuse for payload download (command).yaml |
| T1048 | Elastic 1 | command_and_control_smtp_to_the_internet.toml |
| T1048 | Elastic 1 | exfiltration_smb_rare_destination.toml |
| T1048 | Elastic 1 | initial_access_rdp_remote_desktop_protocol_to_the_internet.toml |
| T1048 | Elastic 1 | initial_access_smb_windows_file_sharing_activity_to_the_internet.toml |
| T1048 | Sigma HQ 4 | win_security_tap_driver_installation.yml |


### T1486

**technique ID**
[[T1486]]

**technique**
[[Data Encrypted for Impact]]

**technique url**
https://attack.mitre.org/techniques/T1486

**technique description**
Adversaries may encrypt data on target systems or on large numbers of systems in a network to interrupt availability to system and network resources. They can attempt to render stored data inaccessible by encrypting files or data on local and remote drives and withholding access to a decryption key. This may be done in order to extract monetary compensation from a victim in exchange for decryption or a decryption key (ransomware) or to render data permanently inaccessible in cases where the key is not saved or transmitted.(Citation: US-CERT Ransomware 2016)(Citation: FireEye WannaCry 2017)(Citation: US-CERT NotPetya 2017)(Citation: US-CERT SamSam 2018)

In the case of ransomware, it is typical that common user files like Office documents, PDFs, images, videos, audio, text, and source code files will be encrypted (and often renamed and/or tagged with specific file markers). Adversaries may need to first employ other behaviors, such as [File and Directory Permissions Modification](https://attack.mitre.org/techniques/T1222) or [System Shutdown/Reboot](https://attack.mitre.org/techniques/T1529), in order to unlock and/or gain access to manipulate these files.(Citation: CarbonBlack Conti July 2020) In some cases, adversaries may encrypt critical system files, disk partitions, and the MBR.(Citation: US-CERT NotPetya 2017) 

To maximize impact on the target organization, malware designed for encrypting data may have worm-like features to propagate across a network by leveraging other attack techniques like [Valid Accounts](https://attack.mitre.org/techniques/T1078), [OS Credential Dumping](https://attack.mitre.org/techniques/T1003), and [SMB/Windows Admin Shares](https://attack.mitre.org/techniques/T1021/002).(Citation: FireEye WannaCry 2017)(Citation: US-CERT NotPetya 2017) Encryption malware may also leverage [Internal Defacement](https://attack.mitre.org/techniques/T1491/001), such as changing victim wallpapers, or otherwise intimidate victims by sending ransom notes or other messages to connected printers (known as "print bombing").(Citation: NHS Digital Egregor Nov 2020)

In cloud environments, storage objects within compromised accounts may also be encrypted.(Citation: Rhino S3 Ransomware Part 1)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0040]]

**tactic**
[[Impact]]

**software ID**
[[S0595]] [[S1053]] [[S1111]] [[S0583]] [[S0576]] [[S1058]] [[S0612]] [[S0618]] [[S0389]] [[S0481]] [[S0606]] [[S0496]] [[S1068]] [[S0658]] [[S0607]] [[S0639]] [[S1073]] [[S0654]] [[S0366]] [[S0605]] [[S0341]] [[S0556]] [[S0617]] [[S0242]] [[S0554]] [[S0449]] [[S0446]] [[S0370]] [[S0575]] [[S0570]] [[S0659]] [[S0368]] [[S1033]] [[S0616]] [[S0372]] [[S0638]] [[S1070]] [[S0625]] [[S0457]] [[S1096]] [[S0140]] [[S0611]] [[S1129]] [[S0400]] [[S0640]]

**software**
[[BitPaymer]] [[Akira]] [[RobbinHood]] [[ThiefQuest]] [[Egregor]] [[Babuk]] [[DCSrv]] [[WannaCry]] [[DarkGate]] [[Royal]] [[Netwalker]] [[ProLock]] [[SamSam]] [[Avaddon]] [[XCSSET]] [[Bad Rabbit]] [[SynAck]] [[Black Basta]] [[BlackCat]] [[KillDisk]] [[Maze]] [[DEATHRANSOM]] [[MegaCortex]] [[WastedLocker]] [[JCry]] [[Seth-Locker]] [[Ryuk]] [[Diavol]] [[Pay2Key]] [[Ragnar Locker]] [[Cheerscrypt]] [[Conti]] [[FIVEHANDS]] [[EKANS]] [[Pysa]] [[Prestige]] [[HELLOKITTY]] [[Cuba]] [[REvil]] [[AvosLocker]] [[NotPetya]] [[Xbash]] [[Shamoon]] [[Clop]] [[LockerGoga]]

**platform**
[[Windows]] [[Linux]] [[macOS]] [[IaaS]]

**group ID**
[[G1015]] [[G0096]] [[G0061]] [[G0059]] [[G1024]] [[G0046]] [[G0119]] [[G0082]] [[G0092]] [[G0034]]

**group**
[[Akira]] [[APT41]] [[FIN8]] [[Scattered Spider]] [[Magic Hound]] [[FIN7]] [[Indrik Spider]] [[TA505]] [[APT38]] [[Sandworm Team]]

**data source ID**
[[DS0017]] [[DS0009]] [[DS0033]] [[DS0010]] [[DS0022]]

**data source**
[[File]] [[Command]] [[Cloud Storage]] [[Network Share]] [[Process]]



### T1114

**technique ID**
[[T1114]]

**technique**
[[Email Collection]]

**technique url**
https://attack.mitre.org/techniques/T1114

**technique description**
Adversaries may target user email to collect sensitive information. Emails may contain sensitive data, including trade secrets or personal information, that can prove valuable to adversaries. Adversaries can collect or forward email from mail servers or clients. 

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0009]]

**tactic**
[[Collection]]

**software ID**
[[S0367]]

**software**
[[Emotet]]

**platform**
[[Windows]] [[Linux]] [[Google Workspace]] [[macOS]] [[Office 365]]

**group ID**
[[G0122]] [[G0059]]

**group**
[[Silent Librarian]] [[Magic Hound]]

**data source ID**
[[DS0029]] [[DS0017]] [[DS0028]] [[DS0015]] [[DS0022]]

**data source**
[[Logon Session]] [[File]] [[Command]] [[Network Traffic]] [[Application Log]]



### T1048

**technique ID**
[[T1048]]

**technique**
[[Exfiltration Over Alternative Protocol]]

**technique url**
https://attack.mitre.org/techniques/T1048

**technique description**
Adversaries may steal data by exfiltrating it over a different protocol than that of the existing command and control channel. The data may also be sent to an alternate network location from the main command and control server.  

Alternate protocols include FTP, SMTP, HTTP/S, DNS, SMB, or any other network protocol not being used as the main command and control channel. Adversaries may also opt to encrypt and/or obfuscate these alternate channels. 

[Exfiltration Over Alternative Protocol](https://attack.mitre.org/techniques/T1048) can be done using various common operating system utilities such as [Net](https://attack.mitre.org/software/S0039)/SMB or FTP.(Citation: Palo Alto OilRig Oct 2016) On macOS and Linux <code>curl</code> may be used to invoke protocols such as HTTP/S or FTP/S to exfiltrate data from a system.(Citation: 20 macOS Common Tools and Techniques)

Many IaaS and SaaS platforms (such as Microsoft Exchange, Microsoft SharePoint, GitHub, and AWS S3) support the direct download of files, emails, source code, and other sensitive information via the web console or [Cloud API](https://attack.mitre.org/techniques/T1059/009).

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0010]]

**tactic**
[[Exfiltration]]

**software ID**
[[S0482]] [[S0677]] [[S0203]] [[S0641]] [[S0428]] [[S0631]] [[S0503]]

**software**
[[Hydraq]] [[AADInternals]] [[Chaes]] [[Bundlore]] [[PoetRAT]] [[FrameworkPOS]] [[Kobalos]]

**platform**
[[Windows]] [[IaaS]] [[Linux]] [[SaaS]] [[Google Workspace]] [[Network]] [[macOS]] [[Office 365]]

**group ID**
[[G0139]]

**group**
[[TeamTNT]]

**data source ID**
[[DS0029]] [[DS0017]] [[DS0015]] [[DS0010]] [[DS0022]]

**data source**
[[File]] [[Command]] [[Cloud Storage]] [[Network Traffic]] [[Application Log]]



