**technique_id**
T1078

**title**
CyberProof - Azure Backup Services - Policy Deleted

**query**
let timerange = 5m;
AzureActivity
| where TimeGenerated >= ago(timerange)
| where OperationNameValue has "MICROSOFT.INSIGHTS/DATACOLLECTIONENDPOINTS/WRITE"
| where ActivityStatusValue == 'Success' and todynamic(Properties).statusCode has_any ('OK','Created')
| extend DCE_Name = extract(@'/providers/microsoft.insights/datacollectionendpoints/(.*)',1,_ResourceId)
| extend IPCustomEntity = CallerIpAddress, AccountCustomEntity = Caller

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

