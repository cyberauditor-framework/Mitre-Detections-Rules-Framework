**technique_id**
T1078

**title**
CyberProof - Azure Active Directory - NRT PIM Elevation Request Rejected

**query**
AuditLogs
| where ActivityDisplayName =~ 'Add member to role request denied (PIM activation)'
| mv-apply ResourceItem = TargetResources on 
  (
      where ResourceItem.type =~ "Role"
      | extend Role = trim(@'"',tostring(ResourceItem.displayName))
  )
| mv-apply ResourceItem = TargetResources on 
  (
      where ResourceItem.type =~ "User"
      | extend User = trim(@'"',tostring(ResourceItem.userPrincipalName))
  )
| project-reorder TimeGenerated, User, Role, OperationName, Result, ResultDescription
| where isnotempty(InitiatedBy.user)
| extend InitiatingUser = tostring(InitiatedBy.user.userPrincipalName), InitiatingIpAddress = tostring(InitiatedBy.user.ipAddress)
| extend InitiatingName = tostring(split(InitiatingUser,'@',0)[0]), InitiatingUPNSuffix = tostring(split(InitiatingUser,'@',1)[0])
| extend UserName = tostring(split(User,'@',0)[0]), UserUPNSuffix = tostring(split(User,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

