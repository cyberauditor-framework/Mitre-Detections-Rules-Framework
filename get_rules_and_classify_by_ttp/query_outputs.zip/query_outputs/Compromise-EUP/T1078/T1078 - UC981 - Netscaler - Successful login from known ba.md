**technique_id**
T1078

**title**
UC981 - Netscaler - Successful login from known bad IP addresses

**query**
// UC981 - Netscaler - Successful login from known bad IP addresses
// This UC detects successful login from known bad IP address
// Mitre Tactic: TA0001
// Mitre Technique: T1078
let USE_CASE_NAME = "Netscaler - Successful login from known bad IP addresses";
let ip_indicators = toscalar(
    intSightsTIIndicatorsFunc(
      lookback_from = 14d,
      threshold = 50
    )
    | where isnotempty(NetworkIP)
    | summarize NetworkIP = make_set(NetworkIP, 1000000)
  );
AxALiveStream_CL
| where TimeGenerated >= ago(1h)
| where deviceVendor_s == "Citrix" and deviceProduct_s == "NetScaler"
| where categoryBehavior_s == "/Authentication/Verify"
  and deviceEventClassId_s == "SSLVPN LOGIN"
| extend
    sourceAddress_s = extract(
      @"\@(\d+\.\d+\.\d+\.\d+)",
      1,
      Message
    )
| where sourceAddress_s in (ip_indicators)
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = "",
      destination_account = "",
      source_ip = sourceAddress_s,
      destination_ip = ""
    )
| project
    TimeGenerated,
    customerURI_s,
    sourceAddress_s,
    sourceUserName_s = extract(
      @"\w+\s+([^\@]+)\@",
      1,
      Message
    ),
    externalId_s = extract(
      @"SessionId:\s+(\d+)",
      1,
      Message
    ),
    destinationAddress_s = extract(
      @"Vserver\s+(\d+\.\d+\.\d+\.\d+)",
      1,
      Message
    ),
    destinationPort_s = extract(
      @"\d+\.\d+\.\d+\.\d+:(\d+)",
      1,
      Message
    ),
    requestClientApplication_s = extract(
      "Browser_type \"([^\"]+)",
      1,
      Message
    ),
    categoryBehavior_s,
    deviceEventClassId_s,
    deviceHostName_s,
    deviceSeverity_s,
    Message,
    name_s = "Successful Login",
    URL = strcat(
      customerURI_s,
      ":",
      name_s = iff(
        3rdparty,
        strcat(USE_CASE_NAME, " [3rd Party]"),
        USE_CASE_NAME
      ),
      ":",
      stage
    )


**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

