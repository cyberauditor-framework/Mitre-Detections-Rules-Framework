**technique_id**
T1078

**title**
Privileged Account Permissions Changed

**query**
let admin_users = (IdentityInfo
  | where TimeGenerated > ago(2d)
  | summarize arg_max(TimeGenerated, *) by AccountUPN
  | where AssignedRoles contains "admin" or GroupMembership has "Admin"
  | summarize by tolower(AccountUPN));
  AuditLogs
  | where Category =~ "RoleManagement"
  | where OperationName has "Add eligible member"
  | extend TargetUserPrincipalName = tostring(TargetResources[0].userPrincipalName)
  | where tolower(TargetUserPrincipalName) in (admin_users)
  | extend TargetAadUserId = tostring(TargetResources[0].id)
  | extend Group = tostring(TargetResources[0].displayName)
  | extend RoleAddedTo = iif(isnotempty(TargetUserPrincipalName), TargetUserPrincipalName, Group)
  | extend mod_props = TargetResources[0].modifiedProperties
  | extend InitiatingAppName = tostring(InitiatedBy.app.displayName)
  | extend InitiatingAppServicePrincipalId = tostring(InitiatedBy.app.servicePrincipalId)
  | extend InitiatingUserPrincipalName = tostring(InitiatedBy.user.userPrincipalName)
  | extend InitiatingAadUserId = tostring(InitiatedBy.user.id)
  | extend InitiatingIPAddress = tostring(InitiatedBy.user.ipAddress)
  | extend RoleAddedBy = iif(isnotempty(InitiatingAppName), InitiatingAppName, InitiatingUserPrincipalName)
  | mv-expand mod_props
  | where mod_props.displayName == "Role.DisplayName"
  | extend UserAgent = tostring(AdditionalDetails[0].value)
  | extend RoleAdded = tostring(parse_json(tostring(mod_props.newValue)))
  | extend TargetAccountName = tostring(split(TargetUserPrincipalName, "@")[0]), TargetAccountUPNSuffix = tostring(split(TargetUserPrincipalName, "@")[1])
  | extend InitiatingAccountName = tostring(split(InitiatingUserPrincipalName, "@")[0]), InitiatingAccountUPNSuffix = tostring(split(InitiatingUserPrincipalName, "@")[1])
  | project-reorder TimeGenerated, OperationName, TargetUserPrincipalName, RoleAddedTo, RoleAdded, RoleAddedBy, InitiatingUserPrincipalName, InitiatingAppName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

