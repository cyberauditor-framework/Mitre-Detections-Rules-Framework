**technique_id**
T1078

**title**
CyberProof - Azure - Connections From Russia - Success

**query**
let Successtype= dynamic( ["0","None"]);
let SuccessfulSignins = (tableName:string){
    table(tableName)
| where  TimeGenerated >= ago(10m) 
| extend failureReason_ = tostring(parse_json(Status).failureReason)
| where LocationDetails has_any("RU","Russia") and ( AuthenticationRequirement =="singleFactorAuthentication" and ResultType has_any (Successtype) or failureReason_ contains "conditional access"   )
| extend browser_ = parse_json(DeviceDetail).browser
| extend operatingSystem_ = parse_json(DeviceDetail).operatingSystem
| extend countryOrRegion = parse_json(LocationDetails).countryOrRegion
| extend location = strcat(parse_json(LocationDetails).city,"-",countryOrRegion)
| summarize make_set(failureReason_), total=count() , mintime = min(TimeGenerated) , maxtime = max(TimeGenerated) , makeset(AppDisplayName) ,  makeset(ResourceDisplayName) , makeset(UserAgent) , makeset(operatingSystem_) by IPAddress , UserPrincipalName , location , Type, ResultType, AuthenticationRequirement
};
let Signins_logs = SuccessfulSignins("SigninLogs");
let NonInteractive = SuccessfulSignins("AADNonInteractiveUserSignInLogs");
union isfuzzy=true Signins_logs , NonInteractive

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

