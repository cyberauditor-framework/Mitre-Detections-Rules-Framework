**technique_id**
T1078

**title**
UC632 - SAP HANA - Account Created And Deleted Within 24 Hours

**query**
//UC632 - SAP HANA - Account Created And Deleted Within 24 Hours
//Description: This UC detects when an account is created and then deleted within 24 hours in SAP HANA
//Mitre Tactics:TA0005
//Mitre Technique:T1078, T1070
let USE_CASE_NAME = "SAP HANA - Account Created And Deleted Within 24 Hours";
let UserCreatedTable = AxALiveStream_CL
  | where TimeGenerated >= ago(1d)
  | where deviceVendor_s == "SAP" and deviceProduct_s == "HANA DB"
  | where customerURI_s == "/All Customers/AXA/AXA Tech North Europe"
    and fileId_s endswith "P"
    and deviceCustomString1_s == "003_CRITICAL_USER_CHANGE"
    and deviceAction_s == "CREATE USER"
  | distinct
      time_created = TimeGenerated,
      customerURI_s,
      created_Username = toupper(destinationUserName_s),
      created_sourceUserName = sourceUserName_s,
      created_sourceUserIds = sourceUserId_s,
      created_sourceProcessName = sourceProcessName_s,
      created_from = strcat(
        sourceHostName_s,
        " (",
        sourceAddress_s,
        ")"
      );
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "SAP" and deviceProduct_s == "HANA DB"
| where customerURI_s == "/All Customers/AXA/AXA Tech North Europe"
  and fileId_s endswith "P"
  and deviceCustomString1_s == "003_CRITICAL_USER_CHANGE"
  and deviceAction_s == "DROP USER"
| extend dropped_Username = toupper(destinationUserName_s)
| join kind=inner UserCreatedTable
  on $left.dropped_Username == $right.created_Username
| where time_created <= TimeGenerated
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    name_s,
    Message = "This UC detects when an account is created and then deleted within 24 hours",
    customerURI_s,
    destinationUserName_s,
    deviceExternalId_s,
    fileId_s,
    sourceAddress_s,
    sourceHostName_s,
    sourceProcessName_s,
    sourceUserName_s,
    sourceUserId_s,
    deviceCustomString1Label_s = "sourceUserName from create event",
    deviceCustomString1_s = created_sourceUserName,
    deviceCustomString2Label_s = "sourceHostname and Address from create event",
    deviceCustomString2_s = created_from,
    deviceCustomString3Label_s = "sourceProcessName from create event",
    deviceCustomString3_s = created_sourceProcessName,
    deviceCustomString4Label_s = "sourceUserId from create event",
    deviceCustomString4_s = created_sourceUserIds,
    categoryBehavior_s = "Suspicious resource",
    categorySignificance_s = "Suspicious Activity",
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    galaxyListName_s,
    galaxyListReference_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

