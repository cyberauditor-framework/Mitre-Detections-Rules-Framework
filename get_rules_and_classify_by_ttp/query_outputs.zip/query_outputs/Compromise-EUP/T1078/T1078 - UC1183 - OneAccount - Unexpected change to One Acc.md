**technique_id**
T1078

**title**
UC1183 - OneAccount - Unexpected change to One Account settings

**query**
// UC1183 - OneAccount - Unexpected change to One Account settings
// Detects admin activity from an unexpected account
// Mitre Tactic: TA0001, TA0003, TA0004
// Mitre Technique: T1078, T1098, T1484
let USE_CASE_NAME = "OneAccount - Unexpected change to One Account settings";
let EventTypeTable = datatable
    (
    deviceFacility_s:string,
    deviceAction_s:string,
    Description:string
    )
  [
    "ADMIN",
    "DELETE",
    "has been deleted. Object deleted in the '",
    "ADMIN",
    "MODIFY",
    "has been updated. Object modified in the '",
    "ADMIN",
    "CREATE",
    "has been created/exported. Object created/exported in the '"
  ]
  ;
AxALiveStream_CL
| where TimeGenerated > ago(1h)
| where deviceVendor_s == "Ping" and deviceProduct_s == "Ping Identity"
| where deviceFacility_s == "ADMIN"
  and deviceAction_s has_any (
    "MODIFY",
    "CREATE",
    "DELETE"
  )
| join kind=leftouter EventTypeTable
  on deviceFacility_s, deviceAction_s
| where not(
    uc1183MainFilteringOut(
      account = destinationUserName_s,
      action = deviceAction_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    DestinationUserName = destinationUserName_s,
    DestinationUserPrivileges = destinationUserPrivileges_s,
    SourceIP = sourceAddress_s,
    Activity = strcat(
      "Resource in '",
      tolower(deviceFacility_s),
      "' facility ",
      Description,
      deviceEventClassId_s,
      "' configuration by ",
      destinationUserName_s,
      '.'
    ),
    DeviceEventClassID = deviceEventClassId_s,
    DeviceAction = deviceAction_s,
    Reason = reason_s,
    DeviceFacility = deviceFacility_s,
    FlexString1 = flexString1_s,
    galaxyListReference_s,
    galaxyListName_s,
    customerURI_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

