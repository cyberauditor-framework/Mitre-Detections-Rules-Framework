**technique_id**
T1078

**title**
CyberProof - Zscaler ZPA - New ZPA connection

**query**
let listUsers =
    ZPA_CL 
    | where TimeGenerated > ago(1d)
    | where InternalReason_s == "OPEN_OR_ACTIVE_CONNECTION"
    | where Policy_s !in ("Allow Internal Application Group", "Posture Allow", "SIPA Test Allow")
    | summarize ListofUsers = make_set(Username_s) by Username_s
    | project ListofUsers;
ZPA_CL
| where TimeGenerated >= ago(1h)
| where Username_s !in (listUsers)
| summarize EventCount = count() by Username_s
| where EventCount >= 200
| extend AccountCustomEntity = Username_s
| project-away AccountCustomEntity

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

