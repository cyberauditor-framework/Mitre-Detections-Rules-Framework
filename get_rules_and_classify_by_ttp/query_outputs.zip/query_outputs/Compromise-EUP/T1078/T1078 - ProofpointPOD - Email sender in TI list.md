**technique_id**
T1078

**title**
ProofpointPOD - Email sender in TI list

**query**
let dt_lookBack = 1h;
let ioc_lookBack = 14d;
ThreatIntelligenceIndicator
| where TimeGenerated >= ago(ioc_lookBack) and ExpirationDateTime > now()
| where Active == true
| where isnotempty(EmailSenderAddress)
| extend TI_emailEntity = EmailSenderAddress
// using innerunique to keep perf fast and result set low, we only need one match to indicate potential malicious activity that needs to be investigated
| join kind=innerunique (
       ProofpointPOD
       | where TimeGenerated >= ago(dt_lookBack)
       | where isnotempty(SrcUserUpn)
       | extend ProofpointPOD_TimeGenerated = TimeGenerated, ClientEmail = SrcUserUpn
)
on $left.TI_emailEntity == $right.ClientEmail
| where ProofpointPOD_TimeGenerated < ExpirationDateTime
| summarize ProofpointPOD_TimeGenerated = arg_max(ProofpointPOD_TimeGenerated, *) by IndicatorId, ClientEmail
| project ProofpointPOD_TimeGenerated, Description, IndicatorId, ThreatType, ExpirationDateTime, ConfidenceScore, ClientEmail
| extend timestamp = ProofpointPOD_TimeGenerated

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

