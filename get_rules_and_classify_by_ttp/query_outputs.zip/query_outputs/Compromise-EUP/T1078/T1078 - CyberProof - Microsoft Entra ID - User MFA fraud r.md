**technique_id**
T1078

**title**
CyberProof - Microsoft Entra ID - User MFA fraud reported

**query**
SigninLogs
| where Status contains "fraud"
//Exclusion for testing account
//| where UserPrincipalName !contains ""
//Filter data to include relevant information for alert.
| summarize
    AuthDetails=make_set(AuthenticationDetails),
    DeviceDetails=make_set(DeviceDetail),
    MFAdetails=make_set(MfaDetail), 
    Locations=make_set(LocationDetails),
    Useragents=make_set(UserAgent)
    by TimeGenerated, UserPrincipalName, IPAddress, tostring(Status)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

