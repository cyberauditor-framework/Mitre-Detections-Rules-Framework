**technique_id**
T1078

**title**
CyberProof - Azure Active Directory - Detected Risky Users - High

**query**
AADUserRiskEvents
| where RiskLevel == "high"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

