**technique_id**
T1078

**title**
CyberProof – Microsoft Entra ID - Detected Risky Users - High

**query**
AADUserRiskEvents
| where RiskLevel == "high"
| summarize make_set(RiskDetail), make_set(RiskEventType) by UserDisplayName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

