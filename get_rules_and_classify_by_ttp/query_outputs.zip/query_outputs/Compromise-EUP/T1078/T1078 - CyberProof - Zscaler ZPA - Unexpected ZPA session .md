**technique_id**
T1078

**title**
CyberProof - Zscaler ZPA - Unexpected ZPA session duration

**query**
let dt_lookBack = 24h;
let time_treshhold = timespan(08:00:00);
let open_sessions =
    ZPA_CL
    | where TimeGenerated > ago(dt_lookBack)
    | where InternalReason_s == 'OPEN_OR_ACTIVE_CONNECTION'
    | summarize timestampstart = min(TimeGenerated) by Username_s, ClientPublicIP_s, ConnectionID_s, Host_s
    | sort by timestampstart asc;
let closed_sessions =
    ZPA_CL
    | where TimeGenerated > ago(dt_lookBack)
    | where InternalReason_s == 'BRK_MT_TERMINATED'
    | summarize timestampend = max(TimeGenerated) by Username_s, ClientPublicIP_s, ConnectionID_s, Host_s
    | sort by timestampend asc;
open_sessions
| join (closed_sessions) on Username_s, ClientPublicIP_s, ConnectionID_s
| extend duration = timestampend - timestampstart
| where duration >= time_treshhold
| where Username_s !has "ZPA LSS"
| where Host_s !has "cepm.phillips66.net"
| extend IPCustomEntity = ClientPublicIP_s, AccountCustomEntity = Username_s
| project-away AccountCustomEntity, IPCustomEntity
| summarize ClientIPs = make_set(ClientPublicIP_s), UnexpectedDurations = make_set(duration), Hosts = make_set(Host_s) by Username_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

