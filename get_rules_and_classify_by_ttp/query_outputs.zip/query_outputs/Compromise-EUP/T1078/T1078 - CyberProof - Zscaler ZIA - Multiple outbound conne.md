**technique_id**
T1078

**title**
CyberProof - Zscaler ZIA - Multiple outbound connections to malicious URL

**query**
let threshold = 3;
CommonSecurityLog
| where Activity == "Reputation block outbound request: adware/spyware site"
| summarize 
sourceIPCount = dcount(SourceIP),
userCount = dcount(SourceUserName),
make_set(SourceUserName),
make_set(DestinationIP),
make_set(SourceIP),
make_set(DeviceAction)
 by RequestURL
 | project RequestURL, set_SourceUserName, userCount, set_DeviceAction, set_DestinationIP, set_SourceIP, sourceIPCount
 | where userCount > (threshold)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

