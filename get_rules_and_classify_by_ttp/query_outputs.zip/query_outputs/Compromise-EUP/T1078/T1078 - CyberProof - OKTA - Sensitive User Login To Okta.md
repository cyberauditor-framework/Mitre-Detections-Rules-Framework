**technique_id**
T1078

**title**
CyberProof - OKTA - Sensitive User Login To Okta

**query**
Okta_CL
| where eventType_s == 'user.session.start' // Event indicating a user login
| where actor_displayName_s contains 'Admin' // Assuming there is a field that flags sensitive users
| extend Location = strcat(client_geographicalContext_city_s, "-", client_geographicalContext_country_s)
| summarize IP = make_set(client_ipAddress_s), Location = make_set(Location)
    by
    actor_alternateId_s, actor_displayName_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

