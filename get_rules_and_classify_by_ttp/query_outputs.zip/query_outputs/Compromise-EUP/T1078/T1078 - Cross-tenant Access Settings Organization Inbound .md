**technique_id**
T1078

**title**
Cross-tenant Access Settings Organization Inbound Direct Settings Changed

**query**
//In User & Groups and in Applications, the following "AccessType" values in columns PremodifiedInboundSettings and ModifiedInboundSettings are interpreted accordingly:
// When Access Type in premodified inbound settings value was 1 that means that the initial access was allowed. When Access Type in premodified inbound settings value was 2 that means that the initial access was blocked. 
// When Access Type in modified inbound settings value is 1 that means that now access is allowed. When Access Type in modified inbound settings value is 2 that means that now access is blocked. 
AuditLogs
| where OperationName has "Update a partner cross-tenant access setting"
| mv-apply TargetResource = TargetResources on
  (
      where TargetResource.type =~ "Policy"
      | extend Properties = TargetResource.modifiedProperties
  )
| mv-apply Property = Properties on
  (
      where Property.displayName =~ "b2bDirectConnectInbound"
      | extend PremodifiedInboundSettings = trim('"',tostring(Property.oldValue)),
               ModifiedInboundSettings = trim(@'"',tostring(Property.newValue))
  )
| extend InitiatedByActionUserInformation = iff(isnotempty(InitiatedBy.user.userPrincipalName), InitiatedBy.user.userPrincipalName, InitiatedBy.app.displayName)
| extend InitiatedByIPAdress = InitiatedBy.user.ipAddress
| where PremodifiedInboundSettings != ModifiedInboundSettings
| extend Name = tostring(split(InitiatedByActionUserInformation,'@',0)[0]), UPNSuffix = tostring(split(InitiatedByActionUserInformation,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

