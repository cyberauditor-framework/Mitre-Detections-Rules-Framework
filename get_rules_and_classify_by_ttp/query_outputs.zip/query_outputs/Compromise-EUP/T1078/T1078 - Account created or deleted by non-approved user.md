**technique_id**
T1078

**title**
Account created or deleted by non-approved user

**query**
// Add non-approved user principal names to the list below to search for their account creation/deletion activity
// ex: dynamic(["UPN1", "upn123"])
let nonapproved_users = dynamic([]);
AuditLogs
| where OperationName =~ "Add user" or OperationName =~ "Delete user"
| where Result =~ "success"
| extend InitiatingUser = tostring(InitiatedBy.user.userPrincipalName)
| where InitiatingUser has_any (nonapproved_users)
| project-reorder TimeGenerated, ResourceId, OperationName, InitiatingUser, TargetResources
| extend InitiatedUserIpAddress = tostring(InitiatedBy.user.ipAddress)
| extend Name = tostring(split(InitiatingUser,'@',0)[0]), UPNSuffix = tostring(split(InitiatingUser,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

