**technique_id**
T1078

**title**
CyberProof - Cisco ASA - User Account Modification

**query**
let modification_user_events=datatable(Event:string, description:string, ) [
'502101' , 'User Added',
'502102','User Deleted',
'502103', 'User privilege changed'
];
CommonSecurityLog_CL
| where TimeGenerated >= ago(5m) 
| where  DeviceVendor_s == 'Cisco' and DeviceProduct_s == 'ASA'
| join kind=inner modification_user_events on $left.DeviceEventClassID_s == $right.Event
| extend _QueryFunction = "Cyberproof_Cisco_ASA_User_Account_Modifications"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

