**technique_id**
T1078

**title**
Cross-tenant Access Settings Organization Added

**query**
// Tenants IDs can be found by navigating to Azure Active Directory then from menu on the left, select External Identities, then from menu on the left, select Cross-tenant access settings and from the list shown of Tenants
let ExpectedTenantIDs = dynamic(["List of expected tenant IDs","Tenant ID 2"]);
AuditLogs
| where OperationName has "Add a partner to cross-tenant access setting"
| extend InitiatedByActionUserInformation = iff(isnotempty(InitiatedBy.user.userPrincipalName), InitiatedBy.user.userPrincipalName, InitiatedBy.app.displayName)
| extend InitiatedByIPAdress = InitiatedBy.user.ipAddress
| mv-apply TargetResource = TargetResources on
  (
      where TargetResource.type =~ "Policy"
      | extend Properties = TargetResource.modifiedProperties
  )
| mv-apply Property = Properties on
  (
      where Property.displayName =~ "tenantId"
      | extend ExtTenantIDAdded = trim('"',tostring(Property.newValue))
  )
| where ExtTenantIDAdded !in (ExpectedTenantIDs)
| extend Name = tostring(split(InitiatedByActionUserInformation,'@',0)[0]), UPNSuffix = tostring(split(InitiatedByActionUserInformation,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

