**technique_id**
T1078

**title**
CyberProof - CyberArk - Usage of Disabled or Expired User

**query**
CommonSecurityLog
| where DeviceVendor == "Cyber-Ark" and DeviceAction !="" 
| where DeviceEventClassID=="103" or DeviceEventClassID=="104"  
| project   SourceHostName, 
            SourceUserName, 
            DestinationUserName, 
            DestinationHostName, 
            DeviceEventClassID, 
            DeviceAction, 
            LogSeverity, 
            DeviceEventCategory, 
            DeviceName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

