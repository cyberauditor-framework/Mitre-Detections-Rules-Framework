**technique_id**
T1078

**title**
Github - Two factor authentication is disabled (enterprise)

**query**
Github_CL
| where action_s == 'business.disable_two_factor_requirement'
| summarize
    Total = count(),
    FirstSeen = min(TimeGenerated),
    LastSeen = max(TimeGenerated),
    Repos = make_set(repo_s, 100),
    User_Agents = make_set(user_agent_s, 10),
    Actions = make_set(action_s, 10)
    by actor_s, business_s
| extend TotalRepos = array_length(Repos), TimeDifference = LastSeen - FirstSeen
| extend AccountCustomEntity = actor_s
//filter out known bots
//| where not(actor_s has_any ('dih-studio-jdf-app[bot]', 'self-hosted-renovate-bot[bot]', 'github-actions[bot]', 'cytric-devsecops[bot]', 'dih-studio-app[bot]', 'dependabot[bot]', 'renovate[bot]', 'mccp-customer-configuration-writer[bot]','cloud-native-jdf-renovate-bot[bot]'))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

