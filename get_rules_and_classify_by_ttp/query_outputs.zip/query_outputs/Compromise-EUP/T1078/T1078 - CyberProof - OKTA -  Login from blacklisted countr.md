**technique_id**
T1078

**title**
CyberProof - OKTA -  Login from blacklisted country

**query**
let timeframe = 5m; 
let bl_countries = dynamic(['Afghanistan', 'Myanmar', 'Belarus', 'Central African Republic', 'Democratic Republic of the Congo', 'Eritrea', 'Haiti', 'Iran', 'Iraq', 'Kyrgyzstan', 'Lebanon', 'Libya', 'North Korea', 'Somalia', 'Sudan', 'Syria', 'Zimbabwe', 'South Sudan', 'GNRepublic of Guinea', 'Liberia', 'Guinea-Bissau']);
//List of countries from which you do not expect connections 
// Afghanistan,Belarus,Central African Republic,Democratic Republic of the Congo,Eritrea,Iran,Iraq,Kyrgyzstan,Lebanon,Libya,North Korea,Russia,Somalia,Sudan,Syria,Zimbabwe,South Sudan,Republic of Guinea,Liberia,Guinea-Bissau
Okta_CL
| where column_ifexists('published_t', now()) >= timeframe
| where eventType_s =~ "user.session.start"
| where outcome_result_s =~ "SUCCESS"
| where client_geographicalContext_country_s in ('bl_countries')
| summarize
    StartTime = min(TimeGenerated),
    EndTime = max(TimeGenerated),
    NumOfCountries = dcount(column_ifexists('client_geographicalContext_country_s', int(null)))
    by actor_alternateId_s, client_geographicalContext_country_s
| extend timestamp = StartTime
| extend AccountCustomEntity = actor_alternateId_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

