**technique_id**
T1078

**title**
Cross-tenant Access Settings Organization Deleted

**query**
AuditLogs
| where OperationName has "Delete partner specific cross-tenant access setting"
| extend InitiatedByActionUserInformation = iff(isnotempty(InitiatedBy.user.userPrincipalName), InitiatedBy.user.userPrincipalName, InitiatedBy.app.displayName)
| extend InitiatedByIPAdress = InitiatedBy.user.ipAddress
| mv-apply TargetResource = TargetResources on
  (
      where TargetResource.type =~ "Policy"
      | extend Properties = TargetResource.modifiedProperties
  )
| mv-apply Property = Properties on
  (
      where Property.displayName =~ "tenantId"
      | extend ExtTenantDeleted = trim('"',tostring(Property.oldValue))
  )
| extend Name = tostring(split(InitiatedByActionUserInformation,'@',0)[0]), UPNSuffix = tostring(split(InitiatedByActionUserInformation,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

