**technique_id**
T1078

**title**
Guest accounts added in Entra ID Groups other than the ones specified

**query**
// OBJECT ID of AAD Groups can be found by navigating to Azure Active Directory then from menu on the left, select Groups and from the list shown of AAD Groups, the Second Column shows the ObjectID of each
let GroupIDs = dynamic(["List with Custom AAD GROUP OBJECT ID 1","Custom AAD GROUP OBJECT ID 2"]);
AuditLogs
| where OperationName in ('Add member to group', 'Add owner to group')
| extend InitiatingAppName = tostring(InitiatedBy.app.displayName)
| extend InitiatingAppServicePrincipalId = tostring(InitiatedBy.app.servicePrincipalId)
| extend InitiatingUserPrincipalName = tostring(InitiatedBy.user.userPrincipalName)
| extend InitiatingAadUserId = tostring(InitiatedBy.user.id)
| extend InitiatingIpAddress = tostring(iff(isnotempty(InitiatedBy.user.ipAddress), InitiatedBy.user.ipAddress, InitiatedBy.app.ipAddress))
// Uncomment the following line to filter events where the inviting user was a guest user
//| where InitiatedBy has_any ("CUSTOM DOMAIN NAME#", "#EXT#")
| mv-apply TargetResource = TargetResources on 
  (
      where TargetResource.type =~ "User"
      | extend InvitedUserPrincipalName = trim(@'"',tostring(TargetResource.userPrincipalName)),
               Properties = TargetResource.modifiedProperties
  )
| mv-apply Property = Properties on 
  (
      where Property.displayName =~ "Group.DisplayName"
      | extend AADGroup = trim('"',tostring(Property.newValue))
  )
| where InvitedUserPrincipalName has_any ("CUSTOM DOMAIN NAME#", "#EXT#")
| mv-apply Property = Properties on
   (
     where Property.displayName =~ "Group.ObjectID"
     | extend AADGroupId = trim('"',tostring(Property.newValue))
   )
| project-away TargetResource, Property
| where AADGroupId !in (GroupIDs)
| extend Name = tostring(split(InitiatingUserPrincipalName,'@',0)[0]), UPNSuffix = tostring(split(InitiatingUserPrincipalName,'@',1)[0])
| extend InvitedUserName = tostring(split(InvitedUserPrincipalName,'@',0)[0]), InvitedUPNSuffix = tostring(split(InvitedUserPrincipalName,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

