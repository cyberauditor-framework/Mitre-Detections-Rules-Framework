**technique_id**
T1078

**title**
UC988 - AWS - Root Credentials Usage Detected

**query**
// UC988 - AWS - Root Credentials Usage Detected
// Detects AWS root account usage
// Mitre Tactic: TA0004
// Mitre Technique: T1078, T1098
let USE_CASE_NAME = "AWS - Root Credentials Usage Detected";
AWSCloudTrail_Events
| where TimeGenerated >= ago(1h)
| where UserIdentityType == "Root"
| where not(
    uc988MainFilteringOut(
      event_id = tostring(EventTypeName),
      ip = tostring(SourceIpAddress)
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = UserIdentityUserName,
      destination_account = UserIdentityUserName,
      source_ip = SourceIpAddress,
      destination_ip = SourceIpAddress
    )
| extend name_s = iff(
      3rdparty,
      (strcat (USE_CASE_NAME, " [3rd Party]")),
      USE_CASE_NAME
    )
| summarize
    totalUsage = count(),
    eventNames = make_set(EventName, 10)
  by
    customerURI_s,
    Galaxy_List_Name_s,
    Galaxy_List_Reference_s,
    SourceIpAddress,
    UserIdentityType,
    EventTypeName,
    EventName,
    UserIdentityAccountId,
    AWSAccountID = RecipientAccountId,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )
| project
    TotalUsage = totalUsage,
    EventNames = eventNames,
    customerURI_s,
    Galaxy_List_Name_s,
    Galaxy_List_Reference_s,
    SourceIpAddress,
    UserIdentityType,
    EventTypeName,
    EventName,
    UserIdentityAccountId,
    AWSAccountID,
    URL,
    AlertMessage = strcat(
      "AWS Root account usage was detected from ",
      SourceIpAddress,
      " on the Account ID",
      AWSAccountID,
      " with ",
      tostring(eventNames),
      " events(s)."
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

