**technique_id**
T1078

**title**
SecurityEvent - User account created and deleted within 10 mins

**query**
let timeframe = 3d;
let spanoftime = 10m;
let threshold = 0;
SecurityEvent 
| where TimeGenerated > ago(2*timeframe) 
// A user account was created
| where EventID == 4720
| where AccountType =~ "User"
| project creationTime = TimeGenerated, CreateEventID = EventID, Activity, Computer, TargetUserName, UserPrincipalName, 
AccountUsedToCreate = SubjectUserName, TargetSid, SubjectUserSid 
| join kind= inner (
  SecurityEvent
  | where TimeGenerated > ago(timeframe) 
  // A user account was deleted 
  | where EventID == 4726
| where AccountType == "User"
| project deletionTime = TimeGenerated, DeleteEventID = EventID, Activity, Computer, TargetUserName, UserPrincipalName, 
AccountUsedToDelete = SubjectUserName, TargetSid, SubjectUserSid 
) on Computer, TargetUserName
| where deletionTime - creationTime < spanoftime
| extend TimeDelta = deletionTime - creationTime
| where tolong(TimeDelta) >= threshold
| where AccountUsedToCreate != "AAQ1994"
| project TimeDelta, creationTime, CreateEventID, Computer, TargetUserName, UserPrincipalName, AccountUsedToCreate, 
deletionTime, DeleteEventID, AccountUsedToDelete
| extend timestamp = creationTime, AccountCustomEntity = AccountUsedToCreate, HostCustomEntity = Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

