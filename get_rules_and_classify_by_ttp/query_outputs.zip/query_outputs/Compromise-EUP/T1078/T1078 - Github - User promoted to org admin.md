**technique_id**
T1078

**title**
Github - User promoted to org admin

**query**
Github_CL
| where action_s == 'org.update_member' or action_s == 'org.add_member'
| where permission_s ==  'admin'
| extend AccountCustomEntity = actor_s, User_Promoted = user_s
//filter out known bots
//| where not(actor_s has_any ('dih-studio-jdf-app[bot]', 'self-hosted-renovate-bot[bot]', 'github-actions[bot]', 'cytric-devsecops[bot]', 'dih-studio-app[bot]', 'dependabot[bot]', 'renovate[bot]', 'mccp-customer-configuration-writer[bot]','cloud-native-jdf-renovate-bot[bot]'))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

