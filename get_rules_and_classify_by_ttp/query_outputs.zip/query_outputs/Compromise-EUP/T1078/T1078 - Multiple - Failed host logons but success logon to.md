**technique_id**
T1078

**title**
Multiple - Failed host logons but success logon to AzureAD

**query**
let timeframe = 1d;
//Adjust this threshold to fit environment
let signin_threshold = 5; 
//Make a list of IPs with failed Windows host logins above threshold
let win_fails = 
SecurityEvent
| where TimeGenerated >= ago(timeframe)
| where EventID == 4625
| where LogonType in (10, 7, 3)
| where IpAddress != "-"
| summarize count() by IpAddress
| where count_ > signin_threshold
| summarize make_list(IpAddress);
//Make a list of IPs with failed *nix host logins above threshold
let nix_fails = 
Syslog
| where TimeGenerated > ago(timeframe)
| where Facility contains 'auth' and ProcessName != 'sudo'
| extend SourceIP = extract("(([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})\\.(([0-9]{1,3})))",1,SyslogMessage)
| where SourceIP != "" and SourceIP != "127.0.0.1"
| summarize count() by SourceIP
| where count_ > signin_threshold
| summarize make_list(SourceIP);
//See if any of the IPs with failed host logins hve had a sucessful Azure AD login
SigninLogs
| where TimeGenerated > ago(timeframe)
| where ResultType !in ("0", "50125", "50140")
| where IPAddress in (win_fails) or IPAddress in (nix_fails)
| extend Reason=  "Multiple failed host logins from IP address with successful Azure AD login"
| extend timstamp = TimeGenerated, AccountCustomEntity = UserPrincipalName, IPCustomEntity = IPAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

