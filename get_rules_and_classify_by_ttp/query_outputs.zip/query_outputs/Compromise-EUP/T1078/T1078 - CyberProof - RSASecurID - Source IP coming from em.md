**technique_id**
T1078

**title**
CyberProof - RSASecurID - Source IP coming from embargo country

**query**
let timeRange = 10m;
let IP_Data = external_data(network:string,geoname_id:long,continent_code:string,continent_name:string ,country_iso_code:string,country_name:string,is_anonymous_proxy:bool,is_satellite_provider:bool)
  ['https://raw.githubusercontent.com/datasets/geoip2-ipv4/master/data/geoip2-ipv4.csv'];
let embargo_countries = dynamic(["North Korea","Cuba","Iran","Syria","Venezuela","Russia","Bangladesh","Belarus","Central African Republic","China","Congo","Eritrea","Hong Kong",
                                  "Iraq","Lebanon","Liberia","Mali","Republic of Moldova","Myanmar [Burma]","Nicaragua","Somalia","South Sudan","Turkey","Ukraine","Venezuela","Yemen"
                                  "Zimbabwe","Afghanistan","Palestine","Libya","Sudan"]);
RSASecurIDAMEvent
| where TimeGenerated >= ago(timeRange)
| evaluate ipv4_lookup(IP_Data, SrcIpAddr, network, return_unmatched = true)
| where country_name in (embargo_countries)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

