**technique_id**
T1078

**title**
CyberProof -  Microsoft Entra ID - Microsoft Entra ID Role Management Permission Grant

**query**
AuditLogs
| where Category =~ "ApplicationManagement" and LoggedByService =~ "Core Directory" and OperationName in~ ("Add delegated permission grant", "Add app role assignment to service principal")
| mv-apply TargetResource = TargetResources on 
  (
      where TargetResource.type =~ "ServicePrincipal" and array_length(TargetResource.modifiedProperties) > 0 and isnotnull(TargetResource.displayName)
      | extend props = TargetResource.modifiedProperties
  )
| mv-apply Property = props on 
  (
      where Property.displayName in~ ("AppRole.Value","DelegatedPermissionGrant.Scope")
      | extend DisplayName = tostring(Property.displayName), PermissionGrant = trim('"',tostring(Property.newValue))
  )
| where PermissionGrant has "RoleManagement.ReadWrite.Directory"
| mv-apply Property = props on 
  (
      where Property.displayName =~ "ServicePrincipal.DisplayName"
      | extend AppDisplayName = trim('"',tostring(Property.newValue))
  )
| mv-apply Property = props on 
  (
      where Property.displayName =~ "ServicePrincipal.ObjectID"
      | extend AppServicePrincipalId = trim('"',tostring(Property.newValue))
  )
| extend 
    Initiator = iif(isnotempty(InitiatedBy.app), tostring(InitiatedBy.app.displayName), tostring(InitiatedBy.user.userPrincipalName)),
    InitiatorId = iif(isnotempty(InitiatedBy.app), tostring(InitiatedBy.app.servicePrincipalId), tostring(InitiatedBy.user.id))
| project TimeGenerated, OperationName, Result, PermissionGrant, AppDisplayName, AppServicePrincipalId, Initiator, InitiatorId, InitiatedBy, TargetResources, AdditionalDetails, CorrelationId
| extend Name = tostring(split(Initiator,'@',0)[0]), UPNSuffix = tostring(split(Initiator,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

