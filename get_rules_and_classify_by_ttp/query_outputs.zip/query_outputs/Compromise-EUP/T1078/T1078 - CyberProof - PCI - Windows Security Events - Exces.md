**technique_id**
T1078

**title**
CyberProof - PCI - Windows Security Events - Excessive User Locked out

**query**
let timeRange = 1d;
let threshold = 50;
let PCIIPs = dynamic(['10.96.25.81', '10.96.25.82', '10.96.25.83', '10.96.25.84', '10.96.25.85', '10.96.25.86', '10.96.25.87', '10.96.25.88', '10.96.25.89', '10.97.0.228', '10.97.0.227', '148.89.244.233', '10.239.34.100', '148.89.222.191', '148.89.194.8', '148.89.194.9', '148.89.254.133', '148.89.254.134', '148.89.254.132']);
let PCIHosts = dynamic(['BRT-PCIAdmin', 'BRT-PCIRicci', 'BRT-PCIKristah', 'BRT-PCIREBCEW', 'BRT-PCIkmgrn', 'BRT-PCIMaricm', 'brtab07pcisw1', 'brtabb53pcisw1', 'brtdc-pcifw1', 'brtdc-pcifw1', 'brtdc-pcifw2', 'brtdc-pcifw2', 'Brtsecap10', 'awsuxace01p', 'brtdcnacadm1', 'brtntp1', 'brtntp2', 'brtdc-pcifw12-vip', 'brtdc-pcifw1-dmz', 'brt-65985356k', 'brt-pcitemp1', 'brt-22ef-pci', 'brt-2422432880k', 'brt-2189147480k', 'brt-2214456900k', 'brt-2224125140k', 'es-phillips66.splunkcloud.com']);
SecurityEvent
| where TimeGenerated >= ago(timeRange) and EventID == "4740"
| where Computer has_any (PCIHosts) or IpAddress has_any (PCIIPs)
| extend StringEventID = tostring(EventID)
| summarize make_set(Computer), make_set(IpAddress), accountLockoutCount = count() by TargetUserName, Activity
| where accountLockoutCount >= (threshold)
| extend AccountCustomEntity = TargetUserName
| extend HostCustomEntity = tostring(set_Computer)
| extend IPCustomEntity = tostring(set_IpAddress)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

