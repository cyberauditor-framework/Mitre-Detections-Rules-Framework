**technique_id**
T1078

**title**
BEC - Account Elevated to New Role

**query**
AuditLogs
  | where TimeGenerated between(ago(14d)..ago(1d))
  | where OperationName =~ "Add member to role completed (PIM activation)"
  | where Result =~ "success"
  | extend ElevatedUser = tostring(TargetResources[2].userPrincipalName)
  | extend displayName = tostring(TargetResources[0].displayName)
  | extend displayName2 = tostring(TargetResources[3].displayName)
  | extend ElevatedRole = iif(displayName =~ "Member", displayName2, displayName)
  | join kind = rightanti (AuditLogs
  | where TimeGenerated > ago(1d)
  | where OperationName =~ "Add member to role completed (PIM activation)"
  | where Result =~ "success"
  | extend ElevatedUser = tostring(TargetResources[2].userPrincipalName)
  | extend displayName = tostring(TargetResources[0].displayName)
  | extend displayName2 = tostring(TargetResources[3].displayName)
  | extend ElevatedRole = iif(displayName =~ "Member", displayName2, displayName)
  | extend ElevatedBy = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)) on ElevatedRole, ElevatedUser
  | project-reorder ElevatedUser, ElevatedRole, ResultReason,ElevatedBy

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

