**technique_id**
T1078

**title**
CyberProof - SQL - Failed Logon Attempts on SQL Server

**query**
let watchlist = (_GetWatchlist('septodone_SQL_server_list')| project IP);

SecurityEvent
| where TimeGenerated >= ago(30d)
| where EventID  == '4625'
| where  IpAddress in (watchlist)
| where Account != '\\'
| summarize total = count() , mintime = min(TimeGenerated) , maxtime = max(TimeGenerated), make_set(AccountName) by IpAddress 
| where total >= 10

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

