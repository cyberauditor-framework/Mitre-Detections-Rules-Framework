**technique_id**
T1078

**title**
CyberProof - Azure Backup Services - Excessive Vault Creation

**query**
let timerange = 1h;
let creationThreshold = 3;
AzureActivity
| where TimeGenerated >= ago(timerange)
| where OperationNameValue =~ "MICROSOFT.RECOVERYSERVICES/VAULTS/WRITE"
| extend ResourceName = tostring(parse_json(Properties).resource)
| summarize
    CallerIpAddress = make_set(CallerIpAddress),
    ActivityStatusValue = make_set(ActivityStatusValue),
    ActivitySubstatusValue = make_set(ActivitySubstatusValue),
    resourceCreationCount = count()
    by Caller, ResourceName
| where ActivitySubstatusValue contains "Created"
| where resourceCreationCount >= (creationThreshold)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

