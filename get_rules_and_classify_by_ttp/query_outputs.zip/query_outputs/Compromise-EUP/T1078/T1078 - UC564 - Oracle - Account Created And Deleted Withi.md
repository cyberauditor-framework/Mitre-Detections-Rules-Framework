**technique_id**
T1078

**title**
UC564 - Oracle - Account Created And Deleted Within 24 Hours

**query**
// UC564 - Oracle - Account Created And Deleted Within 24 Hours
// Description: This UC detects when an account is created and then deleted within 24 hours in Oracle
// Mitre Tactics: TA0005
// Mitre Technique: T1078, T1070
let USE_CASE_NAME = "Oracle - Account Created And Deleted Within 24 Hours";
let UserCreatedTable = AxALiveStream_CL
  | where TimeGenerated >= ago(1d)
  | where deviceVendor_s =~ "Oracle" and deviceProduct_s == "Unified Audit Trail"
  | where reason_s == "0"
  | where name_s == "CREATE USER" or deviceAction_s == "CREATE USER"
  | extend created_Username = extract(@'create\s+user\s+(?:\\")?(.*?)(?:\\")?(?:\s+identified)?$', 1, tolower(Message))
  | distinct
      time_created = TimeGenerated,
      deviceHostName_s,
      deviceAddress_s,
      deviceExternalId_s,
      customerURI_s,
      created_Username,
      galaxyListName_s,
      galaxyListReference_s
  ;
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s =~ "Oracle" and deviceProduct_s == "Unified Audit Trail"
| where reason_s == "0"
| where name_s == "DROP USER" or deviceAction_s == "DROP USER"
| extend dropped_Username = extract(@'drop\s+user\s+(?:\\")?(.*?)(?:\\")?(?:\s+cascade)?$', 1, tolower(Message))
| join
    kind=inner (UserCreatedTable)
  on
    deviceHostName_s,
    deviceAddress_s,
    deviceExternalId_s,
    customerURI_s,
    $left.dropped_Username == $right.created_Username
| where time_created < TimeGenerated
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryBehavior = "/Authentication/Verify",
    categorySignificance = "/Informational/Warning",
    customerURI_s,
    deviceProduct_s,
    deviceVendor_s,
    name_s,
    reason_s,
    deviceProcessName_s,
    destinationUserName_s,
    deviceAddress_s,
    deviceExternalId_s,
    deviceEventClassId_s,
    requestClientApplication_s,
    deviceCustomString6_s,
    deviceCustomString6Label_s,
    sourceUserName_s,
    deviceCustomString4_s,
    deviceCustomString4Label_s,
    destinationUserPrivileges_s,
    deviceCustomString3_s,
    deviceCustomString3Label_s,
    deviceHostName_s,
    message = "This UC detects when an account is created and then deleted within 24 hours",
    dropped_Username,
    destinationAddress_s,
    destinationHostName_s,
    galaxyListName_s,
    galaxyListReference_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

