**technique_id**
T1078

**title**
CyberProof - Nutanix - Failed login attempt to Nutanix UI from Different ip's

**query**
CLCSyslog_CL
| where SyslogMessage_s contains "hassogba-adm"
| extend user = extract(@'\s+User\s+([^ ]*)',1,SyslogMessage_s) , source_ip = extract(@'\s+ip\s+([^ ]*)',1,SyslogMessage_s)
| summarize count() , dcount(source_ip) , makeset(source_ip) by  user 
| where dcount_source_ip > 1

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

