**technique_id**
T1078

**title**
UC982 - Netscaler - Failed login attempts for a logged in user

**query**
//UC982 - Netscaler - Failed login attempts for a logged in user
//This UC detects failed login attempts for a logged in user
//Mitre Tactic: TA0001
//Mitre Technique: T1078
let USE_CASE_NAME = "Netscaler - Failed login attempts for a logged in user";
let ActiveConnectionTable = AxALiveStream_CL
  | where TimeGenerated >= ago(1h)
  | where deviceVendor_s == "Citrix" and deviceProduct_s == "NetScaler"
  | where categoryBehavior_s == "/Communicate/Response"
    and deviceEventClassId_s == "SSLVPN TCPCONNSTAT"
    and deviceAction_s == "Allowed"
  | extend
      domain = extract(
        @"([^\\]+)\\\\",
        1,
        sourceUserName_s
      )
  | extend
      sourceUserName_s = iff(
        isnotempty(domain),
        extract(@"\\([^\\]+)$", 1, toupper(extract(@"\w+\s+([^\@]+)\@", 1, Message))),
        toupper(extract(@"\w+\s+([^\@]+)\@", 1, Message))
      ),
      sourceAddress_s = extract(@"\@(\d+\.\d+\.\d+\.\d+)", 1, Message)
  | summarize
      count(),
      loginTime = max(TimeGenerated),
      logonIP = make_set(sourceAddress_s, 1000)
    by
      sourceUserName_s
;
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Citrix" and deviceProduct_s == "NetScaler"
| where categoryBehavior_s == "/Authentication/Verify"
  and deviceEventClassId_s == "AAA LOGIN_FAILED"
| extend domain = extract(
      @"([^\\]+)\\\\",
      1,
      sourceUserName_s
    )
| extend sourceUserName_s = iff(
      isnotempty(domain),
      extract(
        @"\\([^\\]+)$",
        1,
        sourceUserName_s
      ),
      sourceUserName_s
    )
| lookup kind=inner ActiveConnectionTable
    on sourceUserName_s
| where datetime_diff(
    "minute",
    TimeGenerated,
    loginTime
  )
  between (0 .. 30)
  and TimeGenerated >= loginTime
| where not(
    uc982MainFilteringOut(
      account = sourceUserName_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = "",
      source_ip = sourceAddress_s,
      destination_ip = ""
    )
| project
    TimeGenerated,
    ["Last Connection Time"] = loginTime,
    customerURI_s,
    sourceAddress_s = translate(
      "\\[\\]\"",
      "",
      strcat(
        "Successful connection: ",
        logonIP,
        ", ",
        "Failed attempt: ",
        sourceAddress_s
      )
    ),
    sourceUserName_s,
    deviceEventClassId_s,
    reason_s,
    sourceNtDomain_s = iff(
      isnotempty(domain),
      domain,
      "Domain not available in raw log"
    ),
    deviceHostName_s,
    deviceSeverity_s,
    categoryBehavior_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s = iff(
        3rdparty,
        strcat(USE_CASE_NAME, " [3rd Party]"),
        USE_CASE_NAME
      ),
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

