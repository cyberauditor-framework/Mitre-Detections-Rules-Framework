**technique_id**
T1078

**title**
CyberProof - Okta - User Login from Different Countries within 3 hours

**query**
let timeframe = ago(3h);
let threshold = 2;
OktaSSO
| where column_ifexists('published_t', now()) >= timeframe
| where eventType_s =~ "user.session.start"
| where outcomeResult_s =~ "SUCCESS"
| summarize StartTime = min(TimeGenerated), EndTime = max(TimeGenerated), NumOfCountries = dcount(column_ifexists('client_geographicalContext_country_s', int(null))) by actorAlternateId_s
| where NumOfCountries >= threshold
| extend timestamp = StartTime, AccountCustomEntity = actorAlternateId_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

