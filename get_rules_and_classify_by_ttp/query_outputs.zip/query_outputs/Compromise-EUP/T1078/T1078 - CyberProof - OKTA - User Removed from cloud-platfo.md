**technique_id**
T1078

**title**
CyberProof - OKTA - User Removed from cloud-platform-admin Group

**query**
Okta_CL
| where eventType_s == 'group.user_membership.remove' // Assuming this is the event type for group membership removal
| where parse_json(target_s)[1].displayName contains 'cloud-platform-admin' // The name of the group to check for
| project
    TimeGenerated,
    actor_alternateId_s,
    actor_displayName_s,
    client_ipAddress_s,
    client_geographicalContext_city_s,
    client_geographicalContext_country_s
| extend Location = strcat(client_geographicalContext_city_s, "-", client_geographicalContext_country_s)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

