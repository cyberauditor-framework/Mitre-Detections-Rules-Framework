**technique_id**
T1078

**title**
CyberProof - CyberArk - FETTJA Account Usage

**query**
CommonSecurityLog
| where DeviceVendor == "Cyber-Ark"
| where SourceUserName contains "fettja@PHILLIPS66.NET" or DestinationUserName contains "fettja@PHILLIPS66.NET"
| project   SourceHostName, 
            SourceUserName, 
            DestinationUserName, 
            DestinationHostName, 
            DeviceEventClassID, 
            DeviceAction, 
            LogSeverity, 
            DeviceEventCategory, 
            DeviceName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

