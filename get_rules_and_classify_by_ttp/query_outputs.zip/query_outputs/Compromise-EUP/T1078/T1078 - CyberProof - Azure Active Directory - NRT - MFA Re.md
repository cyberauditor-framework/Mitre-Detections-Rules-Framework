**technique_id**
T1078

**title**
CyberProof - Azure Active Directory - NRT - MFA Rejected by User

**query**
let Threshold = 3;
let UserEventCount =
SigninLogs
| where ResultType == 500121
| extend AdditionalDetails = tostring(Status.additionalDetails)
| where AdditionalDetails =~ "MFA denied; user declined the authentication"
| summarize count() by UserPrincipalName;
SigninLogs
| where ResultType == 500121
| extend AdditionalDetails = tostring(Status.additionalDetails)
| where AdditionalDetails =~ "MFA denied; user declined the authentication"
| summarize 
TimesGenerated=makeset(TimeGenerated), 
AuthenticationDetails=makeset(AuthenticationDetails), 
AuthenticationRequirementPolicies=makeset(AuthenticationRequirementPolicies),
ConditionalAccessPolicies=makeset(ConditionalAccessPolicies),
DeviceDetail=makeset(DeviceDetail),
MfaDetail=makeset(MfaDetail),
ResourceDisplayName=makeset(ResourceDisplayName),
UserAgents=makeset(UserAgent),
UniqueTokenIdentifier=makeset(UniqueTokenIdentifier)
by Identity, UserPrincipalName, IPAddress, Location, Category, ResultType, ResultDescription, ConditionalAccessStatus, CorrelationId, AdditionalDetails
|join kind=inner (
UserEventCount
) on UserPrincipalName
| project-rename Count=count_,IPLocation = Location
| where Count >= 3

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

