**technique_id**
T1078

**title**
CyberProof - SQL - Audit Policy Changes - Success removed

**query**
SecurityEvent
| where Computer contains "SQL"
| where EventID == 4719
| where AuditPolicyChanges == "%%8448"
| summarize count() by EventID, Activity, AuditPolicyChanges, CategoryId, SubcategoryId

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

