**technique_id**
T1078

**title**
Sign-ins from IPs that attempt sign-ins to disabled accounts

**query**
let subnets = _GetWatchlist('SCHNet');
let threshold = 5;
SigninLogs 
| where ResultType == "50057" 
| where ResultDescription == "User account is disabled. The account has been disabled by an administrator." 
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), disabledAccountLoginAttempts = count(), 
    disabledAccountsTargeted = dcount(UserPrincipalName), applicationsTargeted = dcount(AppDisplayName), disabledAccountSet = makeset(UserPrincipalName), 
    applicationSet = makeset(AppDisplayName)
    by IPAddress
| order by disabledAccountLoginAttempts desc
| evaluate ipv4_lookup(subnets, IPAddress, network, return_unmatched = true)
| where isempty(network)
| join kind= leftouter (
    // Consider these IPs suspicious - and alert any related  successful sign-ins
    SigninLogs
    | where ResultType == 0
    | summarize successfulAccountSigninCount = dcount(UserPrincipalName), successfulAccountSigninSet = makeset(UserPrincipalName, 15) by IPAddress
    // Assume IPs associated with sign-ins from 100+ distinct user accounts are safe
    | where successfulAccountSigninCount < 100
    )
    on IPAddress  
// IPs from which attempts to authenticate as disabled user accounts originated, and had a non-zero success rate for some other account
| where successfulAccountSigninCount != 0
| project StartTimeUtc, EndTimeUtc, IPAddress, disabledAccountLoginAttempts, disabledAccountsTargeted, disabledAccountSet, applicationSet, 
    successfulAccountSigninCount, successfulAccountSigninSet
| where disabledAccountLoginAttempts >= threshold
| order by disabledAccountLoginAttempts
| extend timestamp = StartTimeUtc, IPCustomEntity = IPAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

