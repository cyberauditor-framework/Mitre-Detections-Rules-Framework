**technique_id**
T1078

**title**
Multiple Password Reset by user

**query**
let PerUserThreshold = 5;
let TotalThreshold = 100;
let action = dynamic(["change", "changed", "reset"]);
let pWord = dynamic(["password", "credentials"]);
let PasswordResetMultiDataSource =
(union isfuzzy=true
(//Password reset events
//4723: An attempt was made to change an account's password
//4724: An attempt was made to reset an accounts password
SecurityEvent
| where EventID in ("4723","4724")
| project TimeGenerated, Computer, AccountType, Account, Type),
(//Azure Active Directory Password reset events
AuditLogs
| where ResultDescription !contains "User submitted a new password"
        | where ResultDescription <> "User started the mobile SMS verification option"
        | where ResultDescription <> "User submitted their user ID"
        | where ResultDescription <> "User was presented with verification options"
        | where ResultDescription <> "User completed the email verification option"
        | where ResultDescription <> "User completed all verification steps required to reset their password"
        | where ResultDescription <> "Successfully completed reset."
        | where ResultDescription <> "User completed the mobile SMS verification option"    
        | where ResultDescription <> "User started the email verification option"
| where OperationName has_any (pWord) and OperationName has_any (action)
| where OperationName !="Self-service password reset flow activity progress" or "Change password (self-service)" or "Reset password (self-service)"
| extend AccountType = tostring(TargetResources[0].type), Account = tostring(TargetResources[0].userPrincipalName), 
TargetResourceName = tolower(tostring(TargetResources[0].displayName))
| project TimeGenerated, AccountType, Account, Computer = TargetResourceName, Type),
(//OfficeActive ActiveDirectory Password reset events
OfficeActivity
| where OfficeWorkload == "AzureActiveDirectory" 
| where (ExtendedProperties has_any (pWord) or ModifiedProperties has_any (pWord)) and (ExtendedProperties has_any (action) or ModifiedProperties has_any (action))
| extend AccountType = UserType, Account = OfficeObjectId 
| project TimeGenerated, AccountType, Account, Type, Computer = ""),
(// Unix syslog password reset events
Syslog
| where Facility in ("auth","authpriv")
| where SyslogMessage has_any (pWord) and SyslogMessage has_any (action)
| extend AccountType = iif(SyslogMessage contains "root", "Root", "Non-Root")
| parse SyslogMessage with * "password changed for" Account
| project TimeGenerated, AccountType, Account, Computer = HostName, Type),
(SigninLogs
| where OperationName =~ "Sign-in activity" and ResultType has_any ("50125", "50133")
| project TimeGenerated, AccountType = AppDisplayName, Computer = IPAddress, Account = UserPrincipalName, Type
)
);
let pwrmd = PasswordResetMultiDataSource
| project TimeGenerated, Computer, AccountType, Account, Type;
(union isfuzzy=true  
(pwrmd
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), Computer = makeset(Computer), AccountType = makeset(AccountType), Total=count() by Account, Type
| where Total > PerUserThreshold
| extend ResetPivot = "PerUserReset"),  
(pwrmd
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), Computer = makeset(Computer), Account = tostring(makeset(Account)), AccountType = makeset(AccountType), Total=count() by Type
| where Total > TotalThreshold
| extend ResetPivot = "TotalUserReset")
)
| extend timestamp = StartTimeUtc, AccountCustomEntity = Account, HostCustomEntity = tostring(Computer)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

