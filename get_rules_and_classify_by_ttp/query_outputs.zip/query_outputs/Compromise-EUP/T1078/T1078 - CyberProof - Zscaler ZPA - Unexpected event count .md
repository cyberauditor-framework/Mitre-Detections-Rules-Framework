**technique_id**
T1078

**title**
CyberProof - Zscaler ZPA - Unexpected event count of rejects by policy

**query**
let threshold = 1000;
  ZPA_CL
  | where InternalReason_s has "REJECTED_BY_POLICY"
  | summarize rejected = count() by InternalReason_s, Username_s
  | where rejected > threshold
  | extend AccountCustomEntity = Username_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

