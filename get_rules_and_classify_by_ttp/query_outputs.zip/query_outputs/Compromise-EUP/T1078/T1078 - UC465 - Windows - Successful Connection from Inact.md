**technique_id**
T1078

**title**
UC465 - Windows - Successful Connection from Inactive Account

**query**
// UC465 - Windows - Successful Connection from Inactive Account
// Description: This detection rule detects when there is a successful login from an inactive account.
// Mitre Tactics: TA0003
// Mitre Technique: T1078
let USE_CASE_NAME = "Windows - Successful Connection from Inactive Account";
let LOOKBACK = 90d;
let LoginHistoryTable = (
    uc465InactiveAccountsFunc
    // 90d inactive account watchlist - excludes newly created accounts
    | where todatetime(inactiveSince) <= ago(LOOKBACK)
    | summarize
        EventCount = count(),
        InactiveSince = max(inactiveSince)
      by
        destinationNtDomain_s = destinationNTDomain,
        destinationUserName_s = destinationUserName
    | project destinationNtDomain_s, destinationUserName_s, EventCount, InactiveSince
  );
AxALiveStream_CL
| where TimeGenerated >= ago(1h)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4624"
| where not(
    uc465MainFilteringOut(
      entity = customerURI_s,
      account = destinationUserName_s
    )
  )
| join kind = inner LoginHistoryTable on destinationNtDomain_s, destinationUserName_s
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    categoryBehavior = "Suspicious connection",
    categorySignificance = "Suspicious Activity",
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationNtDomain_s,
    destinationUserName_s,
    deviceHostName_s,
    deviceAddress_s,
    message = strcat(
      "Account ",
      destinationNtDomain_s,
      "\\",
      destinationUserName_s,
      " has authenticated against ",
      deviceHostName_s,
      " while it is flagged inactive for 90 days or more"
    ),
    sourceAddress_s,
    sourceHostName_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    name_s,
    galaxyListName_s,
    galaxyListReference_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

