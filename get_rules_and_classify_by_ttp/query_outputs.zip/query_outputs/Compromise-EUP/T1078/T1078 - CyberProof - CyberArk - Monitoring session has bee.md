**technique_id**
T1078

**title**
CyberProof - CyberArk - Monitoring session has been failed

**query**
CommonSecurityLog
| where DeviceVendor == "Cyber-Ark" and DeviceAction != "" and SourceUserName != ""
| where DeviceEventClassID == "375" 
| project
    SourceHostName,
    SourceUserName,
    DestinationUserName,
    DestinationHostName,
    DeviceEventClassID,
    DeviceAction,
    LogSeverity,
    DeviceEventCategory,
    DeviceName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

