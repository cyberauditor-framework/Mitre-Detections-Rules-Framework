**technique_id**
T1078

**title**
UC1181 - OneAccount - Unusual sign-In activity

**query**
// UC1181 - OneAccount - Unusual sign-In activity
// Detects unusual sign-in activity from the same source to multiple OneAccount entities,
// the query relies on a learning average to detect either when the number of distinct users
// for the last hour increase based on the normal activity, or when the number of failed logins
// for the same user increases over normal activity and source.
// Mitre Tactic: TA0001, TA0003
// Mitre Technique: T1078, T1098, T1133
let USE_CASE_NAME = "OneAccount - Unusual sign-In activity";
let SigninActivityTable = AxALiveStream_CL
  | where TimeGenerated > ago(14d)
  | where deviceVendor_s == "Ping" and deviceProduct_s == "Ping Identity"
  | where deviceFacility_s == "AUDIT"
    and deviceEventClassId_s in (
      "AUTHN_ATTEMPT",
      "AUTHN_REQUEST",
      "SSO",
      "OAuth"
    )
    and eventOutcome_s == "failure"
    and deviceCustomString4_s endswith "HTMLFormIDPA"
    and reason_s endswith "Invalid Credentials"
  | where isnotempty(sourceAddress_s)
  ;
let UserTransactionTable = SigninActivityTable
  | where isnotempty(destinationUserName_s)
  | summarize
      destinationUserArray = make_set(destinationUserName_s, 10000)
    by
      devicePayloadId_s
    ;
let EnrichedSigninActivityTable = SigninActivityTable
  | join kind=leftouter UserTransactionTable on devicePayloadId_s
  | extend destinationUserName_s = tostring(destinationUserArray[-1])
  | where isnotempty(destinationUserName_s)
  ;
let Top1UserTable = EnrichedSigninActivityTable
  | where TimeGenerated > ago(1h)
  | summarize
      countTop1User = count()
    by
      sourceAddress_s,
      destinationUserName_s
  | summarize
      countTop1User = arg_max(countTop1User, *)
    by
      sourceAddress_s
  ;
let UnfamiliarActivityThresholdTable = EnrichedSigninActivityTable
  | make-series countOfFailedLogons = count(), distinctUsers = dcount(destinationUserName_s)
      on TimeGenerated from ago(14d) to ago(1h) step 1h by sourceAddress_s
  | extend
      avgOfFailedLogons = series_stats_dynamic(countOfFailedLogons).avg,
      stdDevOfFailedLogons = series_stats_dynamic(countOfFailedLogons).stdev,
      avgOfDestinctUsers = series_stats_dynamic(distinctUsers).avg,
      stdDevOfDestinctUsers = series_stats_dynamic(distinctUsers).stdev
  | project
      thresholdOfFailedLogons = max_of(
        5,
        avgOfFailedLogons + 1 * stdDevOfFailedLogons
      ),
      thresholdOfDestinctUsers = max_of(
        2,
        avgOfDestinctUsers + 1 * stdDevOfDestinctUsers
      ),
      sourceAddress_s
    ;
EnrichedSigninActivityTable
| where TimeGenerated > ago(1h)
| summarize
    StartTime = min(TimeGenerated),
    EndTime = max(TimeGenerated),
    countOfFailedLogons = count(),
    distinctUsers = dcount(destinationUserName_s)
  by
    sourceAddress_s,
    customerURI_s,
    galaxyListName_s,
    galaxyListReference_s
| join kind=inner Top1UserTable on sourceAddress_s
| join kind=inner UnfamiliarActivityThresholdTable on sourceAddress_s
| extend top1PercentageFailedLogons = countTop1User * 100.0 / countOfFailedLogons
| extend Activity = case(
      countOfFailedLogons > thresholdOfFailedLogons and top1PercentageFailedLogons > 40,
      "Brute Force Activity",
      distinctUsers > thresholdOfDestinctUsers and top1PercentageFailedLogons < 40,
      "Password Spray Activity",
      ""
    )
| where not(
    uc1181MainFilteringOut(
      action = Activity
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = "",
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = ""
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    StartTime,
    EndTime,
    Activity,
    SourceIP = sourceAddress_s,
    countOfFailedLogons,
    thresholdOfFailedLogons,
    distinctUsers,
    thresholdOfDestinctUsers,
    countTop1User,
    top1PercentageFailedLogons,
    destinationUserName = destinationUserName_s,
    customerURI_s,
    galaxyListName_s,
    galaxyListReference_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

