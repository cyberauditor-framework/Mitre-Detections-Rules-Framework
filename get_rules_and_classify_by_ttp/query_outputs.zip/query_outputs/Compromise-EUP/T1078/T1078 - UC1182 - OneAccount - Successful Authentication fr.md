**technique_id**
T1078

**title**
UC1182 - OneAccount - Successful Authentication from Suspicious IP

**query**
// UC1182 - OneAccount - Successful Authentication from Suspicious IP
// Detects successful sign-ins to a One Account federated application from a suspicious source IP
// Mitre Tactic: TA0001, TA0003
// Mitre Technique: T1078, T1133, T1556
let USE_CASE_NAME = "OneAccount - Successful Authentication from Suspicious IP";
let UserTransactionTable = AxALiveStream_CL
  | where TimeGenerated >= ago(1d)
  | where deviceVendor_s == "Ping" and deviceProduct_s == "Ping Identity"
  | where isnotempty(destinationUserName_s)
  | summarize
      destinationUserArray = make_set(destinationUserName_s, 10000)
    by
      devicePayloadId_s
    ;
AxALiveStream_CL
| where TimeGenerated >= ago(1h)
| where deviceVendor_s == "Ping" and deviceProduct_s == "Ping Identity"
| where deviceFacility_s == "AUDIT"
  and deviceEventClassId_s in (
    "AUTHN_ATTEMPT",
    "AUTHN_REQUEST",
    "SSO",
    "OAuth"
  )
  and eventOutcome_s == "success"
| lookup kind=leftouter UserTransactionTable on devicePayloadId_s
| extend destinationUserName_s = tostring(destinationUserArray[-1])
| lookup kind=inner uc1182TIAddressIndicatorsFunc
    on $left.sourceAddress_s == $right.AddressIndicator
| where not(
    uc1182MainFilteringOut(
      account = deviceCustomString5_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    DeviceEventClassID = deviceEventClassId_s,
    DevicePayloadId = devicePayloadId_s,
    DestinationUserName = destinationUserName_s,
    DeviceCustomString5 = deviceCustomString5_s,
    SourceIP = sourceAddress_s,
    RequestContext = requestContext_s,
    DeviceExternalID = deviceExternalId_s,
    Reason = reason_s,
    RelatedMalwares,
    IOC_Severity,
    RelatedIPTags,
    ConfidenceScore,
    TI_Feed,
    customerURI_s,
    galaxyListName_s,
    galaxyListReference_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

