**technique_id**
T1078

**title**
CyberProof - OKTA - Admin Log In During Non-Business Hours

**query**
Okta_CL
| where TimeGenerated >= startofday(ago(1d)) and TimeGenerated < startofday(now()) // adjust the time range as needed
| where eventType_s == 'user.session.start' // assuming this event type indicates a login
| extend hourOfDay = hourofday(TimeGenerated) // extracting the hour of the day from the event timestamp
| where hourOfDay < 8 or hourOfDay > 18 // non-business hours before 8 AM or after 6 PM
| where actor_alternateId_s contains "admin" or actor_displayName_s contains "admin" // adjust this to your method of identifying admin users
| summarize StartTime = min(TimeGenerated), EndTime = max(TimeGenerated) by actor_alternateId_s, actor_displayName_s, client_ipAddress_s, client_geographicalContext_city_s, client_geographicalContext_country_s
| extend Location = strcat(client_geographicalContext_city_s, "-", client_geographicalContext_country_s)
| project StartTime, EndTime, actor_alternateId_s, actor_displayName_s, client_ipAddress_s, Location

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

