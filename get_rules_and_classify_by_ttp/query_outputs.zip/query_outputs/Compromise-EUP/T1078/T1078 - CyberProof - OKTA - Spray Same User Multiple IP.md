**technique_id**
T1078

**title**
CyberProof - OKTA - Spray Same User Multiple IP

**query**
Okta_CL
| where eventType_s == 'user.session.start' // or the appropriate event for login attempt
| where TimeGenerated > ago(1h) // Looking at the last hour, adjust the timeframe as needed
| summarize IPCount = dcount(client_ipAddress_s) by actor_alternateId_s // Count distinct IPs per user
| where IPCount > 3 // Filter for users with more than one IP
| project actor_alternateId_s, IPCount

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

