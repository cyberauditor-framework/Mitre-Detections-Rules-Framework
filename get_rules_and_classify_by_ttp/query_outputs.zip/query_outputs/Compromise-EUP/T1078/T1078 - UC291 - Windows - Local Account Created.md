**technique_id**
T1078

**title**
UC291 - Windows - Local Account Created

**query**
// UC291 - Windows - Local Account Created
// version 1.0 - 2021-01-27
// Detect when a local account is created
// Mitre Tactic: TA0001
// Mitre Technique: T1078
// This use case highlights an unusual behaviour that may reveal a malicious activity
// Either a local account is created (destination NT domain is the same as the device hostname)
// Or a new domain has been added (destination NT domain is different from the device Hostname)
let USE_CASE_NAME = "Windows - Local Account Created";
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4720"
| where not(
    uc291MainFilteringOut(
      entity = customerURI_s,
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_domain = sourceNtDomain_s,
      destination_domain = destinationNtDomain_s,
      device_hostname = deviceHostName_s,
      destination_hostname = destinationHostName_s,
      event_time = TimeGenerated
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryBehavior = "Suspicious resource",
    categorySignificance = "Suspicious Activity",
    message = strcat(
      "Local account ",
      toupper(destinationNtDomain_s),
      "/",
      toupper(destinationUserName_s),
      " created by ",
      toupper(sourceNtDomain_s),
      "/",
      toupper(sourceUserName_s),
      " on ",
      deviceHostName_s,
      " (",
      deviceAddress_s,
      ")"
    ),
    categoryOutcome_s,
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationNtDomain_s,
    destinationUserName_s,
    deviceAddress_s,
    deviceHostName_s,
    deviceProduct_s,
    deviceVendor_s,
    sourceAddress_s,
    sourceHostName_s,
    sourceNtDomain_s,
    sourceUserName_s,
    uppersourceNtDomain = toupper(sourceNtDomain_s),
    upperSourceUserName = toupper(sourceUserName_s),
    galaxyListName_s,
    galaxyListReference_s,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

