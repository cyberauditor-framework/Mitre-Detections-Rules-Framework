**technique_id**
T1078

**title**
SigninLogs - Sign-ins from IPs that attempt sign-ins to disabled accounts

**query**
let lookBack = 1d;
SigninLogs 
| where TimeGenerated >= ago(lookBack)
| where ResultType == "50057" 
| where ResultDescription == "User account is disabled. The account has been disabled by an administrator." 
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), disabledAccountLoginAttempts = count(), 
disabledAccountsTargeted = dcount(UserPrincipalName), applicationsTargeted = dcount(AppDisplayName), disabledAccountSet = makeset(UserPrincipalName), 
applicationSet = makeset(AppDisplayName) by IPAddress
| order by disabledAccountLoginAttempts desc
| join kind= leftouter (
    // Consider these IPs suspicious - and alert any related  successful sign-ins
    SigninLogs
    | where TimeGenerated >= ago(lookBack)
    | where ResultType == 0
    | summarize successfulAccountSigninCount = dcount(UserPrincipalName), successfulAccountSigninSet = makeset(UserPrincipalName, 15) by IPAddress
    // Assume IPs associated with sign-ins from 100+ distinct user accounts are safe
    | where successfulAccountSigninCount < 100
) on IPAddress  
// IPs from which attempts to authenticate as disabled user accounts originated, and had a non-zero success rate for some other account
| where successfulAccountSigninCount != 0
| project StartTimeUtc, EndTimeUtc, IPAddress, disabledAccountLoginAttempts, disabledAccountsTargeted, disabledAccountSet, applicationSet, 
successfulAccountSigninCount, successfulAccountSigninSet
| order by disabledAccountLoginAttempts
| extend timestamp = StartTimeUtc, IPCustomEntity = IPAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

