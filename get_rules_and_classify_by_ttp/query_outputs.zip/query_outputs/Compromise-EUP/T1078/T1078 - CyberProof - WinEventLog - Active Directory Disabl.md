**technique_id**
T1078

**title**
CyberProof - WinEventLog - Active Directory Disabled Account Login Attempts

**description**
Attempts to login to a disabled account. Check the integration with Service Now for ticket creation.

**query**
index=windows sourcetype="WinEventLog" EventCode=4625 Sub_Status=0xC0000072 NOT Account_Name="Guest" 
| eval Account_Name=mvindex(Account_Name, 1) 
| where !like(Account_Name,"%$") 
| eval Date=strftime(_time, "%m/%d/%Y") 
| stats count values(src_ip) as src_ip values(app) as app values(Caller_Process_Name) as Caller_Process_Name values(Logon_ID) as Logon_ID values(Logon_Process) as Logon_Process values(severity) as severity values(user) as user values(signature) as signature by Date, src, Account_Name, Workstation_Name, Failure_Reason 
| sort -Date -count  
| where count > 3
| table Date src_ip src user count Caller_Process_Name  Logon_ID Logon_Process app signature severity

**source**
Splunk

**type_source**
ttp from Splunk - Mitre Technique

