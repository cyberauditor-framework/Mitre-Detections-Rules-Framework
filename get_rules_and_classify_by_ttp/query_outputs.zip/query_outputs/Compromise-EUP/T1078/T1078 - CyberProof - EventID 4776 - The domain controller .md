**technique_id**
T1078

**title**
CyberProof - EventID 4776 - The domain controller attempted to validate the credentials for an account.

**query**
SecurityEvent
| where EventID == 4776
| extend AccountCustomEntity = Account
| extend HostCustomEntity = Computer
| extend IPCustomEntity = IpAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

