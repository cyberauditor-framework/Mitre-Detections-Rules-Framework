**technique_id**
T1078

**title**
CyberProof - ProofpointPOD - Possible data exfiltration to private email

**query**
let lbtime = 10m;
  ProofpointPOD
  | where TimeGenerated > ago(lbtime)
  | where EventType == 'message'
  | where NetworkDirection == 'outbound'
  | where array_length(todynamic(DstUserUpn)) == 1
  | extend sender = extract(@'\A(.*?)@', 1, SrcUserUpn)
  | extend sender_domain = extract(@'@(.*)$', 1, SrcUserUpn)
  | extend recipient = extract(@'\A(.*?)@', 1, tostring(todynamic(DstUserUpn)[0]))
  | extend recipient_domain = extract(@'@(.*)$', 1, tostring(todynamic(DstUserUpn)[0]))
  | where sender =~ recipient
  | where sender_domain != recipient_domain
  | project SrcUserUpn, DstUserUpn
  | extend AccountCustomEntity = SrcUserUpn

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

