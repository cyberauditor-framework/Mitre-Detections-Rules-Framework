**technique_id**
T1078

**title**
CyberProof - Microsoft Entra ID - New User Assigned to Privileged Role

**query**
// Define the start and end times based on input values
let starttime = now()-1h;
let endtime = now();
// Set a lookback period of 14 days
let lookback = starttime - 14d;
// Define a reusable function to query audit logs
let awsFunc = (start:datetime, end:datetime) {
  AuditLogs
  | where TimeGenerated between (start..end)
  | where Category =~ "RoleManagement"
  | where AADOperationType in ("Assign", "AssignEligibleRole")
  | where ActivityDisplayName has_any ("Add eligible member to role", "Add member to role")
  | mv-apply TargetResource = TargetResources on
    (
      where TargetResource.type in~ ("User", "ServicePrincipal")
      | extend Target = iff(TargetResource.type =~ "ServicePrincipal", tostring(TargetResource.displayName), tostring(TargetResource.userPrincipalName)),
      props = TargetResource.modifiedProperties
    )
  | mv-apply Property = props on
    (
      where Property.displayName =~ "Role.DisplayName"
      | extend RoleName = trim('"', tostring(Property.newValue))
    )
  | where RoleName contains "Admin" and Result == "success"
};
// Query for audit events in the current day
let EventInfo_CurrentDay = awsFunc(starttime, endtime);
// Query for audit events in the historical period (lookback)
let EventInfo_historical = awsFunc(lookback, starttime);
// Find unseen events by performing a left anti-join
let EventInfo_Unseen = (EventInfo_CurrentDay
  | join kind=leftanti(EventInfo_historical) on Target, RoleName, OperationName
);
// Extend and clean up the results
EventInfo_Unseen
| extend InitiatingApp = tostring(InitiatedBy.app.displayName)
| extend Initiator = iif(isnotempty(InitiatingApp), InitiatingApp, tostring(InitiatedBy.user.userPrincipalName))
// You can uncomment the lines below to filter out PIM activations
| where Initiator != "MS-PIM"
// | summarize StartTime=min(TimeGenerated), EndTime=min(TimeGenerated) by OperationName, RoleName, Target, Initiator, Result
// Project specific columns and split them for further analysis
| project TimeGenerated, OperationName, RoleName, Target, Initiator, Result
| extend TargetName = tostring(split(Target, '@', 0)[0]),
         TargetUPNSuffix = tostring(split(Target, '@', 1)[0]),
         InitiatorName = tostring(split(Initiator, '@', 0)[0]),
         InitiatorUPNSuffix = tostring(split(Initiator, '@', 1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

