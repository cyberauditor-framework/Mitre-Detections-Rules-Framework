**technique_id**
T1078

**title**
CyberProof - CyberArk - Station Time Limits

**query**
CommonSecurityLog
| where DeviceVendor == "Cyber-Ark" and DeviceAction !=""
| where DeviceEventClassID=="113"
| project   SourceHostName, 
            SourceUserName, 
            DestinationUserName, 
            DestinationHostName, 
            DeviceEventClassID, 
            DeviceAction, 
            LogSeverity, 
            DeviceEventCategory, 
            DeviceName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

