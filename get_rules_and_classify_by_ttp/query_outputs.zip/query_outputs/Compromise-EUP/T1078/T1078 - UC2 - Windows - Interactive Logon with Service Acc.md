**technique_id**
T1078

**title**
UC2 - Windows - Interactive Logon with Service Accounts

**query**
// UC2 - Windows - Interactive Logon with Service Accounts v4
// Description: This detection rule detects when a user performs an interactive login with a Service Account
// Mitre Tactics: TA0001
// Mitre Techniques: T1078
let USE_CASE_NAME = "Windows - Interactive Logon with Service Accounts";
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4624"
  and deviceCustomNumber1_s in (2, 10, 11)
  and destinationProcessName_s endswith "Winlogon.exe"
| where isServiceAccountFunc(account = destinationUserName_s, entity = customerURI_s)
| where not(
    uc2MainFilteringOut(
      domain = destinationNtDomain_s,
      account = destinationUserName_s,
      hostname = destinationHostName_s,
      event_time = TimeGenerated,
      entity = customerURI_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationNtDomain_s,
    destinationUserName_s,
    sourceAddress_s,
    sourceHostName_s,
    windowslogontype = deviceCustomNumber1_s,
    galaxyListReference_s,
    galaxyListName_s,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

