**technique_id**
T1078

**title**
CyberProof - Microsoft Entra ID - PIM - Changes to PIM Settings

**query**
AuditLogs
  | where Category =~ "RoleManagement"
  | where OperationName =~ "Update role setting in PIM"
  | extend userPrincipalName = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)
  | extend ipAddress = tostring(parse_json(tostring(InitiatedBy.user)).ipAddress)
  | project-reorder TimeGenerated, OperationName, ResultReason, userPrincipalName, ipAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

