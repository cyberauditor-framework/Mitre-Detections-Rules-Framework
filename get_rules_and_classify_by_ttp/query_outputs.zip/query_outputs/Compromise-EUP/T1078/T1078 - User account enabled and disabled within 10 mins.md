**technique_id**
T1078

**title**
User account enabled and disabled within 10 mins

**query**
let timeframe = 1d;
let spanoftime = 10m;
let threshold = 0;
SecurityEvent 
| where TimeGenerated > ago(2*timeframe) 
// A user account was enabled
| where EventID == 4722
| where AccountType =~ "User"
| where TargetAccount !endswith "$"
| project EnableTime = TimeGenerated, EnableEventID = EventID, EnableActivity = Activity, Computer, UserPrincipalName, 
AccountUsedToEnable = SubjectAccount, SIDofAccountUsedToEnable = SubjectUserSid, TargetAccount = tolower(TargetAccount), TargetSid
| join kind= inner (
  SecurityEvent
  | where TimeGenerated > ago(timeframe) 
  // A user account was disabled 
  | where EventID == 4725
| where AccountType == "User"
| where TargetAccount !endswith "$"
| project DisableTime = TimeGenerated, DisableEventID = EventID, DisableActivity = Activity, Computer, UserPrincipalName, 
AccountUsedToDisable = SubjectAccount, SIDofAccountUsedToDisable = SubjectUserSid, TargetAccount = tolower(TargetAccount), TargetSid
) on Computer, TargetAccount
| where (AccountUsedToDisable != "svcshhoneimad" and AccountUsedToEnable != "svcshhoneimad" and Computer !contains "shhwsrdc1015")
| where DisableTime - EnableTime < spanoftime
| extend TimeDelta = DisableTime - EnableTime
| where tolong(TimeDelta) >= threshold
| project TimeDelta, EnableTime, EnableEventID, EnableActivity, Computer, TargetAccount, TargetSid, UserPrincipalName, AccountUsedToEnable, SIDofAccountUsedToEnable, 
DisableTime, DisableEventID, DisableActivity, AccountUsedToDisable, SIDofAccountUsedToDisable
| extend timestamp = EnableTime, AccountCustomEntity = AccountUsedToEnable, HostCustomEntity = Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

