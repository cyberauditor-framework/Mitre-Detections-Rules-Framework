**technique_id**
T1078

**title**
Failed AWS Console logons but success logon to AzureAD

**query**
//Adjust this threshold to fit environment
let  signin_threshold = 5; 
//Make a list of IPs with failed AWS console logins
let aws_fails = AWSCloudTrail
| where TimeGenerated >= ago(1d)
| where EventName == "ConsoleLogin"
| extend LoginResult = tostring(parse_json(ResponseElements).ConsoleLogin) 
| where LoginResult == "Success"
| where SourceIpAddress != "127.0.0.1"
| summarize count() by SourceIpAddress
| where count_ >  signin_threshold
| summarize make_list(SourceIpAddress);
//See if any of those IPs have sucessfully logged into Azure AD.
SigninLogs
| where TimeGenerated >= ago(1d)
| where ResultType !in ("0", "50125", "50140")
| where IPAddress in (aws_fails) 
| extend Reason = "Multiple failed AWS Console logins from IP address"
| extend timestamp = TimeGenerated, AccountCustomEntity = UserPrincipalName, IPCustomEntity = IPAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

