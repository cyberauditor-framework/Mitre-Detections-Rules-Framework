**technique_id**
T1078

**title**
Workspace deletion attempt from an infected device

**query**
SecurityAlert 
| where AlertName == "Sign-in from an infected device"
| extend Extprop = parsejson(Entities)
| mv-expand Extprop
| extend Extprop = parsejson(Extprop)
| extend CmdLine = iff(Extprop['Type']=="process", Extprop['CommandLine'], '')
| extend File = iff(Extprop['Type']=="file", Extprop['Name'], '')
| extend Account = Extprop['Name']
| extend Domain = Extprop['UPNSuffix']
| extend Account = iif(isnotempty(Domain) and Extprop['Type']=="account", tolower(strcat(Account, "@", Domain)), iif(Extprop['Type']=="account", tolower(Account), ""))
| extend IpAddress = iff(Extprop["Type"] == "ip",Extprop['Address'], '')
| extend Process = iff(isnotempty(CmdLine), CmdLine, File)
| summarize count() by AlertName, AlertSeverity, CompromisedEntity, Account, IpAddress
| join kind=inner 
(
AzureActivity
| where OperationNameValue hassuffix ("/workspaces/computes/delete")
| where ActivityStatusValue =~ "Succeeded"
| summarize  StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), ActivityTimeStamp = makelist(TimeGenerated), ActivityStatusValue = makelist(ActivityStatusValue),  OperationIds = makelist(OperationId), CorrelationIds = makelist(CorrelationId), Resources = makelist(Resource), ResourceGroups = makelist(ResourceGroup), ResourceIds = makelist(ResourceId), ActivityCountByCallerIPAddress = count()  
by CallerIpAddress, Caller, OperationNameValue
) on $left. IpAddress == $right. CallerIpAddress
| extend timestamp = StartTimeUtc, AccountCustomEntity = Caller, IPCustomEntity = CallerIpAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

