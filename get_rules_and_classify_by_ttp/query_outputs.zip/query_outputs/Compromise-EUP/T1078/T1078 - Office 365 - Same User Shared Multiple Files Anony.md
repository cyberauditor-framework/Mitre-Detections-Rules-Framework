**technique_id**
T1078

**title**
Office 365 - Same User Shared Multiple Files Anonymously in a Short Period of Time (COPS)

**query**
OfficeActivity
| where Operation contains "AnonymousLinkCreated"
| summarize ObjectCount = dcount(OfficeObjectId), make_set(UserAgent), make_set(SourceFileName), make_set(OfficeObjectId) by UserId, bin(TimeGenerated,1h)
| where ObjectCount > 10

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

