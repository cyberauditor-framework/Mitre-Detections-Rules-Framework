**technique_id**
T1078

**title**
CyberProof - Zscaler ZPA - Shared ZPA session

**query**
let open_sessions =
  ZPA_CL
| where InternalReason_s == "OPEN_OR_ACTIVE_CONNECTION"
  | summarize timestampstart = min(TimeGenerated) by Username_s, ClientPublicIP_s, SessionID_s
  | sort by timestampstart asc;
  let closed_sessions =
  ZPA_CL
  | where TimeGenerated > ago(1h)
  | where InternalReason_s == 'BRK_MT_TERMINATED'
  | summarize timestampend = max(TimeGenerated) by Username_s, ClientPublicIP_s, SessionID_s
  | sort by timestampend asc;
  open_sessions
  | join (closed_sessions) on Username_s
  | sort by Username_s, timestampstart
  | extend prev_session_closetime = prev(timestampend,1)
  | extend prev_session_starttime = prev(timestampstart,1)
  | extend PreviousClientPublicIP_s = prev(ClientPublicIP_s, 1)
  | extend prev_sessionuser = prev(Username_s, 1) 
  | where Username_s == prev_sessionuser
  | where ClientPublicIP_s != PreviousClientPublicIP_s
  | where prev_session_closetime > timestampstart
  | project Username_s, ClientPublicIP_s, PreviousClientPublicIP_s
  | extend IPCustomEntity = ClientPublicIP_s, AccountCustomEntity = Username_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

