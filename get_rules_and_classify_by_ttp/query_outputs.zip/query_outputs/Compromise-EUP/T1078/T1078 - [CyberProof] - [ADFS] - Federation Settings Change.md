**technique_id**
T1078

**rule**
nan

**source**
Qradar

**type_source**
ttp from Qradar - Baseline - Mitre Technique

