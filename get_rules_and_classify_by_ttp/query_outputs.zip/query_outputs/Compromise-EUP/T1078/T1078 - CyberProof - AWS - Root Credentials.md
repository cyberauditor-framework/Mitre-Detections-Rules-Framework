**technique_id**
T1078

**title**
CyberProof - AWS - Root Credentials

**query**
// CyberProof - AWS - Root Credentials
// Description: The identification of the use of the AWS root account.
// Mitre Tactic: TA0004
// Mitre Technique: T1078.004
AWSCloudTrail
| where UserIdentityType =~ "Root" and UserIdentityAccountId == "444053039951"
| summarize
    count(),
    StartTime=min(TimeGenerated), 
    EndTime=max(TimeGenerated), 
    AwsEventId=make_set(AwsEventId, 1000),
    EventSource=make_set(EventSource, 1000),
    EventTypeName=make_set(EventTypeName, 1000),
    EventName=make_set(EventName, 1000),
    UserIdentityType=make_set(UserIdentityType, 1000),
    UserIdentityPrincipalid=make_set(UserIdentityPrincipalid, 1000),
    UserIdentityArn=make_set(UserIdentityArn, 1000),
    UserIdentityAccessKeyId=make_set(UserIdentityAccessKeyId, 1000),
    UserIdentityAccountId=make_set(UserIdentityAccountId, 1000),
    SessionMfaAuthenticated=make_set(SessionMfaAuthenticated, 1000),
    SessionIssuerType=make_set(SessionIssuerType, 1000),
    SessionIssuerPrincipalId=make_set(SessionIssuerPrincipalId, 1000),
    SessionIssuerArn=make_set(SessionIssuerArn, 1000),
    SessionIssuerAccountId=make_set(SessionIssuerAccountId, 1000),
    SessionIssuerUserName=make_set(SessionIssuerUserName, 1000),
    AWSRegion=make_set(AWSRegion, 1000),
    RequestParameters=make_set(RequestParameters, 1000),
    ResponseElements=make_set(ResponseElements, 1000),
    AwsRequestId_=make_set(AwsRequestId_, 1000),
    ReadOnly=make_set(ReadOnly, 1000),
    RecipientAccountId=make_set(RecipientAccountId, 1000),
    ManagementEvent=make_set(ManagementEvent, 1000) 
    by UserIdentityUserName, SourceIpAddress, Type
| extend message = strcat("The identification of the use of the AWS root account on :", SourceIpAddress)
| extend IPCustomEntity = SourceIpAddress, AccountCustomEntity = UserIdentityUserName
| project-reorder StartTime, EndTime, UserIdentityUserName, message, SourceIpAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - description

