**technique_id**
T1078

**title**
UC565 - SQL - Account Created And Deleted Within 24 Hours

**query**
// UC565 - SQL - Account Created And Deleted Within 24 Hours
// Mitre Tactic: TA0005
// Mitre Technique: T1078, T1070
let USE_CASE_NAME = "SQL - Account Created And Deleted Within 24 Hours";
let LoginCreatedTable = AxALiveStream_CL
  | where TimeGenerated >= ago(1d)
  | where deviceVendor_s == "Microsoft" and deviceProduct_s == "SQL Server"
  | extend created_name = strcat(fileType_s, "|", deviceAction_s)
  | where eventOutcome_s == "true"
    and (
      name_s in ("SQL LOGIN|CREATE", "WINDOWS LOGIN|CREATE")
      or created_name in ("SQL LOGIN|CREATE", "WINDOWS LOGIN|CREATE")
    )
  | extend affectedUserAccount = extract("\\[([^\\]]+)\\]", 1, Message)
  | summarize
      count(),
      time_created = min(TimeGenerated)
    by
      deviceHostName_s,
      deviceAddress_s,
      deviceCustomString3_s,
      customerURI_s,
      affectedUserAccount;
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "SQL Server"
| extend dropped_name = strcat(fileType_s, "|", deviceAction_s)
| where eventOutcome_s == "true"
  and (
    name_s in ("WINDOWS LOGIN|DROP", "SQL LOGIN|DROP")
    or dropped_name in ("WINDOWS LOGIN|DROP", "SQL LOGIN|DROP")
  )
| join kind=inner
    LoginCreatedTable
  on
    deviceHostName_s,
    deviceAddress_s,
    deviceCustomString3_s,
    customerURI_s,
    // JIRA NGSOCTEST-897 request
    $left.deviceCustomString1_s == $right.affectedUserAccount
// JIRA NGSOCTEST-897 request
| where time_created < TimeGenerated
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| project
    categoryBehavior = "/Authentication/Verify",
    categorySignificance = "/Informational/Warning",
    customerURI_s,
    deviceProduct_s,
    deviceVendor_s,
    name_s,
    eventOutcome_s,
    destinationUserId_s,
    destinationUserName_s,
    deviceAddress_s,
    deviceEventClassId_s,
    destinationNtDomain_s,
    deviceCustomString5_s,
    deviceCustomString5Label_s,
    deviceCustomString4_s,
    deviceCustomString4Label_s,
    Message,
    deviceCustomString1_s,
    deviceCustomString1Label_s,
    deviceHostName_s,
    DBName = deviceCustomString3_s,
    deviceCustomString3Label_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s = iff(
        3rdparty,
        strcat(USE_CASE_NAME, " [3rd Party]"),
        USE_CASE_NAME
      ),
      ":",
      stage
    ),
    destinationAddress_s,
    destinationHostName_s,
    message = "This UC detects when an account is created and then deleted within 24 hours",
    galaxyListName_s,
    galaxyListReference_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

