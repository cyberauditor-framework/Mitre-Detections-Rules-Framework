**technique_id**
T1078

**title**
Syslog - SSH newly internet-exposed endpoints

**query**
let PrivateIPregex = @'^127\.|^10\.|^172\.1[6-9]\.|^172\.2[0-9]\.|^172\.3[0-1]\.|^192\.168\.'; 
let avgthreshold = 0;
let probabilityLimit = 0.01;
let ssh_logins = Syslog
| where TimeGenerated >= ago(7d)
| where Facility contains "auth" and ProcessName != "sudo"
| where SyslogMessage has "Accepted"
| extend SourceIP = extract("(([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})\\.(([0-9]{1,3})))",1,SyslogMessage) 
| where isnotempty(SourceIP)
| extend ipType = iff(SourceIP matches regex PrivateIPregex,"private" ,"public" );
ssh_logins 
| summarize privatecount=countif(ipType=="private"), publiccount=countif(ipType=="public") by HostName, HostIP, bin(EventTime, 1d)
| summarize 
publicIPLoginHistory  = make_list(pack('IPCount', publiccount,  'logon_time', EventTime)),
privateIPLoginHistory = make_list(pack('IPCount', privatecount, 'logon_time', EventTime)) by HostName, HostIP
| mv-apply publicIPLoginHistory = publicIPLoginHistory on
(
    order by todatetime(publicIPLoginHistory['logon_time']) asc
    | summarize publicIPLoginCountList=make_list(toint(publicIPLoginHistory['IPCount'])), publicAverage=avg(toint(publicIPLoginHistory['IPCount'])), publicStd=stdev(toint(publicIPLoginHistory['IPCount'])), maxPublicLoginCount=max(toint(publicIPLoginHistory['IPCount']))
)
| mv-apply privateIPLoginHistory = privateIPLoginHistory on
(
    order by todatetime(privateIPLoginHistory['logon_time']) asc
    | summarize privateIPLoginCountList=make_list(toint(privateIPLoginHistory['IPCount'])), privateAverage=avg(toint(privateIPLoginHistory['IPCount'])), privateStd=stdev(toint(privateIPLoginHistory['IPCount']))
)
// Some logins from private IPs
| where privateAverage > avgthreshold
// There is a non-zero number of logins from public IPs
| where publicAverage > avgthreshold
// Approximate probability of seeing login from a public IP is < 1%
| extend probabilityPublic = publicAverage / (privateAverage + publicAverage)
| where probabilityPublic < probabilityLimit
// Today has the highest number of logins from public IPs that we've seen in the last week
| extend publicLoginCountToday = publicIPLoginCountList[-1]
| where publicLoginCountToday >= maxPublicLoginCount
| extend HostCustomEntity = HostName
// Optionally retrieve the original raw data for those logins that we've identified as potentially suspect
// | join kind=rightsemi (
//   ssh_logins
//  | where ipType == "public"
//  ) on HostName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

