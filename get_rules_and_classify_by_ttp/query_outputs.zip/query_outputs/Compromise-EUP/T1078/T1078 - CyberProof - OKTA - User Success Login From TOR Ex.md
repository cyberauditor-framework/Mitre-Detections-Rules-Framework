**technique_id**
T1078

**title**
CyberProof - OKTA - User Success Login From TOR Exit Node

**query**
Okta_CL
| where eventType_s == 'user.session.start' // This is the event type for a successful login
| where TimeGenerated >= startofday(ago(1d)) and TimeGenerated < startofday(now()) // Adjust the time range as necessary
//| where client_ipAddress_s in (list_of_tor_exit_node_ips) // Replace with your list of TOR exit node IPs
| project TimeGenerated, actor_alternateId_s, actor_displayName_s, client_ipAddress_s, client_geographicalContext_city_s, client_geographicalContext_country_s
| extend Location = strcat(client_geographicalContext_city_s, "-", client_geographicalContext_country_s)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

