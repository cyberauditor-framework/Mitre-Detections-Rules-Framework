**technique_id**
T1078

**title**
UC385 - AD - Brute Force Logon Attempt on PKI Server

**query**
// UC385 - AD - Brute Force Logon Attempt on PKI Server v2
// Description:Trigger Alert in the main channel when a potential attacker
// attempts to logon on/try to access the PKI server using the same account ID 3 times in 2 min.
let TOTAL_MATCHES = 3;
let USE_CASE_NAME = "AD - Brute Force Logon Attempt on PKI Server";
AxALiveStream_CL
| where TimeGenerated >= ago(10m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4625"
| where isPKIHostFunc(
    entity = customerURI_s,
    ip = destinationAddress_s,
    hostname = destinationHostName_s
  )
| where not(
    uc385MainFilteringOut(
      entity = customerURI_s,
      source_hostname = sourceHostName_s,
      source_ip = sourceAddress_s,
      destination_account = destinationUserName_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    baseEventCount_s = iif(isempty(baseEventCount_s), 1, toint(baseEventCount_s))
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| summarize
    Matches = sum(baseEventCount_s),
    sources = make_set(sourceAddress_s),
    sourceHostNames = make_set(sourceHostName_s),
    deviceVendors = make_set(deviceVendor_s),
    users = make_set(destinationUserName_s),
    galaxyListReference_s = make_set(galaxyListReference_s),
    galaxyListName_s = make_set(galaxyListName_s)
  by
    categoryBehavior = "Brute Force",
    categorySignificance = "Intrusion",
    customerURI_s,
    destinationAddress_s,
    destinationUserName_s,
    deviceAddress_s,
    deviceHostName_s,
    reason_s,
    message = "This alert triggers when it sees multiple failed logins from a single user"
      h"for further details about the failed attempts please look into the event class id"
      h"and error code",
    URL = strcat (
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    bin(TimeGenerated, 2m)
| where Matches >= TOTAL_MATCHES


**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

