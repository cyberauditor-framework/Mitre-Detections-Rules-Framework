**technique_id**
T1078

**title**
CyberProof - Azure - Anonymous IP address

**query**
// Anonymous IP address
// Version 1.0 2022-1-12
// Mitre Tactic: TA0001
// Mitre Technique: T1133,T1078
// Desciption - Identifies when Anonymous IP address is introduced
let timeRange =1h;
let signInMFAFailed = SigninLogs
    | where ResultDescription contains "User did not pass the MFA challenge" and TimeGenerated >= ago(timeRange)
    | summarize count() by ResultDescription, IPAddress;
(union isfuzzy=true
    (SecurityAlert
    | where AlertName == "Anonymous IP address" and TimeGenerated >= ago(timeRange) 
    | extend IPAddress = tostring(parse_json(Entities)[2].Address) 
    | join (signInMFAFailed) on IPAddress), 
    (AzureDiagnostics 
    | where TimeGenerated >= ago(timeRange - 1m) 
    | where OperationName in ("AzureFirewallApplicationRuleLog", "AzureFirewallNetworkRuleLog") 
    | extend msg_s_replaced0 = replace(@"\s\s", @" ", Message) 
    | extend msg_s_replaced1 = replace(@"\.\s", @" ", msg_s_replaced0) 
    | extend msg_a = split(msg_s_replaced1, " ") 
    | extend srcAddr_a = split(msg_a[3], ":"), destAddr_a = split(msg_a[5], ":") 
    | extend 
        protocol = tostring(msg_a[0]), 
        srcIp = tostring(srcAddr_a[0]), 
        srcPort = tostring(srcAddr_a[1]), 
        destIp = tostring(destAddr_a[0]), 
        destPort = tostring(destAddr_a[1]), 
        action = tostring(msg_a[7]) 
    | where srcIp in (signInMFAFailed) 
    | extend IPCustomEntity = srcIp, Action = action, OperationName), 
     (CommonSecurityLog 
    | where TimeGenerated >= ago(timeRange + 2m) 
    | where DeviceVendor == "Check Point"
    | where SourceIP in (signInMFAFailed) 
    | extend 
        IPCustomEntity = SourceIP) 
)

**source**
Sentinel

**type_source**
ttp from Sentinel - description

