**technique_id**
T1078

**title**
CyberProof - Office Activity - NRT Privileged Role Assigned Outside PIM

**query**
AuditLogs
| where Category =~ "RoleManagement"
| where OperationName has "Add member to role outside of PIM"
        or (LoggedByService =~ "Core Directory" and OperationName =~ "Add member to role" and Identity != "MS-PIM")
| mv-apply TargetResource = TargetResources on 
  (
      where TargetResource.type =~ "User"
      | extend UserPrincipalName = tostring(TargetResource.userPrincipalName)
  )
| extend IpAddress = tostring(InitiatedBy.user.ipAddress), Name = tostring(split(UserPrincipalName,'@',0)[0]), UPNSuffix = tostring(split(UserPrincipalName,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

