**technique_id**
T1078

**title**
Failed AzureAD logons but success logon to AWS Console

**query**
//Adjust this threshold to fit your environment
let signin_threshold = 5; 
//Make a list of IPs with AAD signin failures above our threshold
let suspicious_signins = 
SigninLogs
| where TimeGenerated >= ago(1d)
| where ResultType !in ("0", "50125", "50140")
| where IPAddress != "127.0.0.1"
| summarize count() by IPAddress
| where count_ >  signin_threshold
| summarize make_list(IPAddress);
//See if any of those IPs have sucessfully logged into the AWS console
AWSCloudTrail
| where TimeGenerated > ago(1d)
| where EventName == "ConsoleLogin"
| extend LoginResult = tostring(parse_json(ResponseElements).ConsoleLogin) 
| where LoginResult == "Success"
| where SourceIpAddress in (suspicious_signins)
| extend Reason = "Multiple failed AAD logins from IP address"
| extend MFAUsed = tostring(parse_json(AdditionalEventData).MFAUsed)
| extend User = iif(UserIdentityUserName == "", UserIdentityType, UserIdentityUserName) 
| project TimeGenerated, Reason, LoginResult, EventTypeName, UserIdentityType, User, AWSRegion, SourceIpAddress, UserAgent, MFAUsed
| extend timestamp = TimeGenerated, AccountCustomEntity = User, IPCustomEntity = SourceIpAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

