**technique_id**
T1078

**title**
CyberProof - Microsoft Entra ID - Application ID URI Changed

**query**
AuditLogs
  | where Category == "ApplicationManagement"
  | where OperationName has_any ("Update Application", "Update Service principal")
  | extend appName = tostring(parse_json(tostring(InitiatedBy.app)).displayName)
  | extend UPN = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)
  | extend UpdatedBy = iif(isnotempty(appName), appName, UPN)
  | extend mod_props = TargetResources[0].modifiedProperties
  | extend AppName = tostring(TargetResources[0].displayName)
  | mv-expand mod_props
  | where mod_props.displayName has "AppIdentifierUri"
  | extend OldURI = tostring(mod_props.oldValue)
  | extend NewURI = tostring(mod_props.newValue)
  | project-reorder TimeGenerated, OperationName, AppName, OldURI, NewURI, UpdatedBy

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

