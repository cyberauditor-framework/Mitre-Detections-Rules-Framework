**technique_id**
T1078

**title**
UC568 - SQL - Audit Policy Disabled

**query**
// UC568 - SQL - Audit Policy Disabled
// Description - This UC detects any time that an audit policy is disable
let USE_CASE_NAME = "SQL - Audit Policy Disabled";
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "SQL Server"
| where eventOutcome_s == "true" and Message endswith @"(STATE \= OFF)"
| extend created_name = strcat(fileType_s, "|", deviceAction_s)
| where name_s has_any ("SERVER AUDIT|ALTER", "SERVER AUDIT SPECIFICATION|ALTER")
  or created_name has_any ("SERVER AUDIT|ALTER", "SERVER AUDIT SPECIFICATION|ALTER")
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s = iff(
        3rdparty,
        strcat(USE_CASE_NAME, " [3rd Party]"),
        USE_CASE_NAME
      ),
      ":",
      "Alert"
    ),
    categoryBehavior = "Access/Stop",
    categorySignificance = "Informational/Warning",
    customerURI_s,
    deviceVendor_s,
    deviceProduct_s,
    message = "This UC detects any time that an audit policy is disabled",
    name_s,
    eventOutcome_s,
    deviceCustomString2_s,
    deviceCustomString2Label_s,
    deviceCustomString1_s,
    deviceCustomString1Label_s,
    destinationUserName_s,
    fileName_s,
    deviceAddress_s,
    deviceEventClassId_s,
    destinationNtDomain_s,
    deviceCustomString3Label_s,
    deviceCustomString3_s,
    deviceHostName_s,
    destinationHostName_s,
    destinationAddress_s,
    TimeGenerated,
    galaxyListName_s,
    galaxyListReference_s,
    Unknown = "Unknown"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

