**technique_id**
T1078

**title**
CyberProof - Azure Active Directory - Sign-ins from IPs that attempt sign-ins to disabled accounts

**query**
let aadFunc = (tableName: string) {
let failed_signins = table(tableName)
| where ResultType == "50057"
| where ResultDescription == "User account is disabled. The account has been disabled by an administrator.";
let disabled_users = failed_signins | summarize by UserPrincipalName;
table(tableName)
  | where ResultType == 0
  | where isnotempty(UserPrincipalName)
  | where UserPrincipalName !in (disabled_users)
| summarize
        successfulAccountsTargettedCount = dcount(UserPrincipalName),
        successfulAccountSigninSet = make_set(UserPrincipalName, 100),
        successfulApplicationSet = make_set(AppDisplayName, 100)
    by IPAddress, Type
    // Assume IPs associated with sign-ins from 100+ distinct user accounts are safe
    | where successfulAccountsTargettedCount < 50
    | where isnotempty(successfulAccountsTargettedCount)
  | join kind=inner (failed_signins
| summarize
    StartTime = min(TimeGenerated),
    EndTime = max(TimeGenerated),
    totalDisabledAccountLoginAttempts = count(),
    disabledAccountsTargettedCount = dcount(UserPrincipalName),
    applicationsTargeted = dcount(AppDisplayName),
    disabledAccountSet = make_set(UserPrincipalName, 100),
    disabledApplicationSet = make_set(AppDisplayName, 100)
by IPAddress, Type
| order by totalDisabledAccountLoginAttempts desc) on IPAddress
| project StartTime, EndTime, IPAddress, totalDisabledAccountLoginAttempts, disabledAccountsTargettedCount, disabledAccountSet, disabledApplicationSet, successfulApplicationSet, successfulAccountsTargettedCount, successfulAccountSigninSet, Type
| order by totalDisabledAccountLoginAttempts};
let aadSignin = aadFunc("SigninLogs");
let aadNonInt = aadFunc("AADNonInteractiveUserSignInLogs");
union isfuzzy=true aadSignin, aadNonInt
| join kind=leftouter (
    BehaviorAnalytics
    | where ActivityType in ("FailedLogOn", "LogOn")
    | where EventSource =~ "Azure AD"
    | project UsersInsights, DevicesInsights, ActivityInsights, InvestigationPriority, SourceIPAddress, UserPrincipalName
    | project-rename IPAddress = SourceIPAddress
    | summarize
        Users = make_set(UserPrincipalName, 100),
        UsersInsights = make_set(UsersInsights, 100),
        DevicesInsights = make_set(DevicesInsights, 100),
        IPInvestigationPriority = sum(InvestigationPriority)
    by IPAddress
) on IPAddress
| extend SFRatio = toreal(toreal(disabledAccountsTargettedCount)/toreal(successfulAccountsTargettedCount))
| where SFRatio >= 0.5
| sort by IPInvestigationPriority desc

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

