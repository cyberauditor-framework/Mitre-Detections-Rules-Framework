**technique_id**
T1078

**title**
UC19 - Windows - Account Added to Security-Enabled Group by an Unprivileged Account

**query**
// UC19 - Windows - Account Added to Security-Enabled Group by an Unprivileged Account
// Mitre Tactics: TA0005
// Mitre Technique: T1078
let USE_CASE_NAME = "Windows - Account Added to Security-Enabled Group by an Unprivileged Account";
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s in (
    "Microsoft-Windows-Security-Auditing:4728",
    "Microsoft-Windows-Security-Auditing:4732",
    "Microsoft-Windows-Security-Auditing:4756"
  )
| where not(
    uc19MainFilteringOut(
      domain = sourceNtDomain_s,
      account = sourceUserName_s,
      hostname = deviceHostName_s,
      windows_group = deviceCustomString6_s,
      entity = customerURI_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend
    name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| extend
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )
// Add suppression
| join kind = leftanti uc19AccountAddedToSecurityEnabledGroupsFunc
  on $left.sourceUserName_s == $right.username, $left.customerURI_s == $right.customerURI
| where not(
    isSuppressedFunc(
      suppressed_entities = strcat(sourceUserName_s, sourceNtDomain_s, URL),
      lookback_from = 1d,
      lookback_to = 1tick
    )
  )
| project
    categoryBehavior = "Suspicious resource",
    categorySignificance = "Suspicious Activity",
    destinationUserId_s,
    destinationNtDomain_s,
    externalId_s,
    deviceCustomString6Label_s,
    Use_Case_Name,
    destinationUserName_s,
    deviceHostName_s,
    deviceAddress_s,
    sourceNtDomain_s,
    sourceUserName_s,
    deviceEventClassId_s,
    deviceCustomString6_s,
    customerURI_s,
    sourceUserId_s,
    sourceAddress_s,
    destinationAddress_s,
    message = strcat(
      "Account ",
      destinationNtDomain_s,
      @"\",
      destinationUserName_s,
      " was added to ",
      deviceCustomString6_s,
      " by unprivileged account ",
      sourceNtDomain_s,
      @"\",
      sourceUserName_s
    ),
    stage,
    TimeGenerated,
    categoryOutcome_s,
    deviceVendor_s,
    deviceProduct_s,
    galaxyListReference_s,
    galaxyListName_s,
    Windows_Group = deviceCustomString6_s,
    URL,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

