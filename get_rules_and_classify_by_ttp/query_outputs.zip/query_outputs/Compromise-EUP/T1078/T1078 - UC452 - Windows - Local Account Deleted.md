**technique_id**
T1078

**title**
UC452 - Windows - Local Account Deleted

**query**
// UC452 - Windows - Local Account Deleted
// Detect when a local account is deleted
// Mitre Tactic: TA0001
// Mitre Technique: T1078
let USE_CASE_NAME = "Windows - Local Account Deleted";
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4726"
| where not(
    uc452MainFilteringOut(
      source_account = sourceUserName_s,
      source_domain = sourceNtDomain_s,
      destination_account = destinationUserName_s,
      destination_domain = destinationNtDomain_s,
      device_hostname = deviceHostName_s,
      entity = customerURI_s,
      destination_hostname = destinationHostName_s,
      event_time = TimeGenerated
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryOutcome_s,
    categoryBehavior = "Suspicious resource",
    categorySignificance = "Suspicious Activity",
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationNtDomain_s,
    destinationUserName_s,
    deviceAddress_s,
    deviceHostName_s,
    deviceProduct_s,
    deviceVendor_s,
    message = strcat(
      "Local account ",
      destinationNtDomain_s,
      "/",
      destinationUserName_s,
      " deleted by ",
      sourceNtDomain_s,
      "/",
      sourceUserName_s,
      " on ",
      deviceHostName_s,
      " (",
      deviceAddress_s,
      ")"
    ),
    name_s,
    sourceAddress_s,
    sourceHostName_s,
    sourceNtDomain_s,
    sourceUserName_s,
    deviceCustomString6_s,
    deviceReceiptTime_s,
    galaxyListName_s,
    galaxyListReference_s,
    uppersourceNtDomain_s = toupper(sourceNtDomain_s),
    upperSourceUserName = toupper(sourceUserName_s),
    Unknown = "Unknown",
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

