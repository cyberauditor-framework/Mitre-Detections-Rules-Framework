**technique_id**
T1078

**title**
SOC - Logstash - Syslog - New internet-exposed SSH endpoints

**query**
let subnets = _GetWatchlist('SCHNet');
let avgthreshold = 0;
let probabilityLimit = 0.01;
let ssh_logins = AzurelogstashSyslog_CL
| where syslog_facility_s contains "auth" and program_s =~ "sshd"
| where syslog_message_s has "Accepted"
| extend SourceIP = extract("(([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})\\.(([0-9]{1,3})))",1,syslog_message_s) 
| where isnotempty(SourceIP)
| where SourceIP != "127.0.0.1"
//Exclude Swisscom Range 
| where SourceIP !startswith "138.190.167"
//| where SourceIP !startswith "136.238." or SourceIP !startswith "138.190.167."
| evaluate ipv4_lookup(subnets, SourceIP, network, return_unmatched = true)
| where isempty(network)
| extend result = ipv4_is_private(SourceIP);
ssh_logins 
| summarize privatecount=countif(result== true), publiccount=countif(result==false) by logsource_s, host_s, bin(_timestamp_t, 1d)
| summarize 
publicIPLoginHistory  = make_list(pack('IPCount', publiccount,  'logon_time', _timestamp_t)),
privateIPLoginHistory = make_list(pack('IPCount', privatecount, 'logon_time', _timestamp_t)) by logsource_s, host_s
| mv-apply publicIPLoginHistory = publicIPLoginHistory on
(
    order by todatetime(publicIPLoginHistory['logon_time']) asc
    | summarize publicIPLoginCountList=make_list(toint(publicIPLoginHistory['IPCount'])), publicAverage=avg(toint(publicIPLoginHistory['IPCount'])), publicStd=stdev(toint(publicIPLoginHistory['IPCount'])), maxPublicLoginCount=max(toint(publicIPLoginHistory['IPCount']))
)
| mv-apply privateIPLoginHistory = privateIPLoginHistory on
(
    order by todatetime(privateIPLoginHistory['logon_time']) asc
    | summarize privateIPLoginCountList=make_list(toint(privateIPLoginHistory['IPCount'])), privateAverage=avg(toint(privateIPLoginHistory['IPCount'])), privateStd=stdev(toint(privateIPLoginHistory['IPCount']))
)
// Some logins from private IPs
| where privateAverage > avgthreshold
// There is a non-zero number of logins from public IPs
| where publicAverage > avgthreshold
// Approximate probability of seeing login from a public IP is < 1%
| extend probabilityPublic = publicAverage / (privateAverage + publicAverage)
| where probabilityPublic < probabilityLimit
// Today has the highest number of logins from public IPs that we've seen in the last week
| extend publicLoginCountToday = publicIPLoginCountList[-1]
| where publicLoginCountToday >= maxPublicLoginCount
| extend HostCustomEntity = logsource_s
// Optionally retrieve the original raw data for those logins that we've identified as potentially suspect
//| join kind=rightsemi (
//ssh_logins
//| where result == false
//) on logsource_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

