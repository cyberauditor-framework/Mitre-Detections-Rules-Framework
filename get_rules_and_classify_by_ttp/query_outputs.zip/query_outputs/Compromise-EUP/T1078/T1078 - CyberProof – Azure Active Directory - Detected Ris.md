**technique_id**
T1078

**title**
CyberProof – Azure Active Directory - Detected Risky Users – Medium

**query**
AADUserRiskEvents
| where RiskLevel == "medium"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

