**technique_id**
T1078

**title**
CyberProof - Risky account detections - Henry Schein involved accounts Increase Vigilance

**query**
let watchlist = (_GetWatchlist('HenryScheinSeptoAccounts') | project Account);
AADUserRiskEvents
| where UserPrincipalName in (watchlist)
| where RiskLevel !contains "low"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

