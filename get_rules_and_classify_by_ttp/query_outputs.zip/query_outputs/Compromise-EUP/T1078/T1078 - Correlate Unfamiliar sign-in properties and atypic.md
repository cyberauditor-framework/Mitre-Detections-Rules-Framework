**technique_id**
T1078

**title**
Correlate Unfamiliar sign-in properties and atypical travel alerts

**query**
let NetskopeIPs = dynamic(['163.116.128.0/17','24.206.64.0/18','24.239.128.0/18','45.250.160.0/22','103.219.78.0/23','24.206.80.0/23','24.206.82.0/23','24.206.84.0/23','103.47.244.0/24','103.219.77.0/24','45.250.160.0/24','103.219.78.0/24','103.219.79.0/24','8.36.116.0/24','8.39.144.0/24','24.206.65.0/24','24.206.66.0/24','24.206.68.0/24','24.206.70.0/24','24.206.71.0/24','24.206.72.0/24','24.206.73.0/24','24.206.74.0/24','24.206.75.0/24','24.206.76.0/24','24.206.77.0/24','24.206.78.0/24','24.206.107.0/24','24.206.112.0/24','24.206.120.0/24','24.239.128.0/24','24.239.132.0/24','24.239.133.0/24','24.239.137.0/24','24.239.138.0/24','24.239.141.0/24','24.239.161.0/24','24.239.165.0/24','74.217.93.0/24','103.219.77.0/25','103.219.77.128/25','12.151.36.0/26','50.238.102.0/26','204.237.230.80/28','209.170.91.192/28','64.255.206.48/28','201.234.7.88/29','12.1.66.136/29','12.71.86.136/29','12.133.174.232/29','12.138.3.16/29','12.138.96.112/29','12.157.200.120/29','12.169.99.64/29','12.238.124.120/29','50.238.102.64/29','8.243.120.184/30','209.66.120.36/31','209.249.119.82/31','128.177.100.142/31','208.184.253.172/31']);
let Alert1 = 
SecurityAlert
| where AlertName == "Unfamiliar sign-in properties"
| extend UserPrincipalName = tostring(parse_json(ExtendedProperties).["User Account"])
| extend Alert1Time = TimeGenerated
| extend Alert1 = AlertName
| extend Alert1Severity = AlertSeverity
;
let Alert2 = 
SecurityAlert
| where AlertName == "Atypical travel"
| extend UserPrincipalName = tostring(parse_json(ExtendedProperties).["User Account"])
// Filter out blank user names
| where isnotempty(UserPrincipalName)
| extend Alert2Time = TimeGenerated
| extend Alert2 = AlertName
| extend Alert2Severity = AlertSeverity
| extend CurrentLocation = strcat(tostring(parse_json(tostring(parse_json(Entities)[2].Location)).CountryCode), "|", tostring(parse_json(tostring(parse_json(Entities)[2].Location)).State), "|", tostring(parse_json(tostring(parse_json(Entities)[2].Location)).City))
| extend PreviousLocation = strcat(tostring(parse_json(tostring(parse_json(Entities)[3].Location)).CountryCode), "|", tostring(parse_json(tostring(parse_json(Entities)[3].Location)).State), "|", tostring(parse_json(tostring(parse_json(Entities)[3].Location)).City))
| extend CurrentIPAddress = tostring(parse_json(Entities)[2].Address)
| extend PreviousIPAddress = tostring(parse_json(Entities)[3].Address)
// Adding Country fields for additional Compare
| extend CurrentCountry = tostring(parse_json(tostring(parse_json(Entities)[2].Location)).CountryCode), PreviousCountry = tostring(parse_json(tostring(parse_json(Entities)[3].Location)).CountryCode)
;
let exclusions = 
SecurityAlert
| where AlertName == "Atypical travel"
| extend CurrentIPAddress = tostring(parse_json(Entities)[2].Address)
| mv-apply list=NetskopeIPs to typeof(string) on (  extend Netskope = ipv4_is_match(CurrentIPAddress,list) | where (Netskope) ) // Check IPs are Netskope
| summarize make_set(CurrentIPAddress);
Alert1
| join kind=inner Alert2 on UserPrincipalName
| where abs(datetime_diff('minute', Alert1Time, Alert2Time)) >=10 // changes from <=10 to generate events
| extend TimeDelta = Alert1Time - Alert2Time
| project UserPrincipalName, Alert1, Alert1Time, Alert1Severity, Alert2, Alert2Time, Alert2Severity, TimeDelta, CurrentLocation, PreviousLocation, CurrentIPAddress, PreviousIPAddress, CurrentCountry, PreviousCountry
| extend AccountCustomEntity = UserPrincipalName
| extend IPCustomEntity = CurrentIPAddress
| where not(CurrentCountry == PreviousCountry and (CurrentIPAddress has_any (exclusions) or PreviousIPAddress has_any (exclusions)))
| summarize Delta_Times = make_set(TimeDelta,10) by Alert1Time, Alert2Time, AccountCustomEntity, PreviousIPAddress, PreviousLocation, CurrentIPAddress, CurrentLocation, IPCustomEntity, UserPrincipalName, Alert1Severity, Alert2Severity, Alert1, Alert2, CurrentCountry, PreviousCountry     
| where not(PreviousLocation == '||' or CurrentLocation == '||')

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

