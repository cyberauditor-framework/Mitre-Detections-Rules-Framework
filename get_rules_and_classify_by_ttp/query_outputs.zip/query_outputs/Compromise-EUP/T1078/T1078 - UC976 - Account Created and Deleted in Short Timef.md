**technique_id**
T1078

**title**
UC976 - Account Created and Deleted in Short Timeframe

**query**
// UC976 - Account Created and Deleted in Short Timeframe
// Search for user principal name (UPN) events. Look for accounts created and then deleted in under 24 hours
// Attackers may create an account for their use, and then remove the account when no longer needed.
// Ref:
// https://docs.microsoft.com/azure/active-directory/fundamentals/security-operations-user-accounts#short-lived-account
// Mitre Tactic: TA0003, TA0004
// Mitre Technique: T1098, T1078
let USE_CASE_NAME = "Account Created and Deleted in Short Timeframe";
let AccountCreationTable = AuditLogs_Events
  | where TimeGenerated > ago(7d)
  | where OperationName =~ "Add user"
  | project
      creationTimeGenerated = TimeGenerated,
      userPrincipalName = extract(
        @"([a-f0-9]{32})?(.*)",
        2,
        tostring(TargetResources[0].userPrincipalName)
      ),
      createdByUser = tostring(InitiatedBy.user.userPrincipalName),
      createdByIPAddress = tostring(InitiatedBy.user.ipAddress),
      createdByApp = tostring(InitiatedBy.app.displayName),
      creationAdditionalDetails = AdditionalDetails,
      creationInitiatedBy = InitiatedBy,
      creationTargetResources = TargetResources,
      Galaxy_List_Reference,
      Galaxy_List_Name,
      customerURI_s
  ;
AuditLogs_Events
| where TimeGenerated > ago(1h)
| where OperationName =~ "Delete user"
| project
    deletionTimeGenerated = TimeGenerated,
    userPrincipalName = extract(
      @"([a-f0-9]{32})?(.*)",
      2,
      tostring(TargetResources[0].userPrincipalName)
    ),
    deletedByUser = tostring(InitiatedBy.user.userPrincipalName),
    deletedByIPAddress = tostring(InitiatedBy.user.ipAddress),
    deletedByApp = tostring(InitiatedBy.app.displayName),
    deletionAdditionalDetails = AdditionalDetails,
    deletionInitiatedBy = InitiatedBy,
    deletionTargetResources = TargetResources,
    Galaxy_List_Reference,
    Galaxy_List_Name,
    customerURI_s
| join kind = inner (AccountCreationTable)
  on
    userPrincipalName,
    customerURI_s
| where not(
    uc976MainFilteringOut(
      source_account = tostring(userPrincipalName),
      destination_account = tostring(deletedByUser),
      entity = tostring(customerURI_s)
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = userPrincipalName,
      destination_account = userPrincipalName,
      source_ip = deletedByIPAddress,
      destination_ip = deletedByIPAddress
    )
| extend name_s = iff(
      3rdparty,
      (strcat (USE_CASE_NAME, " [3rd Party]")),
      USE_CASE_NAME
    )
| project
    Creation_TimeGenerated = creationTimeGenerated,
    Deletion_TimeGenerated = deletionTimeGenerated,
    TimeDelta = datetime_diff(
      "day",
      deletionTimeGenerated,
      creationTimeGenerated
    ),
    UserPrincipalName = userPrincipalName,
    DeletedByUser = deletedByUser,
    DeletedByIPAddress = deletedByIPAddress,
    DeletedByApp = deletedByApp,
    CreatedByUser = createdByUser,
    CreatedByIPAddress = createdByIPAddress,
    CreatedByApp = createdByApp,
    Creation_AdditionalDetails = creationAdditionalDetails,
    Creation_InitiatedBy = creationInitiatedBy,
    Creation_TargetResources = creationTargetResources,
    Deletion_AdditionalDetails = deletionAdditionalDetails,
    Deletion_InitiatedBy = deletionInitiatedBy,
    Deletion_TargetResources = deletionTargetResources,
    Galaxy_List_Reference,
    Galaxy_List_Name,
    customerURI_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )
| where TimeDelta between (0 .. 7)

**source**
Sentinel

**type_source**
ttp from Sentinel - description

