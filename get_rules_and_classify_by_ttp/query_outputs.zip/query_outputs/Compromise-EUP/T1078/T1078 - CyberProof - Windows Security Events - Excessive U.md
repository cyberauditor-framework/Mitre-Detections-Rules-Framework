**technique_id**
T1078

**title**
CyberProof - Windows Security Events - Excessive User Locked out

**query**
let timeRange = 1d;
let threshold = 50;
SecurityEvent
| where TimeGenerated >= ago(timeRange) and EventID == "4740"
| extend StringEventID = tostring(EventID)
| summarize make_set(Computer), make_set(IpAddress), accountLockoutCount = count() by TargetUserName, Activity
| where accountLockoutCount >= (threshold)
| extend AccountCustomEntity = TargetUserName
| extend HostCustomEntity = tostring(set_Computer)
| extend IPCustomEntity = tostring(set_IpAddress)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

