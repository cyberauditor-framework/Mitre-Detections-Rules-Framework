**technique_id**
T1078

**title**
CyberProof - Zscaler ZPA - ZPA connections from new IP

**query**
let listIPs =
  ZPA_CL 
  | where TimeGenerated > ago(14d)
  | summarize ListofIPs = make_set(ClientPublicIP_s) by Username_s
  | project ListofIPs;
  ZPA_CL
  | where isnotempty(ClientPublicIP_s)
  | where ClientPublicIP_s !in (listIPs)
  | summarize EventCount = count() by Username_s, ClientPublicIP_s
  | project-away EventCount
  | extend IPCustomEntity = ClientPublicIP_s, AccountCustomEntity = Username_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

