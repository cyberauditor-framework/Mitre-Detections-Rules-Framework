**technique_id**
T1078

**title**
UC18 - AD - Group Deleted by non-Security Admin

**query**
// UC18 - AD - Group Deleted by non-Security Admin
// This rule detects when a windows group of any type was deleted by a user who
// is not on the privileged users watchlist.
// Mitre Tactic: TA0004
// Mitre Technique: T1078
let USE_CASE_NAME = "AD - Group Deleted by non-Security Admin";
let group_deletion_windows_event_ids = dynamic(
    [
      "Microsoft-Windows-Security-Auditing:4748",
      "Microsoft-Windows-Security-Auditing:4753",
      "Microsoft-Windows-Security-Auditing:4763",
      "Microsoft-Windows-Security-Auditing:4758",
      "Microsoft-Windows-Security-Auditing:4734",
      "Microsoft-Windows-Security-Auditing:4730",
      "Microsoft-Windows-Security-Auditing:4789"
    ]
  )
;
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s in (group_deletion_windows_event_ids)
//Filtering Out call
| where not (isPrivilegedAccountFunc(domain = sourceNtDomain_s, account = sourceUserName_s, entity = customerURI_s))
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryOutcome_s,
    categoryBehavior_s = "Misuse of privileged account",
    categorySignificance_s = "Policy Violation",
    customerURI_s,
    deviceAddress_s,
    deviceProduct_s,
    deviceVendor_s,
    externalId_s,
    message = strcat(
      "On ",
      TimeGenerated,
      " the SOC Security Monitoring Service detected an Event of Interest"
    ),
    sourceHostName_s,
    sourceUserName_s,
    sourceNtDomain_s,
    sourceUserId_s,
    deviceHostName_s,
    name_s,
    stage,
    Stage_URI,
    deviceEventClassId_s,
    Windows_Group_Name = deviceCustomString6_s,
    deviceCustomString6_s,
    destinationHostName_s,
    galaxyListReference_s,
    galaxyListName_s,
    Unknown = "Unknown"


**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

