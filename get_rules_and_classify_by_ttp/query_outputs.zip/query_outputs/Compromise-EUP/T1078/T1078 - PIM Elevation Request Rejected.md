**technique_id**
T1078

**title**
PIM Elevation Request Rejected

**query**
AuditLogs
| where ActivityDisplayName =~'Add member to role request denied (PIM activation)'
| mv-apply ResourceItem = TargetResources on 
  (
      where ResourceItem.type =~ "Role"
      | extend Role = trim(@'"',tostring(ResourceItem.displayName))
  )
| mv-apply ResourceItem = TargetResources on 
  (
      where ResourceItem.type =~ "User"
      | extend TargetUserPrincipalName = trim(@'"',tostring(ResourceItem.userPrincipalName))
  )
| where isnotempty(InitiatedBy.user)
| extend InitiatingAppName = tostring(InitiatedBy.app.displayName)
| extend InitiatingAppServicePrincipalId = tostring(InitiatedBy.app.servicePrincipalId)
| extend InitiatingUserPrincipalName = tostring(InitiatedBy.user.userPrincipalName)
| extend InitiatingAadUserId = tostring(InitiatedBy.user.id)
| extend InitiatingIpAddress = tostring(iff(isnotempty(InitiatedBy.user.ipAddress), InitiatedBy.user.ipAddress, InitiatedBy.app.ipAddress))
| extend TargetName = tostring(split(TargetUserPrincipalName,'@',0)[0]), TargetUPNSuffix = tostring(split(TargetUserPrincipalName,'@',1)[0])
| extend InitiatedByName = tostring(split(InitiatingUserPrincipalName,'@',0)[0]), InitiatedByUPNSuffix = tostring(split(InitiatingUserPrincipalName,'@',1)[0])
| project-reorder TimeGenerated, TargetUserPrincipalName, Role, OperationName, Result, ResultDescription

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

