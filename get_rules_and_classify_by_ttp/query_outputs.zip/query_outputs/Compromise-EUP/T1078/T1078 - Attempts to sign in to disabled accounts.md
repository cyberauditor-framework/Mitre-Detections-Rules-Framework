**technique_id**
T1078

**title**
Attempts to sign in to disabled accounts

**query**
let subnets = _GetWatchlist('SCHNet');
let thresholdhits = 5;
let thresholdapp = 3;
let timeframe = 1d;
SigninLogs
| where TimeGenerated > ago(timeframe)
| where ResultType == "50057"
| where ResultDescription =~ "User account is disabled. The account has been disabled by an administrator."
| extend displayName = tostring(DeviceDetail.displayName)
| where isempty(displayName)
| evaluate ipv4_lookup(subnets, IPAddress, network, return_unmatched = true)
| where isempty(network)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), hits = count(), applicationCount = dcount(AppDisplayName), 
    applicationSet = makeset(AppDisplayName)
    by UserPrincipalName, IPAddress
| where hits >= thresholdhits
| where applicationCount >= thresholdapp
// Join to search for OK logins on BehaviourAnalytics table
| join kind=innerunique (BehaviorAnalytics
| where TimeGenerated > ago(timeframe)
// We make an array of activity types for each ip address
        | summarize ActivitySet = make_set(ActivityType)
          by SourceIPAddress
// We want only the hosts that only have failed logins, so we discard the correct ones
        | where ActivitySet !has "LogOn"
        | project SourceIPAddress, ActivitySet)
    on $left.IPAddress == $right.SourceIPAddress
 | where UserPrincipalName !startswith "retired"
 | join kind=leftanti (AuditLogs
 | where TimeGenerated > ago(timeframe)
| extend InitiatedByUser = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)
| where isnotempty(InitiatedByUser)
| where InitiatedByUser == "Sync_shhwsr2458_6cfda6f00822@SchindlerGlobal.onmicrosoft.com"
| where OperationName == "Enable account"
| extend TargetUser = tostring(TargetResources[0].userPrincipalName)) on $left.UserPrincipalName == $right.TargetUser
| join kind=leftanti (SigninLogs
| project NetworkLocationDetails, IPAddress
| where NetworkLocationDetails contains "trusted")
on $left.IPAddress == $right.IPAddress
| join kind=leftanti (SigninLogs
| where ResultType == "0"
| summarize by IPAddress, UserPrincipalName)
on $left.IPAddress == $right.IPAddress
| where SourceIPAddress !contains ":"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

