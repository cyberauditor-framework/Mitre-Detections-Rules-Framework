**technique_id**
T1078

**title**
SecurityEvent - New user created and added to the built-in administrators group

**query**
let timeframe = 1d;
SecurityEvent
| where TimeGenerated > ago(timeframe) 
| where EventID == 4720
| where AccountType == "User"
| project CreatedUserTime = TimeGenerated, CreatedUserEventID = EventID, CreatedUserActivity = Activity, Computer = toupper(Computer), 
CreatedUser = tolower(TargetUserName), Domain = toupper(TargetDomainName), CreatedUserSid = TargetSid, AccountUsedToCreateUser = SubjectUserName
|join (
SecurityEvent 
| where TimeGenerated > ago(timeframe) 
| where AccountType == "User"
// 4732 - A member was added to a security-enabled local group
| where EventID == 4732
//TargetSid is the builin Admins group: S-1-5-32-544
| where TargetSid == "S-1-5-32-544"
| project GroupAddTime = TimeGenerated, GroupAddEventID = EventID, GroupAddActivity = Activity, Computer = toupper(Computer), GroupName = TargetUserName, 
Domain = toupper(TargetDomainName), GroupSid = TargetSid, UserAdded = SubjectUserName, UserAddedSid = SubjectUserSid, CreatedUser = tolower(SubjectUserName), 
CreatedUserSid = MemberSid
)
on CreatedUserSid
//Create User first, then the add to the group.
| project Computer, CreatedUserTime, CreatedUserEventID, CreatedUserActivity, CreatedUser, CreatedUserSid, Domain, GroupAddTime, GroupAddEventID, 
GroupAddActivity, AccountUsedToCreateUser, GroupName, GroupSid, UserAdded, UserAddedSid 
| extend timestamp = CreatedUserTime, AccountCustomEntity = CreatedUser, HostCustomEntity = Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

