**technique_id**
T1078

**title**
CyberProof - At risk accounts - Henry Schein involved accounts Increase Vigilance

**query**
let watchlist = (_GetWatchlist('HenryScheinSeptoAccounts') | project Account);
SigninLogs
| where RiskState == "atRisk"
| where UserPrincipalName <> ""
| where AppDisplayName <> ""
| where UserPrincipalName in (watchlist)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

