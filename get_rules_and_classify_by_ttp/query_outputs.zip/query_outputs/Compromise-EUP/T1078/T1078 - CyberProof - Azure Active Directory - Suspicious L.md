**technique_id**
T1078

**title**
CyberProof - Azure Active Directory - Suspicious linking of existing user to an external User

**query**
let lookback = 1d;
AuditLogs 
| where TimeGenerated > ago(lookback)
| where OperationName=~ "Update user" 
| where Result =~ "success" 
| mv-expand TargetResources 
| mv-expand TargetResources.modifiedProperties 
| extend displayName_ = tostring(TargetResources_modifiedProperties.displayName) , oldValue_ = tostring(TargetResources_modifiedProperties.oldValue), newValue_ = tostring(TargetResources_modifiedProperties.newValue)
| where displayName_ == "UserPrincipalName" and oldValue_ !has "#EXT" and newValue_ has "#EXT"
| extend InitiatingApp = tostring(parse_json(tostring(InitiatedBy.app)).displayName) 
| extend Initiator = iif(isnotempty(InitiatingApp), InitiatingApp, tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)) , IPAddress = tostring(InitiatedBy.["user"].["ipAddress"])
| project TimeGenerated, AADTenantId, IPAddress, Initiator, displayName_, oldValue_, newValue_

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

