**technique_id**
T1078

**title**
CyberProof - OKTA - User Login from 3 Different Countries within 1 Day - TEST for Above 6

**query**
let timeframe = ago(24h);
let threshold = 6;
Okta_CL
| where column_ifexists('published_t', now()) >= timeframe
| where eventType_s =~ "user.session.start"
| where outcome_result_s =~ "SUCCESS"
| extend client_geographicalContext_country_s
| summarize
geographicalcountry_s = make_set(client_geographicalContext_country_s),
    StartTime = min(TimeGenerated),
    EndTime = max(TimeGenerated),
    NumOfCountries = dcount(column_ifexists('client_geographicalContext_country_s', int(null)))
    by actor_alternateId_s
| where NumOfCountries >= threshold
| extend timestamp = StartTime
| extend AccountCustomEntity = actor_alternateId_s

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

