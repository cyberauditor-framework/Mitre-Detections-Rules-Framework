**technique_id**
T1078

**title**
SigninLogs - Successful logon from IP and failure from a different IP

**query**
let timeFrame = 1d;
let logonDiff = 10m;
SigninLogs 
| where TimeGenerated >= ago(timeFrame) 
| where ResultType == "0" 
| where AppDisplayName !in ("Office 365 Exchange Online", "Skype for Business Online")
| project SuccessLogonTime = TimeGenerated, UserPrincipalName, SuccessIPAddress = IPAddress, AppDisplayName, SuccessIPBlock = strcat(split(IPAddress, ".")[0], ".", split(IPAddress, ".")[1])
| join kind= inner (
    SigninLogs 
    | where TimeGenerated >= ago(timeFrame) 
    | where ResultType !in ("0", "50140") 
    | where ResultDescription !~ "Other"  
    | where AppDisplayName !in ("Office 365 Exchange Online", "Skype for Business Online")
    | project FailedLogonTime = TimeGenerated, UserPrincipalName, FailedIPAddress = IPAddress, AppDisplayName, ResultType, ResultDescription
) on UserPrincipalName, AppDisplayName 
| where SuccessLogonTime < FailedLogonTime and FailedLogonTime - SuccessLogonTime <= logonDiff and FailedIPAddress !startswith SuccessIPBlock
| summarize FailedLogonTime = max(FailedLogonTime), SuccessLogonTime = max(SuccessLogonTime) by UserPrincipalName, SuccessIPAddress, AppDisplayName, FailedIPAddress, ResultType, ResultDescription 
| extend timestamp = SuccessLogonTime, AccountCustomEntity = UserPrincipalName, IPCustomEntity = SuccessIPAddress

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

