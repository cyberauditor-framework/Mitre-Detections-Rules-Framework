**technique_id**
T1078

**title**
CyberProof - Microsoft Entra ID - Suspicious Service Principal creation activity

**query**
let queryfrequency = 1h;
let wait_for_deletion = 10m;
let account_created =
  AuditLogs 
  | where ActivityDisplayName == "Add service principal"
  | where Result == "success"
  | extend AppID = tostring(AdditionalDetails[1].value)
  | extend creationTime = ActivityDateTime
  | extend CreatorUserPrincipalName = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)
  | extend CreatorIPAddress = tostring(parse_json(tostring(InitiatedBy.user)).ipAddress);
let account_activity =
  AADServicePrincipalSignInLogs
  | extend Activities = pack("ActivityTime", TimeGenerated ,"IpAddress", IPAddress, "ResourceDisplayName", ResourceDisplayName)
  | extend AppID = AppId
  | summarize make_list(Activities) by AppID;
let account_deleted =
  AuditLogs 
  | where OperationName == "Remove service principal"
  | where Result == "success"
  | extend AppID = tostring(AdditionalDetails[1].value)
  | extend deletionTime = ActivityDateTime
  | extend DeleterUserPrincipalName = tostring(parse_json(tostring(InitiatedBy.user)).userPrincipalName)
  | extend DeleterIPAddress = tostring(parse_json(tostring(InitiatedBy.user)).ipAddress);
let account_credentials =
  AuditLogs
  | where OperationName has_all ("Update application", "Certificates and secrets management")
  | where Result == "success"
  | extend AppID = tostring(AdditionalDetails[1].value)
  | extend credentialCreationTime = ActivityDateTime;
let roles_assigned =
  AuditLogs
  | where ActivityDisplayName == "Add app role assignment to service principal"
  | extend AppID = tostring(TargetResources[1].displayName)
  | extend AssignedRole =  iff(tostring(parse_json(tostring(TargetResources[0].modifiedProperties))[1].displayName)=="AppRole.Value", tostring(parse_json(tostring(parse_json(tostring(TargetResources[0].modifiedProperties))[1].newValue))),"")
  | extend AssignedRoles = pack("Role", AssignedRole)
  | summarize make_list(AssignedRoles) by AppID;
account_created
| where TimeGenerated between (ago(wait_for_deletion+queryfrequency)..ago(wait_for_deletion))
| join kind= inner (account_activity) on AppID
| join kind= inner (account_deleted) on AppID
| join kind= inner (account_credentials) on AppID
| join kind= inner (roles_assigned) on AppID
| where deletionTime - creationTime between (time(0s)..wait_for_deletion)
| extend AliveTime = deletionTime - creationTime
| project AADTenantId, AppID, creationTime, deletionTime, CreatorUserPrincipalName, DeleterUserPrincipalName, CreatorIPAddress, DeleterIPAddress, list_Activities, list_AssignedRoles, AliveTime
| extend CreatorName = tostring(split(CreatorUserPrincipalName, "@")[0]), CreatorUPNSuffix = tostring(split(CreatorUserPrincipalName, "@")[1])
| extend DeleterName = tostring(split(DeleterUserPrincipalName, "@")[0]), DeleterSuffix = tostring(split(DeleterUserPrincipalName, "@")[1])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

