**technique_id**
T1078

**title**
CyberProof - OKTA - Admin privilege granted

**query**
Okta_CL
| where eventType_s == 'user.account.privilege.grant' // This event type should represent the granting of privileges
| where legacyEventType_s contains 'admin' // This field needs to represent the role granted, assuming 'Admin' signifies admin privileges
| summarize StartTime = min(TimeGenerated), EndTime = max(TimeGenerated)
    by
    actor_alternateId_s,
    actor_displayName_s,
    legacyEventType_s,
    client_ipAddress_s,
    client_geographicalContext_city_s,
    client_geographicalContext_country_s
| extend Location = strcat(client_geographicalContext_city_s, "-", client_geographicalContext_country_s)
| project
    StartTime,
    EndTime,
    actor_alternateId_s,
    actor_displayName_s,
    legacyEventType_s,
    client_ipAddress_s,
    Location

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

