**technique_id**
T1078

**title**
CyberProof - RSASecurID - TI map IP entity to RSASecurID

**query**
let dt_lookBack = 1h;
let ioc_lookBack = 14d;
let IoCList = materialize(externaldata(TimeGenerated:datetime,IoC:string,IoC_Type:string,ExpirationDateTime:datetime,Description:string,Action:string, ConfidenceScore:real, ThreatType:string, Active:string,Type:string, TrafficLightProtocolLevel:string, ActivityGroupNames:string)[@"https://raw.githubusercontent.com/microsoft/mstic/master/RapidReleaseTI/Indicators.csv"] with(format="csv", ignoreFirstRecord=True));
let IP_Indicators = (union isfuzzy=true
(ThreatIntelligenceIndicator
| where TimeGenerated >= ago(ioc_lookBack) and ExpirationDateTime > now() and SourceSystem in ("ONG-ISAC_Industry_Community","DHS_AIS_Source")
| summarize LatestIndicatorTime = arg_max(TimeGenerated, *) by IndicatorId
| where Active == true
// Picking up only IOC's that contain the entities we want
| where isnotempty(NetworkIP) or isnotempty(EmailSourceIpAddress) or isnotempty(NetworkDestinationIP) or isnotempty(NetworkSourceIP)
// As there is potentially more than 1 indicator type for matching IP, taking NetworkIP first, then others if that is empty.
// Taking the first non-empty value based on potential IOC match availability
| extend TI_ipEntity = iff(isnotempty(NetworkIP), NetworkIP, NetworkDestinationIP)
| extend TI_ipEntity = iff(isempty(TI_ipEntity) and isnotempty(NetworkSourceIP), NetworkSourceIP, TI_ipEntity)
| extend TI_ipEntity = iff(isempty(TI_ipEntity) and isnotempty(EmailSourceIpAddress), EmailSourceIpAddress, TI_ipEntity)
//Exclude local addresses, using the ipv4_is_private operator
| where ipv4_is_private(TI_ipEntity) == false and  TI_ipEntity !startswith "fe80" and TI_ipEntity !startswith "::" and TI_ipEntity !startswith "127."
),
(IoCList
| where IoC_Type =~ 'IP'
| where ExpirationDateTime > now()
| summarize LatestIndicatorTime = arg_max(TimeGenerated, *) by IoC
| where Active =~ 'True'
| extend TI_ipEntity = IoC
| project-away  IoC_Type
)
);
IP_Indicators
// using innerunique to keep perf fast and result set low, we only need one match to indicate potential malicious activity that needs to be investigated
| join kind=innerunique (
    RSASecurIDAMEvent
    | where TimeGenerated >= ago(dt_lookBack)
    // renaming time column so it is clear the log this came from
    | extend RSASecurID_TimeGenerated = TimeGenerated
)
on $left.TI_ipEntity == $right.SrcIpAddr
| where RSASecurID_TimeGenerated < ExpirationDateTime
| summarize RSASecurID_TimeGenerated = arg_max(RSASecurID_TimeGenerated, *) by IndicatorId, SrcIpAddr,IoC
| extend timestamp = RSASecurID_TimeGenerated, IPCustomEntity = SrcIpAddr, AccountCustomEntity = SrcUserName, URLCustomEntity = Url

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

