**technique_id**
T1078

**title**
CyberProof - Nutanix - Failed login attempt to the CVM

**query**
CLCSyslog_CL
| where SyslogMessage_s contains "An unsuccessful login attempt was made with username"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

