**technique_id**
T1078

**title**
CyberProof - FortiGate - Failed Admin Login

**query**
let threshold = 3;
CommonSecurityLog
| where DeviceProduct == "FortiGate"
| where DeviceEventCategory =~ "event"
| where DeviceCustomString1 =~ "system"
| where DeviceAction =~ "login"
| where EventOutcome has "fail" or EventOutcome !has "succcess"
| where Activity =~ "Admin login failed"
| summarize arg_max(TimeGenerated,*), failedCount = count() by SourceUserName
| where failedCount >= (threshold)

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

