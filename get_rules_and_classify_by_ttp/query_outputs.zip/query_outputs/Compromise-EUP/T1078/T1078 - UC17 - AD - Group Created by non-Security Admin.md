**technique_id**
T1078

**title**
UC17 - AD - Group Created by non-Security Admin

**query**
// UC17 - AD - Group Created by non-Security Admin
// This rule detects when a windows grp of any type was created by a user who is not on the privileged users wtchlist
// Mitre Tactic: TA0004
// Mitre Technique: T1078
let USE_CASE_NAME = "AD - Group Created by non-Security Admin";
let group_modification_windows_event_ids = dynamic(
    [
      "Microsoft-Windows-Security-Auditing:4727",
      "Microsoft-Windows-Security-Auditing:4731",
      "Microsoft-Windows-Security-Auditing:4744",
      "Microsoft-Windows-Security-Auditing:4749",
      "Microsoft-Windows-Security-Auditing:4754",
      "Microsoft-Windows-Security-Auditing:4759",
      "Microsoft-Windows-Security-Auditing:4783"
    ]
  )
;
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s in (group_modification_windows_event_ids)
//Filtering Out call
| where not (
    uc17MainFilteringOut(
      account = sourceUserName_s,
      domain = sourceNtDomain_s,
      windows_group = deviceCustomString6_s,
      entity = customerURI_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| project
    TimeGenerated,
    categoryOutcome_s,
    categoryBehavior_s = "Suspicious connection",
    categorySignificance_s = "Suspicious Activity",
    customerURI_s,
    destinationAddress_s,
    destinationHostName_s,
    destinationPort_s,
    deviceAction_s,
    deviceAddress_s,
    deviceProduct_s,
    deviceVendor_s,
    message = strcat(
      "On ",
      TimeGenerated,
      " the SOC Security Monitoring Service detected an Event of Interest"
    ),
    sourceAddress_s,
    sourceHostName_s,
    Stage_URI,
    sourceUserName_s,
    deviceEventClassId_s,
    deviceHostName_s,
    sourceNtDomain_s,
    destinationNtDomain_s,
    deviceCustomString6_s,
    name_s,
    galaxyListReference_s,
    galaxyListName_s,
    stage,
    URL = strcat(
      customerURI_s,
      ":",
      name_s = iff(
        3rdparty,
        strcat(USE_CASE_NAME, " [3rd Party]"),
        USE_CASE_NAME
      ),
      ":",
      stage
    ),
    Unknown = "Unknown"


**source**
Sentinel

**type_source**
ttp from Sentinel - description

