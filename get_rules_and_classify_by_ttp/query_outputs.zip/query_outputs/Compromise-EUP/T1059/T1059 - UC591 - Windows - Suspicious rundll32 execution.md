**technique_id**
T1059

**title**
UC591 - Windows - Suspicious rundll32 execution

**query**
// UC591 - Windows - Suspicious rundll32 execution
// version 1.0 - 2021-03-02
// The goal of this UC is to detect some suspicious execution of rundll32.exe
// based on the analysis of the command-line passed to the process creation.
// Mitre Tactic: TA0002
// Mitre Technique: T1059.003
let USE_CASE_NAME = "Windows - Suspicious rundll32 execution";
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4688"
  and destinationProcessName_s contains "rundll32.exe"
  and (
    deviceCustomString4_s has_any (
      "\\temp\\",
      "\\temporary\\",
      "%TEMP%",
      "\\perflogs\\"
    )
    or deviceCustomString4_s contains "javascript"
    or deviceCustomString4_s endswith "rundll32.exe"
    or deviceCustomString4_s endswith "rundll32"
    or (
      deviceCustomString4_s has_all (
        "rundll32",
        "comsvcs.dll"
      )
      and deviceCustomString4_s has_any (
        "MiniDump",
        "MiniDumpW",
        "#24"
      )
    )
  )
| where not(
    uc591MainFilteringOut(
      command_line = deviceCustomString4_s,
      entity = customerURI_s,
      account = destinationUserName_s,
      hostname = deviceHostName_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryOutcome_s,
    categoryBehavior_s = "Suspicious Resource",
    categorySignificance_s = "Suspicious Activity",
    customerURI_s,
    deviceProduct_s,
    deviceVendor_s,
    deviceCustomString4_s,
    destinationNtDomain_s = toupper(destinationNtDomain_s),
    destinationUserName_s = toupper(destinationUserName_s),
    destinationUserId_s,
    deviceHostName_s = toupper(deviceHostName_s),
    deviceAddress_s,
    message = strcat(
      "Rundll32 was used by ",
      toupper(destinationNtDomain_s),
      "\\",
      toupper(destinationUserName_s),
      " on ",
      deviceHostName_s,
      " with suspicious execution parameters. Check for malicious activity."
    ),
    name_s,
    deviceCustomString5_s,
    UpperfilePath = toupper(filePath_s),
    deviceCustomString3_s,
    Process_Name = destinationProcessName_s,
    sourceHostName_s,
    sourceAddress_s,
    Process_ID = deviceCustomString3_s,
    externalId_s,
    filePath_s,
    destinationHostName_s = toupper(destinationHostName_s),
    sourceNtDomain_s = toupper(sourceNtDomain_s),
    UpperfileName = toupper(fileName_s),
    destinationAddress_s,
    deviceCustomString5Label_s,
    deviceAction_s,
    deviceCustomString4Label_s,
    galaxyListName_s,
    galaxyListReference_s,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

