**technique_id**
T1059

**title**
Base64 encoded Windows process command-lines

**query**
let ProcessCreationEvents=(union isfuzzy=true
(SecurityEvent
| where EventID==4688
| where isnotempty(CommandLine)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), count() by Computer, Account = SubjectUserName, AccountDomain = SubjectDomainName,
FileName = Process, CommandLine, ParentProcessName
),
(WindowsEvent
| where EventID==4688
| where EventData has "TVqQAAMAAAAEAAA"
| extend CommandLine = tostring(EventData.CommandLine)
| where isnotempty(CommandLine)
| extend ParentProcessName = tostring(EventData.ParentProcessName)
| extend NewProcessName = tostring(EventData.NewProcessName)
| extend Process=tostring(split(NewProcessName, '\\')[-1])
| extend SubjectUserName = tostring(EventData.SubjectUserName)
| extend SubjectDomainName = tostring(EventData.SubjectDomainName)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), count() by Computer, Account = SubjectUserName, AccountDomain = SubjectDomainName,
FileName = Process, CommandLine, ParentProcessName));
ProcessCreationEvents
| where CommandLine contains "TVqQAAMAAAAEAAA"
| extend HostName = iif(Computer has '.',substring(Computer,0,indexof(Computer,'.')),Computer) , DnsDomain = iif(Computer has '.',substring(Computer,indexof(Computer,'.')+1),'')

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

