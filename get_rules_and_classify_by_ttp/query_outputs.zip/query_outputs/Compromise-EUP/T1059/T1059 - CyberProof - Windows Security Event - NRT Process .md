**technique_id**
T1059

**title**
CyberProof - Windows Security Event - NRT Process executed from binary hidden in Base64 encoded file

**query**
SecurityEvent
| where EventID==4688
| where isnotempty(CommandLine)
| project TimeGenerated, Computer, Account = SubjectUserName, AccountDomain = SubjectDomainName, FileName = Process, CommandLine, ParentProcessName
| where CommandLine contains ".decode('base64')"
        or CommandLine contains "base64 --decode"
        or CommandLine contains ".decode64("

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

