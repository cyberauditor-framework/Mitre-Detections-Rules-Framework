**technique_id**
T1059

**title**
CyberProof - Azure Activity - New CloudShell User

**query**
let match_window = 3m;
AzureActivity
| where ResourceGroup has "cloud-shell"
| where (OperationNameValue =~ "Microsoft.Storage/storageAccounts/listKeys/action")
| where ActivityStatusValue =~ "Success"
| extend TimeKey = bin(TimeGenerated, match_window), AzureIP = CallerIpAddress
| join kind = inner
(AzureActivity
| where ResourceGroup has "cloud-shell"
| where (OperationNameValue =~ "Microsoft.Storage/storageAccounts/write")
| extend TimeKey = bin(TimeGenerated, match_window), UserIP = CallerIpAddress
) on Caller, TimeKey
| summarize count() by TimeKey, Caller, ResourceGroup, SubscriptionId, TenantId, AzureIP, UserIP, HTTPRequest, Type, Properties, CategoryValue, OperationList = strcat(OperationNameValue, ' , ', OperationNameValue1)
| extend Name = tostring(split(Caller,'@',0)[0]), UPNSuffix = tostring(split(Caller,'@',1)[0])

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

