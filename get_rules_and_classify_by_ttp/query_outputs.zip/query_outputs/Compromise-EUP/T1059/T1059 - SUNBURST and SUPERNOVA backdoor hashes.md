**technique_id**
T1059

**title**
SUNBURST and SUPERNOVA backdoor hashes

**query**
let SunburstMD5=dynamic(["b91ce2fa41029f6955bff20079468448","02af7cec58b9a5da1c542b5a32151ba1","2c4a910a1299cdae2a4e55988a2f102e","846e27a652a5e1bfbd0ddd38a16dc865","4f2eb62fa529c0283b28d05ddd311fae"]);
let SupernovaMD5="56ceb6d0011d87b6e4d7023d7ef85676";
DeviceFileEvents
| where MD5 in(SunburstMD5) or MD5 in(SupernovaMD5)
| extend timestamp = TimeGenerated, Account = iff(isnotempty(InitiatingProcessAccountUpn), InitiatingProcessAccountUpn, InitiatingProcessAccountName),AlgorithmEntity = "MD5" ,FileHashEntity = MD5

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

