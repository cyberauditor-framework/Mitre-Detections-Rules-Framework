**technique_id**
T1059

**title**
UC453 - Windows - Suspicious Powershell Activity v2

**query**
// UC453 - Windows - Suspicious Powershell Activity v2
// Mitre Tactic: TA0002
// Mitre Technique: T1059
let USE_CASE_NAME = "Windows - Suspicious Powershell Activity v2";
let invoke_commands = toscalar(
    uc453PowershellInvokeCommandsFunc
    | summarize commands = make_set(
          strcat(
            "(?i:",
            MaliciousKeyword,
            ")"
          )
        )
    | project commands
  );
let invoke_commands_regex = strcat(
    "(",
    strcat_array(
      invoke_commands,
      "|"
    ),
    ")"
  );
let bits_commands = toscalar(
    uc453PowershellBitsCommandsFunc
    | summarize keywords = make_set(
          strcat(
            "(?i:",
            MaliciousKeyword,
            ")"
          )
        )
    | project keywords
  );
let bits_commands_regex = strcat(
    "(",
    strcat_array(
      bits_commands,
      "|"
    ),
    ")"
  );
let known_malicious_keywords = toscalar(
    uc453PowershellMaliciousKeywordsFunc
    | summarize keywords = make_set(
          strcat(
            "(?i:",
            MaliciousKeyword,
            ")"
          )
        )
    | project keywords
  );
let known_malicious_keywords_regex = strcat(
    "(",
    strcat_array(
      known_malicious_keywords,
      "|"
    ),
    ")"
  );
let icRegexFunc = (invoke_commands_regex:string, deviceCustomString4_s:string){
    extract_all(invoke_commands_regex, deviceCustomString4_s)
  };
let bcRegexFunc = (bits_commands_regex:string, deviceCustomString4_s:string){
    extract_all(bits_commands_regex, deviceCustomString4_s)
  };
let kmkRegexFunc = (known_malicious_keywords_regex:string, deviceCustomString4_s:string){
    extract_all(known_malicious_keywords_regex, deviceCustomString4_s)
  };
AxALiveStream_CL
| where TimeGenerated > ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4688"
  and destinationProcessName_s has "powershell"
| extend flag = case(
      (
        deviceCustomString4_s has_all ("Net", "WebClient")
        and (
          deviceCustomString4_s has_any ("downloadfile", "DownloadString", "download")
          or (
            deviceCustomString4_s contains "-com"
            and (
              deviceCustomString4_s contains "InternetExplorer"
              or deviceCustomString4_s contains "WinHttp"
            )
          )
        )
      ),
      "Potential Download",
      deviceCustomString4_s contains "-querytype=txt", "DNS Exfiltration",
      deviceCustomString4_s has_any ("-e", "enc", "encodedCommand", "bxor"), "Encoded Command",
      deviceCustomString4_s has_all ("set-content", "-stream"), "NTFS Alternate Data Stream",
      deviceCustomString4_s has_any (uc453PowershellInvokeCommandsFunc), "Invoke Commands",
      deviceCustomString4_s has_any (uc453PowershellBitsCommandsFunc), "BITS Commands",
      deviceCustomString4_s has_any (uc453PowershellMaliciousKeywordsFunc), "Known Malicious Keywords",
      deviceCustomString4_s has "reg", "Registry activity",
      deviceCustomString4_s contains "ScheduledTask", "ScheduledTask",
      deviceCustomString4_s has "hidden" and deviceCustomString4_s has_any ("-w", "-window", "-windowstyle"),
      "Hidden window",
      deviceCustomString4_s has "2" and deviceCustomString4_s has_any (
        "-v",
        "-ve",
        "-ver",
        "-vers",
        "-versio",
        "-version"
      ), "Downgrade version",
      ""
    )
| where isnotempty(flag)
| extend
    decodedCommand = iff(
      flag == "Encoded Command",
      replace_string(
        base64_decode_tostring(
          replace_string(
            extract(@"(\S+=)", 0, deviceCustomString4_s),
            @'\',
            ""
          )
        ),
        "\0",
        ""
      ),
      ""
    )
| where not(
    uc453MainFilteringOut(
      command_line = deviceCustomString4_s,
      account = destinationUserName_s,
      hostname = destinationHostName_s,
      ip = destinationHostName_s,
      process = destinationProcessName_s,
      category = flag,
      decoded_command = decodedCommand,
      entity = customerURI_s,
      domain = destinationNtDomain_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend mpiFeedAndAlertStage = (
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI)
    )
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(mpiFeedAndAlertStage, mpi_stage, stage)
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryBehavior = "TO_CHANGE",
    categorySignificance = "Intrusion",
    name_s,
    customerURI_s,
    destinationHostName_s,
    destinationNtDomain_s,
    destinationUserName_s,
    destinationUserId_s,
    deviceCustomString5_s,
    deviceCustomString4_s,
    destinationAddress_s,
    destinationProcessName_s,
    Stage_URI = iff(mpiFeedAndAlertStage, MPI_Stage_URI, Stage_URI),
    galaxyListName_s,
    galaxyListReference_s,
    flag,
    stage,
    decodedCommand,
    Suspicious_Keyword = case(
      flag == "Invoke Commands", icRegexFunc(invoke_commands_regex, deviceCustomString4_s),
      flag == "BITS Commands", bcRegexFunc(bits_commands_regex, deviceCustomString4_s),
      flag == "Known Malicious Keywords", kmkRegexFunc(known_malicious_keywords_regex, deviceCustomString4_s),
      ""
    ),
    message = strcat(
      "Suspicious powershell activity observed on server ",
      destinationHostName_s,
      "[",
      destinationAddress_s,
      "] launched by ",
      destinationNtDomain_s,
      "/",
      destinationUserName_s
    ),
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    ),
    Unknown = "Unknown"
| where not(
    isSuppressedFunc(
      suppressed_entities = strcat(destinationUserName_s, destinationHostName_s, URL, deviceCustomString4_s),
      lookback_from = 8h,
      lookback_to = 1tick
    )
  )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

