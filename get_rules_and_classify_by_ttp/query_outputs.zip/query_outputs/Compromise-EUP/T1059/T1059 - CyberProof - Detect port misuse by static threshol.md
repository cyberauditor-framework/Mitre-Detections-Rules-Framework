**technique_id**
T1059

**title**
CyberProof - Detect port misuse by static threshold (ASIM Network Session schema)

**query**
let lookback = 10m; 
let mapping = _GetWatchlist('NetworkSession_Monitor_Configuration')
| where Type == "Detection" and ThresholdType == "Static" and Severity != "Disabled"  
| extend Ports = split(Ports,","),
        App = split(App,","),
        Protocol = split(Protocol,","),
        Direction = split(Direction,","),
        Action = split(Action,",")
| project Ports, App, Protocol, Direction, Action, Type, ThresholdType, Threshold, Severity, Tactic, Name, Description
| mv-expand Ports
| mv-expand App
| mv-expand Protocol
| mv-expand Direction
| mv-expand Action
| extend Ports = tostring(Ports), App = tostring(App), Protocol = tostring(Protocol), Direction = tostring(Direction), Action = tostring(Action), Threshold = toint(Threshold)
;
let nosummary = materialize(
              union isfuzzy=true 
                (
                    NetworkCustomAnalytics_protocol_CL 
                    | project v = int(2)
                ),
                (
                    print int(1) 
                    | project v = print_0
                )
                | summarize maxv = max(v)
                | extend nosum = (maxv > 1)
              );
let allData = union isfuzzy=true 
    (
        (datatable(exists:int, nosum:bool)[1,false] | join (nosummary) on nosum) | join (
        _Im_NetworkSession(starttime=bin(now(-10m),10m), endtime=bin(now(),10m))
        | where TimeGenerated > bin(now(-10m),10m)
        | summarize Count=count() by NetworkProtocol, DstPortNumber, DstAppName, NetworkDirection, DvcAction, bin(TimeGenerated,10m)
        | extend EventTime = TimeGenerated, Count = toint(Count), DstPortNumber = toint(DstPortNumber), exists=int(1)
        ) on exists
        | project-away exists, maxv, nosum*
    ),
    (
        NetworkCustomAnalytics_protocol_CL
        | where EventTime_t == toscalar(NetworkCustomAnalytics_protocol_CL | summarize max(EventTime_t))
        | project-rename NetworkProtocol=NetworkProtocol_s, DstPortNumber=DstPortNumber_d, DstAppName=DstAppName_s, NetworkDirection=NetworkDirection_s, DvcAction=DvcAction_s, Count=count__d, EventTime=EventTime_t
        | extend Count = toint(Count),DstPortNumber = toint(DstPortNumber)
    )
;
allData
      | where isnotempty(DstPortNumber)
      | summarize Sum=sum(Count) by DstPortNumber, NetworkProtocol, NetworkDirection, DvcAction 
      | join kind=inner ['mapping'] where Ports has tostring(DstPortNumber)
      | where Sum > Threshold         
                and (Protocol == "*" or Protocol has NetworkProtocol)
                and (Direction == "*" or Direction has NetworkDirection)
                and (Action == "*" or Action has DvcAction)
      | project Name, Description, NetworkProtocol, DstPortNumber, NetworkDirection, DvcAction, Severity, Tactic
      | summarize NetworkProtocols=make_set_if(NetworkProtocol,isnotempty(NetworkProtocol),20), 
                  NetworkDirections=make_set_if(NetworkDirection,isnotempty(NetworkDirection),5), 
                  DvcActions=make_set_if(DvcAction,isnotempty(DvcAction),10) by Name, Severity, Tactic, DstPortNumber, Description

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

