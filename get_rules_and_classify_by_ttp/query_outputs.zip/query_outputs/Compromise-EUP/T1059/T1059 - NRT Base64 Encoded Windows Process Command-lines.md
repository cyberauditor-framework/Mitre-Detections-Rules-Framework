**technique_id**
T1059

**title**
NRT Base64 Encoded Windows Process Command-lines

**query**
SecurityEvent
 | where EventID == 4688
 | where isnotempty(CommandLine)
 | where CommandLine contains "TVqQAAMAAAAEAAA"
 | extend HostName = tostring(split(Computer, '.', 0)[0]), DnsDomain = tostring(strcat_array(array_slice(split(Computer, '.'), 1, -1), '.'))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

