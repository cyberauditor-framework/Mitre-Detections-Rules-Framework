**technique_id**
T1059

**title**
UC983 - Windows - Process executed from binary hidden in Base64 encoded file

**query**
// UC983 - Windows - Process executed from binary hidden in Base64 encoded file
// The goal of this use-case is to detect some suspicious execution of python,
// bash/sh or ruby trying to run binary hidden in Base64 encoded file.
// Mitre Tactic: TA0002, TA0005
// Mitre Technique: T1059
let USE_CASE_NAME = "Windows - Process executed from binary hidden in Base64 encoded file";
let suspicious_commandline = dynamic(
    [
      ".decode('base64')",
      "base64 --decode",
      ".decode64("
    ]
  );
AxALiveStream_CL
| where TimeGenerated > ago(1h)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where externalId_s == "4688"
| where deviceCustomString4_s has_any (suspicious_commandline)
| where not(
    uc983MainFilteringOut(
      payload = deviceCustomString4_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      (strcat (USE_CASE_NAME, " [3rd Party]")),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    customerURI_s,
    galaxyListName_s,
    galaxyListReference_s,
    deviceAddress_s,
    deviceHostName_s,
    destinationUserName_s,
    deviceCustomString3_s,
    deviceCustomString3Label_s,
    deviceCustomString4_s,
    deviceCustomString5_s,
    filePath_s,
    Message,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    URLCustomEntity = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

