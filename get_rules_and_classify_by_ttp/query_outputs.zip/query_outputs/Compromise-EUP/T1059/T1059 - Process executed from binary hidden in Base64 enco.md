**technique_id**
T1059

**title**
Process executed from binary hidden in Base64 encoded file

**query**
let ProcessCreationEvents=() {
let processEvents=SecurityEvent
| where EventID==4688
| where isnotempty(CommandLine)
| project TimeGenerated, Computer, Account = SubjectUserName, AccountDomain = SubjectDomainName, FileName = Process, CommandLine, ParentProcessName;
processEvents;
};
ProcessCreationEvents 
| where CommandLine contains ".decode('base64')"
        or CommandLine contains "base64 --decode"
        or CommandLine contains ".decode64(" 
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), CountToday = count() by Computer, Account, AccountDomain, FileName, CommandLine, ParentProcessName 
| extend timestamp = StartTimeUtc, AccountCustomEntity = Account, HostCustomEntity = Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

