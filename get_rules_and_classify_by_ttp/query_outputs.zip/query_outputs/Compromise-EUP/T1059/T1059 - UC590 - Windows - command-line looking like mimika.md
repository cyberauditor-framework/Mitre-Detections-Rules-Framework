**technique_id**
T1059

**title**
UC590 - Windows - command-line looking like mimikatz

**query**
// UC590 - Windows - command-line looking like mimikatz
// version 1.0 - 2021-03-04
// The goal of this use case aims is to detecte renamed / repacked / undetected
// version of mimikatz by looking at specific command line arguments.
// Mitre Tactic: TA0002
// Mitre Technique: T1059
let USE_CASE_NAME = "Windows - command-line looking like mimikatz";
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4688"
  and deviceCustomString4_s has_any (
    "LSADUMP::",
    "SEKURLSA::",
    "CRYPTO::",
    "KERBEROS::",
    "TOKEN::"
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryOutcome_s,
    categoryBehavior_s = "Hacktool",
    categorySignificance_s = "Malware",
    customerURI_s,
    deviceProduct_s,
    deviceVendor_s,
    deviceCustomString4_s,
    destinationNtDomain_s,
    destinationUserName_s,
    destinationUserId_s,
    deviceHostName_s,
    deviceAddress_s,
    message = strcat(
      "A process was executed on ",
      deviceHostName_s,
      " by ",
      destinationNtDomain_s,
      "\\",
      destinationUserName_s,
      " with a command-line that include arguments typical to mimikatz"
    ),
    name_s,
    deviceCustomString5_s,
    filePath_s,
    deviceCustomString3_s,
    Process_Name = destinationProcessName_s,
    sourceHostName_s,
    sourceAddress_s,
    Process_ID = deviceCustomString3_s,
    externalId_s,
    galaxyListName_s,
    galaxyListReference_s,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

