**technique_id**
T1059

**title**
UC802 - CyberReason - Remote Shell Execution

**query**
// UC802 - CyberReason - Remote Shell Execution
// This Use case detects when there a remote shell execution occurs from the Cybereason Portal
// Mitre Tactic:TA0002
// Mitre Technique:T1059.003
let USE_CASE_NAME = "CyberReason - Remote Shell Execution";
CLCEDR_CL
| where TimeGenerated > ago(5m)
| where DeviceVendor_s == "Cybereason" and DeviceProduct_s == "EDR"
| where DeviceEventClassId_s == "UserAction" and Name_s == "Remote Shell/Connect"
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = DeviceCustomString1_s,
      destination_account = "",
      source_ip = DeviceAddress_s,
      destination_ip = ""
    )
| extend name_s = iff(
      3rdparty,
      (strcat (USE_CASE_NAME, " [3rd Party]")),
      USE_CASE_NAME
    )
| project
    userName = iff(
      DeviceCustomString1_s == "/",
      "",
      DeviceCustomString1_s
    ),
    machineName = iff(
      deviceHostName_s matches regex "\\d+\\.\\d+\\.\\d+\\.\\d+",
      "",
      deviceHostName_s
    ),
    machineIP = DeviceAddress_s,
    actionSuccess = iff(
      DeviceCustomNumber1_s == 1,
      "Success",
      "Failure"
    ),
    input = DeviceCustomString2_s,
    remote_shell_mode = DeviceCustomString3_s,
    action = deviceAction_s,
    entity = entity_s,
    entityname = entityname_s,
    Galaxy_List_Name_s,
    Galaxy_List_Reference_s,
    customerURI_s,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    AccountCustomEntity = iff(
      DeviceCustomString1_s == "/",
      "",
      DeviceCustomString1_s
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

