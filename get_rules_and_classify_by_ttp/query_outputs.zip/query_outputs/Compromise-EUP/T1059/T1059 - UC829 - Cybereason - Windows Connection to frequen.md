**technique_id**
T1059

**title**
UC829 - Cybereason - Windows Connection to frequently abused SSL Provider

**query**
// UC829 - Cybereason - Windows Connection to frequently abused SSL Provider
// Detects process which executes connections to these free SSL certificates providers:
// letsencrypt.org, sslforfree.com, zerossl.com, freessl.org
// Adversaries may employ a known encryption algorithm to conceal command and control traffic.
// Mitre Tactic: TA0002, TA0011, TA0042
// Mitre Technique: T1059, T1573, T1588
let USE_CASE_NAME = "Cybereason - Windows Connection to frequently abused SSL Provider";
let MalopMachineTable = CLCEDR_CL
  | where TimeGenerated > ago(5m)
  | where DeviceVendor_s == "Cybereason"
  | where Name_s in ("Malop Machine Information", "Malop Updated Machine Information")
  | project
      DeviceCustomDate1_s,
      DeviceCustomString1_s,
      affectedUsers = SourceUserName_s,
      affectedMachine = toupper(DeviceCustomString2_s),
      countOfAffectedHosts = DeviceCustomNumber1_s;
CLCEDR_CL
| where TimeGenerated > ago(5m)
| where DeviceVendor_s == "Cybereason"
| where Name_s in ("Malop Created", "Malop Updated")
| where DeviceCustomString2_s == "CUSTOM_RULE"
| extend
    ruleID = trim_start(@"[^\d]+", DeviceCustomString5_s),
    linkToMalop = DeviceCustomString6_s
| where (Syslog_hostname_s == "entity005" and ruleID == "2111628743735806")
//Suppression function part
| where not(
    isSuppressedFunc(
      suppressed_entities = linkToMalop,
      lookback_from = 24h,
      lookback_to = 1tick
    )
  )
| join MalopMachineTable on DeviceCustomString1_s, $left.DeviceCustomDate2_s == $right.DeviceCustomDate1_s
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      sourceUserName_s,
      "",
      "",
      sourceAddress_s
    )
| extend
    name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    TimeGenerated,
    malopSuspect = DeviceCustomString4_s,
    linkToMalop,
    malopKeySuspicion = DeviceCustomString5_s,
    malopActivityType = DeviceCustomString3_s,
    affectedUsers,
    malopDetectionType = DeviceCustomString2_s,
    malopId = DeviceCustomString1_s,
    affectedMachine,
    Severity_s,
    Name_s,
    entity = Syslog_hostname_s,
    ruleID,
    Galaxy_List_Reference_s,
    Galaxy_List_Name_s,
    countOfAffectedAccounts = DeviceCustomNumber2_s,
    countOfAffectedHosts,
    Unknown = "Unknown"

**source**
Sentinel

**type_source**
ttp from Sentinel - description

