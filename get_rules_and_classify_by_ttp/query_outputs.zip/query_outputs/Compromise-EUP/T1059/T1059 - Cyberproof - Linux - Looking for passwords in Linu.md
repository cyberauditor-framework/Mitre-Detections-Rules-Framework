**technique_id**
T1059

**title**
CyberProof - Linux - Looking for passwords in Linux Systems via cmdline

**query**
Syslog | where (((((SyslogMessage contains @'find' and SyslogMessage contains @'/dev/null' and SyslogMessage contains @'grep' and (SyslogMessage contains @'-type' or SyslogMessage contains @'-exec' or SyslogMessage contains @'"PASSWORD'))) or ((SyslogMessage contains @'find' and SyslogMessage contains @'/dev/null' and SyslogMessage contains @'grep' and (SyslogMessage contains @'-mmin' or SyslogMessage contains @'-Ev' or SyslogMessage contains @'/proc'))))) or ((SyslogMessage contains @'strings' and SyslogMessage contains @'/dev/mem' and SyslogMessage contains @'-n10' and SyslogMessage contains @'grep' and SyslogMessage contains @'-i' and SyslogMessage contains @'PASS')))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

