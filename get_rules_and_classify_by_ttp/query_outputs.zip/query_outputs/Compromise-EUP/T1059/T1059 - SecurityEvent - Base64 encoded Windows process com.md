**technique_id**
T1059

**title**
SecurityEvent - Base64 encoded Windows process command-lines

**query**
let timeframe = 1d;
let ProcessCreationEvents=() {
let processEvents=SecurityEvent
| where EventID==4688
| where isnotempty(CommandLine)
| summarize StartTimeUtc = min(TimeGenerated), EndTimeUtc = max(TimeGenerated), count() by Computer, Account = SubjectUserName, AccountDomain = SubjectDomainName,
FileName = Process, CommandLine, ParentProcessName;
processEvents};
ProcessCreationEvents
| where CommandLine contains "TVqQAAMAAAAEAAA"
| where StartTimeUtc >= ago(timeframe)
| extend timestamp = StartTimeUtc, AccountCustomEntity = Account, HostCustomEntity = Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

