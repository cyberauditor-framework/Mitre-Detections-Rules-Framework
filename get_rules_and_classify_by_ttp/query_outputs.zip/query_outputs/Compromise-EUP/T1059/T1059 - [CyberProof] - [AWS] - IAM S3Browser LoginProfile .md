**technique_id**
T1059

**rule**
nan

**source**
Qradar

**type_source**
ttp from Qradar - AWS - Mitre Technique

