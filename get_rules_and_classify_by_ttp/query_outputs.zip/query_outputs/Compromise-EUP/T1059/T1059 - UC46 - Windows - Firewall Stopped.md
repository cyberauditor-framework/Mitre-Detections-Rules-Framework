**technique_id**
T1059

**title**
UC46 - Windows - Firewall Stopped

**query**
// UC46 - Windows - Firewall Stopped
let USE_CASE_NAME = "Windows - Firewall Stopped";
let firewall_stopped__windows_event_ids = dynamic(
    [
      "Microsoft-Windows-Security-Auditing:5025",
      "Microsoft-Windows-Security-Auditing:5027",
      "Microsoft-Windows-Security-Auditing:5028",
      "Microsoft-Windows-Security-Auditing:5029",
      "Microsoft-Windows-Security-Auditing:5030",
      "Microsoft-Windows-Security-Auditing:5034",
      "Microsoft-Windows-Security-Auditing:5035",
      "Microsoft-Windows-Security-Auditing:5037"
    ]
  );
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s in (firewall_stopped__windows_event_ids)
| where not(
    uc46MainFilteringOut(
      entity = customerURI_s,
      event_id = deviceEventClassId_s
    )
  )
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend 3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    )
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    categoryBehavior_s = "Security Bypass",
    categoryCustomFormatField = "/Attack Life Cycle/Exploitation",
    categoryDeviceGroup = "/Operating system",
    categoryDeviceType = "/Windows",
    categoryOutcome_s,
    categorySignificance_s = "Policy Violation",
    categoryTupleDescription = "UC46",
    customerURI_s,
    deviceAction_s,
    deviceAddress_s,
    deviceCustomNumber2_s,
    deviceEventClassId_s,
    deviceHostName_s,
    deviceProduct_s,
    deviceVendor_s,
    galaxyListName_s,
    galaxyListReference_s,
    message = strcat(
      "This use case will alert when the windows firewall receives one of the many error messages.",
      " Review the message and look for corresponding alerts of further security issues "
    ),
    name_s,
    Stage_URI,
    URL = strcat (
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

