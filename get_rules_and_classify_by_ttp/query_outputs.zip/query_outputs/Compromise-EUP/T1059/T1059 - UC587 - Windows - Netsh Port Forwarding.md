**technique_id**
T1059

**title**
UC587 - Windows - Netsh Port Forwarding

**query**
// UC587 - Windows - Netsh Port Forwarding
// version 1.0 - 2021-03-02
// This use case aims at detecting the creation of connection proxies
// through windows port forwarding set up by netsh command line.
// Mitre Tactic: TA0002
// Mitre Technique: T1059
let USE_CASE_NAME = "Windows - Netsh Port Forwarding";
AxALiveStream_CL
| where TimeGenerated >= ago(5m)
| where deviceVendor_s == "Microsoft" and deviceProduct_s == "Microsoft Windows"
| where deviceEventClassId_s == "Microsoft-Windows-Security-Auditing:4688"
  and deviceCustomString4_s has "portproxy"
  and deviceCustomString4_s contains "add"
  and destinationProcessName_s contains "netsh.exe"
| extend isMPI = isMPIFeedFunc(feed_source = column_ifexists("_QuerySource_s", "N/A"))
| join kind = inner useCaseStatusManagementListMergedFunc(use_case_name = USE_CASE_NAME)
  on $left.customerURI_s == $right.CustomerURI
| extend
    3rdparty = isThirdPartyFunc(
      source_account = sourceUserName_s,
      destination_account = destinationUserName_s,
      source_ip = sourceAddress_s,
      destination_ip = destinationAddress_s
    ),
    stage = iff(
      isMPI
      and stage == "Alert"
      and isnotempty(MPI_Stage_URI),
      mpi_stage,
      stage
    )
| where stage in ("Alert", "Tuning")
| extend name_s = iff(
      3rdparty,
      strcat(USE_CASE_NAME, " [3rd Party]"),
      USE_CASE_NAME
    )
| project
    TimeGenerated,
    URL = strcat(
      customerURI_s,
      ":",
      name_s,
      ":",
      stage
    ),
    categoryOutcome_s,
    categoryBehavior_s = "Security Bypass",
    categorySignificance_s = "Policy Violation",
    customerURI_s,
    deviceProduct_s,
    deviceVendor_s,
    deviceCustomString4_s,
    Column1 = toupper(destinationNtDomain_s),
    Column2 = toupper(destinationUserName_s),
    destinationNtDomain_s,
    destinationUserId_s,
    Column3 = toupper(deviceHostName_s),
    deviceAddress_s,
    message = strcat(
      "A local port proxy has been configured using netsh on ",
      deviceHostName_s,
      " by ",
      toupper(destinationNtDomain_s),
      "\\",
      toupper(destinationUserName_s)
    ),
    name_s,
    deviceCustomString5_s,
    filePath_s,
    deviceCustomString3_s,
    Process_Name = destinationProcessName_s,
    Column4 = toupper(sourceHostName_s),
    sourceAddress_s,
    Process_ID = deviceCustomString3_s,
    externalId_s,
    destinationAddress_s,
    deviceCustomString5Label_s,
    Column5 = toupper(destinationHostName_s),
    deviceAction_s,
    Column6 = toupper(fileName_s),
    deviceCustomString4Label_s,
    Column7 = toupper(sourceNtDomain_s),
    destinationHostName_s,
    deviceHostName_s,
    destinationUserName_s,
    sourceUserName_s,
    galaxyListName_s,
    galaxyListReference_s,
    UCName = iff(
      mpi_stage == "Tuning" and isMPI,
      strcat(USE_CASE_NAME, " - MPI"),
      USE_CASE_NAME
    )

**source**
Sentinel

**type_source**
ttp from Sentinel - description

