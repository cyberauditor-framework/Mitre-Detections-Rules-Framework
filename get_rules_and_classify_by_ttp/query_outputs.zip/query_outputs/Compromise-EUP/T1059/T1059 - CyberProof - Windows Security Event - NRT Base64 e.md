**technique_id**
T1059

**title**
CyberProof - Windows Security Event - NRT Base64 encoded Windows process command-lines

**query**
SecurityEvent
 | where EventID==4688
 | where isnotempty(CommandLine)
 | where CommandLine contains "TVqQAAMAAAAEAAA"

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

