**technique_id**
T1485

**title**
CyberProof - Azure Storage - Azure Storage Mass File Deletion

**query**
//https://bi-sec.atlassian.net/browse/COP-1671 - Severity Change
 let deleteThreshold = 3;
  let deleteWindow = 10m;
  union
  StorageFileLogs,
  StorageBlobLogs
  | where StatusText =~ "Success"
  | where OperationName =~ "DeleteBlob" or OperationName =~ "DeleteFile"
  | extend CallerIpAddress = tostring(split(CallerIpAddress, ":", 0)[0])
  | summarize dcount(Uri) by bin(TimeGenerated, deleteWindow), CallerIpAddress, UserAgentHeader, AccountName
  | where dcount_Uri >= deleteThreshold
  | project TimeGenerated, IPCustomEntity=CallerIpAddress, UserAgentHeader, FilesDeleted=dcount_Uri, AccountName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

