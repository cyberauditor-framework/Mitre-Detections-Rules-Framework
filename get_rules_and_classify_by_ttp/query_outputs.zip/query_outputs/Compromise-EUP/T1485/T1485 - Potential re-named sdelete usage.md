**technique_id**
T1485

**title**
Potential re-named sdelete usage

**query**
SecurityEvent
  | where EventID == 4688
  | where Process !~ "sdelete.exe"
  | where CommandLine has_all ("accepteula", "-r", "-s", "-q", "c:/")
  | where CommandLine !has ("sdelete")

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

