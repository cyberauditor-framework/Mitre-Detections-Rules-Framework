**technique_id**
T1485

**rule**
nan

**source**
Qradar

**type_source**
ttp from Qradar - Baseline - Mitre Technique

