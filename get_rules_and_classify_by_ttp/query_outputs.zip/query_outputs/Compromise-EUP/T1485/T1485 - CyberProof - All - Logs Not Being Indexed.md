**technique_id**
T1485

**title**
CyberProof - All - Logs Not Being Indexed

**description**
This will trigger if one of the sourcetypes did not send data for a period of time exceeding the established limits.

**query**
| tstats count, earliest(_time), latest(_time) values(sourcetype) as sourcetype  WHERE (index=okta sourcetype=OktaIM2:log) OR (index=google sourcetype=gws:reports:admin OR sourcetype=gws:reports:drive OR sourcetype=gws:reports:login) OR (index=meraki sourcetype=meraki) OR (index=salesforce sourcetype=sfdc:user) OR (index=salesforce_audit sourcetype=sfdc:setupaudittrail) OR (index=windows sourcetype=wineventlog ) OR (index=palo_alto) OR (index=cisco_ise) OR (index=cloud_aws sourcetype=aws:cloudtrail) OR (index=meraki_api sourcetype=meraki:audit) OR (index=vuln_wiz sourcetype=wiz:issues) OR (index=sentinelone  sourcetype=sentinelone:channel:activities  sourcetype=sentinelone:channel:threats ) BY index
| rename "earliest(_time)" as earliest_time, "latest(_time)" as latest_time
| eval diff=(now() - latest_time), difference_in_mins=(diff / 60), CT=now(), difference_in_mins=round(difference_in_mins,2)

| eval winevenlog_limit = 60
| eval OktaIM2_limit = 180
| eval gws_admin_limit = 60
| eval gws_drive_limit = 60
| eval gws_login_limit = 1460
| eval meraki_limit = 30
| eval sfdc_setupaudittrail_limit = 268
| eval sfdc_user_limit = 300
| eval palo_alto_limit = 5760
| eval cisco_ise_limit = 5760
| eval aws_limit = 125
| eval meraki_api_limit = 9378
| eval vuln_wiz_limit = 1721
| eval sentinelone_limit = 1440

| eval winevenlog_comparison = if(sourcetype="wineventlog" AND difference_in_mins>winevenlog_limit,1,0)
| eval OktaIM2_comparison = if(sourcetype="OktaIM2:log" AND difference_in_mins>OktaIM2_limit,1,0)
| eval gws_admin_comparison = if(sourcetype="gws:reports:admin" AND difference_in_mins>gws_admin_limit ,1,0)
| eval gws_drive_comparison = if(sourcetype="gws:reports:drive" AND difference_in_mins>gws_drive_limit ,1,0)
| eval gws_login_comparison = if(sourcetype="gws:reports:login" AND difference_in_mins>gws_login_limit ,1,0)
| eval meraki_comparison = if(sourcetype="meraki" AND difference_in_mins>meraki_limit ,1,0)
| eval sfdc_setupaudittrail_comparison = if(sourcetype="sfdc:setupaudittrail" AND difference_in_mins>sfdc_setupaudittrail_limit ,1,0)
| eval sfdc_user_comparison = if(sourcetype="sfdc:user" AND difference_in_mins>sfdc_user_limit ,1,0)
| eval palo_alto_comparison = if(index="palo_alto" AND difference_in_mins>palo_alto_limit ,1,0)
| eval cisco_ise_comparison = if(index="cisco_ise" AND difference_in_mins>cisco_ise_limit ,1,0)
| eval aws_comparison = if(sourcetype="aws:cloudtrail" AND difference_in_mins>aws_limit ,1,0)
| eval meraki_api_comparison = if(sourcetype="meraki:audit" AND difference_in_mins>meraki_api_limit ,1,0)
| eval vuln_wiz_comparison = if(sourcetype="wiz:issues" AND difference_in_mins>vuln_wiz_limit ,1,0)
| eval sentinelone_activity_comparison = if(sourcetype="sentinelone:channel:activities" AND difference_in_mins>sentinelone_limit ,1,0)
| eval sentinelone_threat_comparison = if(sourcetype="sentinelone:channel:threats" AND difference_in_mins>sentinelone_limit ,1,0)


| where winevenlog_comparison = 1 OR OktaIM2_comparison=1 OR gws_admin_comparison=1 OR gws_drive_comparison=1 OR gws_login_comparison=1 OR meraki_comparison=1 OR sfdc_setupaudittrail_comparison=1 OR sfdc_user_comparison=1 OR palo_alto_comparison=1 OR cisco_ise_comparison=1 OR aws_comparison=1 OR meraki_api_comparison=1 OR vuln_wiz_comparison=1 OR sentinelone_activity_comparison=1 OR sentinelone_threat_comparison=1
| convert timeformat="%D %H:%M:%S" cTime(latest_time) as LastTimeReported cTime(CT) as CurrentTime
| rename difference_in_mins as No_of_minutes_not_received_from   
| eval meta="index=".index." AND sourcetype= ".sourcetype." has stopped reporting"
| table index, sourcetype, LastTimeReported, CurrentTime, No_of_minutes_not_received_from,meta

**source**
Splunk

**type_source**
ttp from Splunk - Mitre Technique

