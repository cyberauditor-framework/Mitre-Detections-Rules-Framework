**technique_id**
T1485

**title**
CyberProof - CyberArk - Safe Deletion

**query**
CommonSecurityLog
| where DeviceVendor == "Cyber-Ark" and DeviceAction != "" and SourceUserName != ""
| where DeviceEventClassID == "142"
    or DeviceEventClassID == "145"
    or DeviceEventClassID == "148"
    or DeviceEventClassID == "149" 
    or DeviceEventClassID == "170"
    or DeviceEventClassID == "183"
| project
    SourceHostName,
    SourceUserName,
    DestinationUserName,
    DestinationHostName,
    DeviceEventClassID,
    DeviceAction,
    LogSeverity,
    DeviceEventCategory,
    DeviceName

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

