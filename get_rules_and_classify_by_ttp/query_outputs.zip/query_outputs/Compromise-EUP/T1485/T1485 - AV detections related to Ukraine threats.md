**technique_id**
T1485

**title**
AV detections related to Ukraine threats

**query**
let UA_threats = dynamic(["FoxBlade", "WhisperGate", "Lasainraw", "SonicVote", "CaddyWiper", "AprilAxe", "FiberLake", "Industroyer", "DesertBlade"]);
  SecurityAlert
  | where ProviderName =~ "MDATP"
  | extend ThreatFamilyName = tostring(parse_json(ExtendedProperties).ThreatFamilyName)
  | where ThreatFamilyName in~ (UA_threats)
  | extend HostName = iff(CompromisedEntity has '.', substring(CompromisedEntity,0,indexof(CompromisedEntity,'.')),CompromisedEntity)
  | extend DnsDomain = iff(CompromisedEntity has '.', substring(CompromisedEntity,indexof(CompromisedEntity,'.')+1),"")

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

