**technique_id**
T1485

**title**
CyberProof - ALPHV/BlackCat Ransomware Detection

**query**
let ALPHVBlackCatIOCs = _GetWatchlist('ALPHVBlackCatIOCs');
let Hashes = (ALPHVBlackCatIOCs | where TYPE == "SHA1" or TYPE == "SHA256" or TYPE == "MD5" | project INDICATOR);
let IPList = (ALPHVBlackCatIOCs | where TYPE =~ "IPv4"| project INDICATOR);
let domains = (ALPHVBlackCatIOCs | where TYPE =~ "FQDN"| project INDICATOR);
let process = (ALPHVBlackCatIOCs | where TYPE contains "file"| project INDICATOR);
let IPRegex = '[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}';
(union isfuzzy=true
(VMConnection
| where SourceIp in (IPList) or DestinationIp in (IPList) or RemoteDnsCanonicalNames has_any (domains)
| parse RemoteDnsCanonicalNames with * '["' DNSName '"]' *
| project TimeGenerated, Computer, Direction, ProcessName, SourceIp, DestinationIp, DestinationPort, RemoteDnsQuestions, DNSName,BytesSent, BytesReceived, RemoteCountry, Type
| extend IPMatch = case( SourceIp in (IPList), "SourceIP", DestinationIp in (IPList), "DestinationIP", "None") 
| extend timestamp = TimeGenerated, IPEntity = case(IPMatch == "SourceIP", SourceIp, IPMatch == "DestinationIP", DestinationIp, "NoMatch"), File = ProcessName
),
(Event
| where Source == "Microsoft-Windows-Sysmon"
| where EventID == 3
| extend EvData = parse_xml(EventData)
| extend EventDetail = EvData.DataItem.EventData.Data
| extend SourceIP = tostring(EventDetail.[9].["#text"]), DestinationIP = tostring(EventDetail.[14].["#text"]), Image = tostring(EventDetail.[4].["#text"])
| where SourceIP in (IPList) or DestinationIP in (IPList) or Image has_any (process)
| project TimeGenerated, SourceIP, DestinationIP, Image, Account = UserName, Computer, Type
| extend IPMatch = case( SourceIP in (IPList), "SourceIP", DestinationIP in (IPList), "DestinationIP", "None") 
| extend timestamp = TimeGenerated, File = tostring(split(Image, '\\', -1)[-1]), IPEntity = case(IPMatch == "SourceIP", SourceIP, IPMatch == "DestinationIP", DestinationIP, "None")
| extend FilePath = replace_string(Image, File, '')
),  
(OfficeActivity
| where ClientIP in (IPList) 
| project TimeGenerated, UserAgent, Operation, RecordType, UserId, ClientIP, Type
| extend timestamp = TimeGenerated, IPEntity = ClientIP, Account = UserId
),
(DeviceNetworkEvents
| where RemoteUrl has_any (domains) or RemoteIP in (IPList) or InitiatingProcessSHA256 in (Hashes) or InitiatingProcessFileName has_any (process)
| project TimeGenerated, ActionType, DeviceId, Computer = DeviceName, InitiatingProcessAccountDomain, InitiatingProcessAccountName, InitiatingProcessCommandLine, InitiatingProcessFolderPath, InitiatingProcessId, InitiatingProcessParentFileName, InitiatingProcessFileName, RemoteIP, RemoteUrl, RemotePort, LocalIP, Type
| extend timestamp = TimeGenerated, IPEntity = RemoteIP
),
(Event
| where Source == "Microsoft-Windows-Sysmon"
| extend EvData = parse_xml(EventData)
| extend EventDetail = EvData.DataItem.EventData.Data
| where EventDetail has_any (Hashes) 
| parse EventDetail with * 'SHA256=' SHA256 '",' *
| project TimeGenerated, EventDetail, UserName, Computer, Type, Source, SHA256
| extend Type = strcat(Type, ": ", Source), Account = UserName, FileHash = SHA256, Image = tostring(EventDetail.[4].["#text"])
| extend timestamp = TimeGenerated, Computer, Account, File = tostring(split(Image, '\\', -1)[-1]), FileHashAlgo = 'SHA256'
| extend FilePath = replace_string(Image, File, '')
),
(DeviceFileEvents
| where  InitiatingProcessFolderPath has_any (process)
| project TimeGenerated, ActionType, DeviceId, DeviceName, InitiatingProcessAccountDomain, InitiatingProcessAccountName, InitiatingProcessCommandLine, InitiatingProcessFolderPath, InitiatingProcessId, InitiatingProcessParentFileName, InitiatingProcessFileName, RequestAccountName, RequestSourceIP, InitiatingProcessSHA256, Type
| extend Account = RequestAccountName, Computer = DeviceName, IPAddress = RequestSourceIP, CommandLine = InitiatingProcessCommandLine, FileHash = InitiatingProcessSHA256
| extend timestamp = TimeGenerated, Computer, Account, File = InitiatingProcessFileName, FileHashAlgo = 'SHA256'
| extend FilePath = replace_string(InitiatingProcessFolderPath, File, '')
),
(Event
| where Source == "Microsoft-Windows-Sysmon"
| where EventID == 1
| extend EvData = parse_xml(EventData)
| extend EventDetail = EvData.DataItem.EventData.Data
| project TimeGenerated, EventDetail, UserName, Computer, Type
| extend Image = tostring(EventDetail.[4].["#text"]), CommandLine = tostring(EventDetail.[10].["#text"]), Account = UserName, FileHash = tostring(EventDetail.[17].["#text"])
| where Image has_any (process)
| extend timestamp = TimeGenerated, Computer, Account, File = tostring(split(Image, '\\', -1)[-1]), FileHashAlgo = 'SHA256'
| extend FilePath= replace_string(Image, File, '')
),
(DeviceEvents
| where  InitiatingProcessFileName has_any (process) or InitiatingProcessSHA256 in~ (Hashes)
| project TimeGenerated, ActionType, DeviceId, DeviceName, InitiatingProcessAccountDomain, InitiatingProcessAccountName, InitiatingProcessCommandLine, InitiatingProcessFolderPath, InitiatingProcessId, InitiatingProcessParentFileName, InitiatingProcessFileName, InitiatingProcessSHA256, Type
| extend Account = InitiatingProcessAccountName, Computer = DeviceName, CommandLine = InitiatingProcessCommandLine, FileHash = InitiatingProcessSHA256, Image = InitiatingProcessFolderPath
| extend timestamp = TimeGenerated, Computer, Account, File = InitiatingProcessFileName, FileHashAlgo = 'SHA256'
| extend FilePath = replace_string(InitiatingProcessFolderPath, File, '')
),
(SecurityEvent
| where EventID == '4688'
| where NewProcessName  has_any (process)
| project TimeGenerated, Computer, NewProcessName, ParentProcessName, Account, NewProcessId, Type
| extend timestamp = TimeGenerated, Computer, Account, File = tostring(split(NewProcessName, '\\', -1)[-1])
| extend FilePath = replace_string(NewProcessName, File, '')
),
(CLCFortinet_CL
| where sourceAddress_s  in (IPList) or destinationAddress_s  in (IPList) or destinationHostName_s  has_any (domains) or requestUrl_s  has_any (domains) or Message has_any (IPList) or Message has_any (process)
| parse Message with * '(' DNSName ')' * 
| project TimeGenerated, sourceAddress_s, destinationAddress_s, Message, sourceUserId_s, requestUrl_s, DNSName
| extend MessageIP = extract(IPRegex, 0, Message), RequestIP = extract(IPRegex, 0, requestUrl_s)
| extend IPMatch = case(sourceAddress_s in (IPList), "SourceIP", destinationAddress_s in (IPList), "DestinationIP", MessageIP in (IPList), "Message", requestUrl_s has_any (domains), "RequestUrl", "NoMatch")
| extend timestamp = TimeGenerated, IPCustomEntity = case(IPMatch == "SourceIP", sourceAddress_s, IPMatch == "DestinationIP", destinationAddress_s, IPMatch == "Message", MessageIP, "NoMatch"), AccountCustomEntity = sourceUserId_s
),
(CLCCEF_CL
| where sourceAddress_s  in (IPList) or destinationAddress_s  in (IPList) or destinationHostName_s  has_any (domains) or requestUrl_s  has_any (domains) or Message has_any (IPList) or Message has_any (process)
| parse Message with * '(' DNSName ')' * 
| project TimeGenerated, sourceAddress_s, destinationAddress_s, Message, sourceUserId_s, requestUrl_s, DNSName
| extend MessageIP = extract(IPRegex, 0, Message), RequestIP = extract(IPRegex, 0, requestUrl_s)
| extend IPMatch = case(sourceAddress_s in (IPList), "SourceIP", destinationAddress_s in (IPList), "DestinationIP", MessageIP in (IPList), "Message", requestUrl_s has_any (domains), "RequestUrl", "NoMatch")
| extend timestamp = TimeGenerated, IPCustomEntity = case(IPMatch == "SourceIP", sourceAddress_s, IPMatch == "DestinationIP", destinationAddress_s, IPMatch == "Message", MessageIP, "NoMatch"), AccountCustomEntity = sourceUserId_s
),
(CLCMimecast_CL
| where sha256_s has_any (Hashes)
| extend timestamp = TimeGenerated, HostCustomEntity = Sender_Domain_s, AccountCustomEntity = Sender_s,  AlgorithmCustomEntity = "SHA256", FileHashCustomEntity = tostring(sha256_s)
),
(SophosEP_CL
| where appSha256_s has_any (Hashes)
| extend timestamp = TimeGenerated, HostCustomEntity = Computer, AccountCustomEntity = user_id_s,  AlgorithmCustomEntity = "SHA256", FileHashCustomEntity = tostring(appSha256_s)
),
(SophosEP_CL
| where source_info_ip_s in (IPList) or name_s has_any (domains) or name_s has_any (IPList) or name_s has_any (Hashes) or name_s has_any (process)
| extend timestamp = TimeGenerated, HostCustomEntity = Computer, AccountCustomEntity = user_id_s
),
(CLCSyslog_CL
| where SyslogMessage_s has_any (IPList) or SyslogMessage_s has_any (domains) or SyslogMessage_s has_any (IPList) or SyslogMessage_s has_any (Hashes) or SyslogMessage_s has_any (process)
| extend timestamp = TimeGenerated, HostCustomEntity = Computer
))

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

