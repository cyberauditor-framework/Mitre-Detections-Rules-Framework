**technique_id**
T1485

**title**
Sdelete deployed via GPO and run recursively

**query**
SecurityEvent
  | where EventID == 4688
  | where Process =~ "svchost.exe"
  | where CommandLine has "-k GPSvcGroup" or CommandLine has "-s gpsvc"
  | extend timekey = bin(TimeGenerated, 1m)
  | project timekey, NewProcessId, Computer
  | join kind=inner (SecurityEvent
  | where EventID == 4688
  | where Process =~ "sdelete.exe" or CommandLine has "sdelete"
  | where ParentProcessName endswith "svchost.exe"
  | where CommandLine has_all ("-s", "-r")
  | extend newProcess = Process
  | extend timekey = bin(TimeGenerated, 1m)
  ) on $left.NewProcessId == $right.ProcessId, timekey, Computer

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

