**technique_id**
T1485

**title**
Sensitive Azure Key Vault operations

**query**
let SensitiveOperationList = dynamic(
["VaultDelete", "KeyDelete", "KeyDecrypt", "SecretDelete", "SecretPurge", "KeyPurge", "SecretBackup", "KeyBackup"]);
AzureDiagnostics
| extend ResultType = columnifexists("ResultType", "NoResultType")
| extend requestUri_s = columnifexists("requestUri_s", "None"), identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g = columnifexists("identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g", "None")
| extend id_s = columnifexists("id_s", "None"), CallerIPAddress = columnifexists("CallerIPAddress", "None"), clientInfo_s = columnifexists("clientInfo_s", "None")
| where ResultType != "None" and isnotempty(ResultType)
| where identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g != "None" and isnotempty(identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g)
| where id_s != "None" and isnotempty(id_s)
| where CallerIPAddress != "None" and isnotempty(CallerIPAddress)
| where clientInfo_s != "None" and isnotempty(clientInfo_s)
| where requestUri_s != "None" and isnotempty(requestUri_s)
| where ResourceType == "VAULTS" and ResultType == "Success" 
| where OperationName in (SensitiveOperationList)  
| project TimeGenerated, ResourceType, ResultType, Resource, OperationName, id_s, CallerIPAddress, identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g, requestUri_s, clientInfo_s
| extend timestamp = TimeGenerated, IPCustomEntity = CallerIPAddress, AccountCustomEntity = identity_claim_http_schemas_microsoft_com_identity_claims_objectidentifier_g

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

