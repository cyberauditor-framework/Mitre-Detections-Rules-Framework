**technique_id**
T1485

**title**
CyberProof - Azure Backup Services - Anomalous Backup Removal

**query**
let timerange = 5m;
AzureActivity
| where TimeGenerated >= ago(timerange)
| where OperationNameValue has "MICROSOFT.INSIGHTS/ACTIONGROUPS/DELETE"
| where ActivityStatusValue == 'Success' and todynamic(Properties).statusCode == 'OK'
| extend ActionGroup_Name = extract(@'/providers/microsoft.insights/actiongroups/(.*)',1,_ResourceId)
| extend IPCustomEntity = CallerIpAddress, AccountCustomEntity = Caller

**source**
Sentinel

**type_source**
ttp from Sentinel - techniques

