---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_Compromise-EUP.md]]

### T1485

**technique ID**
[[T1485]]

**technique**
Data Destruction

**technique url**
https://attack.mitre.org/techniques/T1485

**technique description**
Adversaries may destroy data and files on specific systems or in large numbers on a network to interrupt availability to systems, services, and network resources. Data destruction is likely to render stored data irrecoverable by forensic techniques through overwriting files or data on local and remote drives.(Citation: Symantec Shamoon 2012)(Citation: FireEye Shamoon Nov 2016)(Citation: Palo Alto Shamoon Nov 2016)(Citation: Kaspersky StoneDrill 2017)(Citation: Unit 42 Shamoon3 2018)(Citation: Talos Olympic Destroyer 2018) Common operating system file deletion commands such as <code>del</code> and <code>rm</code> often only remove pointers to files without wiping the contents of the files themselves, making the files recoverable by proper forensic methodology. This behavior is distinct from [Disk Content Wipe](https://attack.mitre.org/techniques/T1561/001) and [Disk Structure Wipe](https://attack.mitre.org/techniques/T1561/002) because individual files are destroyed rather than sections of a storage disk or the disks logical structure.

Adversaries may attempt to overwrite files and directories with randomly generated data to make it irrecoverable.(Citation: Kaspersky StoneDrill 2017)(Citation: Unit 42 Shamoon3 2018) In some cases politically oriented image files have been used to overwrite data.(Citation: FireEye Shamoon Nov 2016)(Citation: Palo Alto Shamoon Nov 2016)(Citation: Kaspersky StoneDrill 2017)

To maximize impact on the target organization in operations where network-wide availability interruption is the goal, malware designed for destroying data may have worm-like features to propagate across a network by leveraging additional techniques like [Valid Accounts](https://attack.mitre.org/techniques/T1078), [OS Credential Dumping](https://attack.mitre.org/techniques/T1003), and [SMB/Windows Admin Shares](https://attack.mitre.org/techniques/T1021/002).(Citation: Symantec Shamoon 2012)(Citation: FireEye Shamoon Nov 2016)(Citation: Palo Alto Shamoon Nov 2016)(Citation: Kaspersky StoneDrill 2017)(Citation: Talos Olympic Destroyer 2018).

In cloud environments, adversaries may leverage access to delete cloud storage, cloud storage accounts, machine images, and other infrastructure crucial to operations to damage an organization or their customers.(Citation: Data Destruction - Threat Post)(Citation: DOJ  - Cisco Insider)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0040]]

**tactic**
Impact

**software ID**
[[S0089]] [[S0139]] [[S0496]] [[S0364]] [[S0607]] [[S1125]] [[S0265]] [[S0697]] [[S0380]] [[S0341]] [[S0604]] [[S0238]] [[S0693]] [[S0195]] [[S0659]] [[S0688]] [[S0689]] [[S0365]] [[S0140]]

**software**
StoneDrill, CaddyWiper, Proxysvc, Olympic Destroyer, KillDisk, SDelete, Industroyer, Kazuar, Diavol, Meteor, WhisperGate, RawDisk, REvil, BlackEnergy, Xbash, AcidRain, Shamoon, HermeticWiper, PowerDuke

**platform**
[[Windows]] [[IaaS]] [[Linux]] [[macOS]] [[Containers]]

**group ID**
[[G0032]] [[G1004]] [[G0082]] [[G0034]] [[G0047]]

**group**
Gamaredon Group, Lazarus Group, Sandworm Team, APT38, LAPSUS$

**data source ID**
[[DS0030]] [[DS0007]] [[DS0017]] [[DS0020]] [[DS0009]] [[DS0034]] [[DS0010]] [[DS0022]]

**data source**
Image, Snapshot, File, Command, Cloud Storage, Instance, Process, Volume



