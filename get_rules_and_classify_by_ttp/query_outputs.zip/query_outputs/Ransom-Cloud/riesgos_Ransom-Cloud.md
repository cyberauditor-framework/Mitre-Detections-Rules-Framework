---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_Ransom-Cloud-T1486.md]]
[[riesgos_Ransom-Cloud-T1190.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1190 | Azure Sentinel Hunting Queries | 14 |
| T1190 | Elastic 1 | 18 |
| T1190 | Mappings | 29 |
| T1190 | Sigma HQ 1 | 119 |
| T1190 | Sigma HQ 4 | 45 |
| T1190 | UCM Catalog 2024 Qradar | 4 |
| T1190 | UCM Catalog 2024 Sentinel | 47 |
| T1486 | Atomic | 2 |
| T1486 | Azure Sentinel Hunting Queries | 1 |
| T1486 | Elastic 1 | 4 |
| T1486 | Mappings | 10 |
| T1486 | Sigma HQ 1 | 14 |
| T1486 | Sigma HQ 2 | 3 |
| T1486 | Sigma HQ 4 | 10 |
| T1486 | Sigma HQ 9 | 3 |
| T1486 | UCM Catalog 2024 Sentinel | 5 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1486 | Atomic | T1489.md |
| T1486 | Sigma HQ 1 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_wannacry.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_lockergoga_ransomware.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_malware_conti_ransomware_commands.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 1 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 1 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 1 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 1 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 1 | av_ransomware.yml |
| T1486 | Mappings | ActifioGo.yaml |
| T1486 | Atomic | T1490.md |
| T1486 | Mappings | SecurityCenterRecommendations.yaml |
| T1486 | Mappings | CloudAppSecurity.yaml |
| T1486 | Mappings | Chronicle.yaml |
| T1486 | Mappings | AzureSentinel.yaml |
| T1486 | Mappings | AzureBackup.yaml |
| T1486 | Mappings | AWSRDS.yaml |
| T1486 | Mappings | AWSConfig.yaml |
| T1486 | Mappings | AWSCloudEndure.yaml |
| T1486 | Sigma HQ 1 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 1 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 1 | win_security_malware_bluesky_ransomware_files_indicators.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - Suspicious over.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - TEST CyberProof - AWS CloudTrail - S3 bucket suspi.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - Office 365  - Suspicious file renaming activity (C.md |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - CyberProof - CiscoAMP - Ransomware Activity.md |
| T1486 | Sigma HQ 9 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Sigma HQ 9 | win-os-BitLocker feature activation (PowerShell).yaml |
| T1486 | Sigma HQ 4 | proc_creation_win_renamed_gpg4win.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_reg_bitlocker.yml |
| T1486 | Sigma HQ 4 | proc_creation_win_gpg4win_portable_execution.yml |
| T1486 | Sigma HQ 4 | microsoft365_potential_ransomware_activity.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_uncommon_load.yml |
| T1486 | Sigma HQ 4 | image_load_dll_rstrtmgr_suspicious_load.yml |
| T1486 | Sigma HQ 4 | file_rename_win_ransomware.yml |
| T1486 | Sigma HQ 4 | file_event_win_susp_desktop_txt.yml |
| T1486 | Sigma HQ 4 | aws_ec2_disable_encryption.yml |
| T1486 | Sigma HQ 4 | av_ransomware.yml |
| T1486 | Sigma HQ 2 | win-os-BitLocker massive feature activation (native).yaml |
| T1486 | Sigma HQ 2 | win-os-BitLocker feature configuration (Reg via command).yaml |
| T1486 | Mappings | AmazonGuardDuty.yaml |
| T1486 | UCM Catalog 2024 Sentinel | T1486 - UC491 - Azure ATP - Ransomware Infection Attempt.md |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_file_encryption.toml |
| T1486 | Elastic 1 | impact_potential_linux_ransomware_note_detected.toml |
| T1486 | Azure Sentinel Hunting Queries | ASR--Rule-Ransomware-triggered.yaml |
| T1486 | Elastic 1 | impact_microsoft_365_potential_ransomware_activity.toml |
| T1486 | Elastic 1 | impact_data_encrypted_via_openssl.toml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_omigod_scx_runasprovider_executescript.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1190 | Sigma HQ 4 | opencanary_http_post_login_attempt.yml |
| T1190 | Sigma HQ 4 | opencanary_http_get.yml |
| T1190 | Sigma HQ 4 | opencanary_ftp_login_attempt.yml |
| T1190 | Mappings | AWSSecurityHub.yaml |
| T1190 | Sigma HQ 4 | proc_creation_win_mssql_susp_child_process.yml |
| T1190 | Sigma HQ 4 | nodejs_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | net_dns_external_service_interaction_domains.yml |
| T1190 | Sigma HQ 4 | lnx_vsftpd_susp_error_messages.yml |
| T1190 | Sigma HQ 4 | lnx_syslog_susp_named.yml |
| T1190 | Sigma HQ 4 | lnx_sshd_susp_ssh.yml |
| T1190 | Sigma HQ 4 | lnx_auditd_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_remote_access_tools_screenconnect_webshell.yml |
| T1190 | Sigma HQ 4 | java_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | web_apache_threading_error.yml |
| T1190 | Sigma HQ 4 | web_sql_injection_in_access_logs.yml |
| T1190 | Sigma HQ 4 | web_path_traversal_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | web_jndi_exploit.yml |
| T1190 | Sigma HQ 4 | web_java_payload_in_access_logs.yml |
| T1190 | Sigma HQ 4 | web_iis_tilt_shortname_scan.yml |
| T1190 | Sigma HQ 4 | web_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 4 | velocity_ssti_injection.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_svchost_termserv_proc_spawn.yml |
| T1190 | Sigma HQ 4 | spring_spel_injection.yml |
| T1190 | Sigma HQ 4 | spring_application_exceptions.yml |
| T1190 | Sigma HQ 4 | proxy_ua_hacktool.yml |
| T1190 | Sigma HQ 4 | proxy_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_winrm_susp_child_process.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_webshell_susp_process_spawned_from_webserver.yml |
| T1190 | Sigma HQ 4 | java_xxe_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | java_local_file_read.yml |
| T1190 | Sigma HQ 4 | java_ognl_injection_exploitation_attempt.yml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_files.toml |
| T1190 | Sigma HQ 1 | web_sql_injection_in_access_logs.yml |
| T1190 | Sigma HQ 1 | web_susp_useragents.yml |
| T1190 | Sigma HQ 1 | win_security_susp_failed_logon_source.yml |
| T1190 | Sigma HQ 1 | win_vul_cve_2020_0688.yml |
| T1190 | Sigma HQ 1 | win_vul_cve_2021_41379.yml |
| T1190 | Sigma HQ 1 | zeek_http_omigod_no_auth_rce.yml |
| T1190 | Elastic 1 | privilege_escalation_potential_bufferoverflow_attack.toml |
| T1190 | Elastic 1 | persistence_webshell_detection.toml |
| T1190 | Elastic 1 | persistence_linux_shell_activity_via_web_server.toml |
| T1190 | Elastic 1 | initial_access_zoom_meeting_with_no_passcode.toml |
| T1190 | Elastic 1 | initial_access_webshell_screenconnect_server.toml |
| T1190 | Elastic 1 | initial_access_unsecure_elasticsearch_node.toml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_worker_child_process.toml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_process.toml |
| T1190 | Elastic 1 | initial_access_smb_windows_file_sharing_activity_to_the_internet.toml |
| T1190 | Sigma HQ 4 | win_security_susp_failed_logon_source.yml |
| T1190 | Elastic 1 | initial_access_rpc_remote_procedure_call_to_the_internet.toml |
| T1190 | Elastic 1 | initial_access_rpc_remote_procedure_call_from_the_internet.toml |
| T1190 | Elastic 1 | initial_access_rdp_remote_desktop_protocol_to_the_internet.toml |
| T1190 | Elastic 1 | initial_access_exploit_jetbrains_teamcity.toml |
| T1190 | Elastic 1 | command_and_control_vnc_virtual_network_computing_from_the_internet.toml |
| T1190 | Elastic 1 | command_and_control_ssh_secure_shell_from_the_internet.toml |
| T1190 | Sigma HQ 4 | appframework_django_exceptions.yml |
| T1190 | Sigma HQ 4 | appframework_ruby_on_rails_exceptions.yml |
| T1190 | Sigma HQ 4 | app_python_sql_exceptions.yml |
| T1190 | Sigma HQ 4 | app_sqlinjection_errors.yml |
| T1190 | Sigma HQ 4 | db_anomalous_query.yml |
| T1190 | Sigma HQ 4 | file_event_win_exchange_webshell_drop_suspicious.yml |
| T1190 | Sigma HQ 4 | file_event_win_susp_exchange_aspx_write.yml |
| T1190 | Sigma HQ 4 | java_jndi_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | web_susp_useragents.yml |
| T1190 | Elastic 1 | command_and_control_rdp_remote_desktop_protocol_from_the_internet.toml |
| T1190 | Sigma HQ 4 | zeek_http_omigod_no_auth_rce.yml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Detect port misuse by static threshol.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Zscaler ZPA - ZPA connections from ne.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Zscaler ZPA - BL countries.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Web Application Firewall  - A potenti.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Network - Detect port misuse by stati.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Network - Detect port misuse by anoma.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Microsoft Entra ID - User agent searc.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - CiscoAMP - Malware outbreak.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - OLE object mani.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - Front Door Premium WAF - .md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - Azure WAF matching for Lo.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - App GW WAF - Path Travers.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - App GW WAF - Code Injecti.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure Waf - App Gateway WAF - Scanner.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Syntax errors s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Detect port misuse by anomaly based detection (ASI.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Detect port misuse by static threshold (ASIM Netwo.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Exchange OAB Virtual Directory Attribute Containin.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Front Door Premium WAF - SQLi Detection.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Identify SysAid Server web shell creation.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Log4Shell Pattern Detected on User-Agent.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Microsoft Defender for Endpoint (MDE) signatures f.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Network Session Essentials - Detect port misuse by.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - SOC - CTI - ID0114  Spring4Shell - CVE-2022-22965.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Access from malicious.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Directory Traversal a.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Java serialized objec.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Malicious Web Site cr.md |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServerSuspiciousURIsVisited.yaml |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServersAssociatedSecurityAlerts.yaml |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServerProxyLogonURI.yaml |
| T1190 | Azure Sentinel Hunting Queries | ClientIPwithManyUserAgents.yaml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Outgoing connec.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Firewall rule m.md |
| T1190 | Sigma HQ 1 | web_path_traversal_exploitation_attempt.yml |
| T1190 | Azure Sentinel Hunting Queries | RareUserAgentStrings.yaml |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Unauthorized Remote Co.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Login to FW management.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Access to Sensitive Se.md |
| T1190 | Azure Sentinel Hunting Queries | Potential_IIS_CodeInject.yaml |
| T1190 | Azure Sentinel Hunting Queries | RareClientFileAccess.yaml |
| T1190 | Azure Sentinel Hunting Queries | RareDomainsInCloudLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | ReconActivitywithInteractiveLogonCorrelation.yaml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Firewall errors.md |
| T1190 | Azure Sentinel Hunting Queries | SpringShellExploitationAttempt.yaml |
| T1190 | Azure Sentinel Hunting Queries | SQLAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | StorageAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | SuspectedProxyTokenExploitation.yaml |
| T1190 | Azure Sentinel Hunting Queries | UnfamiliarsignincorrelationwithPortalSigninandAuditlogs.yaml |
| T1190 | Elastic 1 | command_and_control_accepted_default_telnet_port_connection.toml |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [IPS] - High or Critical inbound al.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - A potentially malicious web request was executed a.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Azure WAF - Log4Shell Pattern Detected on Web Payl.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Client request from country in blockl.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Empty user agent.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Multiple error requests from single s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Multiple user agents for single sourc.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Unexpected client request.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Unexpected URI.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - XSS probing pattern in request.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Custom - Akamai - HTTP Smuggling detection.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Custom - Fastly - Suspicious HTTP request method w.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Application Gateway WAF - SQLi Detect.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure Active Directory - User agent s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Credential erro.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Drop attempts s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Execution attem.md |
| T1190 | Sigma HQ 1 | web_sonicwall_jarrewrite_exploit.yml |
| T1190 | Sigma HQ 1 | web_java_payload_in_access_logs.yml |
| T1190 | Sigma HQ 1 | web_jndi_exploit.yml |
| T1190 | Sigma HQ 1 | lnx_sshd_susp_ssh.yml |
| T1190 | Sigma HQ 1 | opencanary_http_get.yml |
| T1190 | Sigma HQ 1 | opencanary_ftp_login_attempt.yml |
| T1190 | Sigma HQ 1 | nodejs_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | net_dns_external_service_interaction_domains.yml |
| T1190 | Sigma HQ 1 | lnx_vsftpd_susp_error_messages.yml |
| T1190 | Sigma HQ 1 | lnx_syslog_susp_named.yml |
| T1190 | Sigma HQ 1 | lnx_sshd_exploit_cve_2023_2283_libssh_authentication_bypass.yml |
| T1190 | Sigma HQ 1 | file_event_win_exploit_cve_2023_34362_moveit_transfer.yml |
| T1190 | Sigma HQ 1 | lnx_auditd_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 1 | java_xxe_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_ognl_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_local_file_read.yml |
| T1190 | Sigma HQ 1 | java_jndi_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | opencanary_http_post_login_attempt.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_exploit_cve_2023_22518_confluence_java_child_proc.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_omigod_scx_runasprovider_executescript.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2020_10189.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2020_1350.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2021_26084_atlassian_confluence.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2022_26809_rpcss_child_process_anomaly.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2023_22518_confluence_tomcat_child_proc.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_other_win_server_undocumented_rce.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_mssql_susp_child_process.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_remote_access_tools_screenconnect_webshell.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_svchost_termserv_proc_spawn.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_webshell_susp_process_spawned_from_webserver.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_winrm_susp_child_process.yml |
| T1190 | Sigma HQ 1 | file_event_win_susp_exchange_aspx_write.yml |
| T1190 | Sigma HQ 1 | file_event_win_exchange_webshell_drop_suspicious.yml |
| T1190 | Mappings | AWSWebApplicationFirewall.yaml |
| T1190 | Mappings | AzureWebApplicationFirewall.yaml |
| T1190 | Mappings | SCC.yaml |
| T1190 | Mappings | JustInTimeVMAccess.yaml |
| T1190 | Mappings | IdentityAwareProxy.yaml |
| T1190 | Mappings | CloudIDS.yaml |
| T1190 | Mappings | CloudArmor.yaml |
| T1190 | Mappings | Chronicle.yaml |
| T1190 | Mappings | AzureTrafficAnalytics.yaml |
| T1190 | Sigma HQ 1 | db_anomalous_query.yml |
| T1190 | Mappings | AzureSentinel.yaml |
| T1190 | Mappings | AzurePolicy.yaml |
| T1190 | Mappings | AzureDefenderForKubernetes.yaml |
| T1190 | Mappings | AzureDefenderForContainerRegistries.yaml |
| T1190 | Mappings | AzureDefenderForAppService.yaml |
| T1190 | Mappings | AzureAutomationUpdateMGT.yaml |
| T1190 | Mappings | SecurityCenterRecommendations.yaml |
| T1190 | Mappings | SQLVulnerabilityAssessment.yaml |
| T1190 | Mappings | VMManager.yaml |
| T1190 | Mappings | VPC.yaml |
| T1190 | Mappings | VulnerabilityAssessmentQualys.yaml |
| T1190 | Mappings | AWSRDS.yaml |
| T1190 | Mappings | AWSConfig.yaml |
| T1190 | Mappings | AWSCloudEndure.yaml |
| T1190 | Mappings | ATPForAzureSQLDatabase.yaml |
| T1190 | Mappings | ArtifactRegistry.yaml |
| T1190 | Mappings | AmazonInspector.yaml |
| T1190 | Mappings | AmazonGuardDuty.yaml |
| T1190 | Mappings | AlertsForWindowsMachines.yaml |
| T1190 | Sigma HQ 1 | appframework_django_exceptions.yml |
| T1190 | Sigma HQ 1 | appframework_ruby_on_rails_exceptions.yml |
| T1190 | Sigma HQ 1 | app_python_sql_exceptions.yml |
| T1190 | Sigma HQ 1 | app_sqlinjection_errors.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2022_36804_exchange_owassrf_exploitation.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2022_36804_exchange_owassrf_poc_exploitation.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2023_46747_f5_remote_code_execution.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_43798_grafana.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_31659_vmware_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_31656_auth_bypass.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_27925_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_21587_oracle_ebs.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_44228_log4j.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_42237_sitecore_report_ashx.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_22518_confluence_auth_bypass.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_41773_apache_path_traversal.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_40539_manageengine_adselfservice_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_40539_adselfservice.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_33766_msexchange_proxytoken.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_28480_exchange_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_27905_apache_solr_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_atlassian_bitbucket_command_injection.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_exchange_owassrf_exploitation.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_exchange_owassrf_poc_exploitation.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_44877_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_46169_cacti_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_23752_joomla_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_25717_ruckus_wireless_admin_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_27997_pre_authentication_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_46747_f5_remote_code_execution.yml |
| T1190 | Sigma HQ 1 | web_exchange_exploitation_hafnium.yml |
| T1190 | Sigma HQ 1 | web_exchange_proxyshell.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_22518_confluence_auth_bypass.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_43261_milesight_information_disclosure.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 1 | web_iis_tilt_shortname_scan.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26858_iis_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26814_wzuh_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26084_confluence_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_19781_citrix_exploit.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_43261_milesight_information_disclosure.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | proxy_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 1 | proxy_ua_hacktool.yml |
| T1190 | Sigma HQ 1 | spring_application_exceptions.yml |
| T1190 | Sigma HQ 1 | spring_spel_injection.yml |
| T1190 | Sigma HQ 1 | velocity_ssti_injection.yml |
| T1190 | Sigma HQ 1 | web_apache_threading_error.yml |
| T1190 | Sigma HQ 1 | web_cve_2010_5278_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2014_6287_hfs_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2018_13379_fortinet_preauth_read_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2018_2894_weblogic_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_11510_pulsesecure_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_3398_confluence.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22893_pulse_secure_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_0688_exchange_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_0688_msexchange.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_10148_solarwinds_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_14882_weblogic_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_28188_terramaster_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_3452_cisco_asa_ftd.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_5902_f5_bigip.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_8193_8195_citrix_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_20090_2021_20091_arcadyan_router_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_2109_weblogic_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_21972_vsphere_unauth_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_21978_vmware_view_planner_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22005_vmware_file_upload.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22123_fortinet_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_44228_log4j_fields.yml |


