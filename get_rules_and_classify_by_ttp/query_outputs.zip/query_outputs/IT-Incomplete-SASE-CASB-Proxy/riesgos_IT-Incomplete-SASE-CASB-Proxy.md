---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_IT-Incomplete-SASE-CASB-Proxy-T1485.md]]
[[riesgos_IT-Incomplete-SASE-CASB-Proxy-T1133.md]]
[[riesgos_IT-Incomplete-SASE-CASB-Proxy-T1071.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1071 | Atomic | 1 |
| T1071 | Azure Sentinel Hunting Queries | 6 |
| T1071 | Elastic 1 | 25 |
| T1071 | Elastic 2 | 1 |
| T1071 | Mappings | 17 |
| T1071 | Sigma HQ 1 | 6 |
| T1071 | Sigma HQ 4 | 4 |
| T1071 | UCM Catalog 2024 Sentinel | 33 |
| T1133 | Atomic | 1 |
| T1133 | Azure Sentinel Hunting Queries | 1 |
| T1133 | Elastic 1 | 6 |
| T1133 | Mappings | 20 |
| T1133 | Sigma HQ 1 | 15 |
| T1133 | Sigma HQ 4 | 15 |
| T1133 | UCM Catalog 2024 Sentinel | 25 |
| T1485 | Atomic | 3 |
| T1485 | Azure Sentinel Hunting Queries | 3 |
| T1485 | Elastic 1 | 18 |
| T1485 | Mappings | 13 |
| T1485 | Sigma HQ 1 | 12 |
| T1485 | Sigma HQ 4 | 11 |
| T1485 | UCM Catalog 2024 Qradar | 1 |
| T1485 | UCM Catalog 2024 Sentinel | 20 |
| T1485 | UCM Catalog 2024 Splunk | 1 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1485 | UCM Catalog 2024 Splunk | T1485 - CyberProof - All - Logs Not Being Indexed.md |
| T1485 | Sigma HQ 4 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 4 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | Sigma HQ 4 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 4 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 4 | lnx_auditd_dd_delete_file.yml |
| T1485 | Sigma HQ 4 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Sigma HQ 4 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_fsutil_usage.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | UCM Catalog 2024 Qradar | T1485 - [CyberProof] - [Global] - Single Host Deleted Mult.md |
| T1485 | Elastic 1 | impact_ec2_disable_ebs_encryption.toml |
| T1485 | Elastic 1 | impact_s3_bucket_object_uploaded_with_ransom_extension.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_deletion.toml |
| T1485 | Elastic 1 | impact_rds_group_deletion.toml |
| T1485 | Elastic 1 | impact_ransomware_note_file_over_smb.toml |
| T1485 | Elastic 1 | impact_ransomware_file_rename_smb.toml |
| T1485 | Elastic 1 | impact_microsoft_365_unusual_volume_of_file_deletion.toml |
| T1485 | Elastic 1 | impact_kms_cmk_disabled_or_scheduled_for_deletion.toml |
| T1485 | Elastic 1 | impact_iam_deactivate_mfa_device.toml |
| T1485 | Elastic 1 | impact_high_freq_file_renames_by_kernel.toml |
| T1485 | Elastic 1 | impact_github_repository_deleted.toml |
| T1485 | Sigma HQ 1 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_malware_blackbyte_ransomware.yml |
| T1485 | Sigma HQ 1 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | Sigma HQ 1 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 1 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 1 | lnx_auditd_dd_delete_file.yml |
| T1485 | Sigma HQ 1 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Sigma HQ 1 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_fsutil_usage.yml |
| T1485 | Mappings | SecurityCenterRecommendations.yaml |
| T1485 | Mappings | CloudAppSecurity.yaml |
| T1485 | Mappings | AzureSentinel.yaml |
| T1485 | Mappings | AzurePolicy.yaml |
| T1485 | Mappings | AzureDefenderForStorage.yaml |
| T1485 | Mappings | AzureBackup.yaml |
| T1485 | Mappings | AWSSecurityHub.yaml |
| T1485 | Mappings | AWSS3.yaml |
| T1485 | Mappings | AWSRDS.yaml |
| T1485 | Mappings | AWSConfig.yaml |
| T1485 | Mappings | AWSCloudEndure.yaml |
| T1485 | Mappings | AmazonGuardDuty.yaml |
| T1485 | Mappings | ActifioGo.yaml |
| T1485 | Elastic 1 | impact_efs_filesystem_or_mount_deleted.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_stoppage.toml |
| T1485 | Elastic 1 | impact_deleting_backup_catalogs_with_wbadmin.toml |
| T1485 | Azure Sentinel Hunting Queries | Mass Deletion of Repositories .yaml |
| T1485 | Elastic 1 | impact_cloudwatch_log_stream_deletion.toml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - AV detections related to Ukraine threats.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Azure Managed Services - Mass resource deletions b.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - ALPHV BlackCat Ransomware Detection.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Activity - Mass Cloud resource .md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Backup Services - Anomalous Bac.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - NRT Sensitive Azure.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - Sensitive Azure Key.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure SQL Databases - Affected rows s.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Storage - Azure Storage Mass Fi.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - CyberArk - Safe Deletion.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Office Activity - Multiple Teams dele.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Sophos EDR - Detect Malware Outbreak..md |
| T1485 | Azure Sentinel Hunting Queries | User First Time Repository Delete Activity.yaml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Threat Essentials - Mass Cloud resour.md |
| T1485 | Azure Sentinel Hunting Queries | AzureStorageMassDeletion.yaml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - TEST CyberProof - AWS CloudTrail - Creating keys w.md |
| T1485 | Elastic 1 | impact_cloudwatch_log_group_deletion.toml |
| T1485 | Elastic 1 | impact_backup_file_deletion.toml |
| T1485 | Elastic 1 | defense_evasion_sdelete_like_filename_rename.toml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Mass Cloud resource deletions Time Series Anomaly.md |
| T1485 | Atomic | T1489.md |
| T1485 | Atomic | T1490.md |
| T1485 | Atomic | T1485.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sdelete deployed via GPO and run recursively.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Potential re-named sdelete usage.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - NRT Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Multiple Teams deleted by a single user.md |
| T1133 | Sigma HQ 1 | win_security_successful_external_remote_smb_login.yml |
| T1133 | Sigma HQ 4 | file_change_win_unusual_modification_by_dns_exe.yml |
| T1133 | Sigma HQ 4 | file_delete_win_unusual_deletion_by_dns_exe.yml |
| T1133 | Sigma HQ 4 | opencanary_ssh_login_attempt.yml |
| T1133 | Sigma HQ 4 | opencanary_ssh_new_connection.yml |
| T1133 | Sigma HQ 4 | opencanary_telnet_login_attempt.yml |
| T1133 | Sigma HQ 4 | proc_creation_macos_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | proc_creation_lnx_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_dns_susp_child_process.yml |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - CiscoAMP - Malware outbreak.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Empty user agent.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Multiple error requests from single s.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Multiple user agents for single sourc.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Unexpected client request.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Unexpected URI.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - XSS probing pattern in request.md |
| T1133 | Sigma HQ 1 | registry_set_chrome_extension.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_remote_access_tools_screenconnect_installation_cli_param.yml |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - CheckPoint - Inbound Traffic on Sensi.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Azure - Anonymous IP address.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - AvosLocker Ransomware Detection.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - CTP forensics storage blob acce.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - CTP cpioc artifact storage blob.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Custom - Storage - Anonymous storage blob access.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - Cloudflare - Client request from country in blockl.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - BL countries.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Shared ZPA session.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Unexpected event count .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - Unexpected ZPA session .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - CyberProof - Zscaler ZPA - ZPA connections from ne.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - OfficeActivity - Known Manganese IP and UserAgent .md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - SOC - FW - Inbound Traffic on Sensitive Ports.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC1181 - OneAccount - Unusual sign-In activity.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC1182 - OneAccount - Successful Authentication fr.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC489 - Azure ATP - Unusual VPN Connection.md |
| T1133 | UCM Catalog 2024 Sentinel | T1133 - UC980 - Netscaler - Failed Password brute force.md |
| T1133 | Sigma HQ 4 | win_security_susp_failed_logon_source.yml |
| T1133 | Sigma HQ 4 | win_security_successful_external_remote_smb_login.yml |
| T1133 | Sigma HQ 4 | win_security_successful_external_remote_rdp_login.yml |
| T1133 | Sigma HQ 4 | registry_set_chrome_extension.yml |
| T1133 | Sigma HQ 4 | proc_creation_win_susp_add_user_remote_desktop_group.yml |
| T1133 | Sigma HQ 1 | win_security_successful_external_remote_rdp_login.yml |
| T1133 | Atomic | T1056.md |
| T1133 | Sigma HQ 1 | proc_creation_win_susp_add_user_remote_desktop_group.yml |
| T1133 | Mappings | AWSSSO.yaml |
| T1133 | Mappings | NetworkSecurityGroups.yaml |
| T1133 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1133 | Mappings | JustInTimeVMAccess.yaml |
| T1133 | Mappings | Firewalls.yaml |
| T1133 | Mappings | CloudVPN.yaml |
| T1133 | Mappings | CloudIdentity.yaml |
| T1133 | Mappings | CloudAppSecurity.yaml |
| T1133 | Mappings | BeyondCorpEnterprise.yaml |
| T1133 | Mappings | AzureTrafficAnalytics.yaml |
| T1133 | Mappings | AzurePolicy.yaml |
| T1133 | Mappings | AzureFirewall.yaml |
| T1133 | Mappings | AzureADIdentitySecureScore.yaml |
| T1133 | Mappings | AWSNetworkFirewall.yaml |
| T1133 | Mappings | SecurityCenterRecommendations.yaml |
| T1133 | Mappings | AmazonVirtualPrivateCloud.yaml |
| T1133 | Mappings | AmazonInspector.yaml |
| T1133 | Mappings | AlertsNetworkLayer.yaml |
| T1133 | Mappings | AdvancedProtectionProgram.yaml |
| T1133 | Sigma HQ 1 | proc_creation_win_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Elastic 1 | persistence_exposed_service_created_with_type_nodeport.toml |
| T1133 | Elastic 1 | persistence_ec2_security_group_configuration_change_detection.toml |
| T1133 | Elastic 1 | persistence_ec2_network_acl_creation.toml |
| T1133 | Elastic 1 | lateral_movement_ssh_process_launched_inside_a_container.toml |
| T1133 | Elastic 1 | initial_access_ssh_connection_established_inside_a_container.toml |
| T1133 | Elastic 1 | initial_access_first_occurrence_user_session_started_via_proxy.toml |
| T1133 | Azure Sentinel Hunting Queries | PotentialSSHTunneltoAADConnectHost.yaml |
| T1133 | Mappings | SCC.yaml |
| T1133 | Sigma HQ 1 | win_security_susp_failed_logon_source.yml |
| T1133 | Sigma HQ 1 | proc_creation_macos_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 1 | proc_creation_win_remote_access_tools_screenconnect_installation_cli_param.yml |
| T1133 | Sigma HQ 1 | proc_creation_win_dns_susp_child_process.yml |
| T1133 | Sigma HQ 1 | proc_creation_lnx_remote_access_tools_teamviewer_incoming_connection.yml |
| T1133 | Sigma HQ 1 | opencanary_telnet_login_attempt.yml |
| T1133 | Sigma HQ 1 | opencanary_ssh_new_connection.yml |
| T1133 | Sigma HQ 1 | opencanary_ssh_login_attempt.yml |
| T1133 | Sigma HQ 1 | file_delete_win_unusual_deletion_by_dns_exe.yml |
| T1133 | Sigma HQ 1 | file_change_win_unusual_modification_by_dns_exe.yml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Network Session Essentials - Anomaly found in Netw.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - UC120 - IPS - DNS Tunnel Detected.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - RunningRAT request parameters.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Potential beaconing activity (ASIM Network Session.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - New UserAgent observed in last 24 hours.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Network Session Essentials - Potential beaconing a.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Malformed user agent.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - UC204 - IPS - Infection Detected.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Linked Malicious Storage Artifacts.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Known ZINC Comebacker and Klackring malware hashes.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Known Strontium group domains.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Known Phosphorus group domains IP.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - ET7 - Log4Shell - IPS Detection.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - ET2 - Emerging Threat - Domain.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Palo Alto Threat signatures from Unus.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Palo Alto - potential beaconing detec.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Network - Potential beaconing activit.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Network - New UserAgent observed in l.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Network - Anomaly found in Network Se.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - McAfee ePO - Firewall disabled.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - UC198 - IPS - High Severity Event From Internal.md |
| T1071 | Mappings | AWSNetworkFirewall.yaml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - UC593 - Windows - Account discovery activity v2.md |
| T1071 | Sigma HQ 1 | proc_creation_macos_installer_susp_child_process.yml |
| T1071 | Azure Sentinel Hunting Queries | DownloadofNewFileUsingCurl.yaml |
| T1071 | Azure Sentinel Hunting Queries | ExternalIPaddressinCommandLine.yaml |
| T1071 | Azure Sentinel Hunting Queries | FireEyeRedTeamComms.yaml |
| T1071 | Azure Sentinel Hunting Queries | imProcess_Dev-0056CommandLineActivityNovember2021(ASIMVersion).yaml |
| T1071 | Azure Sentinel Hunting Queries | RareDNSLookupWithDataTransfer.yaml |
| T1071 | Azure Sentinel Hunting Queries | WireDataBeacon.yaml |
| T1071 | Atomic | T1071.md |
| T1071 | Sigma HQ 1 | image_load_hktl_silenttrinity_stager.yml |
| T1071 | Sigma HQ 1 | lnx_auditd_susp_c2_commands.yml |
| T1071 | Sigma HQ 1 | proc_creation_win_apt_gallium_iocs.yml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Windows host username encoded in base64 web reques.md |
| T1071 | Sigma HQ 1 | proc_creation_win_hktl_silenttrinity_stager.yml |
| T1071 | Elastic 1 | command_and_control_cobalt_strike_beacon.toml |
| T1071 | Elastic 1 | command_and_control_cobalt_strike_default_teamserver_cert.toml |
| T1071 | Elastic 1 | command_and_control_dns_tunneling_nslookup.toml |
| T1071 | Elastic 1 | command_and_control_fin7_c2_behavior.toml |
| T1071 | Elastic 1 | command_and_control_halfbaked_beacon.toml |
| T1071 | Elastic 1 | command_and_control_iexplore_via_com.toml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Discord CDN Risky File Download  (ASI.md |
| T1071 | Elastic 1 | command_and_control_ml_packetbeat_rare_dns_question.toml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Cyberproof - Linux - Suspicious APT SparklingGobli.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Azure Active Directory - Malformed us.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Azure Storage - Linked Malicious Stor.md |
| T1071 | Mappings | AzureSentinel.yaml |
| T1071 | Elastic 2 | command_and_control_non_standard_http_port.toml |
| T1071 | Mappings | SCC.yaml |
| T1071 | Mappings | MicrosoftDefenderForIdentity.yaml |
| T1071 | Mappings | Firewalls.yaml |
| T1071 | Mappings | CloudAppSecurity.yaml |
| T1071 | Mappings | Chronicle.yaml |
| T1071 | Mappings | BeyondCorpEnterprise.yaml |
| T1071 | Mappings | AzureWebApplicationFirewall.yaml |
| T1071 | Mappings | AzureTrafficAnalytics.yaml |
| T1071 | Mappings | AzurePolicy.yaml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Azure Firewall - Several deny actions.md |
| T1071 | Sigma HQ 4 | proc_creation_win_hktl_silenttrinity_stager.yml |
| T1071 | Sigma HQ 4 | proc_creation_macos_installer_susp_child_process.yml |
| T1071 | Sigma HQ 4 | lnx_auditd_susp_c2_commands.yml |
| T1071 | Sigma HQ 4 | image_load_hktl_silenttrinity_stager.yml |
| T1071 | Mappings | AzureDNSAnalytics.yaml |
| T1071 | Mappings | AWSWebApplicationFirewall.yaml |
| T1071 | Mappings | AlertsForDNS.yaml |
| T1071 | Mappings | AlertsNetworkLayer.yaml |
| T1071 | Mappings | AmazonGuardDuty.yaml |
| T1071 | Elastic 1 | privilege_escalation_gdb_sys_ptrace_netcon.toml |
| T1071 | Elastic 1 | execution_shell_via_udp_cli_utility_linux.toml |
| T1071 | Elastic 1 | execution_shell_via_tcp_cli_utility_linux.toml |
| T1071 | Elastic 1 | execution_shell_via_suspicious_binary.toml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Azure Blob & File Storage - Linked Ma.md |
| T1071 | Mappings | AWSIOTDeviceDefender.yaml |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Cloudflare - Unexpected POST requests.md |
| T1071 | UCM Catalog 2024 Sentinel | T1071 - Anomaly found in Network Session Traffic (ASIM Net.md |
| T1071 | Elastic 1 | command_and_control_ml_packetbeat_rare_urls.toml |
| T1071 | Elastic 1 | command_and_control_ml_packetbeat_rare_user_agent.toml |
| T1071 | Elastic 1 | command_and_control_sunburst_c2_activity_detected.toml |
| T1071 | Elastic 1 | command_and_control_suspicious_network_activity_from_unknown_executable.toml |
| T1071 | Elastic 1 | defense_evasion_unusual_network_connection_via_rundll32.toml |
| T1071 | Elastic 1 | execution_installer_package_spawned_network_event.toml |
| T1071 | Elastic 1 | execution_netcon_from_rwx_mem_region_binary.toml |
| T1071 | Elastic 1 | execution_network_event_post_compilation.toml |
| T1071 | Elastic 1 | execution_shell_suspicious_parent_child_revshell_linux.toml |
| T1071 | Elastic 1 | execution_shell_via_background_process.toml |
| T1071 | Elastic 1 | execution_shell_via_child_tcp_utility_linux.toml |
| T1071 | Sigma HQ 1 | win_dns_analytic_apt_gallium.yml |
| T1071 | Elastic 1 | execution_shell_via_lolbin_interpreter_linux.toml |
| T1071 | Elastic 1 | execution_shell_via_meterpreter_linux.toml |
| T1071 | Elastic 1 | execution_shell_via_java_revshell_linux.toml |


