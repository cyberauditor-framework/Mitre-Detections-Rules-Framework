---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_IT-Incomplete-SASE-CASB-Proxy.md]]

### T1133

**technique ID**
[[T1133]]

**technique**
External Remote Services

**technique url**
https://attack.mitre.org/techniques/T1133

**technique description**
Adversaries may leverage external-facing remote services to initially access and/or persist within a network. Remote services such as VPNs, Citrix, and other access mechanisms allow users to connect to internal enterprise network resources from external locations. There are often remote service gateways that manage connections and credential authentication for these services. Services such as [Windows Remote Management](https://attack.mitre.org/techniques/T1021/006) and [VNC](https://attack.mitre.org/techniques/T1021/005) can also be used externally.(Citation: MacOS VNC software for Remote Desktop)

Access to [Valid Accounts](https://attack.mitre.org/techniques/T1078) to use the service is often a requirement, which could be obtained through credential pharming or by obtaining the credentials from users after compromising the enterprise network.(Citation: Volexity Virtual Private Keylogging) Access to remote services may be used as a redundant or persistent access mechanism during an operation.

Access may also be gained through an exposed service that doesn’t require authentication. In containerized environments, this may include an exposed Docker API, Kubernetes API server, kubelet, or web application such as the Kubernetes dashboard.(Citation: Trend Micro Exposed Docker Server)(Citation: Unit 42 Hildegard Malware)

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0001]] [[TA0003]]

**tactic**
Persistence, Initial Access

**software ID**
[[S0600]] [[S0599]] [[S0362]] [[S0601]] [[S1060]]

**software**
Kinsing, Hildegard, Doki, Mafalda, Linux Rabbit

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Containers]]

**group ID**
[[G0026]] [[G0102]] [[G1024]] [[G0114]] [[G0035]] [[G0065]] [[G0115]] [[G0049]] [[G0016]] [[G0027]] [[G1004]] [[G0094]] [[G0093]] [[G0004]] [[G1015]] [[G0007]] [[G0096]] [[G0034]] [[G0139]] [[G0053]] [[G1016]]

**group**
Ke3chang, Leviathan, APT18, Akira, GOLD SOUTHFIELD, TeamTNT, Scattered Spider, FIN5, Sandworm Team, Dragonfly, APT29, Wizard Spider, FIN13, Kimsuky, APT28, APT41, Chimera, Threat Group-3390, OilRig, GALLIUM, LAPSUS$

**data source ID**
[[DS0029]] [[DS0028]] [[DS0015]]

**data source**
Logon Session, Network Traffic, Application Log



