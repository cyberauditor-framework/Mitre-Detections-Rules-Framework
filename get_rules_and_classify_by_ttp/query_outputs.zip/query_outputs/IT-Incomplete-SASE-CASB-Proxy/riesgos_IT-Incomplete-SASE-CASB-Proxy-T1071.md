---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_IT-Incomplete-SASE-CASB-Proxy.md]]

### T1071

**technique ID**
[[T1071]]

**technique**
Application Layer Protocol

**technique url**
https://attack.mitre.org/techniques/T1071

**technique description**
Adversaries may communicate using OSI application layer protocols to avoid detection/network filtering by blending in with existing traffic. Commands to the remote system, and often the results of those commands, will be embedded within the protocol traffic between the client and server. 

Adversaries may utilize many different protocols, including those used for web browsing, transferring files, electronic mail, or DNS. For connections that occur internally within an enclave (such as those between a proxy or pivot node and other nodes), commonly used protocols are SMB, SSH, or RDP.(Citation: Mandiant APT29 Eye Spy Email Nov 22) 

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0011]]

**tactic**
Command and Control

**software ID**
[[S0038]] [[S1084]] [[S0034]] [[S0532]] [[S0623]] [[S0660]] [[S0601]]

**software**
QUIETEXIT, Hildegard, Duqu, Siloscape, Clambling, Lucifer, NETEAGLE

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Network]]

**group ID**
[[G0106]] [[G0139]] [[G0059]]

**group**
TeamTNT, Rocke, Magic Hound

**data source ID**
[[DS0029]]

**data source**
Network Traffic



