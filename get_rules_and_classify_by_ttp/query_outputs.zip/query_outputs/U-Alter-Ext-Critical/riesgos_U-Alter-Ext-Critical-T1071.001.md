---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_U-Alter-Ext-Critical.md]]

### T1071.001

**technique ID**
[[T1071.001]]

**technique**
Web Protocols

**technique url**
https://attack.mitre.org/techniques/T1071/001

**technique description**
Adversaries may communicate using application layer protocols associated with web traffic to avoid detection/network filtering by blending in with existing traffic. Commands to the remote system, and often the results of those commands, will be embedded within the protocol traffic between the client and server. 

Protocols such as HTTP/S(Citation: CrowdStrike Putter Panda) and WebSocket(Citation: Brazking-Websockets) that carry web traffic may be very common in environments. HTTP/S packets have many fields and headers in which data can be concealed. An adversary may abuse these protocols to communicate with systems under their control within a victim network while also mimicking normal, expected traffic. 

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0011]]

**tactic**
Command and Control

**software ID**
[[S0127]] [[S0600]] [[S0356]] [[S0335]] [[S0477]] [[S0386]] [[S0603]] [[S0650]] [[S0497]] [[S0582]] [[S0496]] [[S0441]] [[S0251]] [[S0159]] [[S0668]] [[S0011]] [[S1031]] [[S0453]] [[S1026]] [[S0250]] [[S0154]] [[S1023]] [[S0067]] [[S0687]] [[S0673]] [[S0469]] [[S0695]] [[S0059]] [[S0398]] [[S0260]] [[S0243]] [[S0589]] [[S0449]] [[S0268]] [[S0042]] [[S0671]] [[S0238]] [[S0588]] [[S0610]] [[S0633]] [[S0636]] [[S0659]] [[S0267]] [[S0694]] [[S1074]] [[S1042]] [[S1065]] [[S0578]] [[S1051]] [[S1119]] [[S0045]] [[S1076]] [[S0140]] [[S0187]] [[S0696]] [[S0516]] [[S0518]] [[S0598]] [[S0087]] [[S0699]] [[S0044]] [[S0476]] [[S1037]] [[S1020]] [[S0049]] [[S0599]] [[S0022]] [[S0065]] [[S0153]] [[S1112]] [[S1017]] [[S0003]] [[S0330]] [[S1047]] [[S0141]] [[S0037]] [[S0396]] [[S0258]] [[S0257]] [[S0439]] [[S0520]] [[S0391]] [[S0678]] [[S0456]] [[S0276]] [[S0334]] [[S1030]] [[S0138]] [[S0337]] [[S0430]] [[S0282]] [[S0082]] [[S0172]] [[S0115]] [[S0341]] [[S0604]] [[S1110]] [[S0436]] [[S0527]] [[S0353]] [[S0162]] [[S0062]] [[S1024]] [[S0128]] [[S1105]] [[S1099]] [[S0339]] [[S0013]] [[S0662]] [[S0239]] [[S1015]] [[S0024]] [[S0355]] [[S1063]] [[S0622]] [[S0264]] [[S1060]] [[S0048]] [[S0207]] [[S0086]] [[S0352]] [[S1028]] [[S1018]] [[S0051]] [[S0444]] [[S0084]] [[S0244]] [[S0409]] [[S0046]] [[S0066]] [[S0666]] [[S1075]] [[S0491]] [[S0196]] [[S0428]] [[S0458]] [[S0015]] [[S0460]] [[S0068]] [[S0054]] [[S0504]] [[S0595]] [[S1029]] [[S0240]] [[S0374]] [[S0597]] [[S0448]] [[S0060]] [[S0472]] [[S0632]] [[S0170]] [[S0538]] [[S0531]] [[S0493]] [[S1081]] [[S0237]] [[S0543]] [[S0091]] [[S0333]] [[S0078]] [[S0375]] [[S0148]] [[S0348]] [[S0459]] [[S0466]] [[S0184]] [[S0533]] [[S0680]] [[S0363]] [[S0388]] [[S0435]] [[S1050]] [[S0094]] [[S0192]] [[S1066]] [[S0072]] [[S0682]] [[S0495]] [[S1025]] [[S0198]] [[S0442]] [[S0534]] [[S0367]] [[S0125]] [[S0647]] [[S0269]] [[S0554]] [[S0019]] [[S0635]] [[S0226]] [[S0473]] [[S0384]] [[S1046]] [[S0168]] [[S0378]] [[S0241]] [[S0144]] [[S1014]] [[S0381]] [[S0147]] [[S0629]] [[S0031]] [[S0643]] [[S0616]] [[S0674]] [[S1022]] [[S0689]] [[S0200]] [[S0020]] [[S0023]] [[S0053]] [[S0064]] [[S0455]] [[S0050]] [[S0345]] [[S0631]] [[S0447]] [[S0275]] [[S0284]] [[S1035]] [[S0089]] [[S1106]] [[S0331]] [[S0559]] [[S0412]] [[S0686]] [[S0660]] [[S0230]] [[S0513]] [[S1100]] [[S0561]] [[S1059]] [[S0009]] [[S0030]] [[S0514]] [[S1019]] [[S0385]] [[S0034]] [[S0085]] [[S0657]] [[S0653]] [[S0249]] [[S0500]] [[S0691]] [[S0265]] [[S0401]] [[S1115]] [[S0584]] [[S1120]] [[S0502]] [[S0526]] [[S1108]] [[S0171]] [[S0512]] [[S0382]] [[S0342]] [[S0126]] [[S0470]] [[S0483]] [[S0475]] [[S0340]] [[S0137]] [[S0074]] [[S0661]] [[S0649]] [[S0484]] [[S0569]] [[S0070]] [[S0594]] [[S0445]] [[S0371]] [[S0081]] [[S0482]] [[S0052]] [[S0266]] [[S0186]] [[S0596]] [[S1064]] [[S0652]] [[S0664]] [[S0043]] [[S0564]]

**software**
Keydnap, Amadey, Stuxnet, Ninja, DanBot, CHOPSTICK, DarkWatchman, SLOTHFULMEDIA, ThiefQuest, Remsec, LitePower, Dridex, Mongall, Gelsemium, VaporRage, BBK, NOKKI, CreepySnail, Emissary, Spark, Dipsind, QUIETCANARY, BACKSPACE, PlugX, Okrum, FoggyWeb, HTTPBrowser, Taidoor, TSCookie, down_new, QUADAGENT, BUBBLEWRAP, KOPILUWAK, Dacls, DarkComet, DEATHRANSOM, Metamorfo, Kazuar, Get2, GravityRAT, Epic, FRAMESTING, DustySky, GoldenSpy, Pandora, PowGoop, ShimRat, PoetRAT, metaMain, AuTo Stealer, LookBack, OopsIE, Final1stspy, Sys10, CORESHELL, SNUGRIDE, WindTail, PinchDuke, STEADYPULSE, GrimAgent, Valak, Pupy, Daserf, Ixeshe, Shark, ZeroT, Ramsay, CreepyDrive, REvil, Kevin, Gold Dragon, BadPatch, VBShower, Shamoon, Seasalt, StrongPity, MechaFlounder, ChChes, Helminth, JHUHUGIT, Zeus Panda, Saint Bot, GoldMax, MacSpy, Winnti for Windows, BBSRAT, NETEAGLE, China Chopper, CSPY Downloader, Proxysvc, njRAT, FatDuke, OwaAuth, Uroburos, BoomBox, IceApple, RainyDay, Anchor, Bundlore, PUNCHBUGGY, Avenger, xCaon, Reaver, GeminiDuke, IcedID, Maze, ANDROMEDA, OutSteel, Rising Sun, ABK, SUGARDUMP, Trojan.Karagany, More_eggs, Diavol, Bisonal, Carbanak, BlackMould, MCMD, VERMIN, Hi-Zor, Crutch, SLIGHTPULSE, Mis-Type, HAWKBALL, Lokibot, 3PARA RAT, Brute Ratel C4, Empire, TrailBlazer, Smoke Loader, Samurai, Mori, Doki, ShimRatReporter, NGLite, RATANKBA, BlackEnergy, FELIXROOT, LiteDuke, Milan, Dyre, Carberp, TinyTurla, UPPERCUT, Aria-body, DealersChoice, Pteranodon, Zebrocy, SVCReady, Turian, Goopy, Carbon, Egregor, PowerShower, SpeakUp, Pony, COATHANGER, KGH_SPY, POWRUNER, OnionDuke, LIGHTWIRE, WellMess, Bazar, PULSECHECK, SeaDuke, SoreFang, ADVSTORESHELL, SideTwist, CloudDuke, BADHATCH, Regin, Clambling, Explosive, Cobalt Strike, DarkTortilla, PolyglotDuke, Elise, WIREFIRE, pngdowner, 4H RAT, LOWBALL, PingPull, S-Type, Out1, Remexi, Komplex, ZxShell, Vasport, Ursnif, ComRAT, Micropsia, UBoatRAT, BLINDINGCAN, WhisperGate, Psylo, RedLeaves, CharmPower, DownPaper, HAMMERTOSS, ROKRAT, CosmicDuke, BackConfig, Woody RAT, RDAT, RGDoor, ZLib, WinMM, HyperBro, Neoichor, MarkiRAT, ShadowPad, Exaramel for Linux, Bankshot, Kinsing, AppleJeus, Grandoreiro, Cardinal RAT, Gazer, YAHOYAH, FlawedAmmyy, P.A.S. Webshell, Donut, SUPERNOVA, Felismus, Cyclops Blink, Comnie, TrickBot, Koadic, Small Sieve, Emotet, GuLoader, Sibot, Agent Tesla, SMOKEDHAM, Mythic, MiniDuke, Drovorub, Tomiris, Sakula, InvisiMole, RIPTIDE, KEYPLUG, QakBot, POWERTON, Squirrelwaffle, Winnti for Linux, Industroyer, RCSession, OSX_OCEANLOTUS.D, BLUELIGHT, QuietSieve, PoshC2, PcShare, Action RAT, ELMER, RTM, EvilBunny, Chaes, Machete, ServHelper, Hikit, Flagpro, Mafalda, Sliver, KONNI, NETWIRE, AppleSeed, CozyCar, OLDBAIT, BADNEWS, Peppy, PLEAD, Crimson, Torisma, Xbash, DRATzarus, GoldFinder, SUNBURST, Octopus, GreyEnergy, STARWHALE, httpclient

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Network]]

**group ID**
[[G0026]] [[G0087]] [[G0102]] [[G0071]] [[G0114]] [[G0085]] [[G0082]] [[G0070]] [[G0060]] [[G1013]] [[G0121]] [[G0069]] [[G0100]] [[G0049]] [[G0027]] [[G0094]] [[G0059]] [[G0090]] [[G1014]] [[G0064]] [[G0112]] [[G0004]] [[G0106]] [[G0129]] [[G0083]] [[G0010]] [[G0007]] [[G0096]] [[G0061]] [[G0050]] [[G0067]] [[G0125]] [[G0126]] [[G0073]] [[G0034]] [[G0127]] [[G0139]] [[G0038]] [[G1002]] [[G1016]] [[G0081]] [[G0080]] [[G0075]] [[G0092]] [[G0142]] [[G0032]] [[G0047]]

**group**
Ke3chang, Stealth Falcon, Metador, APT18, Lazarus Group, WIRTE, BITTER, TeamTNT, Confucius, Sandworm Team, HAFNIUM, Wizard Spider, APT38, Magic Hound, Orangeworm, LuminousMoth, Inception, FIN13, Cobalt Group, Kimsuky, Mustang Panda, Tropic Trooper, APT28, APT39, Turla, Rocke, APT41, BRONZE BUTLER, APT33, FIN8, FIN4, Rancor, Sidewinder, TA551, Chimera, TA505, SilverTerrier, Threat Group-3390, APT32, Dark Caracal, Gamaredon Group, OilRig, APT19, APT37, Higaisa, Windshift, MuddyWater

**data source ID**
[[DS0029]]

**data source**
Network Traffic



