---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_U-Alter-Ext-Critical-T1485.md]]
[[riesgos_U-Alter-Ext-Critical-T1190.md]]
[[riesgos_U-Alter-Ext-Critical-T1071.001.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1071.001 | Azure Sentinel Hunting Queries | 1 |
| T1071.001 | Elastic 1 | 6 |
| T1071.001 | Elastic 2 | 1 |
| T1071.001 | Mappings | 8 |
| T1071.001 | Sigma HQ 1 | 37 |
| T1071.001 | Sigma HQ 4 | 30 |
| T1071.001 | UCM Catalog 2024 Sentinel | 5 |
| T1190 | Azure Sentinel Hunting Queries | 14 |
| T1190 | Elastic 1 | 18 |
| T1190 | Mappings | 29 |
| T1190 | Sigma HQ 1 | 119 |
| T1190 | Sigma HQ 4 | 45 |
| T1190 | UCM Catalog 2024 Qradar | 4 |
| T1190 | UCM Catalog 2024 Sentinel | 47 |
| T1485 | Atomic | 3 |
| T1485 | Azure Sentinel Hunting Queries | 3 |
| T1485 | Elastic 1 | 18 |
| T1485 | Mappings | 13 |
| T1485 | Sigma HQ 1 | 12 |
| T1485 | Sigma HQ 4 | 11 |
| T1485 | UCM Catalog 2024 Qradar | 1 |
| T1485 | UCM Catalog 2024 Sentinel | 20 |
| T1485 | UCM Catalog 2024 Splunk | 1 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1485 | Atomic | T1485.md |
| T1485 | Sigma HQ 1 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 4 | aws_eks_cluster_created_or_deleted.yml |
| T1485 | Sigma HQ 4 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | Sigma HQ 1 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_malware_blackbyte_ransomware.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_fsutil_usage.yml |
| T1485 | Sigma HQ 1 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Sigma HQ 1 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | Sigma HQ 1 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Sigma HQ 1 | lnx_auditd_dd_delete_file.yml |
| T1485 | Sigma HQ 1 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 1 | aws_efs_fileshare_mount_modified_or_deleted.yml |
| T1485 | Sigma HQ 4 | lnx_auditd_dd_delete_file.yml |
| T1485 | Atomic | T1489.md |
| T1485 | Mappings | SecurityCenterRecommendations.yaml |
| T1485 | Mappings | CloudAppSecurity.yaml |
| T1485 | Mappings | AzureSentinel.yaml |
| T1485 | Mappings | AzurePolicy.yaml |
| T1485 | Mappings | AzureDefenderForStorage.yaml |
| T1485 | Mappings | AzureBackup.yaml |
| T1485 | Mappings | AWSSecurityHub.yaml |
| T1485 | Mappings | AWSS3.yaml |
| T1485 | Mappings | AWSRDS.yaml |
| T1485 | Mappings | AWSConfig.yaml |
| T1485 | Mappings | AWSCloudEndure.yaml |
| T1485 | Sigma HQ 4 | azure_device_or_configuration_modified_or_deleted.yml |
| T1485 | Sigma HQ 4 | microsoft365_unusual_volume_of_file_deletion.yml |
| T1485 | Mappings | ActifioGo.yaml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure SQL Databases - Affected rows s.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - TEST CyberProof - AWS CloudTrail - Creating keys w.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Sdelete deployed via GPO and run recursively.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Potential re-named sdelete usage.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - NRT Sensitive Azure Key Vault operations.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Multiple Teams deleted by a single user.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Mass Cloud resource deletions Time Series Anomaly.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Threat Essentials - Mass Cloud resour.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Sophos EDR - Detect Malware Outbreak..md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Office Activity - Multiple Teams dele.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - CyberArk - Safe Deletion.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Storage - Azure Storage Mass Fi.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - Sensitive Azure Key.md |
| T1485 | Sigma HQ 4 | proc_creation_lnx_dd_file_overwrite.yml |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Key Vault - NRT Sensitive Azure.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Backup Services - Anomalous Bac.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - Azure Activity - Mass Cloud resource .md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - CyberProof - ALPHV BlackCat Ransomware Detection.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - Azure Managed Services - Mass resource deletions b.md |
| T1485 | UCM Catalog 2024 Sentinel | T1485 - AV detections related to Ukraine threats.md |
| T1485 | UCM Catalog 2024 Qradar | T1485 - [CyberProof] - [Global] - Single Host Deleted Mult.md |
| T1485 | Sigma HQ 4 | win_security_susp_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_renamed_sysinternals_sdelete.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_fsutil_usage.yml |
| T1485 | Sigma HQ 4 | proc_creation_win_cipher_overwrite_deleted_data.yml |
| T1485 | Mappings | AmazonGuardDuty.yaml |
| T1485 | UCM Catalog 2024 Splunk | T1485 - CyberProof - All - Logs Not Being Indexed.md |
| T1485 | Elastic 1 | impact_microsoft_365_unusual_volume_of_file_deletion.toml |
| T1485 | Elastic 1 | impact_rds_group_deletion.toml |
| T1485 | Azure Sentinel Hunting Queries | AzureStorageMassDeletion.yaml |
| T1485 | Azure Sentinel Hunting Queries | Mass Deletion of Repositories .yaml |
| T1485 | Elastic 1 | impact_s3_bucket_object_uploaded_with_ransom_extension.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_stoppage.toml |
| T1485 | Elastic 1 | impact_rds_instance_cluster_deletion.toml |
| T1485 | Elastic 1 | defense_evasion_sdelete_like_filename_rename.toml |
| T1485 | Elastic 1 | impact_backup_file_deletion.toml |
| T1485 | Elastic 1 | impact_cloudwatch_log_group_deletion.toml |
| T1485 | Elastic 1 | impact_cloudwatch_log_stream_deletion.toml |
| T1485 | Elastic 1 | impact_deleting_backup_catalogs_with_wbadmin.toml |
| T1485 | Elastic 1 | impact_ec2_disable_ebs_encryption.toml |
| T1485 | Elastic 1 | impact_efs_filesystem_or_mount_deleted.toml |
| T1485 | Elastic 1 | impact_ransomware_note_file_over_smb.toml |
| T1485 | Elastic 1 | impact_ransomware_file_rename_smb.toml |
| T1485 | Elastic 1 | impact_kms_cmk_disabled_or_scheduled_for_deletion.toml |
| T1485 | Elastic 1 | impact_iam_deactivate_mfa_device.toml |
| T1485 | Elastic 1 | impact_high_freq_file_renames_by_kernel.toml |
| T1485 | Atomic | T1490.md |
| T1485 | Azure Sentinel Hunting Queries | User First Time Repository Delete Activity.yaml |
| T1485 | Elastic 1 | impact_github_repository_deleted.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Zscaler ZPA - ZPA connections from ne.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Front Door Premium WAF - SQLi Detection.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Identify SysAid Server web shell creation.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Log4Shell Pattern Detected on User-Agent.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Microsoft Defender for Endpoint (MDE) signatures f.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Exchange OAB Virtual Directory Attribute Containin.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Detect port misuse by static threshold (ASIM Netwo.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Detect port misuse by anomaly based detection (ASI.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Network - Detect port misuse by anoma.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Zscaler ZPA - BL countries.md |
| T1190 | Sigma HQ 4 | appframework_django_exceptions.yml |
| T1190 | Sigma HQ 4 | java_local_file_read.yml |
| T1190 | Sigma HQ 4 | java_jndi_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | file_event_win_susp_exchange_aspx_write.yml |
| T1190 | Sigma HQ 4 | file_event_win_exchange_webshell_drop_suspicious.yml |
| T1190 | Sigma HQ 4 | db_anomalous_query.yml |
| T1190 | Sigma HQ 4 | app_sqlinjection_errors.yml |
| T1190 | Sigma HQ 4 | app_python_sql_exceptions.yml |
| T1190 | Sigma HQ 4 | appframework_ruby_on_rails_exceptions.yml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - App GW WAF - Code Injecti.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Web Application Firewall  - A potenti.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - App GW WAF - Path Travers.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - Azure WAF matching for Lo.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure WAF - Front Door Premium WAF - .md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - CiscoAMP - Malware outbreak.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Detect port misuse by static threshol.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Microsoft Entra ID - User agent searc.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - SOC - CTI - ID0114  Spring4Shell - CVE-2022-22965.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Network - Detect port misuse by stati.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Network Session Essentials - Detect port misuse by.md |
| T1190 | Sigma HQ 1 | web_java_payload_in_access_logs.yml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Access from malicious.md |
| T1190 | Elastic 1 | persistence_webshell_detection.toml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 1 | web_iis_tilt_shortname_scan.yml |
| T1190 | Sigma HQ 1 | web_jndi_exploit.yml |
| T1190 | Sigma HQ 1 | web_path_traversal_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_sonicwall_jarrewrite_exploit.yml |
| T1190 | Sigma HQ 1 | web_sql_injection_in_access_logs.yml |
| T1190 | Sigma HQ 1 | web_susp_useragents.yml |
| T1190 | Sigma HQ 1 | win_security_susp_failed_logon_source.yml |
| T1190 | Sigma HQ 1 | win_vul_cve_2020_0688.yml |
| T1190 | Sigma HQ 1 | win_vul_cve_2021_41379.yml |
| T1190 | Sigma HQ 1 | zeek_http_omigod_no_auth_rce.yml |
| T1190 | Elastic 1 | privilege_escalation_potential_bufferoverflow_attack.toml |
| T1190 | Elastic 1 | persistence_linux_shell_activity_via_web_server.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Directory Traversal a.md |
| T1190 | Elastic 1 | initial_access_zoom_meeting_with_no_passcode.toml |
| T1190 | Elastic 1 | initial_access_webshell_screenconnect_server.toml |
| T1190 | Azure Sentinel Hunting Queries | RareUserAgentStrings.yaml |
| T1190 | Azure Sentinel Hunting Queries | ReconActivitywithInteractiveLogonCorrelation.yaml |
| T1190 | Azure Sentinel Hunting Queries | SpringShellExploitationAttempt.yaml |
| T1190 | Azure Sentinel Hunting Queries | SQLAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | StorageAlertCorrelationwithCommonSecurityLogsandAuditLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | SuspectedProxyTokenExploitation.yaml |
| T1190 | Azure Sentinel Hunting Queries | UnfamiliarsignincorrelationwithPortalSigninandAuditlogs.yaml |
| T1190 | Sigma HQ 4 | java_rce_exploitation_attempt.yml |
| T1190 | Elastic 1 | command_and_control_accepted_default_telnet_port_connection.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Malicious Web Site cr.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - TEST Cyberproof - F5 - WAF - Java serialized objec.md |
| T1190 | Sigma HQ 4 | java_ognl_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | net_dns_external_service_interaction_domains.yml |
| T1190 | Sigma HQ 4 | java_xxe_exploitation_attempt.yml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_files.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Credential erro.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Drop attempts s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Execution attem.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Firewall errors.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Firewall rule m.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - OLE object mani.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Outgoing connec.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure SQL Databases - Syntax errors s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure Waf - App Gateway WAF - Scanner.md |
| T1190 | Elastic 1 | command_and_control_ssh_secure_shell_from_the_internet.toml |
| T1190 | Elastic 1 | command_and_control_vnc_virtual_network_computing_from_the_internet.toml |
| T1190 | Elastic 1 | initial_access_exploit_jetbrains_teamcity.toml |
| T1190 | Elastic 1 | initial_access_rdp_remote_desktop_protocol_to_the_internet.toml |
| T1190 | Elastic 1 | initial_access_rpc_remote_procedure_call_from_the_internet.toml |
| T1190 | Elastic 1 | initial_access_rpc_remote_procedure_call_to_the_internet.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Azure Active Directory - User agent s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - CyberProof - Application Gateway WAF - SQLi Detect.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Custom - Fastly - Suspicious HTTP request method w.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Azure WAF - Log4Shell Pattern Detected on Web Payl.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Access to Sensitive Se.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Login to FW management.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [Firewall] - Unauthorized Remote Co.md |
| T1190 | UCM Catalog 2024 Qradar | T1190 - [CyberProof] - [IPS] - High or Critical inbound al.md |
| T1190 | Elastic 1 | command_and_control_rdp_remote_desktop_protocol_from_the_internet.toml |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - A potentially malicious web request was executed a.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Client request from country in blockl.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Custom - Akamai - HTTP Smuggling detection.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Empty user agent.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Multiple error requests from single s.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Multiple user agents for single sourc.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Unexpected client request.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - Unexpected URI.md |
| T1190 | UCM Catalog 2024 Sentinel | T1190 - Cloudflare - XSS probing pattern in request.md |
| T1190 | Elastic 1 | initial_access_smb_windows_file_sharing_activity_to_the_internet.toml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_process.toml |
| T1190 | Sigma HQ 4 | lnx_auditd_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Elastic 1 | initial_access_suspicious_ms_exchange_worker_child_process.toml |
| T1190 | Sigma HQ 4 | proc_creation_win_svchost_termserv_proc_spawn.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_remote_access_tools_screenconnect_webshell.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_mssql_susp_child_process.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_omigod_scx_runasprovider_executescript.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 4 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1190 | Sigma HQ 4 | opencanary_http_post_login_attempt.yml |
| T1190 | Sigma HQ 4 | opencanary_http_get.yml |
| T1190 | Sigma HQ 4 | opencanary_ftp_login_attempt.yml |
| T1190 | Sigma HQ 4 | nodejs_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_43261_milesight_information_disclosure.yml |
| T1190 | Sigma HQ 4 | lnx_vsftpd_susp_error_messages.yml |
| T1190 | Sigma HQ 4 | lnx_syslog_susp_named.yml |
| T1190 | Sigma HQ 4 | lnx_sshd_susp_ssh.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_webshell_susp_process_spawned_from_webserver.yml |
| T1190 | Sigma HQ 4 | proc_creation_win_winrm_susp_child_process.yml |
| T1190 | Sigma HQ 4 | proxy_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 4 | web_jndi_exploit.yml |
| T1190 | Elastic 1 | initial_access_unsecure_elasticsearch_node.toml |
| T1190 | Sigma HQ 4 | zeek_http_omigod_no_auth_rce.yml |
| T1190 | Sigma HQ 4 | win_security_susp_failed_logon_source.yml |
| T1190 | Sigma HQ 4 | web_susp_useragents.yml |
| T1190 | Sigma HQ 4 | web_sql_injection_in_access_logs.yml |
| T1190 | Sigma HQ 4 | web_path_traversal_exploitation_attempt.yml |
| T1190 | Sigma HQ 4 | web_java_payload_in_access_logs.yml |
| T1190 | Sigma HQ 4 | proxy_ua_hacktool.yml |
| T1190 | Sigma HQ 4 | web_iis_tilt_shortname_scan.yml |
| T1190 | Sigma HQ 4 | web_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 4 | web_apache_threading_error.yml |
| T1190 | Sigma HQ 4 | velocity_ssti_injection.yml |
| T1190 | Sigma HQ 4 | spring_spel_injection.yml |
| T1190 | Sigma HQ 4 | spring_application_exceptions.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_27997_pre_authentication_rce.yml |
| T1190 | Sigma HQ 1 | web_exploit_cve_2023_22518_confluence_auth_bypass.yml |
| T1190 | Sigma HQ 1 | file_event_win_susp_exchange_aspx_write.yml |
| T1190 | Sigma HQ 1 | lnx_auditd_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 1 | java_xxe_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_ognl_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | java_local_file_read.yml |
| T1190 | Sigma HQ 1 | java_jndi_injection_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | file_event_win_exploit_cve_2023_34362_moveit_transfer.yml |
| T1190 | Sigma HQ 1 | lnx_sshd_susp_ssh.yml |
| T1190 | Sigma HQ 1 | file_event_win_exchange_webshell_drop_suspicious.yml |
| T1190 | Sigma HQ 1 | db_anomalous_query.yml |
| T1190 | Sigma HQ 1 | app_sqlinjection_errors.yml |
| T1190 | Sigma HQ 1 | app_python_sql_exceptions.yml |
| T1190 | Sigma HQ 1 | appframework_ruby_on_rails_exceptions.yml |
| T1190 | Sigma HQ 1 | appframework_django_exceptions.yml |
| T1190 | Sigma HQ 1 | lnx_sshd_exploit_cve_2023_2283_libssh_authentication_bypass.yml |
| T1190 | Sigma HQ 1 | lnx_syslog_susp_named.yml |
| T1190 | Azure Sentinel Hunting Queries | RareClientFileAccess.yaml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_exploit_cve_2023_22518_confluence_java_child_proc.yml |
| T1190 | Sigma HQ 1 | web_exchange_proxyshell.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2021_26084_atlassian_confluence.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2020_1350.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2020_10189.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_omigod_scx_runasprovider_executeshellcommand.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_omigod_scx_runasprovider_executescript.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 1 | lnx_vsftpd_susp_error_messages.yml |
| T1190 | Sigma HQ 1 | proc_creation_lnx_cve_2022_26134_atlassian_confluence.yml |
| T1190 | Sigma HQ 1 | opencanary_http_post_login_attempt.yml |
| T1190 | Sigma HQ 1 | opencanary_http_get.yml |
| T1190 | Sigma HQ 1 | opencanary_ftp_login_attempt.yml |
| T1190 | Sigma HQ 1 | nodejs_rce_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | net_dns_external_service_interaction_domains.yml |
| T1190 | Azure Sentinel Hunting Queries | RareDomainsInCloudLogs.yaml |
| T1190 | Azure Sentinel Hunting Queries | Potential_IIS_CodeInject.yaml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_other_win_server_undocumented_rce.yml |
| T1190 | Mappings | AWSRDS.yaml |
| T1190 | Mappings | AzureDefenderForKubernetes.yaml |
| T1190 | Mappings | AzureDefenderForContainerRegistries.yaml |
| T1190 | Mappings | AzureDefenderForAppService.yaml |
| T1190 | Mappings | AzureAutomationUpdateMGT.yaml |
| T1190 | Mappings | AWSWebApplicationFirewall.yaml |
| T1190 | Mappings | AWSSecurityHub.yaml |
| T1190 | Mappings | AWSConfig.yaml |
| T1190 | Mappings | AzureSentinel.yaml |
| T1190 | Mappings | AWSCloudEndure.yaml |
| T1190 | Mappings | ATPForAzureSQLDatabase.yaml |
| T1190 | Mappings | ArtifactRegistry.yaml |
| T1190 | Mappings | AmazonInspector.yaml |
| T1190 | Mappings | AmazonGuardDuty.yaml |
| T1190 | Mappings | AlertsForWindowsMachines.yaml |
| T1190 | Mappings | AzurePolicy.yaml |
| T1190 | Mappings | AzureTrafficAnalytics.yaml |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServerSuspiciousURIsVisited.yaml |
| T1190 | Mappings | SQLVulnerabilityAssessment.yaml |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServersAssociatedSecurityAlerts.yaml |
| T1190 | Azure Sentinel Hunting Queries | ExchangeServerProxyLogonURI.yaml |
| T1190 | Azure Sentinel Hunting Queries | ClientIPwithManyUserAgents.yaml |
| T1190 | Mappings | VulnerabilityAssessmentQualys.yaml |
| T1190 | Mappings | VPC.yaml |
| T1190 | Mappings | VMManager.yaml |
| T1190 | Mappings | SecurityCenterRecommendations.yaml |
| T1190 | Mappings | AzureWebApplicationFirewall.yaml |
| T1190 | Mappings | SCC.yaml |
| T1190 | Mappings | JustInTimeVMAccess.yaml |
| T1190 | Mappings | IdentityAwareProxy.yaml |
| T1190 | Mappings | CloudIDS.yaml |
| T1190 | Mappings | CloudArmor.yaml |
| T1190 | Mappings | Chronicle.yaml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2023_22518_confluence_tomcat_child_proc.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_exploit_cve_2022_26809_rpcss_child_process_anomaly.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_mssql_susp_child_process.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_27905_apache_solr_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_42237_sitecore_report_ashx.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_41773_apache_path_traversal.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_40539_manageengine_adselfservice_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_40539_adselfservice.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_33766_msexchange_proxytoken.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_28480_exchange_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26858_iis_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_2109_weblogic_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26814_wzuh_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_26084_confluence_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22893_pulse_secure_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22123_fortinet_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_22005_vmware_file_upload.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_remote_access_tools_screenconnect_webshell.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_43798_grafana.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_44228_log4j.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_44228_log4j_fields.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_21587_oracle_ebs.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_27925_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_31656_auth_bypass.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_31659_vmware_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_33891_spark_shell_command_injection.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_atlassian_bitbucket_command_injection.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_exchange_owassrf_exploitation.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_36804_exchange_owassrf_poc_exploitation.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_44877_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2022_46169_cacti_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_23752_joomla_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_25717_ruckus_wireless_admin_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2023_46747_f5_remote_code_execution.yml |
| T1190 | Sigma HQ 1 | web_exchange_exploitation_hafnium.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_21972_vsphere_unauth_rce_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_21978_vmware_view_planner_exploit.yml |
| T1190 | Sigma HQ 1 | web_apache_threading_error.yml |
| T1190 | Sigma HQ 1 | proxy_f5_tm_utility_bash_api_request.yml |
| T1190 | Sigma HQ 1 | web_cve_2010_5278_exploitation_attempt.yml |
| T1190 | Sigma HQ 1 | web_cve_2021_20090_2021_20091_arcadyan_router_exploit.yml |
| T1190 | Sigma HQ 1 | velocity_ssti_injection.yml |
| T1190 | Sigma HQ 1 | spring_spel_injection.yml |
| T1190 | Sigma HQ 1 | spring_application_exceptions.yml |
| T1190 | Sigma HQ 1 | proxy_ua_hacktool.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit_attempt.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_webshell_susp_process_spawned_from_webserver.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_4966_citrix_sensitive_information_disclosure_exploit.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_43261_milesight_information_disclosure.yml |
| T1190 | Sigma HQ 1 | proxy_exploit_cve_2023_22518_confluence_auth_bypass.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2023_46747_f5_remote_code_execution.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2022_36804_exchange_owassrf_poc_exploitation.yml |
| T1190 | Sigma HQ 1 | proxy_cve_2022_36804_exchange_owassrf_exploitation.yml |
| T1190 | Sigma HQ 1 | web_cve_2014_6287_hfs_rce.yml |
| T1190 | Sigma HQ 1 | web_cve_2018_13379_fortinet_preauth_read_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2018_2894_weblogic_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_11510_pulsesecure_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_19781_citrix_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2019_3398_confluence.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_0688_exchange_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_0688_msexchange.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_10148_solarwinds_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_14882_weblogic_exploit.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_28188_terramaster_rce_exploit.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_svchost_termserv_proc_spawn.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_3452_cisco_asa_ftd.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_5902_f5_bigip.yml |
| T1190 | Sigma HQ 1 | web_cve_2020_8193_8195_citrix_exploit.yml |
| T1190 | Sigma HQ 1 | proc_creation_win_winrm_susp_child_process.yml |
| T1071.001 | UCM Catalog 2024 Sentinel | T1071.001 - UC204 - IPS - Infection Detected.md |
| T1071.001 | UCM Catalog 2024 Sentinel | T1071.001 - UC355 - IPS - One Source - High Number of Alerts.md |
| T1071.001 | Azure Sentinel Hunting Queries | FireEyeRedTeamComms.yaml |
| T1071.001 | Sigma HQ 4 | proxy_ua_susp.yml |
| T1071.001 | UCM Catalog 2024 Sentinel | T1071.001 - UC198 - IPS - High Severity Event From Internal.md |
| T1071.001 | UCM Catalog 2024 Sentinel | T1071.001 - UC179 - EPP - Hacktool Detected.md |
| T1071.001 | UCM Catalog 2024 Sentinel | T1071.001 - ET7 - Log4Shell - IPS Detection.md |
| T1071.001 | Sigma HQ 4 | proxy_ua_susp_base64.yml |
| T1071.001 | Elastic 1 | command_and_control_sunburst_c2_activity_detected.toml |
| T1071.001 | Sigma HQ 4 | proxy_ua_powershell.yml |
| T1071.001 | Sigma HQ 1 | proxy_apt_apt40_dropbox_tool_ua.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_macos_installer_susp_child_process.yml |
| T1071.001 | Elastic 1 | defense_evasion_unusual_network_connection_via_rundll32.toml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_susp_exfil_and_tunneling_tool_execution.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_vscode_tunnel_execution.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_vscode_tunnel_remote_shell_.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_vscode_tunnel_renamed_execution.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_vscode_tunnel_service_install.yml |
| T1071.001 | Sigma HQ 1 | proxy_downloadcradle_webdav.yml |
| T1071.001 | Sigma HQ 1 | posh_ps_susp_invoke_webrequest_useragent.yml |
| T1071.001 | Sigma HQ 1 | proxy_hktl_baby_shark_default_agent_url.yml |
| T1071.001 | Sigma HQ 1 | proxy_hktl_cobalt_strike_malleable_c2_requests.yml |
| T1071.001 | Sigma HQ 1 | proxy_hktl_empire_ua_uri_patterns.yml |
| T1071.001 | Sigma HQ 1 | proxy_malware_chafer_url_pattern.yml |
| T1071.001 | Sigma HQ 1 | proxy_malware_comrat_network_indicators.yml |
| T1071.001 | Sigma HQ 1 | proxy_malware_ursnif_c2_url.yml |
| T1071.001 | Sigma HQ 1 | proxy_malware_ursnif_download_url.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_lnx_susp_curl_useragent.yml |
| T1071.001 | Sigma HQ 1 | net_dns_wannacry_killswitch_domain.yml |
| T1071.001 | Sigma HQ 1 | proxy_raw_paste_service_access.yml |
| T1071.001 | Mappings | AWSNetworkFirewall.yaml |
| T1071.001 | Elastic 1 | execution_installer_package_spawned_network_event.toml |
| T1071.001 | Elastic 2 | command_and_control_non_standard_http_port.toml |
| T1071.001 | Elastic 1 | command_and_control_ml_packetbeat_rare_user_agent.toml |
| T1071.001 | Elastic 1 | command_and_control_ml_packetbeat_rare_urls.toml |
| T1071.001 | Elastic 1 | command_and_control_cobalt_strike_default_teamserver_cert.toml |
| T1071.001 | Mappings | AlertsNetworkLayer.yaml |
| T1071.001 | Mappings | AmazonGuardDuty.yaml |
| T1071.001 | Mappings | AWSWebApplicationFirewall.yaml |
| T1071.001 | Sigma HQ 1 | net_connection_win_dialer_initiated_connection.yml |
| T1071.001 | Mappings | AzureSentinel.yaml |
| T1071.001 | Mappings | AzureWebApplicationFirewall.yaml |
| T1071.001 | Mappings | BeyondCorpEnterprise.yaml |
| T1071.001 | Mappings | Chronicle.yaml |
| T1071.001 | Sigma HQ 1 | dns_query_win_cloudflared_communication.yml |
| T1071.001 | Sigma HQ 1 | dns_query_win_devtunnels_communication.yml |
| T1071.001 | Sigma HQ 1 | dns_query_win_vscode_tunnel_communication.yml |
| T1071.001 | Sigma HQ 1 | proxy_pwndrop.yml |
| T1071.001 | Sigma HQ 1 | proxy_telegram_api.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_malware.yml |
| T1071.001 | Sigma HQ 4 | proxy_raw_paste_service_access.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_win_vscode_tunnel_renamed_execution.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_win_vscode_tunnel_service_install.yml |
| T1071.001 | Sigma HQ 4 | proxy_downloadcradle_webdav.yml |
| T1071.001 | Sigma HQ 4 | proxy_hktl_baby_shark_default_agent_url.yml |
| T1071.001 | Sigma HQ 4 | proxy_hktl_cobalt_strike_malleable_c2_requests.yml |
| T1071.001 | Sigma HQ 4 | proxy_hktl_empire_ua_uri_patterns.yml |
| T1071.001 | Sigma HQ 4 | proxy_pwndrop.yml |
| T1071.001 | Sigma HQ 4 | proxy_telegram_api.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_win_vscode_tunnel_execution.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_apt.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_base64_encoded.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_bitsadmin_susp_ip.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_bitsadmin_susp_tld.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_cryptominer.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_empty.yml |
| T1071.001 | Sigma HQ 4 | proxy_ua_frameworks.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_win_vscode_tunnel_remote_shell_.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_macos_installer_susp_child_process.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_apt.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_powershell.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_base64_encoded.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_bitsadmin_susp_ip.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_bitsadmin_susp_tld.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_cryptominer.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_empty.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_frameworks.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_malware.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_susp.yml |
| T1071.001 | Sigma HQ 4 | proc_creation_lnx_susp_curl_useragent.yml |
| T1071.001 | Sigma HQ 1 | proxy_ua_susp_base64.yml |
| T1071.001 | Sigma HQ 4 | dns_query_win_cloudflared_communication.yml |
| T1071.001 | Sigma HQ 4 | dns_query_win_devtunnels_communication.yml |
| T1071.001 | Sigma HQ 4 | dns_query_win_vscode_tunnel_communication.yml |
| T1071.001 | Sigma HQ 4 | net_connection_win_dialer_initiated_connection.yml |
| T1071.001 | Sigma HQ 4 | net_dns_wannacry_killswitch_domain.yml |
| T1071.001 | Sigma HQ 4 | posh_ps_susp_invoke_webrequest_useragent.yml |
| T1071.001 | Sigma HQ 1 | proc_creation_win_curl_useragent.yml |


