---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_SMS-Unknown-data-loc.md]]

### T1056

**technique ID**
[[T1056]]

**technique**
Input Capture

**technique url**
https://attack.mitre.org/techniques/T1056

**technique description**
Adversaries may use methods of capturing user input to obtain credentials or collect information. During normal system usage, users often provide credentials to various different locations, such as login pages/portals or system dialog boxes. Input capture mechanisms may be transparent to the user (e.g. [Credential API Hooking](https://attack.mitre.org/techniques/T1056/004)) or rely on deceiving the user into providing input into what they believe to be a genuine service (e.g. [Web Portal Capture](https://attack.mitre.org/techniques/T1056/003)).

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0006]] [[TA0009]]

**tactic**
Credential Access, Collection

**software ID**
[[S1059]] [[S0381]] [[S0631]] [[S0641]] [[S1060]]

**software**
FlawedAmmyy, Chaes, metaMain, Mafalda, Kobalos

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Network]]

**group ID**
[[G0087]]

**group**
APT39

**data source ID**
[[DS0009]] [[DS0027]] [[DS0022]] [[DS0024]]

**data source**
Driver, Process, Windows Registry, File



