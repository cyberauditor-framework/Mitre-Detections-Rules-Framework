---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_SMS-Unknown-data-loc.md]]

### T1041

**technique ID**
[[T1041]]

**technique**
Exfiltration Over C2 Channel

**technique url**
https://attack.mitre.org/techniques/T1041

**technique description**
Adversaries may steal data by exfiltrating it over an existing command and control channel. Stolen data is encoded into the normal communications channel using the same protocol as command and control communications.

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0010]]

**tactic**
Exfiltration

**software ID**
[[S0356]] [[S0600]] [[S1016]] [[S0477]] [[S0438]] [[S0386]] [[S0650]] [[S0603]] [[S0496]] [[S0251]] [[S0441]] [[S1031]] [[S1026]] [[S0615]] [[S0687]] [[S0588]] [[S0268]] [[S0238]] [[S0671]] [[S1021]] [[S0610]] [[S0633]] [[S1042]] [[S1065]] [[S0692]] [[S0670]] [[S0045]] [[S0663]] [[S0696]] [[S0572]] [[S1037]] [[S0476]] [[S1020]] [[S1017]] [[S0395]] [[S0439]] [[S0391]] [[S0520]] [[S0678]] [[S0377]] [[S0461]] [[S1078]] [[S1030]] [[S0115]] [[S0376]] [[S0604]] [[S1122]] [[S1024]] [[S0062]] [[S0239]] [[S0024]] [[S0622]] [[S1060]] [[S0264]] [[S0086]] [[S0084]] [[S0409]] [[S1075]] [[S0487]] [[S0491]] [[S0428]] [[S0240]] [[S0595]] [[S1029]] [[S0632]] [[S0448]] [[S0083]] [[S1111]] [[S0234]] [[S0538]] [[S0531]] [[S0493]] [[S1034]] [[S1039]] [[S1081]] [[S0373]] [[S0543]] [[S0568]] [[S0587]] [[S1044]] [[S0078]] [[S0375]] [[S0658]] [[S0459]] [[S0533]] [[S0363]] [[S0680]] [[S1089]] [[S1050]] [[S0192]] [[S0495]] [[S1025]] [[S0367]] [[S0431]] [[S0381]] [[S0147]] [[S0031]] [[S0674]] [[S1022]] [[S1090]] [[S0079]] [[S0447]] [[S0455]] [[S1059]] [[S0351]] [[S1019]] [[S0385]] [[S0034]] [[S0667]] [[S0085]] [[S0657]] [[S0651]] [[S0502]] [[S0584]] [[S0077]] [[S0526]] [[S0434]] [[S0340]] [[S0467]] [[S0661]] [[S0649]] [[S0484]] [[S0445]] [[S0266]] [[S1064]] [[S0652]]

**software**
Amadey, Stuxnet, SLOTHFULMEDIA, NightClub, ThiefQuest, LitePower, Mongall, CreepySnail, Spark, BACKSPACE, Okrum, FoggyWeb, KOPILUWAK, Metamorfo, Penquin, Bumblebee, DustySky, Caterpillar WebShell, ShimRatReporter, GoldenSpy, EVILNUM, PoetRAT, metaMain, AuTo Stealer, FunnyDream, OopsIE, SILENTTRINITY, GrimAgent, HOPLIGHT, Valak, Pupy, Shark, REvil, Kevin, Kessel, BoxCaon, StrongPity, MechaFlounder, GoldMax, NETEAGLE, CallMe, Proxysvc, njRAT, IceApple, OutSteel, Rising Sun, SUGARDUMP, Bisonal, Misdat, HAWKBALL, Crutch, Mis-Type, Lokibot, Empire, TajMahal, Doki, MobileOrder, Dyre, Carberp, Imminent Monitor, Pteranodon, StrifeWater, Zebrocy, SVCReady, Goopy, SombRAT, MacMa, LightNeuron, PowerShower, DarkGate, KGH_SPY, ADVSTORESHELL, SideTwist, SharpDisco, BADHATCH, HotCroissant, PingPull, S-Type, Bandook, Ebury, Remexi, Ursnif, BLINDINGCAN, Psylo, CharmPower, ROKRAT, Woody RAT, RDAT, RotaJakiro, ZLib, Chrommme, MarkiRAT, Bankshot, AppleJeus, Grandoreiro, FlawedAmmyy, Cyclops Blink, TrickBot, Emotet, Mispadu, Drovorub, SMOKEDHAM, XCSSET, Tomiris, QakBot, Squirrelwaffle, Industroyer, BLUELIGHT, Cannon, PcShare, DnsSystem, Machete, Flagpro, Sliver, KONNI, Astaroth, Mafalda, AppleSeed, SysUpdate, Crimson, Torisma, SDBbot, Octopus, WarzoneRAT, Attor, STARWHALE

**platform**
[[Windows]] [[Linux]] [[macOS]]

**group ID**
[[G0038]] [[G0022]] [[G0087]] [[G0047]] [[G0128]] [[G0102]] [[G0050]] [[G0094]] [[G0093]] [[G0114]] [[G1014]] [[G0126]] [[G0004]] [[G0065]] [[G0142]] [[G0034]] [[G0032]] [[G0069]]

**group**
Ke3chang, Stealth Falcon, Leviathan, Gamaredon Group, MuddyWater, Lazarus Group, ZIRCONIUM, Confucius, APT3, Wizard Spider, LuminousMoth, GALLIUM, Chimera, Higaisa, APT39, Kimsuky, APT32, Sandworm Team

**data source ID**
[[DS0029]] [[DS0022]] [[DS0017]]

**data source**
Command, Network Traffic, File



