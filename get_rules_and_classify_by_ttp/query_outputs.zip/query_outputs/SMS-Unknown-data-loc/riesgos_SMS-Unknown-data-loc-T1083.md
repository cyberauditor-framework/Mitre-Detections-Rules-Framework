---
Risk: true
Risk relations: true
---

**parent risk file**
[[riesgos_SMS-Unknown-data-loc.md]]

### T1083

**technique ID**
[[T1083]]

**technique**
File and Directory Discovery

**technique url**
https://attack.mitre.org/techniques/T1083

**technique description**
Adversaries may enumerate files and directories or may search in specific locations of a host or network share for certain information within a file system. Adversaries may use the information from [File and Directory Discovery](https://attack.mitre.org/techniques/T1083) during automated discovery to shape follow-on behaviors, including whether or not the adversary fully infects the target and/or attempts specific actions.

Many command shell utilities can be used to obtain this information. Examples include <code>dir</code>, <code>tree</code>, <code>ls</code>, <code>find</code>, and <code>locate</code>.(Citation: Windows Commands JPCERT) Custom tools may also be used to gather file and directory information and interact with the [Native API](https://attack.mitre.org/techniques/T1106). Adversaries may also leverage a [Network Device CLI](https://attack.mitre.org/techniques/T1059/008) on network devices to gather file and directory information (e.g. <code>dir</code>, <code>show flash</code>, and/or <code>nvram</code>).(Citation: US-CERT-TA18-106A)

Some files and directories may require elevated or specific user permissions to access.

**technique deprecated**
False

**technique revoked**
False

**matrix domains**
enterprise-attack

**tactic ID**
[[TA0007]]

**tactic**
Discovery

**software ID**
[[S0127]] [[S0600]] [[S1053]] [[S1016]] [[S1102]] [[S0356]] [[S1101]] [[S0438]] [[S0208]] [[S0650]] [[S0603]] [[S0497]] [[S0582]] [[S0496]] [[S0251]] [[S0088]] [[S0011]] [[S1031]] [[S0131]] [[S0203]] [[S0607]] [[S0346]] [[S0615]] [[S1023]] [[S0250]] [[S0414]] [[S0201]] [[S0687]] [[S0642]] [[S0154]] [[S0673]] [[S0059]] [[S0272]] [[S0260]] [[S1109]] [[S0242]] [[S0344]] [[S0268]] [[S0238]] [[S0693]] [[S0610]] [[S0633]] [[S0659]] [[S0350]] [[S1042]] [[S0021]] [[S0670]] [[S0692]] [[S1065]] [[S1096]] [[S0443]] [[S0045]] [[S0663]] [[S0236]] [[S0516]] [[S0255]] [[S0598]] [[S0572]] [[S0644]] [[S0576]] [[S0049]] [[S0599]] [[S0022]] [[S0065]] [[S0153]] [[S1017]] [[S0063]] [[S0612]] [[S0330]] [[S0592]] [[S0141]] [[S0271]] [[S0149]] [[S0439]] [[S0520]] [[S0377]] [[S0456]] [[S0665]] [[S0461]] [[S1043]] [[S0337]] [[S1125]] [[S0115]] [[S0376]] [[S0604]] [[S0436]] [[S0182]] [[S1122]] [[S1114]] [[S0062]] [[S0128]] [[S0567]] [[S1099]] [[S1105]] [[S0339]] [[S0181]] [[S0013]] [[S0239]] [[S0048]] [[S0622]] [[S1060]] [[S0229]] [[S0368]] [[S0086]] [[S1028]] [[S0069]] [[S1018]] [[S0638]] [[S0402]] [[S0666]] [[S0444]] [[S0066]] [[S0051]] [[S1070]] [[S0409]] [[S0015]] [[S0491]] [[S0428]] [[S0332]] [[S0458]] [[S1129]] [[S0498]] [[S0640]] [[S0240]] [[S0632]] [[S0136]] [[S0354]] [[S0448]] [[S0472]] [[S0083]] [[S1111]] [[S1058]] [[S0234]] [[S0113]] [[S0157]] [[S0493]] [[S1034]] [[S0237]] [[S1068]] [[S0091]] [[S0161]] [[S1044]] [[S0587]] [[S0212]] [[S0078]] [[S0375]] [[S0093]] [[S0658]] [[S0148]] [[S0348]] [[S0466]] [[S0533]] [[S0184]] [[S0283]] [[S0363]] [[S0697]] [[S1089]] [[S1073]] [[S0435]] [[S0252]] [[S0347]] [[S0248]] [[S0192]] [[S0072]] [[S0492]] [[S0410]] [[S0094]] [[S0277]] [[S0630]] [[S0198]] [[S0534]] [[S1025]] [[S0431]] [[S0647]] [[S0488]] [[S0125]] [[S0211]] [[S0635]] [[S0226]] [[S0473]] [[S1040]] [[S0378]] [[S0259]] [[S0144]] [[S0035]] [[S0147]] [[S0616]] [[S0629]] [[S0031]] [[S0643]] [[S0468]] [[S0674]] [[S0452]] [[S0689]] [[S1022]] [[S1090]] [[S1027]] [[S0623]] [[S0079]] [[S0023]] [[S0020]] [[S0447]] [[S0064]] [[S0345]] [[S0455]] [[S1121]] [[S0050]] [[S0275]] [[S0628]] [[S0235]] [[S0437]] [[S0089]] [[S0559]] [[S0139]] [[S0412]] [[S0686]] [[S0660]] [[S0618]] [[S0219]] [[S1100]] [[S0180]] [[S1059]] [[S0263]] [[S0036]] [[S0351]] [[S0385]] [[S0034]] [[S0657]] [[S0124]] [[S0249]] [[S0651]] [[S0142]] [[S0265]] [[S0055]] [[S0526]] [[S0366]] [[S0512]] [[S0129]] [[S0672]] [[S0434]] [[S0475]] [[S0340]] [[S0387]] [[S0562]] [[S0446]] [[S0575]] [[S0090]] [[S0467]] [[S0661]] [[S0070]] [[S0081]] [[S0586]] [[S0625]] [[S0266]] [[S0216]] [[S0193]] [[S0106]] [[S0611]] [[S0547]] [[S0652]] [[S0564]]

**software**
Amadey, CHOPSTICK, Stuxnet, SLOTHFULMEDIA, FYAnti, Derusbi, Gelsemium, Ninja, NightClub, DarkWatchman, ZIPLINE, Royal, FALLCHILL, BACKSPACE, PlugX, Octopus, Okrum, POORAIM, FoggyWeb, HTTPBrowser, Taidoor, TSCookie, down_new, Dacls, Azorult, LoFiSe, Metamorfo, Kazuar, DEATHRANSOM, Hydraq, RARSTONE, Penquin, SOUNDBITE, Epic, Ryuk, DustySky, GravityRAT, GoldenSpy, Caterpillar WebShell, ShimRat, PoetRAT, FunnyDream, LookBack, metaMain, Prestige, PinchDuke, WindTail, BabyShark, MoonWind, Pcexter, SILENTTRINITY, HOPLIGHT, GrimAgent, Linfo, Pupy, CrackMapExec, Ixeshe, Ramsay, CreepyDrive, REvil, FinFisher, BadPatch, Gold Dragon, BoxCaon, Seasalt, StrongPity, DropBook, LITTLELAMB.WOOLTEA, ChChes, Zeus Panda, Forfiles, Saint Bot, FLASHFLOOD, Winnti for Windows, BBSRAT, NETEAGLE, China Chopper, XAgentOSX, Proxysvc, FatDuke, Uroburos, OwaAuth, BoomBox, njRAT, IceApple, RainyDay, Black Basta, Avenger, KillDisk, GeminiDuke, WINERACK, Pisloader, OutSteel, Rising Sun, MESSAGETAP, Nebulae, SUGARDUMP, Brave Prince, Trojan.Karagany, Diavol, BlackMould, Misdat, Bisonal, Conti, Fysbis, FIVEHANDS, Lokibot, FruitFly, 3PARA RAT, Kivars, Empire, TajMahal, Smoke Loader, RemoteUtilities, Pasam, Samurai, Doki, BlackEnergy, AcidRain, TINYTYPHON, MobileOrder, ObliqueRAT, Clop, Imminent Monitor, Rclone, Aria-body, JPIN, PACEMAKER, StrifeWater, Zebrocy, PowerDuke, Pteranodon, UPPERCUT, Turian, ThreatNeedle, DDKONG, SombRAT, MacMa, Skidmap, AutoIt backdoor, NDiskMonitor, Babuk, WannaCry, CrossRAT, OceanSalt, DarkGate, COATHANGER, POWRUNER, KGH_SPY, Kwampirs, Bazar, SUNSPOT, SoreFang, Orz, SharpDisco, Remcos, SideTwist, ADVSTORESHELL, Clambling, Kasidet, BlackCat, Cobalt Strike, Elise, OSX/Shlayer, MegaCortex, SPACESHIP, 4H RAT, HotCroissant, PingPull, Rover, Bandook, Cheerscrypt, Ebury, Remexi, ZxShell, Micropsia, WhisperGate, BLINDINGCAN, Psylo, StreamEx, CharmPower, RedLeaves, ROKRAT, NotPetya, Remsec, BackConfig, Heyoka Backdoor, Woody RAT, CosmicDuke, ZLib, WinMM, MarkiRAT, KeyBoy, Cryptoistic, KEYMARBLE, Bankshot, Kinsing, Akira, InnaputRAT, Cardinal RAT, ccf32, P.A.S. Webshell, cmd, jRAT, TrickBot, Cyclops Blink, CaddyWiper, Koadic, SHOTPUT, Mispadu, Prikormka, MiniDuke, XCSSET, Avaddon, yty, SynAck, InvisiMole, Dtrack, QakBot, Denis, Industroyer, WastedLocker, BLUELIGHT, PoshC2, QuietSieve, BLACKCOFFEE, USBStealer, Cannon, Action RAT, ELMER, RTM, Siloscape, TYPEFRAME, Machete, CORALDECK, Sliver, Mafalda, Zox, Backdoor.Oldrea, BADFLICK, zwShell, NETWIRE, CookieMiner, AppleSeed, KONNI, BADNEWS, Peppy, PLEAD, SysUpdate, Cuba, Crimson, AvosLocker, TAINTEDSCRIBE, SUNBURST, AuditCred, SDBbot, Volgmer, USBferry, HermeticWiper, WarzoneRAT, Attor

**platform**
[[Windows]] [[Linux]] [[macOS]] [[Network]]

**group ID**
[[G0026]] [[G0087]] [[G0054]] [[G0114]] [[G0035]] [[G0082]] [[G0070]] [[G0060]] [[G0121]] [[G0069]] [[G0100]] [[G0124]] [[G0094]] [[G1022]] [[G0059]] [[G1014]] [[G0077]] [[G0117]] [[G0004]] [[G0129]] [[G0044]] [[G0010]] [[G1023]] [[G1015]] [[G0022]] [[G0007]] [[G0096]] [[G0050]] [[G0012]] [[G0125]] [[G1007]] [[G0045]] [[G0034]] [[G0139]] [[G0040]] [[G1016]] [[G0018]] [[G0081]] [[G0142]] [[G0032]] [[G0047]]

**group**
Ke3chang, APT18, Lazarus Group, TeamTNT, Scattered Spider, Winnti Group, Windigo, Confucius, Sandworm Team, Aoqin Dragon, Patchwork, Dragonfly, HAFNIUM, APT38, LuminousMoth, Magic Hound, Sowbug, FIN13, Inception, admin@338, Darkhotel, Kimsuky, Mustang Panda, Tropic Trooper, ToddyCat, APT28, APT5, Turla, APT41, BRONZE BUTLER, Sidewinder, Chimera, APT32, Dark Caracal, Gamaredon Group, menuPass, Leafminer, APT3, APT39, Fox Kitten, MuddyWater

**data source ID**
[[DS0009]] [[DS0017]]

**data source**
Command, Process



