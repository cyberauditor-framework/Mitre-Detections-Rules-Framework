---
Risk: true
Technique: true
Tactic: true
Platform: true
Data source: true
Group: true
Software: true
---

**related detail files**
[[riesgos_SMS-Unknown-data-loc-T1083.md]]
[[riesgos_SMS-Unknown-data-loc-T1056.md]]
[[riesgos_SMS-Unknown-data-loc-T1041.md]]


### Resumen reglas de detección disponibles:

| technique ID | source | rule |
| ------------ | ------ | ---- |
| T1041 | Atomic | 1 |
| T1041 | Azure Sentinel Hunting Queries | 1 |
| T1041 | Elastic 1 | 5 |
| T1041 | Mappings | 8 |
| T1041 | Sigma HQ 1 | 4 |
| T1041 | Sigma HQ 2 | 1 |
| T1041 | Sigma HQ 4 | 2 |
| T1041 | Sigma HQ 9 | 1 |
| T1041 | UCM Catalog 2024 Qradar | 1 |
| T1041 | UCM Catalog 2024 Sentinel | 5 |
| T1056 | Atomic | 2 |
| T1056 | Elastic 1 | 2 |
| T1056 | Mappings | 3 |
| T1056 | Sigma HQ 1 | 2 |
| T1056 | Sigma HQ 4 | 2 |
| T1056 | UCM Catalog 2024 Sentinel | 2 |
| T1083 | Atomic | 2 |
| T1083 | Elastic 1 | 2 |
| T1083 | Elastic 2 | 2 |
| T1083 | Mappings | 2 |
| T1083 | Sigma HQ 1 | 16 |
| T1083 | Sigma HQ 4 | 14 |
| T1083 | UCM Catalog 2024 Sentinel | 3 |


### Desglose reglas de detección disponibles:

| technique ID | source | rules |
| ------------ | ------ | ---- |
| T1083 | Atomic | T1083.md |
| T1083 | Sigma HQ 1 | posh_ps_susp_directory_enum.yml |
| T1083 | Sigma HQ 1 | proc_creation_lnx_file_and_directory_discovery.yml |
| T1083 | Sigma HQ 1 | proc_creation_lnx_gtfobin_apt.yml |
| T1083 | Sigma HQ 1 | proc_creation_lnx_gtfobin_vim.yml |
| T1083 | Sigma HQ 1 | proc_creation_lnx_susp_find_execution.yml |
| T1083 | Sigma HQ 1 | proc_creation_macos_file_and_directory_discovery.yml |
| T1083 | Sigma HQ 1 | proc_creation_macos_susp_find_execution.yml |
| T1083 | Sigma HQ 1 | proc_creation_win_apt_turla_commands_critical.yml |
| T1083 | Atomic | T1119.md |
| T1083 | Sigma HQ 1 | proc_creation_win_hktl_pchunter.yml |
| T1083 | Sigma HQ 1 | proc_creation_win_malware_wannacry.yml |
| T1083 | Sigma HQ 1 | proc_creation_win_pua_seatbelt.yml |
| T1083 | Sigma HQ 1 | web_source_code_enumeration.yml |
| T1083 | Sigma HQ 4 | cisco_cli_discovery.yml |
| T1083 | Sigma HQ 4 | posh_ps_sensitive_file_discovery.yml |
| T1083 | Sigma HQ 4 | posh_ps_susp_directory_enum.yml |
| T1083 | Sigma HQ 4 | proc_creation_lnx_capa_discovery.yml |
| T1083 | Sigma HQ 4 | proc_creation_lnx_file_and_directory_discovery.yml |
| T1083 | Sigma HQ 4 | proc_creation_lnx_gtfobin_apt.yml |
| T1083 | Sigma HQ 4 | proc_creation_lnx_gtfobin_vim.yml |
| T1083 | Sigma HQ 4 | proc_creation_lnx_susp_find_execution.yml |
| T1083 | Sigma HQ 4 | proc_creation_macos_file_and_directory_discovery.yml |
| T1083 | Sigma HQ 4 | proc_creation_macos_susp_find_execution.yml |
| T1083 | Sigma HQ 4 | proc_creation_win_dirlister_execution.yml |
| T1083 | Sigma HQ 4 | proc_creation_win_hktl_pchunter.yml |
| T1083 | Sigma HQ 4 | proc_creation_win_pua_seatbelt.yml |
| T1083 | Sigma HQ 4 | web_source_code_enumeration.yml |
| T1083 | UCM Catalog 2024 Sentinel | T1083 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1083 | UCM Catalog 2024 Sentinel | T1083 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1083 | UCM Catalog 2024 Sentinel | T1083 - UC826 - Cybereason - Windows Multiple Process Enum.md |
| T1083 | Sigma HQ 1 | proc_creation_lnx_capa_discovery.yml |
| T1083 | Sigma HQ 1 | proc_creation_win_dirlister_execution.yml |
| T1083 | Sigma HQ 1 | posh_ps_sensitive_file_discovery.yml |
| T1083 | Elastic 1 | discovery_file_dir_discovery.toml |
| T1083 | Sigma HQ 1 | cisco_cli_discovery.yml |
| T1083 | Elastic 2 | discovery_files_dir_systeminfo_via_cmd.toml |
| T1083 | Elastic 2 | discovery_posh_generic.toml |
| T1083 | Mappings | AzureSentinel.yaml |
| T1083 | Mappings | DockerHostHardening.yaml |
| T1083 | Elastic 1 | discovery_suid_sguid_enumeration.toml |
| T1056 | Sigma HQ 1 | dns_query_win_onelaunch_update_service.yml |
| T1056 | Elastic 1 | credential_access_promt_for_pwd_via_osascript.toml |
| T1056 | Sigma HQ 4 | dns_query_win_onelaunch_update_service.yml |
| T1056 | Sigma HQ 4 | proxy_susp_ipfs_cred_harvest.yml |
| T1056 | Sigma HQ 1 | proxy_susp_ipfs_cred_harvest.yml |
| T1056 | Elastic 1 | collection_posh_keylogger.toml |
| T1056 | Mappings | AzureDefenderForAppService.yaml |
| T1056 | Mappings | Chronicle.yaml |
| T1056 | UCM Catalog 2024 Sentinel | T1056 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1056 | UCM Catalog 2024 Sentinel | T1056 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1056 | Mappings | AzureSentinel.yaml |
| T1056 | Atomic | T1145.md |
| T1056 | Atomic | T1056.md |
| T1041 | Sigma HQ 4 | net_connection_win_domain_portmap.yml |
| T1041 | Sigma HQ 4 | opencanary_tftp_request.yml |
| T1041 | Sigma HQ 9 | win-os-exfiltration from vice society (PowerShell).yaml |
| T1041 | UCM Catalog 2024 Qradar | T1041 - [CyberProof] - [Firewall] - Unusual Outbound SMB T.md |
| T1041 | UCM Catalog 2024 Sentinel | T1041 - CyberProof - Attacker Tools Threat Protection Esse.md |
| T1041 | UCM Catalog 2024 Sentinel | T1041 - PCI - CyberProof - Check Point - Local to Remote.md |
| T1041 | Azure Sentinel Hunting Queries | ExternalIPaddressinCommandLine.yaml |
| T1041 | UCM Catalog 2024 Sentinel | T1041 - Powershell Empire Cmdlets Executed in Command Line.md |
| T1041 | UCM Catalog 2024 Sentinel | T1041 - RunningRAT request parameters.md |
| T1041 | Atomic | T1022.md |
| T1041 | Elastic 1 | exfiltration_ml_high_bytes_destination_port.toml |
| T1041 | Elastic 1 | command_and_control_linux_kworker_netcon.toml |
| T1041 | Elastic 1 | exfiltration_ml_high_bytes_destination_geo_country_iso_code.toml |
| T1041 | Mappings | Firewalls.yaml |
| T1041 | Mappings | CloudIDS.yaml |
| T1041 | Mappings | Chronicle.yaml |
| T1041 | Mappings | AzureSentinel.yaml |
| T1041 | Mappings | AzureDNSAnalytics.yaml |
| T1041 | Mappings | AWSNetworkFirewall.yaml |
| T1041 | Mappings | AWSIOTDeviceDefender.yaml |
| T1041 | Mappings | AmazonGuardDuty.yaml |
| T1041 | Sigma HQ 1 | net_connection_win_domain_portmap.yml |
| T1041 | Sigma HQ 1 | net_firewall_apt_equationgroup_c2.yml |
| T1041 | Sigma HQ 1 | opencanary_tftp_request.yml |
| T1041 | Sigma HQ 1 | proc_creation_win_susp_exfil_and_tunneling_tool_execution.yml |
| T1041 | Sigma HQ 2 | win-os-exfiltration from vice society (PowerShell).yaml |
| T1041 | Elastic 1 | exfiltration_ml_high_bytes_destination_region_name.toml |
| T1041 | Elastic 1 | exfiltration_ml_high_bytes_destination_ip.toml |
| T1041 | UCM Catalog 2024 Sentinel | T1041 - Windows host username encoded in base64 web reques.md |


