| Title          | RA_0041_eradication_report_incident_to_external_companies                                                                                                      |
|:---------------|:-----------------------------------------------------------------------------------------------------------------|
| Stage    | eradication                                                            |
| Automation |<ul><li>thehive</li></ul> |
| Author    | @atc_project                                                          |
| Creation Date    | 31.01.2019                                            |
| References     |<ul><li>[https://blog.thehive-project.org/2017/06/19/thehive-cortex-and-misp-how-they-all-fit-together/](https://blog.thehive-project.org/2017/06/19/thehive-cortex-and-misp-how-they-all-fit-together/)</li><li>[https://www.sei.cmu.edu/education-outreach/computer-security-incident-response-teams/national-csirts/](https://www.sei.cmu.edu/education-outreach/computer-security-incident-response-teams/national-csirts/)</li><li>[https://www.crowdstrike.com/blog/indicators-attack-vs-indicators-compromise/](https://www.crowdstrike.com/blog/indicators-attack-vs-indicators-compromise/)</li><li>[https://mitre.github.io/unfetter/about/](https://mitre.github.io/unfetter/about/)</li></ul>                                  |
| Description    | Report incident to external companies                                                               |
| Linked Response Actions | None |
| Linked Analytics | None |


### Workflow

Report incident to external companites, like [National Computer Security Incident Response Teams (CSIRTs)](https://www.sei.cmu.edu/education-outreach/computer-security-incident-response-teams/national-csirts/).
Provide all Indicators of Compromise and Indicators of Attack you've observed.

This Response Action could be automated with [TheHive and MISP integration](https://blog.thehive-project.org/2017/06/19/thehive-cortex-and-misp-how-they-all-fit-together/).
