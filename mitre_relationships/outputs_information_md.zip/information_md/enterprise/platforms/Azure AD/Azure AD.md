---
Platform: true
---

### Azure AD

**platform**
[[Azure AD]]

