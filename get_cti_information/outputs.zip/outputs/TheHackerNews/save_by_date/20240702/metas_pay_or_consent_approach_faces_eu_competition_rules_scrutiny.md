---
CP Source: The Hacker News
CP Execution date:  2024-07-02
Headline: "Meta's 'Pay or Consent' Approach Faces E.U. Competition Rules Scrutiny"
Date: 2024-07-02
Category: "Digital Regulation"
Sub-Category: "Tech News"
---

**title**
Meta's 'Pay or Consent' Approach Faces E.U. Competition Rules Scrutiny

**date**
02/07/2024

**url_news**
https://thehackernews.com/2024/07/metas-pay-or-consent-approach-faces-eu.html

**thn_category_and_subcategory**
'Digital Regulation / Tech News'

**links**
'https://digital-markets-act.ec.europa.eu/about-dma_en', 'https://ec.europa.eu/commission/presscorner/detail/en/ip_24_3582', 'https://thehackernews.com/2023/10/meta-launches-paid-ad-free-subscription.html', 'https://thehackernews.com/2024/03/us-court-orders-nso-group-to-hand-over.html', 'https://noyb.eu/en/noyb-files-gdpr-complaint-against-meta-over-pay-or-okay', 'https://apnews.com/article/meta-facebook-european-union-privacy-tech-c0019ea93e7b8b8205fab27d071d15d6', 'https://noyb.eu/en/norwegian-court-confirms-eu-57-million-fine-grindr'

**body**
"Meta's decision to offer an ad-free subscription in the European Union (E.U.) has faced a new setback after regulators accused the social media behemoth of breaching the bloc's competition rules by forcing users to choose between seeing ads or paying to avoid them.", 'The European Commission said the company\'s "pay or consent" advertising model is in contravention of the Digital Markets Act (DMA).', '"This binary choice forces users to consent to the combination of their personal data and fails to provide them a less personalized but equivalent version of Meta\'s social networks," the Commission said.', "It also noted that companies in gatekeeper roles must seek users' permission to combine their personal data between designated core platform services and other services (e.g., advertising), and that users who refuse to opt in should have access to a less personalized but equivalent alternative.", "On top of that, Meta's approach does not allow users to choose a service that uses less of their personal data, stating it doesn't permit users to exercise their right to freely consent to combine their data from its services to target them with personalized online ads, the Commission said.", '"Users who do not consent should still get access to an equivalent service which uses less of their personal data, in this case for the personalisation of advertising," it added.', 'Meta first announced its plans for an ad-free option to access Facebook and Instagram for users in the E.U., European Economic Area (EEA), and Switzerland in October 2023 as a way to comply with the strict privacy laws in the region.', 'It also came in response to a ruling from the European Court of Justice last year that a company may offer an "alternative" version of its service that does not rely on data collection for ads.', 'But in the intervening months, the American tech giant has faced criticism for essentially not offering real choices for customers to opt from, instead forcing them to either consent to tracking for advertising purposes or pay up every month to avoid seeing personalized ads altogether.', '"European users now have the \'choice\' to either consent to being tracked for personalized advertising – or pay up to €251.88 a year to retain their fundamental right to data protection on Instagram and Facebook," Austrian privacy non-profit noyb said late last year.', '"Not only is the cost unacceptable, but industry numbers suggest that only 3 percent of people want to be tracked – while more than 99 percent decide against a payment when faced with a \'privacy fee.\'"', 'Should the preliminary findings be confirmed, Meta could be fined up to 10% of its total worldwide turnover, a number that can go up to 20% for systematic infringement of the rules.', '"Subscription for no ads follows the direction of the highest court in Europe and complies with the DMA," Meta was quoted as saying in a statement shared with the Associated Press. It further said it will engage in "constructive dialogue" with the Commission as part of the investigation.', 'The development comes as a Norwegian court has confirmed that online dating app Grindr violated GDPR data protection laws in the E.U. by sharing user data with advertisers, requiring it to pay a fine of €5.7 million ($6.1 million).', 'Continuous Attack Surface Discovery & Penetration Testing', 'Continuously discover, prioritize, & mitigate exposures with evidence-backed ASM, Pentesting, and Red Teaming.', 'Facing identity threats? Discover how ITDR can save you from lateral movement and ransomware attacks.', 'From data breaches to identity theft, compromised credentials can cost you everything. Learn how to stop attackers in their tracks.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

