---
CP Source: The Hacker News
CP Execution date:  2024-07-02
Headline: "Australian Man Charged for Fake Wi-Fi Scam on Domestic Flights"
Date: 2024-07-02
Category: "Data Theft"
Sub-Category: "Wi-Fi Security"
---

**title**
Australian Man Charged for Fake Wi-Fi Scam on Domestic Flights

**date**
02/07/2024

**url_news**
https://thehackernews.com/2024/07/australian-man-charged-for-fake-wi-fi.html

**thn_category_and_subcategory**
'Data Theft / Wi-Fi Security'

**links**
'https://www.afp.gov.au/news-centre/media-release/man-charged-over-creation-evil-twin-free-wifi-networks-access-personal', 'https://www.okta.com/identity-101/evil-twin-attack/', 'https://en.wikipedia.org/wiki/Captive_portal'

**body**
'An Australian man has been charged with running a fake Wi-Fi access point during a domestic flight with an aim to steal user credentials and data.', 'The unnamed 42-year-old "allegedly established fake free Wi-Fi access points, which mimicked legitimate networks, to capture personal data from unsuspecting victims who mistakenly connected to them," the Australian Federal Police (AFP) said in a press release last week.', 'The agency said the suspect was charged in May 2024 after it launched an investigation a month earlier following a report from an airline about a suspicious Wi-Fi network identified by its employees during a domestic flight.', 'A subsequent search of his baggage on April 19 led to the seizure of a portable wireless access device, a laptop, and a mobile phone. He was arrested on May 8 after a search warrant was executed at his home.', "The individual is said to have staged what's called an evil twin Wi-Fi attack across various locations, including domestic flights and airports in Perth, Melbourne, and Adelaide, to impersonate legitimate Wi-Fi networks.", 'Users who attempted to connect to the free, phony network were prompted to enter their email address or social media credentials through a captive portal web page.', '"The email and password details harvested could be used to access more personal information, including a victim\'s online communications, stored images and videos, or bank details," the AFP said.', 'The defendant has been charged with three counts of unauthorized impairment of electronic communication and three counts of possession or control of data with the intent to commit a serious offense.', 'He has also been charged with one count of unauthorized access or modification of restricted data, one count of dishonestly obtaining or dealing in personal financial information, and one count of possession of identification information. If convicted, he faces up to a maximum of 23 years in prison.', '"To connect to a free Wi-Fi network, you shouldn\'t have to enter any personal details -- such as logging in through an email or social media account," AFP Western Command Cybercrime Detective Inspector Andrea Coleman said.', '"If you do want to use public Wi-Fi hotspots, install a reputable virtual private network (VPN) on your devices to encrypt and secure your data when using the internet."', 'Continuous Attack Surface Discovery & Penetration Testing', 'Continuously discover, prioritize, & mitigate exposures with evidence-backed ASM, Pentesting, and Red Teaming.', 'Facing identity threats? Discover how ITDR can save you from lateral movement and ransomware attacks.', 'From data breaches to identity theft, compromised credentials can cost you everything. Learn how to stop attackers in their tracks.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

