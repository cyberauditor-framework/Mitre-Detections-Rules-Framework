---
CP Source: The Hacker News
CP Execution date:  2024-07-02
Headline: "Critical Flaws in CocoaPods Expose iOS and macOS Apps to Supply Chain Attacks"
Date: 2024-07-01
Category: "Supply Chain"
Sub-Category: "Software Security"
---

**title**
Critical Flaws in CocoaPods Expose iOS and macOS Apps to Supply Chain Attacks

**date**
01/07/2024

**url_news**
https://thehackernews.com/2024/07/critical-flaws-in-cocoapods-expose-ios.html

**thn_category_and_subcategory**
'Supply Chain / Software Security'

**links**
'https://cocoapods.org/', 'https://www.evasec.io/blog/eva-discovered-supply-chain-vulnerabities-in-cocoapods', 'https://blog.cocoapods.org/CocoaPods-Trunk-RCEs-2023/', 'https://blog.cocoapods.org/Claim-Your-Pods/', 'https://blog.cocoapods.org/CocoaPods-Trunk/', 'https://cocoapods.org/owners/7', 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Forwarded-Host', 'https://zero.checkmarx.com/this-is-how-i-hijacked-cocoapods-subdomain-using-github-pages-4e368e849022'

**body**
'A trio of security flaws has been uncovered in the CocoaPods dependency manager for Swift and Objective-C Cocoa projects that could be exploited to stage software supply chain attacks, putting downstream customers at severe risks.', 'The vulnerabilities allow "any malicious actor to claim ownership over thousands of unclaimed pods and insert malicious code into many of the most popular iOS and macOS applications," E.V.A Information Security researchers Reef Spektor and Eran Vaknin said in a report published today.', 'The Israeli application security firm said the three issues have since been patched by CocoaPods as of October 2023. It also resets all user sessions at the time in response to the disclosures.', 'One of the vulnerabilities is CVE-2024-38368 (CVSS score: 9.3), which makes it possible for an attacker to abuse the "Claim Your Pods" process and take control of a package, effectively allowing them to tamper with the source code and introduce malicious changes. However, this required that all prior maintainers have been removed from the project.', 'The roots of the problem go back to 2014, when a migration to the Trunk server left thousands of packages with unknown (or unclaimed) owners, permitting an attacker to use a public API for claiming pods and an email address that was available in the CocoaPods source code ("unclaimed-pods@cocoapods.org") to take over control.', 'The second bug is even more critical (CVE-2024-38366, CVSS score: 10.0) and takes advantage of an insecure email verification workflow to run arbitrary code on the Trunk server, which could then be used to manipulate or replace the packages.', "Also identified in the service is a second problem in the email address verification component (CVE-2024-38367, CVSS score: 8.2) that could entice a recipient into clicking on a seemingly-benign verification link, when, in reality, it reroutes the request to an attacker-controlled domain in order to gain access to a developer's session tokens.", 'Making matters worse, this can be upgraded into a zero-click account takeover attack by spoofing an HTTP header – i.e., modifying the X-Forwarded-Host header field – and taking advantage of misconfigured email security tools.', '"We have found that almost every pod owner is registered with their organizational email on the Trunk server, which makes them vulnerable to our zero-click takeover vulnerability," the researchers said.', 'This is not the first time CocoaPods has come under the scanner. In March 2023, Checkmarx revealed that an abandoned sub-domain associated with the dependency manager ("cdn2.cocoapods.org") could have been hijacked by an adversary via GitHub Pages with an aim to host their payloads.', 'Continuous Attack Surface Discovery & Penetration Testing', 'Continuously discover, prioritize, & mitigate exposures with evidence-backed ASM, Pentesting, and Red Teaming.', 'Facing identity threats? Discover how ITDR can save you from lateral movement and ransomware attacks.', 'From data breaches to identity theft, compromised credentials can cost you everything. Learn how to stop attackers in their tracks.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

