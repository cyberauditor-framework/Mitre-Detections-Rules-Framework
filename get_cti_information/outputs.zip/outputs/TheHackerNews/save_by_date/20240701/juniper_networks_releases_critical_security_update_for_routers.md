---
CP Source: The Hacker News
CP Execution date:  2024-07-02
Headline: "Juniper Networks Releases Critical Security Update for Routers"
Date: 2024-07-01
Category: "Vulnerability"
Sub-Category: "Network Security"
---

**title**
Juniper Networks Releases Critical Security Update for Routers

**date**
01/07/2024

**url_news**
https://thehackernews.com/2024/07/juniper-networks-releases-critical.html

**thn_category_and_subcategory**
'Vulnerability / Network Security'

**links**
'https://supportportal.juniper.net/s/article/2024-06-Out-Of-Cycle-Security-Bulletin-Session-Smart-Router-SSR-On-redundant-router-deployments-API-authentication-can-be-bypassed-CVE-2024-2973?language=en_US', 'https://thehackernews.com/2024/01/critical-rce-vulnerability-uncovered-in.html', 'https://thehackernews.com/2023/11/cisa-sets-deadline-patch-juniper-junos.html'

**body**
'Juniper Networks has released out-of-band security updates to address a critical security flaw that could lead to an authentication bypass in some of its routers.', 'The vulnerability, tracked as CVE-2024-2973, carries a CVSS score of 10.0, indicating maximum severity.', '"An Authentication Bypass Using an Alternate Path or Channel vulnerability in Juniper Networks Session Smart Router or Conductor running with a redundant peer allows a network based attacker to bypass authentication and take full control of the device," the company said in an advisory issued last week.', 'According to Juniper Networks, the shortcoming affects only those routers or conductors that are running in high-availability redundant configurations. The list of impacted devices is listed below -', 'The networking equipment maker, which was bought out by Hewlett Packard Enterprise (HPE) for approximately $14 billion earlier this year, said it found no evidence of active exploitation of the flaw in the wild.', 'It also said that it discovered the vulnerability during internal product testing and that there are no workarounds that resolve the issue.', '"This vulnerability has been patched automatically on affected devices for MIST managed WAN Assurance routers connected to the Mist Cloud," it further noted. "It is important to note that the fix is applied automatically on managed routers by a Conductor or on WAN assurance routers has no impact on data-plane functions of the router."', 'In January 2024, the company also rolled out fixes for a critical vulnerability in the same products (CVE-2024-21591, CVSS score: 9.8) that could enable an attacker to cause a denial-of-service (DoS) or remote code execution and obtain root privileges on the devices.', "With multiple security flaws affecting the company's SRX firewalls and EX switches weaponized by threat actors last year, it's essential that users apply the patches to protect against potential threats.", 'Continuous Attack Surface Discovery & Penetration Testing', 'Continuously discover, prioritize, & mitigate exposures with evidence-backed ASM, Pentesting, and Red Teaming.', 'Facing identity threats? Discover how ITDR can save you from lateral movement and ransomware attacks.', 'From data breaches to identity theft, compromised credentials can cost you everything. Learn how to stop attackers in their tracks.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

