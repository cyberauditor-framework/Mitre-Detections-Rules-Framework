---
CP Source: The Hacker News
CP Execution date:  2024-07-02
Headline: "CapraRAT Spyware Disguised as Popular Apps Threatens Android Users"
Date: 2024-07-01
Category: "Mobile Security"
Sub-Category: "Spyware"
---

**title**
CapraRAT Spyware Disguised as Popular Apps Threatens Android Users

**date**
01/07/2024

**url_news**
https://thehackernews.com/2024/07/caprarat-spyware-disguised-as-popular.html

**thn_category_and_subcategory**
'Mobile Security / Spyware'

**links**
'https://thehackernews.com/2024/06/pakistani-hackers-use-disgomoji-malware.html', 'https://www.sentinelone.com/labs/capratube-remix-transparent-tribes-android-spyware-targeting-gamers-weapons-enthusiasts/', 'https://thehackernews.com/2023/09/transparent-tribe-uses-fake-youtube.html', 'https://thehackernews.com/2022/02/new-caprarat-android-malware-targets.html', 'https://thehackernews.com/2023/12/new-fjordphantom-android-malware.html', 'https://en.wikipedia.org/wiki/Seccomp', 'https://promon.co/app-threat-reports/snowblind'

**body**
'The threat actor known as Transparent Tribe has continued to unleash malware-laced Android apps as part of a social engineering campaign to target individuals of interest.', '"These APKs continue the group\'s trend of embedding spyware into curated video browsing applications, with a new expansion targeting mobile gamers, weapons enthusiasts, and TikTok fans," SentinelOne security researcher Alex Delamotte said in a new report shared with The Hacker News.', 'The campaign, dubbed CapraTube, was first outlined by the cybersecurity company in September 2023, with the hacking crew employing weaponized Android apps impersonating legitimate apps like YouTube to deliver a spyware called CapraRAT, a modified version of AndroRAT with capabilities to capture a wide range of sensitive data.', 'Transparent Tribe, suspected to be of Pakistan origin, has leveraged CapraRAT for over two years in attacks targeting the Indian government and military personnel. The group has a history of leaning into spear-phishing and watering hole attacks to deliver a variety of Windows and Android spyware.', '"The activity highlighted in this report shows the continuation of this technique with updates to the social engineering pretexts as well as efforts to maximize the spyware\'s compatibility with older versions of the Android operating system while expanding the attack surface to include modern versions of Android," Delamotte explained.', 'The list of new malicious APK files identified by SentinelOne is as follows -', 'CapraRAT uses WebView to launch a URL to either YouTube or a mobile gaming site named CrazyGames.com, while, in the background, it abuses its permissions to access locations, SMS messages, contacts, and call logs; make phone calls; take screenshots; or record audio and video.', 'A notable change to the malware is that permissions such as READ_INSTALL_SESSIONS, GET_ACCOUNTS, AUTHENTICATE_ACCOUNTS, and REQUEST_INSTALL_PACKAGES are no longer requested, suggesting that the threat actors are aiming to use it as a surveillance tool than a backdoor.', '"The updates to the CapraRAT code between the September 2023 campaign and the current campaign are minimal, but suggest the developers are focused on making the tool more reliable and stable," Delamotte said.', '"The decision to move to newer versions of the Android OS are logical, and likely align with the group\'s sustained targeting of individuals in the Indian government or military space, who are unlikely to use devices running older versions of Android, such as Lollipop which was released 8 years ago."', "The disclosure comes as Promon revealed a novel type of Android banking malware called Snowblind that, in ways similar to FjordPhantom, attempts to bypass detection methods and make use of the operating system's accessibility services API in a surreptitious manner.", 'By using the seccomp functionality to intercept and manipulate system calls, it not only allows the malware to undermine security checks and fly under the radar, but also steal credentials, export data, and disable features like two-factor authentication (2FA) or biometric verification.', '"Snowblind ... performs a normal repackaging attack but uses a lesser-known technique based on seccomp that is capable of bypassing many anti-tampering mechanisms," the company said.', '"Interestingly, FjordPhantom and Snowblind target apps from Southeast Asia and leverage powerful new attack techniques. That seems to indicate that malware authors in that region have become extremely sophisticated."', 'Continuous Attack Surface Discovery & Penetration Testing', 'Continuously discover, prioritize, & mitigate exposures with evidence-backed ASM, Pentesting, and Red Teaming.', 'Facing identity threats? Discover how ITDR can save you from lateral movement and ransomware attacks.', 'From data breaches to identity theft, compromised credentials can cost you everything. Learn how to stop attackers in their tracks.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

