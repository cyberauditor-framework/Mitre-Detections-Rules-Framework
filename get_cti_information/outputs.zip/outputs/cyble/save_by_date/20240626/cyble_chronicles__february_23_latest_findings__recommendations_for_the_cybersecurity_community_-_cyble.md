---
CP Source: Cyble
CP Execution date:  2024-07-11
Headline: "Cyble Chronicles – February 23: Latest Findings & Recommendations For The Cybersecurity Community  - Cyble"
Date: 2024-06-26
Category: ""
---

**title**
Cyble Chronicles – February 23: Latest Findings & Recommendations For The Cybersecurity Community  - Cyble

**date**
26/06/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-february-23-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**
'https://cyble.com/blog/the-fate-of-the-criminalmw-group-endgame-or-a-new-rebranding-journey/', 'https://cyble.com/blog/asukastealer-a-revamped-version-of-the-observerstealer-advertised-as-malware-as-a-service/', 'https://thecyberexpress.com/decoding-tangerine-data-breach/', 'https://us06web.zoom.us/webinar/register/WN_PxsgvHqFTVinMZVLbX2PBQ#/registration'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles February 23: Latest Findings Recommendations for the Cybersecurity Community Recently, an enhanced version of the CriminalMW Android Banking Trojan was discovered, now available for rent at 5,000 per month on Telegram. This update includes new features like a unique overlay technique and targets 10 Brazilian banks using the PIX platform. Four threat actors, including SickoDevZ, have been linked to this malware. Law enforcement actions have led to the arrest of individuals associated with similar banking Trojans, including SickoDevZ. Despite these arrests, the emergence of a rebranding effort named WebDroid indicates that the CriminalMW Group continues to evolve, suggesting a larger network is still operational. Read the full analysis here. On February 2, 2024, Cyble Research Intelligence Labs CRIL discovered AsukaStealer, a MalwareasaService MaaS being marketed on a Russianlanguage cybercrime forum. This malware, in its version 0.9.7, is available for rent at USD 80 per month. Interestingly, AsukaStealer first made its appearance on another prominent Russian forum on January 24, 2024, under a different identity, showcasing its operators efforts to widely promote their malicious service. AsukaStealer, developed in C, is equipped with a range of functionalities and a userfriendly webbased control panel. It is adept at harvesting a variety of sensitive data including browser information, Discord and Telegram session details, credentials from FileZilla and Steam Desktop Authenticator, as well as data from crypto wallets and extensions. Additionally, it can capture screenshots from desktops. Further investigation suggests that AsukaStealer might be an evolved form of the previously known ObserverStealer malware, indicating its advanced and potentially more dangerous capabilities. Read the full analysis here. Tangerine, a major telecom operator, recently suffered a significant data breach affecting 232,000 customers. This incident, which took place on February 18, 2024, was only brought to the attention of Tangerines management two days later, on February 20. The breach resulted in the unauthorized disclosure of a substantial amount of personal customer data. The company issued a statement on February 21, 2024, detailing the extent of the data leak. Compromised information included customers full names, dates of birth, mobile and email contacts, postal addresses, and Tangerine account numbers. However, Tangerine assured that more sensitive data like credit/debit card details, drivers license numbers, ID documents, banking information, and passwords were not affected, as the company does not store such data. Read the complete article here. Join us on February 29, 2024, at 8:30 PM for an engaging and informative webinar: Navigating the Cyber Threat Landscape in 2024: Mastering Risk Scoring for Enhanced Security Posture. This session, led by the esteemed Ankit Sharma, Senior Director and Head of Solutions Engineering Sales, is meticulously designed to equip you with the knowledge and skills necessary to navigate the complexities of cyber threat risk scoring. Its an invaluable opportunity for those seeking to bolster their cybersecurity defenses with advanced strategies and insights. Attendees will gain insights into the latest trends and challenges in cyber threat evaluation alongside an exploration of cuttingedge methodologies and tools for risk assessment and scoring. Well also provide practical guidance on integrating risk scoring into your security strategy, supplemented by case studies and realworld applications that demonstrate the efficacy of these approaches in preempting and mitigating cyber threats. This session is tailormade for IT professionals, cybersecurity experts, risk management consultants, and CISOs keen on leveraging cyber threat risk scoring to enhance their organizations security posture. Attendees will also enjoy exclusive giveaways, including the latest issue of The Cyber Express, the newest Threat Landscape Report, and a threemonth Odin Subscription. Secure your spot for the webinar here Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

