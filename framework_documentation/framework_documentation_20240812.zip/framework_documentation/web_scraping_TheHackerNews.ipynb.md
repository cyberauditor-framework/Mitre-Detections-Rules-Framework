---
Status: Ok
Refactored: true
Code block: get_cti_information
Requirements: os, re, requests, bs4, datetime, pandas, dateutil.parser, stix2, yaml
Last modification: 2024-06-21
1st deploy: 2024-07-02
Author: Juan Enrique López Marcos (CP)
Functions: link_to_soup, get_news_urls, get_date_from_news, get_cat_from_news, get_body_and_links_from_news, get_news_info, format_name, format_name_cat, create_header_properties, write_dict_to_md, print_oldest_and_most_recent_notice, get_count_files_from_path, split_list_by_hyphen, get_unified_cat, modify_string, get_data_from_branch, get_list_techniques_from_stix2, find_techniques, NoAliasDumper-ignore_aliases, write_dict_to_yaml
---
**Resumen**

Este código tiene como objetivo obtener la información publicada en la web [The Hacker News](https://thehackernews.com/) sobre noticias relacionadas con ciberdelincuencia mediante técnicas web scraping. Como resultado se obtiene la información y se guarda en archivos en formato markdown ordenados en una estructura de carpetas cuyo nombre es la fecha de publicación de la noticia para la posterior integración en bóveda Obsidian. Adicionalmente en el código hay desarrollados una serie de métodos que permiten: guardar con extensión yaml, guardar clasificado por categoria y subcategoría o bien por categoría unificada y por último, guardar identificando previamente menciones a TTP's (este último no ha retornado ninguna identificación en ninguna de las pruebas realizadas).

***

**Estructura**

Para la ejecución de este código no es necesario disponer de ningún tipo de input pero su ejecución generará una estructura de carpetas: `outputs\TheHackerNews\save_by_date\{%Y%m%d}` en la que se almacenarán archivos markdown con el contenido de la noticia.

***

**Funciones**

Enumeramos las funciones creadas para este código junto con una breve descripción de la utilidad.


- *link_to_soup ()*
	Argumentos requeridos:
	- *link*: url como cadena.
	
	Funcionalidad: Función cuyo cometido es peticionar a la url proporcionada como request y convertirlo en un objeto BeautifulSoup para su posterior tratamiento. Retornamos el propio objeto BeautifulSoup


- *get_news_urls ()*
	Argumentos requeridos:
	- *main_bs4_page*: objeto
	- *num_scrap_pages*: número de páginas a scrapear. En formato entero.
	- *class_searched*: nombre (cadena) de la clase en la que se aloja el link que permite navegar entre páginas. 
	- *link*: url principal desde la que se navegará para buscar las noticias.
	
	Funcionalidad: Cuando entramos en la web de THN nos encontramos una página principal donde se listan las últimas n noticias junto con una ilustración y un breve texto. Con esta función obtenemos las url's propias de cada noticia para las n hojas pasadas como parámetro.


- *get_date_from_news ()*
	Argumentos requeridos:
	- *news*: diccionario que contiene la información de una única noticia.
	
	Funcionalidad: Obtención de la fecha de publicación de la noticia a partir del objeto bs4 que contiene la información completa de la noticia.


- *get_cat_from_news ()*
	Argumentos requeridos:
	- *news*: diccionario que contiene la información de una única noticia.
	
	Funcionalidad: Obtención de la categoría asignada por THN a la noticia a partir del objeto bs4 que contiene la información completa de la noticia.


- *get_body_and_links_from_news ()*
	Argumentos requeridos:
	- *news*: diccionario que contiene la información de una única noticia.
	
	Funcionalidad: Obtención del cuerpo y links en la noticia a partir del objeto bs4 que contiene la información completa.


- *get_news_info ()*
	Argumentos requeridos:
	- *news_url_list*: lista de url's de noticias a scrapear.
	
	Funcionalidad: Función que, dada una lista de urls de las noticias recopiladas en THN, retorna una lista de diccionarios que contienen la información de cada noticia. Esta función llamará a otras definidas: *get_date_from_news ()*, *get_cat_from_news ()* y *get_body_and_links_from_news ()* . Retorna la lista de diccionarios con la información.

- *format_name ()*
	Argumentos requeridos:
	- *item*: lista de cadenas.
	
	Funcionalidad: Función creada para la eliminación de caracteres extraños en los elementos str de una lista. Retorna la lista formateada.

- *format_name_cat ()*
	Argumentos requeridos:
	- *item*: lista de cadenas.
	
	Funcionalidad: Función específica para la obtención y formateo de la categoría a partir del etiquetado global asignada por THN. THN asigna generalmente un etiquetado global conformado por lo que nosotros hemos identificado como catgoría-subcatgoría. En esta función únicamente se retorna la categoría o primera etiqueta asignada. Retorna la lista formateada.

- *create_header_properties ()*
	Argumentos requeridos:
	- *dictionary*: diccionario que contiene la información de la noticia.
	
	Funcionalidad: Con el objetivo de integrar en el fichero markdown final las propiedades por las que poder filtrar en obsidian. Mediante la función se mapean una serie de características y se retorna una cadena para poder añadir al principio del documento .md. 


- *write_dict_to_md ()*
	Argumentos requeridos:
	- *dictionary*: diccionario que contiene la información de la noticia.
	- *filename*: nombre de guardado del archivo.
	
	Funcionalidad: Función de escritura y guardado del contenido de la noticia como archivo .markdown.

- *print_oldest_and_most_recent_notice ()*
	Argumentos requeridos:
	- *dict_news*: lista de diccionarios que contienen la información de cada noticia.
	
	Funcionalidad: Función encargada de mostrar la fecha de la noticia más reciente y la noticia más antigua a partir del diccionario que contiene la información de las noticias scrapeadas.


- *get_count_files_from_path ()*
	Argumentos requeridos:
	- *main_folder*: path de carpeta a analizar.
	- *col_name*: nombre a asignar a la columna que almcena el recuento de archivos.
	
	Funcionalidad: Función encargada de construir un df que contendrá por un lado el nombre de la subcarpeta y por otro lado el número de archivos identificados en esa. Requiere un path así como un nombre para la columna de recuento.


- *class NoAliasDumper \\ ignore_aliases()*
	Argumentos requeridos:
	- *yaml.SafeDumper*: objeto de la librería yaml.
	
	Funcionalidad: La clase NoAliasDumper es una extensión de yaml.SafeDumper que sobrescribe el método ignore_aliases para siempre devolver True. Esto asegura que los datos se serialicen sin usar referencias alias en el formato YAML. Es llamado en *write_dict_to_yaml ()*.


- *write_dict_to_yaml ()*
	Argumentos requeridos:
	- *news*: diccionario que contiene la información de la noticia.
	- *filename*: nombre de guardado del archivo.
	
	Funcionalidad: Función de escritura y guardado del contenido de la noticia como archivo .yaml. 


- *split_list_by_hyphen ()*
	Argumentos requeridos:
	- *items*: lista de cadenas.
	
	Funcionalidad: Función encargada de retornar una lista con las etiquetas asignadas como categoría y subcategoría a la noticia.


- *get_unified_cat ()*
	Argumentos requeridos:
	- *item*: lista de cadenas.
	
	Funcionalidad: Función específica para unificar el formateo de las etiquetas asignadas.

- *modify_string ()*
	Argumentos requeridos:
	- *s*: cadena.
	
	Funcionalidad: Breve función para formatear posibles casos en los que se hayan asignado más de una subcategoría.

- *get_data_from_branch ()*
	Argumentos requeridos:
	- *matrix*: Cadena que se define como parámetro y solo puede obtener como valores: enterprise, ics o mobile.
	
	Funcionalidad: Se encarga de peticionar a la url de GitHub donde está publicada la última versión MITRE de la información en formato stix2. Retorna el objeto que contiene toda la información de MITRE.


- *get_list_techniques_from_stix2 ()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	- 
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.

	Funcionalidad: Función encargada de la obtención de la lista de técnicas de los datos facilitados. Por defecto se retornan tanto técnicas como subtécnicas. Retorna una lista de strings con el id correspondiente a cada técnica.


- *find_techniques ()*
	Argumentos requeridos:
	- *texto*: cadena sobre la que se va a iterar para identificar id de técnicas.
	- *techniques_list*: lista de técnicas sobre las que iterar. 

	Funcionalidad: Función encargada de buscar en un texto facilitado los elementos contenidos en la lista de técnicas. Retorna una lista con las técnicas encontradas.