---
Status: Ok
Refactored: false
Code block: cti_mitre_relationships
Requirements: os, re, pandas, stix2, request
1st deploy: 2024-07-17
Last modification: 2024-08-09
Author: Juan Enrique López Marcos (CP)
Functions: get_data_from_branch, get_list_techniques_from_stix2, get_techniques_lists, get_tactics_lists, get_datasources_lists, get_platforms_list, get_software_lists, get_groups_lists, get_list_of_files_sub, find_content_in_list, list_to_string clean_col, clean_description_col, match_items, results_to_df, unique_list, get_data_from_techniques, get_data_from_relation,
---
**Resumen**

Este código tiene como objetivo complementar los archivos markdown de noticias generados por el bloque get_cti_information. Para ello, se ha configurado de tal forma que lee en la path donde se han guardado los archivos (debe existir al menos una noticia generada). El header que contiene las propiedades de la nota se modificará en caso de encontrar algún id o nombre de propiedad Mitre en el contenido del archivo.

***

**Estructura**

Para la ejecución de este código no es necesario haber ejecutado el bloque [[get_cti_information]] y disponer de al menos una noticia almacenada como .md. Tras la ejecución se sobrescribirán los archivos originales

***

**Funciones**

Enumeramos las funciones creadas para este código junto con una breve descripción de la utilidad.

- *get_data_from_branch ()*
	Argumentos requeridos:
	- *matrix*: Cadena que se define como parámetro y solo puede obtener como valores: enterprise, ics o mobile.
	
	Funcionalidad: Se encarga de peticionar a la url de GitHub donde está publicada la última versión MITRE de la información en formato stix2. Retorna el objeto que contiene toda la información de MITRE.

- *get_list_techniques_from_stix2 ()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.

	Funcionalidad: Función encargada de la obtención de la lista de técnicas de los datos facilitados. Por defecto se retornan tanto técnicas como subtécnicas. Retorna una lista de strings con el id correspondiente a cada técnica.

- *get_list_of_files_sub ()*
	Argumentos requeridos:
	- *dir_name*: path facilitada para obtener la lista de archivos.
	
	Funcionalidad: Función encargada de retornar una lista de archivos ubicados en la ruta facilitada así como en los subdirectorios disponibles.

- *get_list_techniques_from_stix2()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	- 
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.
	
	Funcionalidad: Función encargada de la obtención de la lista de técnicas de los datos facilitados. Por defecto se retornan tanto técnicas como subtécnicas. Retorna una lista de strings con el id correspondiente a cada técnica.

- *get_techniques_lists()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Argumentos opcionales:
	- *revoked_deprecated*: Por defecto 'True' para aplicar un filtro que elimine aquellas técnicas deprecadas o revocadas.
	
	Funcionalidad: Función que retorna las listas de id técnicas y nombre de técnicas.

- *get_tactics_lists()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Funcionalidad: Función que retorna las listas de id táctica y nombre de táctica.

- *get_datasources_lists()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	- 
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.
	
	Funcionalidad: Función que retorna las listas de id data source y nombre de data source.

- *get_platforms_list()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.
	
	Funcionalidad: Función que retorna las lista de plataformas.

- *get_software_lists()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.
	
	Funcionalidad: Función que retorna las listas de id software y nombre de software.

- *get_groups_lists()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().

	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.
	
	Funcionalidad: Función que retorna las listas de id grupo y nombre de grupo.

- *find_content_in_list ()*
	Argumentos requeridos:
	- *texto*: cadena en la que se desea buscar una serie de elementos.
	- *items_list*: lista de cadenas que se desean buscar.
	
	Funcionalidad: Función encargada de buscar en un texto facilitado los elementos contenidos en la lista de técnicas. Retorna una lista con el contenido encontrado.

- *list_to_string ()*
	Argumentos requeridos:
	- *cell*: contenido de caracteres de una celda de un dataframe de pandas.
	
	Funcionalidad: Función para convertir listas en cadenas separadas por ";".

- *clean_col ()*
	Argumentos requeridos:
	- *cell*: contenido de caracteres de una celda de un dataframe de pandas.
	
	Funcionalidad: Función para eliminar caracteres no alfanuméricos excepto ".", y "," de cada celda de un dataframe de pandas.

- *clean_description_col ()*
	Argumentos requeridos:
	- *cell*: contenido de caracteres de una celda de un dataframe de pandas.
	
	Funcionalidad: Función específica de la columna descriptiva para eliminar caracteres no alfanuméricos excepto ".", y "," de cada celda.

- *match_items ()*
	Argumentos requeridos:
	- *items_list*: lista de cadenas que se desean buscar.
	- *news_sources_list*: lista de noticias generadas como archivos .md.
	
	Funcionalidad: Función encargada de devolver un diccionario compuesto por la ruta del archivo analizado como clave y como valor una lista que a su vez se compone por el numero de coincidencias encontradas y las propias coincidencias (únicas). Retorna un diccionario.

- *results_to_df ()*
	Argumentos requeridos:
	- *dict_results*: diccionario generado por match_items().
	
	Funcionalidad: Función para convertir en df el diccionario generado por match_items().

- *unique_list ()*
	Argumentos requeridos:
	- *series*: lista.
	
	Funcionalidad: Función para devolver sólo ítems únicos a partir de una lista.

- *get_data_from_techniques ()*
	Argumentos requeridos:
	- *matrix*: Cadena que se define como parámetro y solo puede obtener como valores: enterprise, ics o mobile.
	
	Funcionalidad: Función cuyo cometido es leer el archivo csv de técnicas generado por el módulo mitre_relationships y el nb `[stix2]_mitre_relationships.ipynb` El archivo consultado se corresponderá con la matriz facilitada en el argumento obligatorio.

- *get_data_from_relation ()*
	Argumentos requeridos:
	- *matrix*: Cadena que se define como parámetro y solo puede obtener como valores: enterprise, ics o mobile.
	- *source_rel*: Cadena que identifica la relación deseada entre propiedades Mitre para identificar el archivo.
	- *source_info*: Cadena que identifica la propiedad Mitre deseada para identificar el archivo.
	
	Funcionalidad: Función encargada de generar un df que contiene la información de la relación entre técnicas y propiedad así como la información complementaria relativa a la propiedad (data source, grupo, plataforma, software y táctica). Retorna un dataframe con la información correspondiente. 


