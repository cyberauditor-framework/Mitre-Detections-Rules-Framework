---
Status: Ok
Refactored: false
Code block: mitre_relationships
Requirements: os, requests, pandas, stix2, datetime, csv
Last modification: 2024-07-10
1st deploy: 2024-07-09
Author: Juan Enrique López Marcos (CP)
Functions:
---

**Resumen**

Este jupyter notebook permite la obtención de las tablas relacionales de las diferentes propiedades de técnicas MITRE. Adicionalmente se generan tablas con campos informativos para cada propiedad así como tablas resumen identificando el numero de reglas de detección por técnica disponible para cada propiedad. Las propiedades disponibles son: táctica, data source, plataforma, grupo y software. Adicionalmente se ha incorporado la relación existente entre grupo y software. 

***

**Estructura**

Para la correcta ejecución del código es necesaria la previa ejecución del bloque [get_rules_and_classify_by_ttp], el cual nos permite identificar, del conjunto total de técnicas MITRE, cuales están cubiertas en CyberProof por al menos una regla de detección.
Los outputs generados están disponibles siguiendo la estructura de carpetas: `outputs\stix2\{matrix}\` la cual estará seguida por las subcarpetas `information`, `relations` y `availability_rules`. En `information` estará disponible la tabla con el detalle de cada propiedad, en `relations` podrá consultarse las relaciones entre técnicas y propiedad, y por último, en  `availability_rules` está disponible, por propiedad, una tabla resumen entre reglas de detección disponible en CP, TTP y propiedad en detalle y agregado por TTP. Todas las tablas generadas son guardadas como archivos .csv.

***

**Funciones**

- *create_output_folder ()*
	Argumentos requeridos:
	- *path*: ruta de guardado.
	
	Funcionalidad: encargada creada para crear el directorio facilitado en caso de no existir previamente.


- *get_list_of_files_sub ()*
	Argumentos requeridos:
	- *dir_name*: path facilitada para obtener la lista de archivos.
	
	Funcionalidad: Función encargada de retornar una lista de archivos ubicados en la ruta facilitada así como en los subdirectorios disponibles.


- *get_unique_ttps_generated ()*
	Argumentos requeridos:
	- *path*: ruta de directorio.
	
	Funcionalidad: Función encargada de retornar una lista de id de TTP's únicas generadas. Esta función recibirá una ruta generada previamente en la estructura de carpetas de guardado. 

- *unique_list ()*
	Argumentos requeridos:
	- *series*: lista.
	
	Funcionalidad: Función para devolver sólo ítems únicos a partir de una lista.


- *get_data_from_branch ()*
	Argumentos requeridos:
	- *matrix*: Cadena que se define como parámetro y solo puede obtener como valores: enterprise, ics o mobile.
	
	Funcionalidad: Se encarga de peticionar a la url de GitHub donde está publicada la última versión MITRE de la información en formato stix2. Retorna el objeto que contiene toda la información de MITRE.


- *save_df_as_csv ()*
	Argumentos requeridos:
	- *df*: Dataframe que se quiere guardar como csv.
	- *name*: Cadena con la que se quiera guardar el csv. 
	- *matrix*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando. 
	
	Argumentos opcionales
	- *aux_folder*: Por defecto vacío. Cadena para generar una subcarpeta opcional posterior a la carpeta de la matriz.
	
	Funcionalidad: Función encargada de guardar un dataframe pasado como argumento como csv.


- *get_list_techniques_from_stix2 ()*
	Argumentos requeridos:
	- *src*: Se trata de un objeto stix2 que se genera por la función get_data_from_branch().
	- 
	Argumentos opcionales:
	- *include*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.

	Funcionalidad: Función encargada de la obtención de la lista de técnicas de los datos facilitados. Por defecto se retornan tanto técnicas como subtécnicas. Retorna una lista de strings con el id correspondiente a cada técnica.


- *get_CP_ttps_with_rules ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	
	Argumentos opcionales:
	- *way*: Por defecto 'both', para retornar técnicas y subtécnicas. Otras opciones: techniques, subtechniques.

	Funcionalidad: Función encargada de obtener el listado de TTP's para las que desde CP disponemos de reglas de detección. Para la ejecutarla correctamente debe de haberse ejecutado previamente el código del bloque get_rules_and_classify_by_ttp. Hay dos formas de evaluar las técnicas disponibles y son gestionadas por el parámetro "way". Por defecto el modo es "file", lo que nos indica que se va a evaluar uno de los ficheros generados de resumen de reglas por TTP clasificadas. En el caso de que el parámetro "way" recoja el valor "path", lo que hará es identificar las reglas mediante la exploración de subdirectorios.


- *get_CP_ttps_with_rules ()*
	Argumentos requeridos:
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	- *df*: Dataframe sobre el que queremos obtener los dataframes con y sin disponibilidad de técnicas.
	
	Funcionalidad: Función encargada de filtrar un df dado el cual contiene el campo techniques_ID por las técnicas disponibles en CP (estas son facilitadas como parámetro en forma de lista).


- *get_techniques_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Argumentos opcionales:
	- *revoked_deprecated*: Por defecto 'True' para aplicar un filtro que elimine aquellas técnicas deprecadas o revocadas.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a la técnicas (ID, nombre, url, descripción, estado deprecado, estado revocado, dominios MITRE).


- *get_tactics_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a la tácticas (ID, nombre, url, descripción, estado deprecado, estado revocado, dominios MITRE).


- *get_datasources_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Argumentos opcionales:
	- *revoked_deprecated*: Por defecto 'True' para aplicar un filtro que elimine aquellas técnicas deprecadas o revocadas.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a los data sources (ID, nombre, url, descripción, estado deprecado, estado revocado, dominios MITRE).


- *get_platforms_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a las plataformas. Únicamente está conformado por una columna con el nombre de la misma ya que las plataformas no se obtienen de una tipología propia de la matriz, se obtienen como parámetro de las técnicas.


- *get_groups_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Argumentos opcionales:
	- *revoked_deprecated*: Por defecto 'True' para aplicar un filtro que elimine aquellas técnicas deprecadas o revocadas.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a los grupos (ID, nombre, alias, url, descripción, estado deprecado, estado revocado, dominios MITRE).


- *get_software_information ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Argumentos opcionales:
	- *revoked_deprecated*: Por defecto 'True' para aplicar un filtro que elimine aquellas técnicas deprecadas o revocadas.
	
	Funcionalidad: Función que retorna el dataframe con la información relativa a los tipos de software (ID, nombre, alias, url, descripción, estado deprecado, estado revocado, dominios MITRE).


- *get_techniques_tactics_relationships ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función que retorna las relaciones entre técnicas y tácticas (N:N, 1:N y N:1), también devuelve estas tablas como dataframes de pandas filtrados por: todos los disponibles en MITRE, los disponibles en CyberProof y los NO disponibles en CyberProof. Requiere la matriz MITRE (enterprise, ICS o Mobile) en formato MemoryStore de stix2. Retorna 9 df, 3 para las posibles relaciones 1:N, N:N y N:1, y 3 opciones para MITRE (todas las técnicas), CP (sólo técnicas disponibles en CyberProof) y NOCP (sólo técnicas ausentes en CyberProof).



- *get_techniques_datasources_relationships ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función que retorna las relaciones entre técnicas y data sources (N:N, 1:N y N:1), tambien devuelve estas tablas como dataframes de pandas filtrados por: todos los disponibles en MITRE, los disponibles en CyberProof y los NO disponibles en CyberProof. Requiere la matriz MITRE (enterprise, ICS o Mobile) en formato MemoryStore de stix2.Retorna 9 df, 3 para las posibles relaciones 1:N, N:N y N:1, y 3 opciones para MITRE (todas las técnicas), CP (sólo técnicas disponibles en CyberProof) y NOCP (sólo técnicas ausentes en CyberProof).


- *get_techniques_platforms_relationships ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función que retorna las relaciones entre técnicas y plataformas (N:N, 1:N y N:1), tambien devuelve estas tablas como dataframes de pandas filtrados por: todos los disponibles en MITRE, los disponibles en CyberProof y los NO disponibles en CyberProof. Requiere la matriz MITRE (enterprise, ICS o Mobile) en formato MemoryStore de stix2.Retorna 9 df, 3 para las posibles relaciones 1:N, N:N y N:1, y 3 opciones para MITRE (todas las técnicas), CP (sólo técnicas disponibles en CyberProof) y NOCP (sólo técnicas ausentes en CyberProof).



- *get_techniques_groups_relationships ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función que retorna las relaciones entre técnicas y grupos (N:N, 1:N y N:1), también devuelve estas tablas como dataframes de pandas filtrados por: todos los disponibles en MITRE, los disponibles en CyberProof y los NO disponibles en CyberProof. Requiere la matriz MITRE (enterprise, ICS o Mobile) en formato MemoryStore de stix2. Retorna 9 df, 3 para las posibles relaciones 1:N, N:N y N:1, y 3 opciones para MITRE (todas las técnicas), CP (sólo técnicas disponibles en CyberProof) y NOCP (sólo técnicas ausentes en CyberProof).


- *get_groups_software_relationships ()*
	Argumentos requeridos:
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	
	Funcionalidad: Función que retorna las relaciones entre grupos y software (N:N, 1:N y N:1). A diferencia de anteriores relaciones, en este caso no se puede filtrar por lista de técnicas disponibles. Requiere la matriz MITRE (enterprise, ICS o Mobile) en formato MemoryStore de stix2. Retorna únicamente 3 df para las posibles relaciones 1:N, N:N y N:1 ya que en esta relación no hay disponibilidad de filtrar por técnica.


- *get_availability_rules_by_technique ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica. Devuelve una primera tabla idéntica a la generada en el resumen generado en 'get_rules_and_classify_by_ttp/{matrix}-classified_rules.csv'. Y por otro lado genera una tabla con el agregado del número de reglas por técnica disponible que será requerida en posteriores cruces.


- *get_availability_rules_by_technique_and_tactics ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica y táctica. Se llama a las funciones get_availability_rules_by_technique() y get_techniques_tactics_relationships() de las cuales se recogen 2 dataframes para su posterior leftjoin. Se retornan 2 dataframes, por un lado un resumen detallado a nivel de táctica y técnica del número de reglas disponibles, y por otro lado un resumen agregado del numero de técnicas y reglas por táctica.


- *get_availability_rules_by_technique_and_datasource ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica y data source. Se llama a las funciones get_availability_rules_by_technique() y get_techniques_datasources_relationships() de las cuales se recogen 2 dataframes para su posterior leftjoin. Se retornan 2 dataframes, por un lado un resumen detallado a nivel de táctica y técnica del número de reglas disponibles, y por otro lado un resumen agregado del numero de técnicas y reglas por data source.


- *get_availability_rules_by_technique_and_platform ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica y data source. Se llama a las funciones get_availability_rules_by_technique() y get_techniques_datasources_relationships() de las cuales se recogen 2 dataframes para su posterior leftjoin. Se retornan 2 dataframes, por un lado un resumen detallado a nivel de táctica y técnica del número de reglas disponibles, y por otro lado un resumen agregado del numero de técnicas y reglas por data source.


- *get_availability_rules_by_technique_and_group ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica y grupo. Se llama a las funciones get_availability_rules_by_technique() y get_availability_rules_by_technique_and_group() de las cuales se recogen 2 dataframes para su posterior leftjoin. Se retornan 2 dataframes, por un lado un resumen detallado a nivel de táctica y técnica del número de reglas disponibles, y por otro lado un resumen agregado del numero de técnicas y reglas por grupo.


- *get_availability_rules_by_technique_and_software ()*
	Argumentos requeridos:
	- *mitre_matrix_str*: Cadena que recoge la matriz MITRE (dominio) que se está ejecutando.
	- *matrix_store*: Matriz MITRE obtenida mediante request y almacenada como objeto MemoryStore stix2.
	- *cp_techniques_list*: Lista de técnicas en CP que disponen al menos de una regla de detección. 
	
	Funcionalidad: Función encargada de obtener la disponibilidad de reglas por técnica y software. Se llama a las funciones get_availability_rules_by_technique() y get_techniques_software_relationships() de las cuales se recogen 2 dataframes para su posterior leftjoin. Se retornan 2 dataframes, por un lado un resumen detallado a nivel de táctica y técnica del número de reglas disponibles, y por otro lado un resumen agregado del numero de técnicas y reglas por software.