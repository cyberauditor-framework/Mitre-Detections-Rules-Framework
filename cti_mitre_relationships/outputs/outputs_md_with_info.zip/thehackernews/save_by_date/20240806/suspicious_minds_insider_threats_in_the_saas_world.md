---
CP Source: The Hacker News
CP Execution date:  2024-08-08
Headline: "Suspicious Minds: Insider Threats in The SaaS World"
Date: 2024-08-06
Category: "SaaS Security"
Sub-Category: "Threat Detection"

AI_technique_ID_1: "T1588.002"
AI_technique_1: "TOOL"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_1: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1589.001"
AI_technique_2: "CREDENTIALS"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1589/001"
AI_technique_description_2: "Adversaries may gather credentials that can be used during targeting. Account credentials gathered by adversaries may be those directly associated with the target victim organization or attempt to take advantage of the tendency for users to use the same passwords across personal and business accounts. Adversaries may gather credentials from potential victims in various ways, such as direct elicitation via Phishing for Information https://attack.mitre.org/techniques/T1598. Adversaries may also compromise sites then add malicious content designed to collect website authentication cookies from visitors.Citation ATT ScanBox Credential information may also be exposed to adversaries via leaks to online or other accessible data sets ex Search Engines https://attack.mitre.org/techniques/T1593/002, breach dumps, code repositories, etc..Citation Register DeloitteCitation Register UberCitation Detectify Slack TokensCitation Forbes GitHub CredsCitation GitHub truffleHogCitation GitHub GitrobCitation CNET Leaks Adversaries may also purchase credentials from dark web or other blackmarkets. Finally, where multifactor authentication MFA based on outofband communications is in use, adversaries may compromise a service provider to gain access to MFA codes and onetime passwords OTP.Citation Okta Scatter Swine 2022 Gathering this information may reveal opportunities for other forms of reconnaissance ex Search Open WebsitesDomains https://attack.mitre.org/techniques/T1593 or Phishing for Information https://attack.mitre.org/techniques/T1598, establishing operational resources ex Compromise Accounts https://attack.mitre.org/techniques/T1586, andor initial access ex External Remote Services https://attack.mitre.org/techniques/T1133 or Valid Accounts https://attack.mitre.org/techniques/T1078."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1053.002"
AI_technique_3: "AT"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_3: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"


AI_data_source_ID_1: "DS0026"
AI_technique_ID_1: "T1134.005; T1649; T1037; T1134; T1556; T1003; T1037.003; T1222; T1558.004; T1531; T1558.003; T1222.001; T1556.005; T1484.001; T1615; T1556.006; T1484.002; T1098; T1558; T1207; T1003.006; T1033; T1098.005; T1550.003; T1528; T1550; T1550.002; T1558.001; T1556.009; T1484"
AI_technique_1: "Modify Authentication Process; Group Policy Discovery; Conditional Access Policies; Access Token Manipulation; SID-History Injection; Multi-Factor Authentication; Reversible Encryption; Steal or Forge Kerberos Tickets; Steal or Forge Authentication Certificates; Device Registration; OS Credential Dumping; Kerberoasting; Golden Ticket; Account Access Removal; Pass the Ticket; System Owner/User Discovery; Group Policy Modification; Account Manipulation; Pass the Hash; Steal Application Access Token; Boot or Logon Initialization Scripts; Trust Modification; Use Alternate Authentication Material; AS-REP Roasting; Windows File and Directory Permissions Modification; Network Logon Script; Rogue Domain Controller; Domain or Tenant Policy Modification; File and Directory Permissions Modification; DCSync"
AI_data_source_1: "ACTIVE DIRECTORY"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0026"
AI_data_source_description_1: "A database and set of services that allows administrators to manage permissions, access to network resources, and stored data objects user, group, application, or devicesCitation Microsoft AD DS Getting Started"
AI_matrix_domains_1: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1595.001; T1583.008; T1587; T1598.003; T1588.001; T1584.006; T1584.003; T1588; T1585; T1594; T1583.001; T1608.001; T1587.001; T1587.003; T1608.005; T1583.003; T1583.006; T1588.003; T1598; T1584.001; T1598.004; T1588.002; T1608; T1587.002; T1608.006; T1584.002; T1592.002; T1584.008; T1595.002; T1589.002; T1608.003; T1584; T1598.002; T1586.001; T1608.004; T1589; T1583.004; T1595; T1598.001; T1592; T1583.007; T1586; T1592.001; T1588.004; T1585.001; T1592.004; T1584.004; T1608.002; T1583; T1595.003; T1584.007"
AI_technique_1: "DNS Server; Server; Compromise Infrastructure; Serverless; Client Configurations; Vulnerability Scanning; Install Digital Certificate; Link Target; Acquire Infrastructure; Hardware; Obtain Capabilities; SEO Poisoning; Code Signing Certificates; Digital Certificates; Active Scanning; Virtual Private Server; Spearphishing Service; Stage Capabilities; Search Victim-Owned Websites; Web Services; Gather Victim Identity Information; Email Addresses; Wordlist Scanning; Spearphishing Voice; Malvertising; Tool; Upload Malware; Social Media Accounts; Develop Capabilities; Establish Accounts; Drive-by Target; Gather Victim Host Information; Scanning IP Blocks; Phishing for Information; Compromise Accounts; Upload Tool; Malware; Domains; Spearphishing Attachment; Network Devices; Spearphishing Link; Software"
AI_platform_2: "SAAS"
AI_technique_ID_2: "T1530; T1537; T1556; T1110.001; T1078.004; T1110.004; T1552.008; T1552; T1567.004; T1606.001; T1556.007; T1538; T1539; T1606.002; T1499.004; T1550.001; T1531; T1119; T1499.002; T1189; T1534; T1550.004; T1499; T1566; T1110.003; T1556.006; T1087.004; T1484.002; T1566.004; T1136; T1069.003; T1498; T1098; T1199; T1213.003; T1566.002; T1080; T1213; T1484; T1021.007; T1059.009; T1098.005; T1136.003; T1213.001; T1098.001; T1562.008; T1648; T1087; T1656; T1078; T1621; T1078.001; T1528; T1498.002; T1657; T1526; T1546; T1498.001; T1069; T1048; T1211; T1550; T1567; T1072; T1098.003; T1606; T1499.003; T1556.009; T1110"
AI_technique_2: "Cloud Account; Modify Authentication Process; SAML Tokens; Additional Cloud Roles; Default Accounts; Reflection Amplification; Conditional Access Policies; Account Discovery; Automated Collection; Event Triggered Execution; Service Exhaustion Flood; Multi-Factor Authentication; Password Spraying; Data from Information Repositories; Code Repositories; Direct Network Flood; Web Cookies; Create Account; Password Guessing; Exfiltration Over Web Service; Disable or Modify Cloud Logs; Unsecured Credentials; Impersonation; Valid Accounts; Application Access Token; Forge Web Credentials; Multi-Factor Authentication Request Generation; Device Registration; Chat Messages; Account Access Removal; Endpoint Denial of Service; Steal Web Session Cookie; Transfer Data to Cloud Account; Trusted Relationship; Spearphishing Voice; Confluence; Network Denial of Service; Cloud Accounts; Account Manipulation; Steal Application Access Token; Exfiltration Over Webhook; Permission Groups Discovery; Cloud Services; Cloud Service Discovery; Data from Cloud Storage; Exfiltration Over Alternative Protocol; Additional Cloud Credentials; Trust Modification; Application Exhaustion Flood; Use Alternate Authentication Material; Software Deployment Tools; Drive-by Compromise; Cloud Service Dashboard; Hybrid Identity; Phishing; Taint Shared Content; Serverless Execution; Web Session Cookie; Brute Force; Domain or Tenant Policy Modification; Application or System Exploitation; Spearphishing Link; Credential Stuffing; Cloud API; Exploitation for Defense Evasion; Cloud Groups; Internal Spearphishing; Financial Theft"


AI_software_ID_1: "S0183"
AI_technique_ID_1: "T1090.003; T1573.002"
AI_technique_1: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_1: "TOR"
AI_software_type_1: "tool"
AI_software_url_1: "https://attack.mitre.org/software/S0183"
AI_software_description_1: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0110"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "At"
AI_software_2: "AT"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0110"
AI_software_description_2: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0075"
AI_technique_ID_3: "T1112; T1552.002; T1012"
AI_technique_3: "Credentials in Registry; Query Registry; Modify Registry"
AI_software_3: "REG"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0075"
AI_software_description_3: "Reg https://attack.mitre.org/software/S0075 is a Windows utility used to interact with the Windows Registry. It can be used at the commandline interface to query, add, modify, and remove information. Citation Microsoft Reg Utilities such as Reg https://attack.mitre.org/software/S0075 are known to be used by persistent threats. Citation Windows Commands JPCERT"
AI_matrix_domains_3: "enterprise-attack"

---

**title**
Suspicious Minds: Insider Threats in The SaaS World

**date**
06/08/2024

**url_news**
https://thehackernews.com/2024/08/suspicious-minds-insider-threats-in.html

**thn_category_and_subcategory**
'SaaS Security / Threat Detection'

**links**
'https://www.adaptive-shield.com/landing-page/the-annual-saas-security-survey-report-2025-ciso-plans-and-priorities/?utm_source=thehackernews&utm_medium=sponsored_content&utm_campaign=thn_detectinginsideractivity_1', 'https://www.adaptive-shield.com/book-a-demo/?utm_source=thehackernews&utm_medium=sponsored_content&utm_campaign=thn_detectinginsideractivity_2', 'https://www.adaptive-shield.com/academy/identity-threat-detection-and-response-itdr/', 'https://www.adaptive-shield.com/use-cases/identity-threat-detection-response/?utm_source=thehackernews&utm_medium=sponsored_content&utm_campaign=thn_detectinginsideractivity_3', 'https://www.adaptive-shield.com/book-a-demo/?utm_source=thehackernews&utm_medium=sponsored_content&utm_campaign=thn_detectinginsideractivity_4'

**body**
"Everyone loves the double-agent plot twist in a spy movie, but it's a different story when it comes to securing company data. Whether intentional or unintentional, insider threats are a legitimate concern. According to CSA research, 26% of companies who reported a SaaS security incident were struck by an insider. ", 'The challenge for many is detecting those threats before they lead to full breaches. Many security professionals assume there is nothing they can do to protect themselves from a legitimate managed user who logs in with valid credentials using a company MFA method. Insiders can log in during regular business hours, and can easily justify their access within the application. ', 'Cue the plot twist: With the right tools in place, businesses can protect themselves from the enemy from within (and without). ', 'Learn how to secure your entire SaaS stack from both internal and external threats', "In SaaS security, an Identity Threat Detection & Response (ITDR) platform looks for behavioral clues that indicate an app has been compromised. Every event in a SaaS application is captured by the application's event logs. Those logs are monitored, and when something suspicious takes place, it raises a red flag, called an Indicator of Compromise (IOC). ", "With outside threats, many of these IOCs relate to login methods and devices, as well as user behavior once they've gained access. With insider threats, IOCs are primarily behavioral anomalies. When IOCs reach a predetermined threshold, the system recognizes that the application is under threat. ", 'Most ITDR solutions primarily address endpoint and on-prem Active Directory protection. However, they are not designed to address SaaS threats, which require deep expertise in the application and can only be achieved by cross-referencing and analyzing suspicious events from multiple sources.', '', '', "Each of these IOCs on their own doesn't necessarily indicate an insider threat. There may be legitimate operational reasons that can justify each action. However, as IOCs accumulate and reach a predefined threshold, security teams should investigate the user to understand why they are taking these actions.", 'Take a deeper look at how ITDR works together with SSPM', 'The Principle of Least Privilege (PoLP) is one of the most important approaches in the fight against insider threats, as most employees typically have more access than required.', 'SaaS Security Posture Management (SSPM) and ITDR are two parts of a comprehensive SaaS security program. SSPM focuses on prevention, while ITDR focuses on detection and response. SSPM is used to enforce a strong Identity-First Security strategy, prevent data loss by monitoring share settings on documents, detect shadow apps used by users and monitor compliance with standards designed to detect insider threats. Effective ITDRs enable security teams to monitor users engaging in suspicious activity, enabling them to stop insider threats before they can cause significant harm.', "Get a 15 minute demo and learn more about ITDR and it's different use cases", 'Note:', 'Watch as experts simulate real-world threats to demonstrate compelling advantages.', 'Get actionable steps and tools to harness the full potential of GenAI while protecting your sensitive data.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

