---
CP Source: The Hacker News
CP Execution date:  2024-08-08
Headline: "INTERPOL Recovers $41 Million in Largest Ever BEC Scam in Singapore"
Date: 2024-08-06
Category: "Email Security"
Sub-Category: "Financial Fraud"

AI_technique_ID_1: "T1588.002"
AI_technique_1: "TOOL"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_1: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1087.003"
AI_technique_2: "EMAIL ACCOUNT"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1087/003"
AI_technique_description_2: "Adversaries may attempt to get a listing of email addresses and accounts. Adversaries may try to dump Exchange address lists such as global address lists GALs.Citation Microsoft Exchange Address Lists In onpremises Exchange and Exchange Online, thecodeGetGlobalAddressListcode PowerShell cmdlet can be used to obtain email addresses and accounts from a domain using an authenticated session.Citation Microsoft getglobaladdresslistCitation Black Hills Attacking Exchange MailSniper, 2016 In Google Workspace, the GAL is shared with Microsoft Outlook users through the Google Workspace Sync for Microsoft Outlook GWSMO service. Additionally, the Google Workspace Directory allows for users to get a listing of other users within the organization.Citation Google Workspace Global Access List"
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1053.002"
AI_technique_3: "AT"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_3: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"


AI_data_source_ID_1: "DS0021"
AI_technique_ID_1: "T1586; T1585.001; T1586.001; T1585"
AI_technique_1: "Establish Accounts; Social Media Accounts; Compromise Accounts"
AI_data_source_1: "PERSONA"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0021"
AI_data_source_description_1: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
AI_matrix_domains_1: "enterprise-attack"
AI_data_source_ID_2: "DS0036"
AI_technique_ID_2: "T1069.002; T1098.002; T1087.002; T1087.001; T1069; T1098; T1069.003; T1069.001"
AI_technique_2: "Domain Account; Account Manipulation; Additional Email Delegate Permissions; Permission Groups Discovery; Local Groups; Local Account; Domain Groups; Cloud Groups"
AI_data_source_2: "GROUP"
AI_data_source_url_2: "https://attack.mitre.org/datasources/DS0036"
AI_data_source_description_2: "A collection of multiple user accounts that share the same access rights to the computer andor network resources and have common security rightsCitation Amazon IAM Groups"
AI_matrix_domains_2: "enterprise-attack"
AI_data_source_ID_3: "DS0019"
AI_technique_ID_3: "T1562; T1490; T1564; T1489; T1557; T1564.006; T1036; T1036.004; T1543; T1543.003; T1574.005; T1543.002; T1574.010; T1569; T1557.001; T1574.011; T1543.004; T1569.002; T1574; T1021.006; T1562.001; T1543.001; T1197; T1569.001"
AI_technique_3: "Services File Permissions Weakness; Launch Daemon; Disable or Modify Tools; Windows Service; Create or Modify System Process; Executable Installer File Permissions Weakness; Services Registry Permissions Weakness; Launchctl; BITS Jobs; System Services; Systemd Service; Impair Defenses; Hide Artifacts; Masquerade Task or Service; Service Execution; Windows Remote Management; Adversary-in-the-Middle; Launch Agent; Inhibit System Recovery; Hijack Execution Flow; Masquerading; Service Stop; Run Virtual Instance; LLMNR/NBT-NS Poisoning and SMB Relay"
AI_data_source_3: "SERVICE"
AI_data_source_url_3: "https://attack.mitre.org/datasources/DS0019"
AI_data_source_description_3: "A computer process that is configured to execute continuously in the background and perform system tasks, in some cases before any user has logged inCitation Microsoft ServicesCitation Linux Services Run Levels"
AI_matrix_domains_3: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1595.001; T1583.008; T1587; T1598.003; T1588.001; T1584.006; T1584.003; T1588; T1585; T1594; T1583.001; T1608.001; T1587.001; T1587.003; T1608.005; T1583.003; T1583.006; T1588.003; T1598; T1584.001; T1598.004; T1588.002; T1608; T1587.002; T1608.006; T1584.002; T1592.002; T1584.008; T1595.002; T1589.002; T1608.003; T1584; T1598.002; T1586.001; T1608.004; T1589; T1583.004; T1595; T1598.001; T1592; T1583.007; T1586; T1592.001; T1588.004; T1585.001; T1592.004; T1584.004; T1608.002; T1583; T1595.003; T1584.007"
AI_technique_1: "DNS Server; Server; Compromise Infrastructure; Serverless; Client Configurations; Vulnerability Scanning; Install Digital Certificate; Link Target; Acquire Infrastructure; Hardware; Obtain Capabilities; SEO Poisoning; Code Signing Certificates; Digital Certificates; Active Scanning; Virtual Private Server; Spearphishing Service; Stage Capabilities; Search Victim-Owned Websites; Web Services; Gather Victim Identity Information; Email Addresses; Wordlist Scanning; Spearphishing Voice; Malvertising; Tool; Upload Malware; Social Media Accounts; Develop Capabilities; Establish Accounts; Drive-by Target; Gather Victim Host Information; Scanning IP Blocks; Phishing for Information; Compromise Accounts; Upload Tool; Malware; Domains; Spearphishing Attachment; Network Devices; Spearphishing Link; Software"


AI_software_ID_1: "S0148"
AI_technique_ID_1: "T1112; T1120; T1083; T1082; T1113; T1115; T1059.003; T1119; T1553.002; T1204.002; T1056.001; T1568; T1219; T1105; T1106; T1553.004; T1027; T1071.001; T1036; T1036.004; T1218.011; T1518.001; T1070.009; T1033; T1559.002; T1573.001; T1571; T1057; T1518; T1070.004; T1497; T1102.001; T1547.001; T1124; T1053.005; T1548.002; T1566.001"
AI_technique_1: "Bypass User Account Control; Dynamic Data Exchange; Registry Run Keys / Startup Folder; Non-Standard Port; File Deletion; Automated Collection; Security Software Discovery; Clipboard Data; File and Directory Discovery; Screen Capture; Remote Access Software; Symmetric Cryptography; Scheduled Task; Modify Registry; Malicious File; System Owner/User Discovery; Windows Command Shell; Keylogging; Dead Drop Resolver; Ingress Tool Transfer; Clear Persistence; Install Root Certificate; Code Signing; Web Protocols; Peripheral Device Discovery; Dynamic Resolution; Masquerade Task or Service; Virtualization/Sandbox Evasion; Rundll32; Obfuscated Files or Information; Spearphishing Attachment; Software Discovery; Native API; System Time Discovery; Masquerading; System Information Discovery; Process Discovery"
AI_software_1: "RTM"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S0148"
AI_software_description_1: "RTM https://attack.mitre.org/software/S0148 is custom malware written in Delphi. It is used by the group of the same name RTM https://attack.mitre.org/groups/G0048. Newer versions of the malware have been reported publicly as Redaman.Citation ESET RTM Feb 2017Citation Unit42 Redaman January 2019"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0110"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "At"
AI_software_2: "AT"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0110"
AI_software_description_2: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0039"
AI_technique_ID_3: "T1136.001; T1069.002; T1087.002; T1021.002; T1124; T1087.001; T1070.005; T1018; T1007; T1049; T1136.002; T1201; T1569.002; T1135; T1069.001"
AI_technique_3: "Service Execution; Domain Account; Remote System Discovery; Network Share Connection Removal; Local Groups; System Service Discovery; Password Policy Discovery; Local Account; System Time Discovery; Domain Groups; Network Share Discovery; System Network Connections Discovery; SMB/Windows Admin Shares"
AI_software_3: "NET"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0039"
AI_software_description_3: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_3: "enterprise-attack"
AI_software_ID_4: "S0183"
AI_technique_ID_4: "T1090.003; T1573.002"
AI_technique_4: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_4: "TOR"
AI_software_type_4: "tool"
AI_software_url_4: "https://attack.mitre.org/software/S0183"
AI_software_description_4: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_4: "enterprise-attack"


AI_group_ID_1: "G0048"
AI_group_1: "RTM"
AI_technique_ID_1: "T1102.001; T1219; T1547.001; T1574.001; T1204.002; T1566.001; T1189"
AI_technique_1: "Registry Run Keys / Startup Folder; Remote Access Software; DLL Search Order Hijacking; Dead Drop Resolver; Spearphishing Attachment; Malicious File; Drive-by Compromise"
AI_group_aliases_1: "['RTM']"
AI_group_url_1: "https://attack.mitre.org/groups/G0048"
AI_group_description_1: "RTM https://attack.mitre.org/groups/G0048 is a cybercriminal group that has been active since at least 2015 and is primarily interested in users of remote banking systems in Russia and neighboring countries. The group uses a Trojan by the same name RTM https://attack.mitre.org/software/S0148. Citation ESET RTM Feb 2017"
AI_matrix_domains_1: "enterprise-attack"

---

**title**
INTERPOL Recovers $41 Million in Largest Ever BEC Scam in Singapore

**date**
06/08/2024

**url_news**
https://thehackernews.com/2024/08/interpol-recovers-41-million-in-largest.html

**thn_category_and_subcategory**
'Email Security / Financial Fraud'

**links**
'https://www.microsoft.com/en-us/security/business/security-101/what-is-business-email-compromise-bec', 'https://www.interpol.int/News-and-Events/News/2024/Police-recover-over-USD-40-million-from-international-email-scam', 'https://thehackernews.com/2024/07/global-police-operation-shuts-down-600.html', 'https://www.interpol.int/Crimes/Financial-crime', 'https://www.trmlabs.com/post/us-and-german-authorities-seize-crypto-wallet-cryptonator-and-charge-administrator', 'https://thehackernews.com/2023/12/beware-scam-as-service-aiding.html', 'https://www.kaspersky.com/resource-center/definitions/cryptocurrency-scams', 'https://consumer.ftc.gov/articles/what-know-about-cryptocurrency-and-scams', 'https://securityintelligence.com/articles/crypto-fraud-in-2023-how-can-security-teams-fight/', 'https://research.checkpoint.com/2024/unveiling-the-scam-how-fraudsters-abuse-legitimate-blockchain-protocols-to-steal-your-cryptocurrency-wallet/'

**body**
'INTERPOL said it devised a "global stop-payment mechanism" that helped facilitate the largest-ever recovery of funds defrauded in a business email compromise (BEC) scam. ', 'The development comes after an unnamed commodity firm based in Singapore fell victim to a BEC scam in mid-July 2024. It refers to a type of cybercrime where a malicious actor poses as a trusted figure and uses email to trick targets into sending money or divulging confidential company information.', "Such attacks can take place in myriad ways, including gaining unauthorized access to a finance employee or a law firm's email account to send fake invoices or impersonating a third-party vendor to email a phony bill.", '"On 15 July, the firm had received an email from a supplier requesting that a pending payment be sent to a new bank account based in Timor-Leste," INTERPOL said in a press statement. "The email, however, came from a fraudulent account spelled slightly different to the supplier\'s official email address."', 'The Singaporean company is said to have transferred $42.3 million to the non-existent supplier on July 19, only for it to realize the blunder on July 23 after the actual supplier said it had not been compensated.', "However, by taking advantage of INTERPOL's Global Rapid Intervention of Payments (I-GRIP) mechanism, authorities in Singapore managed to detect $39 million and froze the counterfeit bank account a day later.", 'Separately, seven suspects have been arrested in the Southeast Asian nation in connection with the scam, leading to the further recovery of $2 million.', 'Back in June, I-GRIP was used to trace and intercept the illicit proceeds stemming from fiat and cryptocurrency crime, successfully recovering millions and intercepting hundreds of thousands of BEC accounts as part of a global police operation named First Light.', '"Since its launch in 2022, INTERPOL\'s I-GRIP mechanism has helped law enforcement intercept hundreds of millions of dollars in illicit funds," the agency said.', '"INTERPOL is encouraging businesses and individuals to take preventative steps to avoid falling victim to business email compromise and other social engineering scams."', 'The disclosure follows the law enforcement seizure of an online digital wallet and cryptocurrency exchange known as Cryptonator for allegedly receiving criminal proceeds of computer intrusions and hacking incidents, ransomware scams, various fraud markets, and identity theft schemes.', 'Cryptonator, launched in December 2013 by Roman Boss, has also been accused of failing to institute appropriate anti-money laundering controls in place. The U.S. Justice Department indicted Boss for founding and operating the service.', 'Blockchain intelligence firm TRM Labs said the platform facilitated more than 4 million transactions worth a total of $1.4 billion, with Boss taking a small cut from each transaction. This comprised money exchanged with darknet markets, scam wallet addresses, high-risk exchanges, ransomware groups, crypto theft operations, mixers, and sanctioned addresses.', 'Specifically, cryptocurrency addresses controlled by Cryptonator transacted with darknet markets, virtual exchanges, and criminal marketplaces like Bitzlato, Blender, Finiko, Garantex, Hydra, Nobitex, and an unnamed terrorist entity.', '"Hackers, darknet market operators, ransomware groups, sanctions evaders and others threat actors gravitated to the platform to exchange cryptocurrencies as well as cash out crypto into fiat currency," TRM Labs noted.', "The popularity of cryptocurrency has created plenty of opportunities for fraud, with threat actors constantly devising new ways to drain victims' wallets over the years.", 'Indeed, a recent report from Check Point found that fraudsters are abusing legitimate blockchain protocols like Uniswap and Safe.global to conceal their malicious activities and siphon funds from cryptocurrency wallets.', '"Attackers leverage the Uniswap Multicall contract to orchestrate fund transfers from victims\' wallets to their own," researchers said. "Attackers have been known to use the Gnosis Safe contracts and framework, coaxing unsuspecting victims into signing off on fraudulent transactions."', 'Watch as experts simulate real-world threats to demonstrate compelling advantages.', 'Get actionable steps and tools to harness the full potential of GenAI while protecting your sensitive data.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

