---
CP Source: The Hacker News
CP Execution date:  2024-08-08
Headline: "New Zero-Day Flaw in Apache OFBiz ERP Allows Remote Code Execution"
Date: 2024-08-06
Category: "Enterprise Security"
Sub-Category: "Vulnerability"

AI_technique_ID_1: "T1583.004"
AI_technique_1: "SERVER"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1583/004"
AI_technique_description_1: "Adversaries may buy, lease, rent, or obtain physical servers that can be used during targeting. Use of servers allows an adversary to stage, launch, and execute an operation. During postcompromise activity, adversaries may utilize servers for various tasks, such as watering hole operations in Driveby Compromise https://attack.mitre.org/techniques/T1189, enabling Phishing https://attack.mitre.org/techniques/T1566 operations, or facilitating Command and Control https://attack.mitre.org/tactics/TA0011. Instead of compromising a thirdparty Server https://attack.mitre.org/techniques/T1584/004 or renting a Virtual Private Server https://attack.mitre.org/techniques/T1583/003, adversaries may opt to configure and run their own servers in support of operations. Free trial periods of cloud servers may also be abused.Citation Free Trial PurpleUrchinCitation Freejacked Adversaries may only need a lightweight setup if most of their activities will take place using online infrastructure. Or, they may need to build extensive infrastructure if they want to test, communicate, and control other aspects of their activities on their own systems.Citation NYTStuxnet"
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1584.004"
AI_technique_2: "SERVER"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1584/004"
AI_technique_description_2: "Adversaries may compromise thirdparty servers that can be used during targeting. Use of servers allows an adversary to stage, launch, and execute an operation. During postcompromise activity, adversaries may utilize servers for various tasks, including for Command and Control.Citation TrendMicro EarthLusca 2022 Instead of purchasing a Server https://attack.mitre.org/techniques/T1583/004 or Virtual Private Server https://attack.mitre.org/techniques/T1583/003, adversaries may compromise thirdparty servers in support of operations. Adversaries may also compromise web servers to support watering hole operations, as in Driveby Compromise https://attack.mitre.org/techniques/T1189, or email servers to support Phishing https://attack.mitre.org/techniques/T1566 operations."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1053.002"
AI_technique_3: "AT"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_3: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"
AI_technique_ID_4: "T1592.002"
AI_technique_4: "SOFTWARE"
AI_technique_url_4: "https://attack.mitre.org/techniques/T1592/002"
AI_technique_description_4: "Adversaries may gather information about the victims host software that can be used during targeting. Information about installed software may include a variety of details such as types and versions on specific hosts, as well as the presence of additional components that might be indicative of added defensive protections ex antivirus, SIEMs, etc.. Adversaries may gather this information in various ways, such as direct collection actions via Active Scanning https://attack.mitre.org/techniques/T1595 ex listening ports, server banners, user agent strings or Phishing for Information https://attack.mitre.org/techniques/T1598. Adversaries may also compromise sites then include malicious content designed to collect host information from visitors.Citation ATT ScanBox Information about the installed software may also be exposed to adversaries via online or other accessible data sets ex job postings, network maps, assessment reports, resumes, or purchase invoices. Gathering this information may reveal opportunities for other forms of reconnaissance ex Search Open WebsitesDomains https://attack.mitre.org/techniques/T1593 or Search Open Technical Databases https://attack.mitre.org/techniques/T1596, establishing operational resources ex Develop Capabilities https://attack.mitre.org/techniques/T1587 or Obtain Capabilities https://attack.mitre.org/techniques/T1588, andor for initial access ex Supply Chain Compromise https://attack.mitre.org/techniques/T1195 or External Remote Services https://attack.mitre.org/techniques/T1133."
AI_technique_deprecated_4: "False"
AI_technique_revoked_4: "False"
AI_matrix_domains_4: "enterprise-attack"
AI_technique_ID_5: "T1588.002"
AI_technique_5: "TOOL"
AI_technique_url_5: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_5: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_5: "False"
AI_technique_revoked_5: "False"
AI_matrix_domains_5: "enterprise-attack"
AI_technique_ID_6: "T1583.005"
AI_technique_6: "BOTNET"
AI_technique_url_6: "https://attack.mitre.org/techniques/T1583/005"
AI_technique_description_6: "Adversaries may buy, lease, or rent a network of compromised systems that can be used during targeting. A botnet is a network of compromised systems that can be instructed to perform coordinated tasks.Citation Norton Botnet Adversaries may purchase a subscription to use an existing botnet from a booterstresser service. With a botnet at their disposal, adversaries may perform followon activity such as largescale Phishing https://attack.mitre.org/techniques/T1566 or Distributed Denial of Service DDoS.Citation Imperva DDoS for HireCitation KrebsAnnaCitation KrebsBazaarCitation KrebsBooter"
AI_technique_deprecated_6: "False"
AI_technique_revoked_6: "False"
AI_matrix_domains_6: "enterprise-attack"
AI_technique_ID_7: "T1584.005"
AI_technique_7: "BOTNET"
AI_technique_url_7: "https://attack.mitre.org/techniques/T1584/005"
AI_technique_description_7: "Adversaries may compromise numerous thirdparty systems to form a botnet that can be used during targeting. A botnet is a network of compromised systems that can be instructed to perform coordinated tasks.Citation Norton Botnet Instead of purchasingrenting a botnet from a booterstresser service, adversaries may build their own botnet by compromising numerous thirdparty systems.Citation Imperva DDoS for Hire Adversaries may also conduct a takeover of an existing botnet, such as redirecting bots to adversarycontrolled C2 servers.Citation Dell Dridex Oct 2015 With a botnet at their disposal, adversaries may perform followon activity such as largescale Phishing https://attack.mitre.org/techniques/T1566 or Distributed Denial of Service DDoS."
AI_technique_deprecated_7: "False"
AI_technique_revoked_7: "False"
AI_matrix_domains_7: "enterprise-attack"


AI_tactic_ID_1: "TA0002"
AI_technique_ID_1: "T1204.003; T1609; T1059.006; T1053.002; T1053.006; T1059.003; T1059; T1204.002; T1059.002; T1053.007; T1129; T1106; T1559.001; T1072; T1053; T1059.010; T1059.005; T1204; T1559; T1559.002; T1203; T1559.003; T1610; T1569; T1059.009; T1053.003; T1569.002; T1204.001; T1047; T1648; T1059.004; T1059.007; T1059.001; T1053.005; T1059.008; T1651; T1569.001"
AI_technique_1: "Unix Shell; Malicious Image; Visual Basic; Cloud Administration Command; XPC Services; Windows Management Instrumentation; Scheduled Task; At; Malicious File; Inter-Process Communication; Launchctl; Network Device CLI; AutoHotKey & AutoIT; Python; System Services; Shared Modules; Systemd Timers; Component Object Model; Windows Command Shell; AppleScript; User Execution; JavaScript; Container Administration Command; Malicious Link; Software Deployment Tools; PowerShell; Service Execution; Deploy Container; Scheduled Task/Job; Serverless Execution; Cron; Native API; Cloud API; Command and Scripting Interpreter; Exploitation for Client Execution; Container Orchestration Job; Dynamic Data Exchange"
AI_tactic_1: "EXECUTION"
AI_tactic_url_1: "https://attack.mitre.org/tactics/TA0002"
AI_tactic_description_1: "The adversary is trying to run malicious code. Execution consists of techniques that result in adversarycontrolled code running on a local or remote system. Techniques that run malicious code are often paired with techniques from all other tactics to achieve broader goals, like exploring a network or stealing data. For example, an adversary might use a remote access tool to run a PowerShell script that does Remote System Discovery."
AI_matrix_domains_1: "enterprise-attack"


AI_data_source_ID_1: "DS0030"
AI_technique_ID_1: "T1578; T1204.003; T1204; T1578.003; T1580; T1535; T1578.002; T1578.004; T1485"
AI_technique_1: "Unused/Unsupported Cloud Regions; Data Destruction; Cloud Infrastructure Discovery; Delete Cloud Instance; Revert Cloud Instance; Malicious Image; User Execution; Modify Cloud Compute Infrastructure; Create Cloud Instance"
AI_data_source_1: "INSTANCE"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0030"
AI_data_source_description_1: "A virtual server environment which runs workloads, hosted onpremise or by thirdparty cloud providersCitation Amazon VMCitation Google VM"
AI_matrix_domains_1: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1595.001; T1583.008; T1587; T1598.003; T1588.001; T1584.006; T1584.003; T1588; T1585; T1594; T1583.001; T1608.001; T1587.001; T1587.003; T1608.005; T1583.003; T1583.006; T1588.003; T1598; T1584.001; T1598.004; T1588.002; T1608; T1587.002; T1608.006; T1584.002; T1592.002; T1584.008; T1595.002; T1589.002; T1608.003; T1584; T1598.002; T1586.001; T1608.004; T1589; T1583.004; T1595; T1598.001; T1592; T1583.007; T1586; T1592.001; T1588.004; T1585.001; T1592.004; T1584.004; T1608.002; T1583; T1595.003; T1584.007"
AI_technique_1: "DNS Server; Server; Compromise Infrastructure; Serverless; Client Configurations; Vulnerability Scanning; Install Digital Certificate; Link Target; Acquire Infrastructure; Hardware; Obtain Capabilities; SEO Poisoning; Code Signing Certificates; Digital Certificates; Active Scanning; Virtual Private Server; Spearphishing Service; Stage Capabilities; Search Victim-Owned Websites; Web Services; Gather Victim Identity Information; Email Addresses; Wordlist Scanning; Spearphishing Voice; Malvertising; Tool; Upload Malware; Social Media Accounts; Develop Capabilities; Establish Accounts; Drive-by Target; Gather Victim Host Information; Scanning IP Blocks; Phishing for Information; Compromise Accounts; Upload Tool; Malware; Domains; Spearphishing Attachment; Network Devices; Spearphishing Link; Software"


AI_software_ID_1: "S0183"
AI_technique_ID_1: "T1090.003; T1573.002"
AI_technique_1: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_1: "TOR"
AI_software_type_1: "tool"
AI_software_url_1: "https://attack.mitre.org/software/S0183"
AI_software_description_1: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S1088"
AI_technique_ID_2: "T1659; T1105; T1071.002; T1053.005; T1204.002"
AI_technique_2: "File Transfer Protocols; Scheduled Task; Content Injection; Ingress Tool Transfer; Malicious File"
AI_software_2: "DISCO"
AI_software_type_2: "malware"
AI_software_url_2: "https://attack.mitre.org/software/S1088"
AI_software_description_2: "Disco https://attack.mitre.org/software/S1088 is a custom implant that has been used by MoustachedBouncer https://attack.mitre.org/groups/G1019 since at least 2020 including in campaigns using targeted malicious content injection for initial access and command and control.Citation MoustachedBouncer ESET August 2023"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0110"
AI_technique_ID_3: "T1053.002"
AI_technique_3: "At"
AI_software_3: "AT"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0110"
AI_software_description_3: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_3: "enterprise-attack"
AI_software_ID_4: "S0039"
AI_technique_ID_4: "T1136.001; T1069.002; T1087.002; T1021.002; T1124; T1087.001; T1070.005; T1018; T1007; T1049; T1136.002; T1201; T1569.002; T1135; T1069.001"
AI_technique_4: "Service Execution; Domain Account; Remote System Discovery; Network Share Connection Removal; Local Groups; System Service Discovery; Password Policy Discovery; Local Account; System Time Discovery; Domain Groups; Network Share Discovery; System Network Connections Discovery; SMB/Windows Admin Shares"
AI_software_4: "NET"
AI_software_type_4: "tool"
AI_software_url_4: "https://attack.mitre.org/software/S0039"
AI_software_description_4: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_4: "enterprise-attack"

---

**title**
New Zero-Day Flaw in Apache OFBiz ERP Allows Remote Code Execution

**date**
06/08/2024

**url_news**
https://thehackernews.com/2024/08/new-zero-day-flaw-in-apache-ofbiz-erp.html

**thn_category_and_subcategory**
'Enterprise Security / Vulnerability'

**links**
'https://nvd.nist.gov/vuln/detail/CVE-2024-38856', 'https://nvd.nist.gov/vuln/detail/CVE-2024-36104', 'https://blog.sonicwall.com/en-us/2024/08/sonicwall-discovers-second-critical-apache-ofbiz-zero-day-vulnerability/', 'https://nvd.nist.gov/vuln/detail/CVE-2024-32113', 'https://thehackernews.com/2024/08/mirai-botnet-targeting-ofbiz-servers.html', 'https://thehackernews.com/2023/12/critical-zero-day-in-apache-ofbiz-erp.html'

**body**
'A new zero-day pre-authentication remote code execution vulnerability has been disclosed in the Apache OFBiz open-source enterprise resource planning (ERP) system that could allow threat actors to achieve remote code execution on affected instances.', 'Tracked as CVE-2024-38856, the flaw has a CVSS score of 9.8 out of a maximum of 10.0. It affects Apache OFBiz versions prior to 18.12.15.', '"The root cause of the vulnerability lies in a flaw in the authentication mechanism," SonicWall, which discovered and reported the shortcoming, said in a statement.', '"This flaw allows an unauthenticated user to access functionalities that generally require the user to be logged in, paving the way for remote code execution."', 'CVE-2024-38856 is also a patch bypass for CVE-2024-36104, a path traversal vulnerability that was addressed in early June with the release of 18.12.14.', 'SonicWall described the flaw as residing in the override view functionality that exposes critical endpoints to unauthenticated threat actors, who could leverage it to achieve remote code execution via specially crafted requests.', '"Unauthenticated access was allowed to the ProgramExport endpoint by chaining it with any other endpoints that do not require authentication by abusing the override view functionality," security researcher Hasib Vhora said.', 'The development comes as another critical path traversal vulnerability in OFBiz that could result in remote code execution (CVE-2024-32113) has since come under active exploitation to deploy the Mirai botnet. It was patched in May 2024.', 'In December 2023, SonicWall also disclosed a then-zero-day flaw in the same software (CVE-2023-51467) that made it possible to bypass authentication protections. It was subsequently subjected to a large number of exploitation attempts.', 'Watch as experts simulate real-world threats to demonstrate compelling advantages.', 'Get actionable steps and tools to harness the full potential of GenAI while protecting your sensitive data.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

