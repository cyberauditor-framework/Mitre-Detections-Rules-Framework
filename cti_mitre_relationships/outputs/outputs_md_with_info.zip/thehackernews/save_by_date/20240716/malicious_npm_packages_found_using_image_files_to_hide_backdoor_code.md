---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Malicious npm Packages Found Using Image Files to Hide Backdoor Code"
Date: 2024-07-16
Category: "Open Source"
Sub-Category: "Software Supply Chain"

ADD_INFORMATION_technique_ID: "T1587.001"
ADD_INFORMATION_technique: "MALWARE"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1587/001"
ADD_INFORMATION_technique_description: "Adversaries may develop malware and malware components that can be used during targeting. Building malicious software can include the development of payloads, droppers, post-compromise tools, backdoors (including backdoored images), packers, C2 protocols, and the creation of infected removable media. Adversaries may develop malware to support their operations, creating a means for maintaining control of remote machines, evading defenses, and executing post-compromise behaviors.(Citation: Mandiant APT1)(Citation: Kaspersky Sofacy)(Citation: ActiveMalwareEnergy)(Citation: FBI Flash FIN7 USB)

As with legitimate development efforts, different skill sets may be required for developing malware. The skills needed may be located in-house, or may need to be contracted out. Use of a contractor may be considered an extension of that adversarys malware development capabilities, provided the adversary plays a role in shaping requirements and maintains a degree of exclusivity to the malware.

Some aspects of malware development, such as C2 protocol development, may require adversaries to obtain additional infrastructure. For example, malware developed that will communicate with Twitter for C2, may require use of Web Services(https://attack.mitre.org/techniques/T1583/006).(Citation: FireEye APT29)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0011"
ADD_INFORMATION_technique_ID: "T1205, T1001.003, T1001.001, T1132.002, T1071.003, T1571, T1008, T1572, T1102.001, T1568.002, T1092, T1071.002, T1071.001, T1090, T1665, T1205.001, T1568.003, T1001.002, T1659, T1095, T1102, T1205.002, T1001, T1573, T1104, T1132, T1219, T1090.003, T1105, T1132.001, T1090.002, T1568.001, T1573.002, T1090.001, T1568, T1071, T1090.004, T1071.004, T1102.002, T1573.001, T1102.003"
ADD_INFORMATION_technique: "Non-Application Layer Protocol, Proxy, Fast Flux DNS, Application Layer Protocol, Mail Protocols, Remote Access Software, Domain Fronting, Internal Proxy, Junk Data, Data Obfuscation, Protocol Impersonation, Symmetric Cryptography, One-Way Communication, Non-Standard Port, Hide Infrastructure, Encrypted Channel, Data Encoding, Dynamic Resolution, Traffic Signaling, Standard Encoding, External Proxy, Port Knocking, DNS Calculation, Multi-Stage Channels, Multi-hop Proxy, Asymmetric Cryptography, Content Injection, Socket Filters, File Transfer Protocols, Non-Standard Encoding, Web Service, Fallback Channels, Communication Through Removable Media, Dead Drop Resolver, Bidirectional Communication, Domain Generation Algorithms, DNS, Web Protocols, Ingress Tool Transfer, Steganography, Protocol Tunneling"
ADD_INFORMATION_tactic: "COMMAND AND CONTROL"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0011"
ADD_INFORMATION_tactic_description: "The adversary is trying to communicate with compromised systems to control them.Command and Control consists of techniques that adversaries may use to communicate with systems under their control within a victim network. Adversaries commonly attempt to mimic normal, expected traffic to avoid detection. There are many ways an adversary can establish command and control with various levels of stealth depending on the victim’s network structure and defenses."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1586, T1586.001, T1585.001, T1585"
ADD_INFORMATION_technique: "Establish Accounts, Social Media Accounts, Compromise Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Malicious npm Packages Found Using Image Files to Hide Backdoor Code

**date**
16/07/2024

**url_news**
https://thehackernews.com/2024/07/malicious-npm-packages-found-using.html

**thn_category_and_subcategory**
'Open Source / Software Supply Chain'

**links**
'https://npm-stat.com/charts.html?package=img-aws-s3-object-multipart-copy', 'https://npm-stat.com/charts.html?package=legacyaws-s3-object-multipart-copy', 'https://blog.phylum.io/fake-aws-packages-ship-command-and-control-malware-in-jpeg-files/', 'https://github.com/little-core-labs/aws-s3-object-multipart-copy'

**body**
'Cybersecurity researchers have identified two malicious packages on the npm package registry that concealed backdoor code to execute malicious commands sent from a remote server.', 'The packages in question – img-aws-s3-object-multipart-copy and legacyaws-s3-object-multipart-copy – have been downloaded 190 and 48 times each. As of writing, they have been taken down by the npm security team.', '"They contained sophisticated command and control functionality hidden in image files that would be executed during package installation," software supply chain security firm Phylum said in an analysis.', 'The packages are designed to impersonate a legitimate npm library called aws-s3-object-multipart-copy, but come with an altered version of the "index.js" file to execute a JavaScript file ("loadformat.js").', "For its part, the JavaScript file is designed to process three images -- that feature the corporate logos for Intel, Microsoft, and AMD -- with the image corresponding to Microsoft's logo used to extract and execute the malicious content.", 'The code works by registering the new client with a command-and-control (C2) server by sending the hostname and operating system details. It then attempts to execute attacker-issued commands periodically every five seconds.', "In the final stage, the output of the commands' execution is exfiltrated back to the attacker via a specific endpoint.", '"In the last few years, we\'ve seen a dramatic rise in the sophistication and volume of malicious packages published to open source ecosystems," Phylum said.', '"Make no mistake, these attacks are successful. It is absolutely imperative that developers and security organizations alike are keenly aware of this fact and are deeply vigilant with regard to open source libraries they consume."', 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

