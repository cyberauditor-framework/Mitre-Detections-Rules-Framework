---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Kaspersky Exits U.S. Market Following Commerce Department Ban"
Date: 2024-07-16
Category: "National Security"
Sub-Category: "Data Security"

ADD_INFORMATION_technique_ID: "T1592.002"
ADD_INFORMATION_technique: "SOFTWARE"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1592/002"
ADD_INFORMATION_technique_description: "Adversaries may gather information about the victims host software that can be used during targeting. Information about installed software may include a variety of details such as types and versions on specific hosts, as well as the presence of additional components that might be indicative of added defensive protections (ex: antivirus, SIEMs, etc.).

Adversaries may gather this information in various ways, such as direct collection actions via Active Scanning(https://attack.mitre.org/techniques/T1595) (ex: listening ports, server banners, user agent strings) or Phishing for Information(https://attack.mitre.org/techniques/T1598). Adversaries may also compromise sites then include malicious content designed to collect host information from visitors.(Citation: ATT ScanBox) Information about the installed software may also be exposed to adversaries via online or other accessible data sets (ex: job postings, network maps, assessment reports, resumes, or purchase invoices). Gathering this information may reveal opportunities for other forms of reconnaissance (ex: Search Open Websites/Domains(https://attack.mitre.org/techniques/T1593) or Search Open Technical Databases(https://attack.mitre.org/techniques/T1596)), establishing operational resources (ex: Develop Capabilities(https://attack.mitre.org/techniques/T1587) or Obtain Capabilities(https://attack.mitre.org/techniques/T1588)), and/or for initial access (ex: Supply Chain Compromise(https://attack.mitre.org/techniques/T1195) or External Remote Services(https://attack.mitre.org/techniques/T1133))."
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1657, T1499, T1565, T1499.003, T1491.002, T1565.001, T1565.002, T1495, T1499.001, T1491, T1498.001, T1561.002, T1565.003, T1561.001, T1498, T1499.002, T1529, T1486, T1531, T1489, T1498.002, T1561, T1499.004, T1490, T1491.001, T1485, T1496"
ADD_INFORMATION_technique: "Account Access Removal, Direct Network Flood, Runtime Data Manipulation, OS Exhaustion Flood, Application or System Exploitation, External Defacement, Disk Wipe, Data Destruction, Financial Theft, Internal Defacement, Transmitted Data Manipulation, Disk Content Wipe, Application Exhaustion Flood, Stored Data Manipulation, Inhibit System Recovery, Disk Structure Wipe, Defacement, Resource Hijacking, Data Encrypted for Impact, Service Exhaustion Flood, Service Stop, Reflection Amplification, System Shutdown/Reboot, Data Manipulation, Firmware Corruption, Endpoint Denial of Service, Network Denial of Service"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0019"
ADD_INFORMATION_technique_ID: "T1564.006, T1543.001, T1036, T1197, T1543.002, T1569.002, T1557.001, T1021.006, T1543.004, T1574.010, T1543.003, T1036.004, T1557, T1574.005, T1562.001, T1562, T1574.011, T1569, T1564, T1574, T1489, T1490, T1543, T1569.001"
ADD_INFORMATION_technique: "Masquerading, LLMNR/NBT-NS Poisoning and SMB Relay, Masquerade Task or Service, System Services, Adversary-in-the-Middle, Impair Defenses, Inhibit System Recovery, Run Virtual Instance, Launch Daemon, Service Execution, Launchctl, Services File Permissions Weakness, Launch Agent, Disable or Modify Tools, Windows Remote Management, Hide Artifacts, Service Stop, Windows Service, Create or Modify System Process, Systemd Service, Services Registry Permissions Weakness, Executable Installer File Permissions Weakness, Hijack Execution Flow, BITS Jobs"
ADD_INFORMATION_data_source: "SERVICE"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0019"
ADD_INFORMATION_data_source_description: "A computer process that is configured to execute continuously in the background and perform system tasks, in some cases before any user has logged in(Citation: Microsoft Services)(Citation: Linux Services Run Levels)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1588.001, T1585, T1594, T1595.001, T1608.001, T1584.007, T1588, T1608.004, T1588.002, T1589, T1598.003, T1587.003, T1584.002, T1584, T1595.003, T1592, T1608.002, T1595, T1587.002, T1583.003, T1598.001, T1598.004, T1583.006, T1583.008, T1588.004, T1584.004, T1584.006, T1608.003, T1584.003, T1584.008, T1587.001, T1598, T1583.004, T1592.001, T1583.007, T1595.002, T1608, T1583, T1586.001, T1598.002, T1608.005, T1592.004, T1583.001, T1585.001, T1589.002, T1608.006, T1584.001, T1588.003, T1586, T1592.002, T1587"
ADD_INFORMATION_technique: "Digital Certificates, Drive-by Target, Compromise Accounts, Establish Accounts, Web Services, Tool, Spearphishing Voice, Obtain Capabilities, Stage Capabilities, Spearphishing Link, Serverless, Code Signing Certificates, Phishing for Information, Virtual Private Server, SEO Poisoning, Hardware, Server, Software, Install Digital Certificate, Upload Tool, Compromise Infrastructure, Search Victim-Owned Websites, Social Media Accounts, Gather Victim Identity Information, DNS Server, Malware, Domains, Gather Victim Host Information, Develop Capabilities, Link Target, Malvertising, Scanning IP Blocks, Acquire Infrastructure, Network Devices, Client Configurations, Active Scanning, Vulnerability Scanning, Email Addresses, Wordlist Scanning, Spearphishing Service, Upload Malware, Spearphishing Attachment"

ADD_INFORMATION_software_ID: "S0575"
ADD_INFORMATION_technique_ID: "T1106, T1018, T1135, T1489, T1140, T1059.003, T1049, T1027, T1021.002, T1083, T1490, T1057, T1055.001, T1016, T1486, T1080"
ADD_INFORMATION_technique: "Obfuscated Files or Information, System Network Connections Discovery, Process Discovery, Windows Command Shell, Native API, Service Stop, Remote System Discovery, Taint Shared Content, System Network Configuration Discovery, Network Share Discovery, SMB/Windows Admin Shares, File and Directory Discovery, Deobfuscate/Decode Files or Information, Inhibit System Recovery, Dynamic-link Library Injection, Data Encrypted for Impact"
ADD_INFORMATION_software: "CONTI"
ADD_INFORMATION_software_type: "malware"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0575"
ADD_INFORMATION_software_description: "Conti(https://attack.mitre.org/software/S0575) is a Ransomware-as-a-Service (RaaS) that was first observed in December 2019. Conti(https://attack.mitre.org/software/S0575) has been deployed via TrickBot(https://attack.mitre.org/software/S0266) and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti(https://attack.mitre.org/software/S0575) steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.(Citation: Cybereason Conti Jan 2021)(Citation: CarbonBlack Conti July 2020)(Citation: Cybleinc Conti January 2020)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_group_ID: "G0048"
ADD_INFORMATION_group: "RTM"
ADD_INFORMATION_technique_ID: "T1547.001, T1102.001, T1566.001, T1219, T1189, T1204.002, T1574.001"
ADD_INFORMATION_technique: "Dead Drop Resolver, Remote Access Software, Registry Run Keys / Startup Folder, Drive-by Compromise, DLL Search Order Hijacking, Malicious File, Spearphishing Attachment"
ADD_INFORMATION_group_aliases: "RTM"
ADD_INFORMATION_group_url: "https://attack.mitre.org/groups/G0048"
ADD_INFORMATION_group_description: "RTM(https://attack.mitre.org/groups/G0048) is a cybercriminal group that has been active since at least 2015 and is primarily interested in users of remote banking systems in Russia and neighboring countries. The group uses a Trojan by the same name (RTM(https://attack.mitre.org/software/S0148)). (Citation: ESET RTM Feb 2017)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Kaspersky Exits U.S. Market Following Commerce Department Ban

**date**
16/07/2024

**url_news**
https://thehackernews.com/2024/07/kaspersky-exits-us-market-following.html

**thn_category_and_subcategory**
'National Security / Data Security'

**links**
'https://www.zetter-zeroday.com/kaspersky-lab-closing-u-s-division-laying-off-workers-2/', 'https://thehackernews.com/2024/06/us-bans-kaspersky-software-citing.html'

**body**
"Russian security vendor Kaspersky has said it's exiting the U.S. market nearly a month after the Commerce Department announced a ban on the sale of its software in the country citing a national security risk.", 'News of the closure was first reported by journalist Kim Zetter.', "The company is expected to wind down its U.S. operations on July 20, 2024, the same day the ban comes into effect. It's also expected to lay off less than 50 employees in the U.S.", '"The company has carefully examined and evaluated the impact of the U.S. legal requirements and made this sad and difficult decision as business opportunities in the country are no longer viable," the company said in a statement.', 'In late June 2024, the Commerce Department said it was enforcing a ban after what it said was an "extremely thorough investigation." The company was also added to the Entity List, preventing U.S. enterprises from conducting business with it.', "It's currently not known what was uncovered as a result of the probe, but the agency said the company's continued operations in the U.S. could serve as a conduit for the Kremlin's offensive cyber capabilities.", '"The manipulation of Kaspersky software, including in U.S. critical infrastructure, can cause significant risks of data theft, espionage, and system malfunction," the Bureau of Industry and Security (BIS) noted. "It can also risk the country\'s economic security and public health, resulting in injuries or loss of life."', 'Existing U.S. customers have been urged to find alternative tech solutions ahead of September 29, by which the company is expected to stop providing software and antivirus signature updates.', 'Kaspersky has refuted the allegations, stating it does not engage in activities that could threaten U.S. national security and that the decision was made based on the "present geopolitical climate and theoretical concerns," rather than a comprehensive evaluation of its products and services.', 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

