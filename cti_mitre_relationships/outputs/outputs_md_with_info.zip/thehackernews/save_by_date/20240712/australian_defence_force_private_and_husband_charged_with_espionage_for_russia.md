---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Australian Defence Force Private and Husband Charged with Espionage for Russia"
Date: 2024-07-12
Category: "Cyber Crime"
Sub-Category: "Online Safety"

ADD_INFORMATION_technique_ID: "T1589.001"
ADD_INFORMATION_technique: "CREDENTIALS"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1589/001"
ADD_INFORMATION_technique_description: "Adversaries may gather credentials that can be used during targeting. Account credentials gathered by adversaries may be those directly associated with the target victim organization or attempt to take advantage of the tendency for users to use the same passwords across personal and business accounts.

Adversaries may gather credentials from potential victims in various ways, such as direct elicitation via Phishing for Information(https://attack.mitre.org/techniques/T1598). Adversaries may also compromise sites then add malicious content designed to collect website authentication cookies from visitors.(Citation: ATT ScanBox) Credential information may also be exposed to adversaries via leaks to online or other accessible data sets (ex: Search Engines(https://attack.mitre.org/techniques/T1593/002), breach dumps, code repositories, etc.).(Citation: Register Deloitte)(Citation: Register Uber)(Citation: Detectify Slack Tokens)(Citation: Forbes GitHub Creds)(Citation: GitHub truffleHog)(Citation: GitHub Gitrob)(Citation: CNET Leaks) Adversaries may also purchase credentials from dark web or other black-markets. Finally, where multi-factor authentication (MFA) based on out-of-band communications is in use, adversaries may compromise a service provider to gain access to MFA codes and one-time passwords (OTP).(Citation: Okta Scatter Swine 2022)

Gathering this information may reveal opportunities for other forms of reconnaissance (ex: Search Open Websites/Domains(https://attack.mitre.org/techniques/T1593) or Phishing for Information(https://attack.mitre.org/techniques/T1598)), establishing operational resources (ex: Compromise Accounts(https://attack.mitre.org/techniques/T1586)), and/or initial access (ex: External Remote Services(https://attack.mitre.org/techniques/T1133) or Valid Accounts(https://attack.mitre.org/techniques/T1078)). "
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1657, T1499, T1565, T1499.003, T1491.002, T1565.001, T1565.002, T1495, T1499.001, T1491, T1498.001, T1561.002, T1565.003, T1561.001, T1498, T1499.002, T1529, T1486, T1531, T1489, T1498.002, T1561, T1499.004, T1490, T1491.001, T1485, T1496"
ADD_INFORMATION_technique: "Account Access Removal, Direct Network Flood, Runtime Data Manipulation, OS Exhaustion Flood, Application or System Exploitation, External Defacement, Disk Wipe, Data Destruction, Financial Theft, Internal Defacement, Transmitted Data Manipulation, Disk Content Wipe, Application Exhaustion Flood, Stored Data Manipulation, Inhibit System Recovery, Disk Structure Wipe, Defacement, Resource Hijacking, Data Encrypted for Impact, Service Exhaustion Flood, Service Stop, Reflection Amplification, System Shutdown/Reboot, Data Manipulation, Firmware Corruption, Endpoint Denial of Service, Network Denial of Service"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0019"
ADD_INFORMATION_technique_ID: "T1564.006, T1543.001, T1036, T1197, T1543.002, T1569.002, T1557.001, T1021.006, T1543.004, T1574.010, T1543.003, T1036.004, T1557, T1574.005, T1562.001, T1562, T1574.011, T1569, T1564, T1574, T1489, T1490, T1543, T1569.001"
ADD_INFORMATION_technique: "Masquerading, LLMNR/NBT-NS Poisoning and SMB Relay, Masquerade Task or Service, System Services, Adversary-in-the-Middle, Impair Defenses, Inhibit System Recovery, Run Virtual Instance, Launch Daemon, Service Execution, Launchctl, Services File Permissions Weakness, Launch Agent, Disable or Modify Tools, Windows Remote Management, Hide Artifacts, Service Stop, Windows Service, Create or Modify System Process, Systemd Service, Services Registry Permissions Weakness, Executable Installer File Permissions Weakness, Hijack Execution Flow, BITS Jobs"
ADD_INFORMATION_data_source: "SERVICE"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0019"
ADD_INFORMATION_data_source_description: "A computer process that is configured to execute continuously in the background and perform system tasks, in some cases before any user has logged in(Citation: Microsoft Services)(Citation: Linux Services Run Levels)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1588.001, T1585, T1594, T1595.001, T1608.001, T1584.007, T1588, T1608.004, T1588.002, T1589, T1598.003, T1587.003, T1584.002, T1584, T1595.003, T1592, T1608.002, T1595, T1587.002, T1583.003, T1598.001, T1598.004, T1583.006, T1583.008, T1588.004, T1584.004, T1584.006, T1608.003, T1584.003, T1584.008, T1587.001, T1598, T1583.004, T1592.001, T1583.007, T1595.002, T1608, T1583, T1586.001, T1598.002, T1608.005, T1592.004, T1583.001, T1585.001, T1589.002, T1608.006, T1584.001, T1588.003, T1586, T1592.002, T1587"
ADD_INFORMATION_technique: "Digital Certificates, Drive-by Target, Compromise Accounts, Establish Accounts, Web Services, Tool, Spearphishing Voice, Obtain Capabilities, Stage Capabilities, Spearphishing Link, Serverless, Code Signing Certificates, Phishing for Information, Virtual Private Server, SEO Poisoning, Hardware, Server, Software, Install Digital Certificate, Upload Tool, Compromise Infrastructure, Search Victim-Owned Websites, Social Media Accounts, Gather Victim Identity Information, DNS Server, Malware, Domains, Gather Victim Host Information, Develop Capabilities, Link Target, Malvertising, Scanning IP Blocks, Acquire Infrastructure, Network Devices, Client Configurations, Active Scanning, Vulnerability Scanning, Email Addresses, Wordlist Scanning, Spearphishing Service, Upload Malware, Spearphishing Attachment"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Australian Defence Force Private and Husband Charged with Espionage for Russia

**date**
12/07/2024

**url_news**
https://thehackernews.com/2024/07/australian-defence-force-private-and.html

**thn_category_and_subcategory**
'Cyber Crime / Online Safety'

**links**
'https://apnews.com/article/australia-espionage-russia-spying-db92e5c5182b82cd815743298ea0dd56', 'https://www.smh.com.au/politics/federal/married-couple-charged-with-spying-for-russia-20240712-p5jt2k.html', 'https://www.afp.gov.au/news-centre/media-release/two-australian-citizens-charged-espionage-related-offence', 'https://www.legislation.gov.au/Details/C2022C00324', 'https://www.afp.gov.au/news-centre/media-release/australian-man-charged-foreign-interference', 'https://www.afp.gov.au/news-centre/media-release/first-sentence-foreign-interference-handed-down', 'https://www.asio.gov.au/director-generals-press-conference-statement', 'https://www.facebook.com/photo/?fbid=812201204373784&set=a.300654688861774'

**body**
'Two Russian-born Australian citizens have been arrested and charged in the country for spying on behalf of Russia as part of a "complex" law enforcement operation codenamed BURGAZADA.', 'This includes a 40-year-old woman, an Australian Defence Force (ADF) Army Private, and her husband, a 62-year-old self-employed laborer. Media reports have identified them as Kira Korolev and Igor Korolev, respectively, noting that they had been in Australia for over a decade.', "The married couple were arrested at their home in the Brisbane suburb of Everton Park on July 11, 2024, the Australian Federal Police (AFP) said in a statement. They have been charged with one count each of preparing for an espionage offense, which carries a maximum penalty of 15 years' imprisonment.", '"It is the first time an espionage offense has been laid in Australia since new laws were introduced by the Commonwealth in 2018," the AFP said.', 'The federal law enforcement agency has alleged the pair colluded together to obtain sensitive information after the woman traveled to Russia while on a long-term leave from the ADF since 2023.', 'She is said to have instructed her husband, who remained in Australia, to log into her official work account and instructed him to access specific information and send it directly to her private email account while she was overseas.', '"The woman\'s ADF account credentials were used on a number of occasions to access sensitive ADF information, with the intent to provide it to Russian authorities," the AFP said.', 'Although the exact documents that were accessed were not disclosed, the AFP said they related to Australian national security interests. An investigation into whether the information was handed over to Russia remains ongoing.', '"Espionage is an insidious crime, and at a time of global instability, state actors have ramped-up their efforts to obtain information held by Western democracies, including Australia," AFP Commissioner Reece Kershaw said.', '"Espionage is not a victimless crime. It has the potential to impact on Australia\'s sovereignty, safety and way of life."', 'The arrests mark the third time individuals have been charged with espionage or foreign interference related offenses since their incorporation into the Criminal Code Act 1995.', 'Last April, a New South Wales man, 55, was charged with providing information about "Australian defense, economic and national security arrangements" to two individuals associated with a foreign intelligence service who are suspected to be undertaking intelligence gathering activities.', 'Then in late February 2024, a 68-year-old man from Melbourne was sentenced to two years and nine months in prison for attempting to influence a Federal Parliamentarian on behalf of a foreign government.', 'Mike Burgess, Director-General of Security in charge of the Australian Security Intelligence Organization (ASIO), said the ongoing threat of espionage is "real," and that "multiple countries are seeking to steal Australia\'s secrets."', 'The Embassy of Russia in Australia shared the following statement on its Facebook page -', 'The press conference of AFP and ASIO chiefs on 12 July was clearly intended to launch another wave of anti-Russian paranoia in Australia. Theatrical tricks were used like talking to imaginary "Russian spies" presumed to be all around. The Embassy has requested official written information from the Australian authorities on the situation and status of Mrs Kira Korolev and Mr Igor Korolev. We\'ll consider appropriate measures of consular assistance.', 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

