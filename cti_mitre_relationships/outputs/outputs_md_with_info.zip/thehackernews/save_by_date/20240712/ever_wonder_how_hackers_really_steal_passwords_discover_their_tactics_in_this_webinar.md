---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Ever Wonder How Hackers Really Steal Passwords? Discover Their Tactics in This Webinar"
Date: 2024-07-12
Category: "Digital Security"
Sub-Category: "Online Safety"

ADD_INFORMATION_technique_ID: "T1587.004"
ADD_INFORMATION_technique: "EXPLOITS"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1587/004"
ADD_INFORMATION_technique_description: "Adversaries may develop exploits that can be used during targeting. An exploit takes advantage of a bug or vulnerability in order to cause unintended or unanticipated behavior to occur on computer hardware or software. Rather than finding/modifying exploits from online or purchasing them from exploit vendors, an adversary may develop their own exploits.(Citation: NYTStuxnet) Adversaries may use information acquired via Vulnerabilities(https://attack.mitre.org/techniques/T1588/006) to focus exploit development efforts. As part of the exploit development process, adversaries may uncover exploitable vulnerabilities through methods such as fuzzing and patch analysis.(Citation: Irongeek Sims BSides 2017)

As with legitimate development efforts, different skill sets may be required for developing exploits. The skills needed may be located in-house, or may need to be contracted out. Use of a contractor may be considered an extension of that adversarys exploit development capabilities, provided the adversary plays a role in shaping requirements and maintains an initial degree of exclusivity to the exploit.

Adversaries may use exploits during various phases of the adversary lifecycle (i.e. Exploit Public-Facing Application(https://attack.mitre.org/techniques/T1190), Exploitation for Client Execution(https://attack.mitre.org/techniques/T1203), Exploitation for Privilege Escalation(https://attack.mitre.org/techniques/T1068), Exploitation for Defense Evasion(https://attack.mitre.org/techniques/T1211), Exploitation for Credential Access(https://attack.mitre.org/techniques/T1212), Exploitation of Remote Services(https://attack.mitre.org/techniques/T1210), and Application or System Exploitation(https://attack.mitre.org/techniques/T1499/004))."
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1588.001, T1585, T1594, T1595.001, T1608.001, T1584.007, T1588, T1608.004, T1588.002, T1589, T1598.003, T1587.003, T1584.002, T1584, T1595.003, T1592, T1608.002, T1595, T1587.002, T1583.003, T1598.001, T1598.004, T1583.006, T1583.008, T1588.004, T1584.004, T1584.006, T1608.003, T1584.003, T1584.008, T1587.001, T1598, T1583.004, T1592.001, T1583.007, T1595.002, T1608, T1583, T1586.001, T1598.002, T1608.005, T1592.004, T1583.001, T1585.001, T1589.002, T1608.006, T1584.001, T1588.003, T1586, T1592.002, T1587"
ADD_INFORMATION_technique: "Digital Certificates, Drive-by Target, Compromise Accounts, Establish Accounts, Web Services, Tool, Spearphishing Voice, Obtain Capabilities, Stage Capabilities, Spearphishing Link, Serverless, Code Signing Certificates, Phishing for Information, Virtual Private Server, SEO Poisoning, Hardware, Server, Software, Install Digital Certificate, Upload Tool, Compromise Infrastructure, Search Victim-Owned Websites, Social Media Accounts, Gather Victim Identity Information, DNS Server, Malware, Domains, Gather Victim Host Information, Develop Capabilities, Link Target, Malvertising, Scanning IP Blocks, Acquire Infrastructure, Network Devices, Client Configurations, Active Scanning, Vulnerability Scanning, Email Addresses, Wordlist Scanning, Spearphishing Service, Upload Malware, Spearphishing Attachment"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Ever Wonder How Hackers Really Steal Passwords? Discover Their Tactics in This Webinar

**date**
12/07/2024

**url_news**
https://thehackernews.com/2024/07/ever-wonder-how-hackers-really-steal.html

**thn_category_and_subcategory**
'Digital Security / Online Safety'

**links**
'https://thehacker.news/compromised-credentials?source=article'

**body**
"In today's digital age, passwords serve as the keys to our most sensitive information, from social media accounts to banking and business systems. This immense power brings with it significant responsibility—and vulnerability.", "Most people don't realize their credentials have been compromised until the damage is done.", "Imagine waking up to drained bank accounts, stolen identities, or a company's reputation in tatters. This isn't just a hypothetical scenario – it's the harsh reality faced by countless individuals and organizations every day.", 'Recent data reveals that compromised credentials are the single biggest attack vector in 2024. That means stolen passwords, not exotic malware or zero-day exploits, are the most common way hackers breach systems and wreak havoc.', 'To help you navigate this critical issue, we invite you to join our exclusive webinar, "Compromised Credentials in 2024: What to Know About the World\'s #1 Attack Vector."', 'In this webinar, Tim Chase will delve into the world of compromised credentials, covering:', "Don't miss this opportunity to arm yourself with the knowledge and tools needed to protect your digital kingdom from the ever-present threat of compromised credentials.", 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

