---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "CRYSTALRAY Hackers Infect Over 1,500 Victims Using Network Mapping Tool"
Date: 2024-07-15
Category: "SaaS Security"
Sub-Category: "Vulnerability"

ADD_INFORMATION_technique_ID: "T1021.004"
ADD_INFORMATION_technique: "SSH"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1021/004"
ADD_INFORMATION_technique_description: "Adversaries may use Valid Accounts(https://attack.mitre.org/techniques/T1078) to log into remote machines using Secure Shell (SSH). The adversary may then perform actions as the logged-on user.

SSH is a protocol that allows authorized users to open remote shells on other computers. Many Linux and macOS versions come with SSH installed by default, although typically disabled until the user enables it. The SSH server can be configured to use standard password authentication or public-private keypairs in lieu of or in addition to a password. In this authentication scenario, the user’s public key must be in a special file on the computer running the server that lists which keypairs are allowed to login as that user."
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0008"
ADD_INFORMATION_technique_ID: "T1210, T1563.002, T1563, T1021.003, T1021.006, T1072, T1550, T1534, T1550.002, T1563.001, T1570, T1021.001, T1091, T1080, T1550.004, T1021.007, T1021, T1550.001, T1021.004, T1021.002, T1550.003, T1021.008, T1021.005"
ADD_INFORMATION_technique: "Direct Cloud VM Connections, Pass the Ticket, Exploitation of Remote Services, Use Alternate Authentication Material, SMB/Windows Admin Shares, VNC, Replication Through Removable Media, Remote Desktop Protocol, Software Deployment Tools, SSH Hijacking, Cloud Services, Taint Shared Content, Distributed Component Object Model, Windows Remote Management, RDP Hijacking, Lateral Tool Transfer, Application Access Token, SSH, Web Session Cookie, Remote Service Session Hijacking, Internal Spearphishing, Pass the Hash, Remote Services"
ADD_INFORMATION_tactic: "LATERAL MOVEMENT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0008"
ADD_INFORMATION_tactic_description: "The adversary is trying to move through your environment.Lateral Movement consists of techniques that adversaries use to enter and control remote systems on a network. Following through on their primary objective often requires exploring the network to find their target and subsequently gaining access to it. Reaching their objective often involves pivoting through multiple systems and accounts to gain. Adversaries might install their own remote access tools to accomplish Lateral Movement or use legitimate credentials with native network and operating system tools, which may be stealthier. "
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0030"
ADD_INFORMATION_technique_ID: "T1580, T1578.002, T1578, T1578.003, T1578.004, T1535, T1485, T1204, T1204.003"
ADD_INFORMATION_technique: "Malicious Image, Unused/Unsupported Cloud Regions, Cloud Infrastructure Discovery, User Execution, Delete Cloud Instance, Revert Cloud Instance, Modify Cloud Compute Infrastructure, Create Cloud Instance, Data Destruction"
ADD_INFORMATION_data_source: "INSTANCE"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0030"
ADD_INFORMATION_data_source_description: "A virtual server environment which runs workloads, hosted on-premise or by third-party cloud providers(Citation: Amazon VM)(Citation: Google VM)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "NETWORK"
ADD_INFORMATION_technique_ID: "T1027, T1071.003, T1600.001, T1071.002, T1071.001, T1090, T1136.001, T1505.003, T1190, T1552.004, T1070, T1136, T1057, T1078.003, T1562.001, T1562, T1046, T1070.007, T1098.004, T1083, T1124, T1601.002, T1556, T1037, T1601.001, T1078, T1018, T1561, T1490, T1599, T1573.001, T1110.004, T1542.004, T1006, T1110, T1016, T1110.001, T1072, T1205.001, T1542, T1059.008, T1602.001, T1562.003, T1098, T1600.002, T1552, T1048.003, T1090.003, T1090.002, T1602.002, T1071.004, T1037.004, T1205, T1049, T1110.003, T1201, T1556.004, T1110.002, T1542.001, T1059.004, T1070.003, T1082, T1573, T1020, T1033, T1529, T1573.002, T1071, T1056.001, T1599.001, T1048, T1542.005, T1040, T1562.004, T1495, T1505, T1665, T1547, T1056, T1557, T1600, T1095, T1561.002, T1027.008, T1059, T1561.001, T1601, T1105, T1090.001, T1005, T1020.001, T1078.001, T1602, T1653"
ADD_INFORMATION_technique: "Mail Protocols, System Network Connections Discovery, Network Device Authentication, Internal Proxy, File and Directory Discovery, Data from Configuration Repository, Pre-OS Boot, Encrypted Channel, Private Keys, Automated Exfiltration, Keylogging, Disk Content Wipe, System Time Discovery, Inhibit System Recovery, Multi-hop Proxy, Asymmetric Cryptography, Impair Command History Logging, System Owner/User Discovery, System Shutdown/Reboot, DNS, Clear Network Connection History and Configurations, Server Software Component, System Network Configuration Discovery, Non-Application Layer Protocol, Process Discovery, Local Accounts, System Information Discovery, Default Accounts, Network Boundary Bridging, Modify System Image, Network Service Discovery, SNMP (MIB Dump), Software Deployment Tools, System Firmware, Exfiltration Over Unencrypted Non-C2 Protocol, Credential Stuffing, RC Scripts, TFTP Boot, Disable or Modify Tools, Unix Shell, File Transfer Protocols, Clear Command History, Network Sniffing, Password Spraying, Remote System Discovery, Ingress Tool Transfer, Data from Local System, Disable or Modify System Firewall, Valid Accounts, Disable Crypto Hardware, Disk Wipe, Command and Scripting Interpreter, Weaken Encryption, Power Settings, Impair Defenses, Network Device Configuration Dump, Port Knocking, Disk Structure Wipe, Input Capture, Direct Volume Access, Obfuscated Files or Information, Network Address Translation Traversal, Create Account, Modify Authentication Process, SSH Authorized Keys, Unsecured Credentials, Proxy, Application Layer Protocol, Stripped Payloads, Reduce Key Space, Symmetric Cryptography, Password Guessing, Hide Infrastructure, Adversary-in-the-Middle, Traffic Signaling, Patch System Image, External Proxy, ROMMONkit, Brute Force, Password Cracking, Exploit Public-Facing Application, Indicator Removal, Traffic Duplication, Downgrade System Image, Account Manipulation, Exfiltration Over Alternative Protocol, Web Shell, Network Device CLI, Boot or Logon Initialization Scripts, Web Protocols, Boot or Logon Autostart Execution, Firmware Corruption, Local Account, Password Policy Discovery"

ADD_INFORMATION_software_ID: "S0633"
ADD_INFORMATION_technique_ID: "T1132.001, T1573.002, T1573.001, T1049, T1001.002, T1083, T1027.013, T1071.004, T1134, T1055, T1071.001, T1041, T1016, T1113, T1105"
ADD_INFORMATION_technique: "Encrypted/Encoded File, Screen Capture, System Network Connections Discovery, Exfiltration Over C2 Channel, Asymmetric Cryptography, DNS, Access Token Manipulation, Standard Encoding, System Network Configuration Discovery, Web Protocols, File and Directory Discovery, Steganography, Process Injection, Ingress Tool Transfer, Symmetric Cryptography"
ADD_INFORMATION_software: "SLIVER"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0633"
ADD_INFORMATION_software_description: "Sliver(https://attack.mitre.org/software/S0633) is an open source, cross-platform, red team command and control framework written in Golang.(Citation: Bishop Fox Sliver Framework August 2019)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_group_ID: "G0106"
ADD_INFORMATION_group: "ROCKE"
ADD_INFORMATION_technique_ID: "T1140, T1027, T1571, T1562.004, T1102.001, T1543.002, T1071.001, T1027.004, T1027.002, T1190, T1552.004, T1070.006, T1070.002, T1057, T1053.003, T1059.004, T1562.001, T1564.001, T1055.002, T1222.002, T1102, T1046, T1082, T1547.001, T1574.006, T1037, T1105, T1518.001, T1018, T1059.006, T1014, T1070.004, T1021.004, T1071, T1036.005, T1496"
ADD_INFORMATION_technique: "Application Layer Protocol, Process Discovery, Cron, Portable Executable Injection, Dynamic Linker Hijacking, Disable or Modify System Firewall, System Information Discovery, File Deletion, Non-Standard Port, Hidden Files and Directories, Compile After Delivery, Clear Linux or Mac System Logs, Linux and Mac File and Directory Permissions Modification, Network Service Discovery, Private Keys, Security Software Discovery, Match Legitimate Name or Location, Rootkit, Timestomp, Exploit Public-Facing Application, Disable or Modify Tools, Unix Shell, Web Service, Resource Hijacking, Dead Drop Resolver, Obfuscated Files or Information, SSH, Python, Remote System Discovery, Registry Run Keys / Startup Folder, Boot or Logon Initialization Scripts, Software Packing, Web Protocols, Ingress Tool Transfer, Systemd Service, Deobfuscate/Decode Files or Information"
ADD_INFORMATION_group_aliases: "Rocke"
ADD_INFORMATION_group_url: "https://attack.mitre.org/groups/G0106"
ADD_INFORMATION_group_description: "Rocke(https://attack.mitre.org/groups/G0106) is an alleged Chinese-speaking adversary whose primary objective appeared to be cryptojacking, or stealing victim system resources for the purposes of mining cryptocurrency. The name Rocke(https://attack.mitre.org/groups/G0106) comes from the email address "rocke@live.cn" used to create the wallet which held collected cryptocurrency. Researchers have detected overlaps between Rocke(https://attack.mitre.org/groups/G0106) and the Iron Cybercrime Group, though this attribution has not been confirmed.(Citation: Talos Rocke August 2018)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
CRYSTALRAY Hackers Infect Over 1,500 Victims Using Network Mapping Tool

**date**
15/07/2024

**url_news**
https://thehackernews.com/2024/07/crystalray-hackers-infect-over-1500.html

**thn_category_and_subcategory**
'SaaS Security / Vulnerability'

**links**
'https://sysdig.com/blog/CRYSTALRAY-rising-threat-actor-exploiting-oss-tools/', 'https://github.com/MegaManSec/SSH-Snake', 'https://thehackernews.com/2024/02/cybercriminals-weaponizing-open-source.html', 'https://github.com/nitefood/asn', 'https://github.com/zmap/zmap', 'https://github.com/projectdiscovery/httpx', 'https://github.com/projectdiscovery/nuclei', 'https://thehackernews.com/2023/01/threat-actors-turn-to-sliver-as-open.html', 'https://www.archcloudlabs.com/projects/cryptojacking-adopts-termite-c2-utility/', 'https://github.com/WangYihang/Platypus'

**body**
'A threat actor that was previously observed using an open-source network mapping tool has greatly expanded their operations to infect over 1,500 victims.', 'Sysdig, which is tracking the cluster under the name CRYSTALRAY, said the activities have witnessed a tenfold surge, adding it includes "mass scanning, exploiting multiple vulnerabilities, and placing backdoors using multiple open-source software security tools."', 'The primary objective of the attacks is to harvest and sell credentials, deploy cryptocurrency miners, and maintain persistence in victim environments. A majority of the infections are concentrated in the U.S., China, Singapore, Russia, France, Japan, and India, among others.', 'Prominent among the open-source programs used by the threat actor is SSH-Snake, which was first released in January 2024. It has been described as a tool to carry out automatic network traversal using SSH private keys discovered on systems.', 'The abuse of the software by CRYSTALRAY was documented by the cybersecurity company earlier this February, with the tool deployed for lateral movement following the exploitation of known security flaws in public-facing Apache ActiveMQ and Atlassian Confluence instances.', 'Joshua Rogers, the developer behind SSH-Snake, told The Hacker News at the time that the tool only automates what would have been otherwise manual steps, and called on companies to "discover the attack paths that exist – and fix them."', 'Some of the other tools employed by the attackers include asn, zmap, httpx, and nuclei in order to check if a domain is active and launch scans for vulnerable services such as Apache ActiveMQ, Apache RocketMQ, Atlassian Confluence, Laravel, Metabase, Openfire, Oracle WebLogic Server, and Solr.', 'CRYSTALRAY also weaponizes its initial foothold to conduct a wide-ranging credential discovery process that goes beyond moving between servers accessible via SSH. Persistent access to the compromised environment is accomplished by means of a legitimate command-and-control (C2) framework called Sliver and a reverse shell manager codenamed Platypus.', 'In a further bid to derive monetary value from the infected assets, cryptocurrency miner payloads are delivered to illicitly use the victim resources for financial gain, while simultaneously taking steps to terminate competing miners that may have already been running on the machines.', '"CRYSTALRAY is able to discover and extract credentials from vulnerable systems, which are then sold on black markets for thousands of dollars," Sysdig researcher Miguel Hernández said. "The credentials being sold involve a multitude of services, including Cloud Service Providers and SaaS email providers."', 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

