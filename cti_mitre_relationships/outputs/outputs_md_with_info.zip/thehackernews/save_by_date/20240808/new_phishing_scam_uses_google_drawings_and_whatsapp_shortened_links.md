---
CP Source: The Hacker News
CP Execution date:  2024-08-08
Headline: "New Phishing Scam Uses Google Drawings and WhatsApp Shortened Links"
Date: 2024-08-08
Category: "Network Security"
Sub-Category: "Cloud Security"

AI_technique_ID_1: "T1588.002"
AI_technique_1: "TOOL"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_1: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1589.001"
AI_technique_2: "CREDENTIALS"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1589/001"
AI_technique_description_2: "Adversaries may gather credentials that can be used during targeting. Account credentials gathered by adversaries may be those directly associated with the target victim organization or attempt to take advantage of the tendency for users to use the same passwords across personal and business accounts. Adversaries may gather credentials from potential victims in various ways, such as direct elicitation via Phishing for Information https://attack.mitre.org/techniques/T1598. Adversaries may also compromise sites then add malicious content designed to collect website authentication cookies from visitors.Citation ATT ScanBox Credential information may also be exposed to adversaries via leaks to online or other accessible data sets ex Search Engines https://attack.mitre.org/techniques/T1593/002, breach dumps, code repositories, etc..Citation Register DeloitteCitation Register UberCitation Detectify Slack TokensCitation Forbes GitHub CredsCitation GitHub truffleHogCitation GitHub GitrobCitation CNET Leaks Adversaries may also purchase credentials from dark web or other blackmarkets. Finally, where multifactor authentication MFA based on outofband communications is in use, adversaries may compromise a service provider to gain access to MFA codes and onetime passwords OTP.Citation Okta Scatter Swine 2022 Gathering this information may reveal opportunities for other forms of reconnaissance ex Search Open WebsitesDomains https://attack.mitre.org/techniques/T1593 or Phishing for Information https://attack.mitre.org/techniques/T1598, establishing operational resources ex Compromise Accounts https://attack.mitre.org/techniques/T1586, andor initial access ex External Remote Services https://attack.mitre.org/techniques/T1133 or Valid Accounts https://attack.mitre.org/techniques/T1078."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1566"
AI_technique_3: "PHISHING"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1566"
AI_technique_description_3: "Adversaries may send phishing messages to gain access to victim systems. All forms of phishing are electronically delivered social engineering. Phishing can be targeted, known as spearphishing. In spearphishing, a specific individual, company, or industry will be targeted by the adversary. More generally, adversaries can conduct nontargeted phishing, such as in mass malware spam campaigns. Adversaries may send victims emails containing malicious attachments or links, typically to execute malicious code on victim systems. Phishing may also be conducted via thirdparty services, like social media platforms. Phishing may also involve social engineering techniques, such as posing as a trusted source, as well as evasive techniques such as removing or manipulating emails or metadataheaders from compromised accounts being abused to send messages e.g., Email Hiding Rules https://attack.mitre.org/techniques/T1564/008.Citation Microsoft OAuth Spam 2022Citation Palo Alto Unit 42 VBA Infostealer 2014 Another way to accomplish this is by forging or spoofingCitation Proofpointspoof the identity of the sender which can be used to fool both the human recipient as well as automated security tools.Citation cyberproofdoublebounce Victims may also receive phishing messages that instruct them to call a phone number where they are directed to visit a malicious URL, download malware,Citation sygnia Luna MonthCitation CISA Remote Monitoring and Management Software or install adversaryaccessible remote management tools onto their computer i.e., User Execution https://attack.mitre.org/techniques/T1204.Citation Unit42 Luna Moth"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"
AI_technique_ID_4: "T1053.002"
AI_technique_4: "AT"
AI_technique_url_4: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_4: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_4: "False"
AI_technique_revoked_4: "False"
AI_matrix_domains_4: "enterprise-attack"


AI_data_source_ID_1: "DS0021"
AI_technique_ID_1: "T1586; T1585.001; T1586.001; T1585"
AI_technique_1: "Establish Accounts; Social Media Accounts; Compromise Accounts"
AI_data_source_1: "PERSONA"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0021"
AI_data_source_description_1: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
AI_matrix_domains_1: "enterprise-attack"
AI_data_source_ID_2: "DS0018"
AI_technique_ID_2: "T1562.004; T1070; T1562; T1562.007; T1518.001; T1070.007; T1518"
AI_technique_2: "Impair Defenses; Disable or Modify System Firewall; Software Discovery; Security Software Discovery; Clear Network Connection History and Configurations; Disable or Modify Cloud Firewall; Indicator Removal"
AI_data_source_2: "FIREWALL"
AI_data_source_url_2: "https://attack.mitre.org/datasources/DS0018"
AI_data_source_description_2: "A network security system, running locally on an endpoint or remotely as a service ex cloud environment, that monitors and controls incomingoutgoing network traffic based on predefined rulesCitation AWS Sec Groups VPC"
AI_matrix_domains_2: "enterprise-attack"
AI_data_source_ID_3: "DS0036"
AI_technique_ID_3: "T1069.002; T1098.002; T1087.002; T1087.001; T1069; T1098; T1069.003; T1069.001"
AI_technique_3: "Domain Account; Account Manipulation; Additional Email Delegate Permissions; Permission Groups Discovery; Local Groups; Local Account; Domain Groups; Cloud Groups"
AI_data_source_3: "GROUP"
AI_data_source_url_3: "https://attack.mitre.org/datasources/DS0036"
AI_data_source_description_3: "A collection of multiple user accounts that share the same access rights to the computer andor network resources and have common security rightsCitation Amazon IAM Groups"
AI_matrix_domains_3: "enterprise-attack"
AI_data_source_ID_4: "DS0019"
AI_technique_ID_4: "T1562; T1490; T1564; T1489; T1557; T1564.006; T1036; T1036.004; T1543; T1543.003; T1574.005; T1543.002; T1574.010; T1569; T1557.001; T1574.011; T1543.004; T1569.002; T1574; T1021.006; T1562.001; T1543.001; T1197; T1569.001"
AI_technique_4: "Services File Permissions Weakness; Launch Daemon; Disable or Modify Tools; Windows Service; Create or Modify System Process; Executable Installer File Permissions Weakness; Services Registry Permissions Weakness; Launchctl; BITS Jobs; System Services; Systemd Service; Impair Defenses; Hide Artifacts; Masquerade Task or Service; Service Execution; Windows Remote Management; Adversary-in-the-Middle; Launch Agent; Inhibit System Recovery; Hijack Execution Flow; Masquerading; Service Stop; Run Virtual Instance; LLMNR/NBT-NS Poisoning and SMB Relay"
AI_data_source_4: "SERVICE"
AI_data_source_url_4: "https://attack.mitre.org/datasources/DS0019"
AI_data_source_description_4: "A computer process that is configured to execute continuously in the background and perform system tasks, in some cases before any user has logged inCitation Microsoft ServicesCitation Linux Services Run Levels"
AI_matrix_domains_4: "enterprise-attack"


AI_platform_1: "NETWORK"
AI_technique_ID_1: "T1562; T1556; T1490; T1110.004; T1556.004; T1059; T1600.002; T1653; T1190; T1110.003; T1098; T1601.002; T1046; T1552.004; T1602.002; T1078.003; T1602.001; T1505; T1600; T1078; T1020; T1124; T1562.001; T1110.002; T1599; T1037; T1083; T1600.001; T1027.008; T1048.003; T1561.001; T1599.001; T1095; T1005; T1090.001; T1018; T1049; T1562.003; T1020.001; T1027; T1071.001; T1547; T1033; T1056; T1542.004; T1542.005; T1562.004; T1070; T1136.001; T1205; T1059.004; T1078.001; T1110; T1006; T1016; T1542.001; T1561.002; T1070.003; T1037.004; T1071.004; T1601.001; T1056.001; T1070.007; T1090.003; T1071.003; T1090; T1601; T1205.001; T1090.002; T1573.002; T1505.003; T1072; T1529; T1110.001; T1552; T1082; T1098.004; T1201; T1561; T1105; T1557; T1071.002; T1602; T1136; T1573.001; T1495; T1040; T1057; T1071; T1048; T1059.008; T1665; T1542; T1573"
AI_technique_1: "System Shutdown/Reboot; Remote System Discovery; Default Accounts; Local Account; Exploit Public-Facing Application; Automated Exfiltration; Create Account; Traffic Duplication; Symmetric Cryptography; DNS; Input Capture; Private Keys; Network Sniffing; Web Protocols; Password Cracking; Data from Configuration Repository; Software Deployment Tools; Brute Force; Boot or Logon Autostart Execution; Firmware Corruption; Clear Network Connection History and Configurations; Password Policy Discovery; Modify System Image; Password Spraying; Mail Protocols; TFTP Boot; Unsecured Credentials; File Transfer Protocols; Traffic Signaling; Clear Command History; Network Boundary Bridging; Impair Defenses; Keylogging; System Firmware; Adversary-in-the-Middle; Obfuscated Files or Information; Application Layer Protocol; System Network Connections Discovery; Hide Infrastructure; Unix Shell; Modify Authentication Process; Weaken Encryption; SNMP (MIB Dump); Non-Application Layer Protocol; Patch System Image; File and Directory Discovery; Disable or Modify Tools; Downgrade System Image; Valid Accounts; Multi-hop Proxy; Impair Command History Logging; Proxy; Network Device Authentication; Network Address Translation Traversal; Pre-OS Boot; SSH Authorized Keys; Account Manipulation; Boot or Logon Initialization Scripts; Exfiltration Over Alternative Protocol; External Proxy; Inhibit System Recovery; Disable or Modify System Firewall; Credential Stuffing; System Time Discovery; Network Service Discovery; Indicator Removal; System Information Discovery; Direct Volume Access; Reduce Key Space; Disk Structure Wipe; Stripped Payloads; Disk Wipe; Port Knocking; Disable Crypto Hardware; RC Scripts; Data from Local System; Password Guessing; Asymmetric Cryptography; Internal Proxy; Server Software Component; ROMMONkit; Local Accounts; Network Device CLI; Exfiltration Over Unencrypted Non-C2 Protocol; System Owner/User Discovery; Encrypted Channel; Ingress Tool Transfer; Disk Content Wipe; Network Device Configuration Dump; Web Shell; Power Settings; System Network Configuration Discovery; Command and Scripting Interpreter; Process Discovery"
AI_platform_2: "PRE"
AI_technique_ID_2: "T1595.001; T1583.008; T1587; T1598.003; T1588.001; T1584.006; T1584.003; T1588; T1585; T1594; T1583.001; T1608.001; T1587.001; T1587.003; T1608.005; T1583.003; T1583.006; T1588.003; T1598; T1584.001; T1598.004; T1588.002; T1608; T1587.002; T1608.006; T1584.002; T1592.002; T1584.008; T1595.002; T1589.002; T1608.003; T1584; T1598.002; T1586.001; T1608.004; T1589; T1583.004; T1595; T1598.001; T1592; T1583.007; T1586; T1592.001; T1588.004; T1585.001; T1592.004; T1584.004; T1608.002; T1583; T1595.003; T1584.007"
AI_technique_2: "DNS Server; Server; Compromise Infrastructure; Serverless; Client Configurations; Vulnerability Scanning; Install Digital Certificate; Link Target; Acquire Infrastructure; Hardware; Obtain Capabilities; SEO Poisoning; Code Signing Certificates; Digital Certificates; Active Scanning; Virtual Private Server; Spearphishing Service; Stage Capabilities; Search Victim-Owned Websites; Web Services; Gather Victim Identity Information; Email Addresses; Wordlist Scanning; Spearphishing Voice; Malvertising; Tool; Upload Malware; Social Media Accounts; Develop Capabilities; Establish Accounts; Drive-by Target; Gather Victim Host Information; Scanning IP Blocks; Phishing for Information; Compromise Accounts; Upload Tool; Malware; Domains; Spearphishing Attachment; Network Devices; Spearphishing Link; Software"


AI_software_ID_1: "S1088"
AI_technique_ID_1: "T1659; T1105; T1071.002; T1053.005; T1204.002"
AI_technique_1: "File Transfer Protocols; Scheduled Task; Content Injection; Ingress Tool Transfer; Malicious File"
AI_software_1: "DISCO"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S1088"
AI_software_description_1: "Disco https://attack.mitre.org/software/S1088 is a custom implant that has been used by MoustachedBouncer https://attack.mitre.org/groups/G1019 since at least 2020 including in campaigns using targeted malicious content injection for initial access and command and control.Citation MoustachedBouncer ESET August 2023"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0110"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "At"
AI_software_2: "AT"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0110"
AI_software_description_2: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0039"
AI_technique_ID_3: "T1136.001; T1069.002; T1087.002; T1021.002; T1124; T1087.001; T1070.005; T1018; T1007; T1049; T1136.002; T1201; T1569.002; T1135; T1069.001"
AI_technique_3: "Service Execution; Domain Account; Remote System Discovery; Network Share Connection Removal; Local Groups; System Service Discovery; Password Policy Discovery; Local Account; System Time Discovery; Domain Groups; Network Share Discovery; System Network Connections Discovery; SMB/Windows Admin Shares"
AI_software_3: "NET"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0039"
AI_software_description_3: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_3: "enterprise-attack"

---

**title**
New Phishing Scam Uses Google Drawings and WhatsApp Shortened Links

**date**
08/08/2024

**url_news**
https://thehackernews.com/2024/08/new-phishing-scam-uses-google-drawings.html

**thn_category_and_subcategory**
'Network Security / Cloud Security'

**links**
'https://www.menlosecurity.com/blog/google-drawings-and-whatsapp-zero-hour-open-redirection-phish-exposed', 'https://lots-project.com/', 'https://certitude.consulting/blog/en/o365-anti-phishing-measures/'

**body**
'Cybersecurity researchers have discovered a novel phishing campaign that leverages Google Drawings and shortened links generated via WhatsApp to evade detection and trick users into clicking on bogus links designed to steal sensitive information.', '"The attackers chose a group of the best-known websites in computing to craft the threat, including Google and WhatsApp to host the attack elements, and an Amazon look-alike to harvest the victim\'s information," Menlo Security researcher Ashwin Vamshi said. "This attack is a great example of a Living Off Trusted Sites (LoTS) threat."', 'The starting point of the attack is a phishing email that directs the recipients to a graphic that appears to be an Amazon account verification link. This graphic, for its part, is hosted on Google Drawings, in an apparent effort to evade detection.', "Abusing legitimate services has obvious benefits for attackers in that they're not only a low-cost solution, but more importantly, they offer a clandestine way of communication inside networks, as they are unlikely to be blocked by security products or firewalls.", '"Another thing that makes Google Drawings appealing in the beginning of the attack is that it allows users (in this case, the attacker) to include links in their graphics," Vamshi said. "Such links may easily go unnoticed by users, particularly if they feel a sense of urgency around a potential threat to their Amazon account."', 'Users who end up clicking on the verification link are taken to a lookalike Amazon login page, with the URL crafted successively using two different URL shorteners -- WhatsApp ("l.wl.co") followed by qrco.de -- as an added layer of obfuscation and deceive security URL scanners.', 'The fake page is designed to harvest credentials, personal information, and credit card details, after which the victims are redirected to the original phished Amazon login page. As an extra step, the web page is rendered inaccessible from the same IP address once the credentials have been validated.', "The disclosure comes as researchers have identified a loophole in Microsoft 365's anti-phishing mechanisms that could be abused to increase the risk of users opening phishing emails.", 'The method entails the use of CSS trickery to hide the "First Contact Safety Tip," which alerts users when they receive emails from an unknown address. Microsoft, which has acknowledged the issue, has yet to release a fix.', '"The First Contact Safety Tip is prepended to the body of an HTML email, which means it is possible to alter the way it is displayed through the use of CSS style tags," Austrian cybersecurity outfit Certitude said. "We can take this a step further, and spoof the icons Microsoft Outlook adds to emails that are encrypted and/or signed."', 'Watch as experts simulate real-world threats to demonstrate compelling advantages.', 'Get actionable steps and tools to harness the full potential of GenAI while protecting your sensitive data.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

