---
CP Source: The Hacker News
CP Execution date:  2024-08-08
Headline: "The Loper Bright Decision: How it Impacts Cybersecurity Law"
Date: 2024-08-05
Category: "Cybersecurity Law"
Sub-Category: "Data Privacy"

AI_technique_ID_1: "T1588.002"
AI_technique_1: "TOOL"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_1: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "AT"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_2: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"


AI_tactic_ID_1: "TA0040"
AI_technique_ID_1: "T1565.001; T1529; T1561.002; T1490; T1485; T1499.004; T1531; T1491; T1486; T1499.002; T1491.002; T1561.001; T1561; T1565; T1489; T1499; T1565.002; T1498; T1499.001; T1496; T1495; T1491.001; T1565.003; T1498.002; T1657; T1498.001; T1499.003"
AI_technique_1: "Disk Structure Wipe; External Defacement; System Shutdown/Reboot; Reflection Amplification; Disk Wipe; Service Exhaustion Flood; Transmitted Data Manipulation; Direct Network Flood; Resource Hijacking; Defacement; Data Manipulation; Internal Defacement; Runtime Data Manipulation; Account Access Removal; Endpoint Denial of Service; Stored Data Manipulation; Network Denial of Service; Application Exhaustion Flood; OS Exhaustion Flood; Disk Content Wipe; Data Encrypted for Impact; Data Destruction; Inhibit System Recovery; Firmware Corruption; Application or System Exploitation; Service Stop; Financial Theft"
AI_tactic_1: "IMPACT"
AI_tactic_url_1: "https://attack.mitre.org/tactics/TA0040"
AI_tactic_description_1: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
AI_matrix_domains_1: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1595.001; T1583.008; T1587; T1598.003; T1588.001; T1584.006; T1584.003; T1588; T1585; T1594; T1583.001; T1608.001; T1587.001; T1587.003; T1608.005; T1583.003; T1583.006; T1588.003; T1598; T1584.001; T1598.004; T1588.002; T1608; T1587.002; T1608.006; T1584.002; T1592.002; T1584.008; T1595.002; T1589.002; T1608.003; T1584; T1598.002; T1586.001; T1608.004; T1589; T1583.004; T1595; T1598.001; T1592; T1583.007; T1586; T1592.001; T1588.004; T1585.001; T1592.004; T1584.004; T1608.002; T1583; T1595.003; T1584.007"
AI_technique_1: "DNS Server; Server; Compromise Infrastructure; Serverless; Client Configurations; Vulnerability Scanning; Install Digital Certificate; Link Target; Acquire Infrastructure; Hardware; Obtain Capabilities; SEO Poisoning; Code Signing Certificates; Digital Certificates; Active Scanning; Virtual Private Server; Spearphishing Service; Stage Capabilities; Search Victim-Owned Websites; Web Services; Gather Victim Identity Information; Email Addresses; Wordlist Scanning; Spearphishing Voice; Malvertising; Tool; Upload Malware; Social Media Accounts; Develop Capabilities; Establish Accounts; Drive-by Target; Gather Victim Host Information; Scanning IP Blocks; Phishing for Information; Compromise Accounts; Upload Tool; Malware; Domains; Spearphishing Attachment; Network Devices; Spearphishing Link; Software"


AI_software_ID_1: "S0183"
AI_technique_ID_1: "T1090.003; T1573.002"
AI_technique_1: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_1: "TOR"
AI_software_type_1: "tool"
AI_software_url_1: "https://attack.mitre.org/software/S0183"
AI_software_description_1: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0110"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "At"
AI_software_2: "AT"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0110"
AI_software_description_2: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0075"
AI_technique_ID_3: "T1112; T1552.002; T1012"
AI_technique_3: "Credentials in Registry; Query Registry; Modify Registry"
AI_software_3: "REG"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0075"
AI_software_description_3: "Reg https://attack.mitre.org/software/S0075 is a Windows utility used to interact with the Windows Registry. It can be used at the commandline interface to query, add, modify, and remove information. Citation Microsoft Reg Utilities such as Reg https://attack.mitre.org/software/S0075 are known to be used by persistent threats. Citation Windows Commands JPCERT"
AI_matrix_domains_3: "enterprise-attack"

---

**title**
The Loper Bright Decision: How it Impacts Cybersecurity Law

**date**
05/08/2024

**url_news**
https://thehackernews.com/2024/08/the-loper-bright-decision-how-it.html

**thn_category_and_subcategory**
'Cybersecurity Law / Data Privacy'

**links**
'https://ballotpedia.org/Chevron_deference_(doctrine)', 'https://hyperproof.io/product/?utm_source=referral&utm_medium=hackernews&utm_campaign=2024%2520The%2520Hacker%2520News#risk-management'

**body**
'The Loper Bright decision has yielded impactful results: the Supreme Court has overturned forty years of administrative law, leading to potential litigation over the interpretation of ambiguous laws previously decided by federal agencies. This article explores key questions for cybersecurity professionals and leaders as we enter a more contentious period of cybersecurity law.', "The Loper Bright decision by the U.S. Supreme Court overruled the Chevron deference, stating that courts, not agencies, will decide all relevant questions of law arising on review of agency action. The Court held that because the Administrative Procedure Act (APA)'s text is clear, agency interpretations of statutes are not entitled to deference. The ruling emphasized that courts must exercise independent judgment in deciding whether an agency has acted within its statutory authority. This decision shifts the power of statutory interpretation from federal agencies to the judiciary.", "The Chevron deference required courts to defer to federal agencies' reasonable interpretations of ambiguous statutes. It originated from the 1984 Supreme Court case Chevron U.S.A., Inc. v. Natural Resources Defense Council. Under Chevron, if a statute was ambiguous, courts would defer to the agency's interpretation if it was reasonable. This deference shaped administrative law for nearly 40 years.", 'Nothing has changed, yet. However, to ensure compliance with cybersecurity regulations that might now be challenged in court, companies should:', 'Effective cybersecurity controls are deployed when they are mapped to one or more agreed-upon risks, which can include regulatory or legal requirements as well as external threats. Companies should consider updating or removing controls in light of any future jurisprudence based on Loper Bright only if those controls exclusively existed for regulatory purposes and did not mitigate additional risks. Companies should ensure that their controls have clear traceability to requirements so that they can quickly assess the effects of any future regulatory changes.', 'The Loper Bright decision will likely make cybersecurity regulations more vulnerable to legal challenges. Courts will no longer defer to agency interpretations of ambiguous statutes and will exercise their independent judgment. This shift may lead to more frequent legal challenges, increased scrutiny of regulations, and delays. A partial list of agencies that may be affected by litigation post-Loper Bright follows:', 'The Loper Bright decision may impact the consistency of cybersecurity regulations and enforcement across different jurisdictions. By eliminating the Chevron deference, courts now have more ability to interpret statutes independently, which could lead to varied interpretations and applications of cybersecurity laws. This inconsistency might force businesses to adapt their compliance programs more frequently due to varying interpretations across jurisdictions.', 'The removal of the Chevron deference will likely create a more fragmented and inconsistent regulatory environment for cybersecurity. Federal agencies will need to provide more compelling justifications and details for their rulemaking decisions. This shift may lead to increased judicial scrutiny of existing regulations and proposed rules, making it harder for agencies like the FTC and CISA to quickly adapt to new threats.', 'Courts will consider the persuasive power of agency interpretations, giving weight to their expertise only if it is especially informative and based on thorough, consistent reasoning. This shift is likely to result in increased legal challenges to existing cybersecurity regulations and new rulemakings, complicating compliance efforts.', 'Judicial interpretation will play a significant role in defining the scope of cybersecurity regulations post-Loper Bright. Courts will independently assess the statutory authority of agencies, leading to potentially more fragmented and inconsistent regulatory environments. This change necessitates a reevaluation of regulatory compliance and advocacy approaches.', 'Ultimately, the decision underscores the need for Congress to provide clearer statutory guidance for cybersecurity regulations to withstand judicial review.', 'Note: This article is expertly written and contributed by Kayne McGladrey, Field CISO at Hyperproof.', 'Watch as experts simulate real-world threats to demonstrate compelling advantages.', 'Get actionable steps and tools to harness the full potential of GenAI while protecting your sensitive data.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

