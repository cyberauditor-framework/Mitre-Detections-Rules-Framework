---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Streamlined Security Solutions: PAM for Small to Medium-sized Businesses "
Date: 2024-07-11
Category: "Compliance"
Sub-Category: "Identity Management"

ADD_INFORMATION_technique_ID: "T1566"
ADD_INFORMATION_technique: "PHISHING"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1566"
ADD_INFORMATION_technique_description: "Adversaries may send phishing messages to gain access to victim systems. All forms of phishing are electronically delivered social engineering. Phishing can be targeted, known as spearphishing. In spearphishing, a specific individual, company, or industry will be targeted by the adversary. More generally, adversaries can conduct non-targeted phishing, such as in mass malware spam campaigns.

Adversaries may send victims emails containing malicious attachments or links, typically to execute malicious code on victim systems. Phishing may also be conducted via third-party services, like social media platforms. Phishing may also involve social engineering techniques, such as posing as a trusted source, as well as evasive techniques such as removing or manipulating emails or metadata/headers from compromised accounts being abused to send messages (e.g., Email Hiding Rules(https://attack.mitre.org/techniques/T1564/008)).(Citation: Microsoft OAuth Spam 2022)(Citation: Palo Alto Unit 42 VBA Infostealer 2014) Another way to accomplish this is by forging or spoofing(Citation: Proofpoint-spoof) the identity of the sender which can be used to fool both the human recipient as well as automated security tools.(Citation: cyberproof-double-bounce) 

Victims may also receive phishing messages that instruct them to call a phone number where they are directed to visit a malicious URL, download malware,(Citation: sygnia Luna Month)(Citation: CISA Remote Monitoring and Management Software) or install adversary-accessible remote management tools onto their computer (i.e., User Execution(https://attack.mitre.org/techniques/T1204)).(Citation: Unit42 Luna Moth)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0012"
ADD_INFORMATION_technique_ID: "T1216.002, T1559, T1140, T1059.005, T1651, T1027, T1562.002, T1216, T1059.007, T1056.002, T1615, T1016, T1482, T1216.001, T1559.002, T1556.005, T1564.003, T1620, T1562, T1119, T1027.010, T1059, T1559.001, T1560.002, T1020, T1560.003, T1564.007, T1564, T1560, T1005, T1059.001"
ADD_INFORMATION_technique: "Hidden Window, PubPrn, SyncAppvPublishingServer, Reversible Encryption, Archive Collected Data, Command and Scripting Interpreter, Automated Exfiltration, JavaScript, Impair Defenses, PowerShell, Dynamic Data Exchange, Archive via Library, Disable Windows Event Logging, System Script Proxy Execution, GUI Input Capture, Command Obfuscation, Component Object Model, VBA Stomping, Hide Artifacts, Automated Collection, Visual Basic, Obfuscated Files or Information, Group Policy Discovery, Domain Trust Discovery, Inter-Process Communication, Reflective Code Loading, System Network Configuration Discovery, Cloud Administration Command, Data from Local System, Archive via Custom Method, Deobfuscate/Decode Files or Information"
ADD_INFORMATION_data_source: "SCRIPT"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0012"
ADD_INFORMATION_data_source_description: "A file or stream containing a list of commands, allowing them to be launched in sequence(Citation: Microsoft PowerShell Logging)(Citation: FireEye PowerShell Logging)(Citation: Microsoft AMSI)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1588.001, T1585, T1594, T1595.001, T1608.001, T1584.007, T1588, T1608.004, T1588.002, T1589, T1598.003, T1587.003, T1584.002, T1584, T1595.003, T1592, T1608.002, T1595, T1587.002, T1583.003, T1598.001, T1598.004, T1583.006, T1583.008, T1588.004, T1584.004, T1584.006, T1608.003, T1584.003, T1584.008, T1587.001, T1598, T1583.004, T1592.001, T1583.007, T1595.002, T1608, T1583, T1586.001, T1598.002, T1608.005, T1592.004, T1583.001, T1585.001, T1589.002, T1608.006, T1584.001, T1588.003, T1586, T1592.002, T1587"
ADD_INFORMATION_technique: "Digital Certificates, Drive-by Target, Compromise Accounts, Establish Accounts, Web Services, Tool, Spearphishing Voice, Obtain Capabilities, Stage Capabilities, Spearphishing Link, Serverless, Code Signing Certificates, Phishing for Information, Virtual Private Server, SEO Poisoning, Hardware, Server, Software, Install Digital Certificate, Upload Tool, Compromise Infrastructure, Search Victim-Owned Websites, Social Media Accounts, Gather Victim Identity Information, DNS Server, Malware, Domains, Gather Victim Host Information, Develop Capabilities, Link Target, Malvertising, Scanning IP Blocks, Acquire Infrastructure, Network Devices, Client Configurations, Active Scanning, Vulnerability Scanning, Email Addresses, Wordlist Scanning, Spearphishing Service, Upload Malware, Spearphishing Attachment"

ADD_INFORMATION_software_ID: "S0575"
ADD_INFORMATION_technique_ID: "T1106, T1018, T1135, T1489, T1140, T1059.003, T1049, T1027, T1021.002, T1083, T1490, T1057, T1055.001, T1016, T1486, T1080"
ADD_INFORMATION_technique: "Obfuscated Files or Information, System Network Connections Discovery, Process Discovery, Windows Command Shell, Native API, Service Stop, Remote System Discovery, Taint Shared Content, System Network Configuration Discovery, Network Share Discovery, SMB/Windows Admin Shares, File and Directory Discovery, Deobfuscate/Decode Files or Information, Inhibit System Recovery, Dynamic-link Library Injection, Data Encrypted for Impact"
ADD_INFORMATION_software: "CONTI"
ADD_INFORMATION_software_type: "malware"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0575"
ADD_INFORMATION_software_description: "Conti(https://attack.mitre.org/software/S0575) is a Ransomware-as-a-Service (RaaS) that was first observed in December 2019. Conti(https://attack.mitre.org/software/S0575) has been deployed via TrickBot(https://attack.mitre.org/software/S0266) and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti(https://attack.mitre.org/software/S0575) steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.(Citation: Cybereason Conti Jan 2021)(Citation: CarbonBlack Conti July 2020)(Citation: Cybleinc Conti January 2020)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Streamlined Security Solutions: PAM for Small to Medium-sized Businesses 

**date**
11/07/2024

**url_news**
https://thehackernews.com/2024/07/streamlined-security-solutions-pam-for.html

**thn_category_and_subcategory**
'Compliance / Identity Management'

**links**
'https://www.oneidentity.com/what-is-privileged-identity-management/', 'https://www.oneidentity.com/learn/what-is-access-control-in-cybersecurity.aspx', 'https://www.oneidentity.com/techbrief/adopting-a-saas-based-solution-to-secure-privileged-access-in-enterprise-it-/', 'https://www.oneidentity.com/what-is-privileged-access-management/'

**body**
'Today, all organizations are exposed to the threat of cyber breaches, irrespective of their scale. Historically, larger companies were frequent targets due to their substantial resources, sensitive data, and regulatory responsibilities, whereas smaller entities often underestimated their attractiveness to hackers. However, this assumption is precarious, as cybercriminals frequently exploit perceived vulnerabilities in smaller firms for expedient profit. ', 'Small to medium-sized organizations often lack the resources and expertise for robust privileged identity management. Yet they increasingly require PAM solutions. Fortunately, the market now offers numerous vendors specializing in these needs. Recognizing the demand for accessible solutions, these vendors provide affordable options tailored to organizations aiming to meet stringent compliance standards or enhance security practices, requiring minimal installation and maintenance to gain full access controls. ', 'To enhance threat awareness, many organizations train employees to identify phishing attacks. Extending this proactive approach to protect corporate assets is essential. A PAM tool defends against both external and internal threats. Despite concerns about fostering a surveillance culture, the primary goal is protection. ', 'Implementing a PAM solution demonstrates trust in your IT team, providing a safety net to exonerate them from suspicion in case of questionable activities, proving actions were neither malicious nor their own. ', 'The following are cybersecurity functions offered by a PAM solution: ', 'Small to medium-sized organizations do not need all the complex and convoluted setup required for a traditional PAM solution. This is why One Identity developed a PAM solution that caters specifically to small to medium-sized organizations, allowing businesses of any size to utilize session monitoring and recording, logging all activities carried out with privileged accounts to facilitate forensic analysis during security incidents. ', 'Offering a SaaS solution ensures quick implementation, allowing organizations to establish robust privileged access management without significant delays. Additionally, this approach promotes cost-efficiency through a subscription-based model, reducing upfront costs and eliminating the need for substantial investments in hardware or dedicated personnel.', 'Deploying a PAM solution for small to medium-sized enterprises is now straightforward. With accessible, affordable, and scalable options available, organizations can protect critical assets from external threats and insider risks effectively. By adopting proactive security measures and modern PAM technologies, these enterprises can ensure data protection, regulatory compliance, and operational continuity without undue complexity or resource strain. ', 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

