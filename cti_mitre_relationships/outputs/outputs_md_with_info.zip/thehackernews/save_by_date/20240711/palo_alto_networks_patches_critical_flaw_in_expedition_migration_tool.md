---
CP Source: The Hacker News
CP Execution date:  2024-07-16
Headline: "Palo Alto Networks Patches Critical Flaw in Expedition Migration Tool"
Date: 2024-07-11
Category: "Vulnerability"
Sub-Category: "Enterprise Security"

ADD_INFORMATION_technique_ID: "T1583.004"
ADD_INFORMATION_technique: "SERVER"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1583/004"
ADD_INFORMATION_technique_description: "Adversaries may buy, lease, rent, or obtain physical servers that can be used during targeting. Use of servers allows an adversary to stage, launch, and execute an operation. During post-compromise activity, adversaries may utilize servers for various tasks, such as watering hole operations in Drive-by Compromise(https://attack.mitre.org/techniques/T1189), enabling Phishing(https://attack.mitre.org/techniques/T1566) operations, or facilitating Command and Control(https://attack.mitre.org/tactics/TA0011). Instead of compromising a third-party Server(https://attack.mitre.org/techniques/T1584/004) or renting a Virtual Private Server(https://attack.mitre.org/techniques/T1583/003), adversaries may opt to configure and run their own servers in support of operations. Free trial periods of cloud servers may also be abused.(Citation: Free Trial PurpleUrchin)(Citation: Freejacked) 

Adversaries may only need a lightweight setup if most of their activities will take place using online infrastructure. Or, they may need to build extensive infrastructure if they want to test, communicate, and control other aspects of their activities on their own systems.(Citation: NYTStuxnet)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1657, T1499, T1565, T1499.003, T1491.002, T1565.001, T1565.002, T1495, T1499.001, T1491, T1498.001, T1561.002, T1565.003, T1561.001, T1498, T1499.002, T1529, T1486, T1531, T1489, T1498.002, T1561, T1499.004, T1490, T1491.001, T1485, T1496"
ADD_INFORMATION_technique: "Account Access Removal, Direct Network Flood, Runtime Data Manipulation, OS Exhaustion Flood, Application or System Exploitation, External Defacement, Disk Wipe, Data Destruction, Financial Theft, Internal Defacement, Transmitted Data Manipulation, Disk Content Wipe, Application Exhaustion Flood, Stored Data Manipulation, Inhibit System Recovery, Disk Structure Wipe, Defacement, Resource Hijacking, Data Encrypted for Impact, Service Exhaustion Flood, Service Stop, Reflection Amplification, System Shutdown/Reboot, Data Manipulation, Firmware Corruption, Endpoint Denial of Service, Network Denial of Service"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0018"
ADD_INFORMATION_technique_ID: "T1518.001, T1562, T1518, T1070, T1070.007, T1562.004, T1562.007"
ADD_INFORMATION_technique: "Disable or Modify Cloud Firewall, Software Discovery, Disable or Modify System Firewall, Security Software Discovery, Clear Network Connection History and Configurations, Impair Defenses, Indicator Removal"
ADD_INFORMATION_data_source: "FIREWALL"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0018"
ADD_INFORMATION_data_source_description: "A network security system, running locally on an endpoint or remotely as a service (ex: cloud environment), that monitors and controls incoming/outgoing network traffic based on predefined rules(Citation: AWS Sec Groups VPC)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "NETWORK"
ADD_INFORMATION_technique_ID: "T1027, T1071.003, T1600.001, T1071.002, T1071.001, T1090, T1136.001, T1505.003, T1190, T1552.004, T1070, T1136, T1057, T1078.003, T1562.001, T1562, T1046, T1070.007, T1098.004, T1083, T1124, T1601.002, T1556, T1037, T1601.001, T1078, T1018, T1561, T1490, T1599, T1573.001, T1110.004, T1542.004, T1006, T1110, T1016, T1110.001, T1072, T1205.001, T1542, T1059.008, T1602.001, T1562.003, T1098, T1600.002, T1552, T1048.003, T1090.003, T1090.002, T1602.002, T1071.004, T1037.004, T1205, T1049, T1110.003, T1201, T1556.004, T1110.002, T1542.001, T1059.004, T1070.003, T1082, T1573, T1020, T1033, T1529, T1573.002, T1071, T1056.001, T1599.001, T1048, T1542.005, T1040, T1562.004, T1495, T1505, T1665, T1547, T1056, T1557, T1600, T1095, T1561.002, T1027.008, T1059, T1561.001, T1601, T1105, T1090.001, T1005, T1020.001, T1078.001, T1602, T1653"
ADD_INFORMATION_technique: "Mail Protocols, System Network Connections Discovery, Network Device Authentication, Internal Proxy, File and Directory Discovery, Data from Configuration Repository, Pre-OS Boot, Encrypted Channel, Private Keys, Automated Exfiltration, Keylogging, Disk Content Wipe, System Time Discovery, Inhibit System Recovery, Multi-hop Proxy, Asymmetric Cryptography, Impair Command History Logging, System Owner/User Discovery, System Shutdown/Reboot, DNS, Clear Network Connection History and Configurations, Server Software Component, System Network Configuration Discovery, Non-Application Layer Protocol, Process Discovery, Local Accounts, System Information Discovery, Default Accounts, Network Boundary Bridging, Modify System Image, Network Service Discovery, SNMP (MIB Dump), Software Deployment Tools, System Firmware, Exfiltration Over Unencrypted Non-C2 Protocol, Credential Stuffing, RC Scripts, TFTP Boot, Disable or Modify Tools, Unix Shell, File Transfer Protocols, Clear Command History, Network Sniffing, Password Spraying, Remote System Discovery, Ingress Tool Transfer, Data from Local System, Disable or Modify System Firewall, Valid Accounts, Disable Crypto Hardware, Disk Wipe, Command and Scripting Interpreter, Weaken Encryption, Power Settings, Impair Defenses, Network Device Configuration Dump, Port Knocking, Disk Structure Wipe, Input Capture, Direct Volume Access, Obfuscated Files or Information, Network Address Translation Traversal, Create Account, Modify Authentication Process, SSH Authorized Keys, Unsecured Credentials, Proxy, Application Layer Protocol, Stripped Payloads, Reduce Key Space, Symmetric Cryptography, Password Guessing, Hide Infrastructure, Adversary-in-the-Middle, Traffic Signaling, Patch System Image, External Proxy, ROMMONkit, Brute Force, Password Cracking, Exploit Public-Facing Application, Indicator Removal, Traffic Duplication, Downgrade System Image, Account Manipulation, Exfiltration Over Alternative Protocol, Web Shell, Network Device CLI, Boot or Logon Initialization Scripts, Web Protocols, Boot or Logon Autostart Execution, Firmware Corruption, Local Account, Password Policy Discovery"

ADD_INFORMATION_software_ID: "S0075"
ADD_INFORMATION_technique_ID: "T1112, T1552.002, T1012"
ADD_INFORMATION_technique: "Modify Registry, Credentials in Registry, Query Registry"
ADD_INFORMATION_software: "REG"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0075"
ADD_INFORMATION_software_description: "Reg(https://attack.mitre.org/software/S0075) is a Windows utility used to interact with the Windows Registry. It can be used at the command-line interface to query, add, modify, and remove information. (Citation: Microsoft Reg)Utilities such as Reg(https://attack.mitre.org/software/S0075) are known to be used by persistent threats. (Citation: Windows Commands JPCERT)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Palo Alto Networks Patches Critical Flaw in Expedition Migration Tool

**date**
11/07/2024

**url_news**
https://thehackernews.com/2024/07/palo-alto-networks-patches-critical.html

**thn_category_and_subcategory**
'Vulnerability / Enterprise Security'

**links**
'https://security.paloaltonetworks.com/', 'https://security.paloaltonetworks.com/CVE-2024-5910', 'https://thehackernews.com/2024/07/radius-protocol-vulnerability-exposes.html', 'https://docs.paloaltonetworks.com/pan-os/9-1/pan-os-admin/authentication/configure-radius-authentication', 'https://security.paloaltonetworks.com/CVE-2024-3596'

**body**
'Palo Alto Networks has released security updates to address five security flaws impacting its products, including a critical bug that could lead to an authentication bypass.', 'Cataloged as CVE-2024-5910 (CVSS score: 9.3), the vulnerability has been described as a case of missing authentication in its Expedition migration tool that could lead to an admin account takeover.', '"Missing authentication for a critical function in Palo Alto Networks Expedition can lead to an Expedition admin account takeover for attackers with network access to Expedition," the company said in an advisory. "Configuration secrets, credentials, and other data imported into Expedition is at risk due to this issue."', "The flaw impacts all versions of Expedition prior to version 1.2.92, which remediates the problem. Synopsys Cybersecurity Research Center's (CyRC) Brian Hysell has been credited with discovering and reporting the issue.", 'While there is no evidence that the vulnerability has been exploited in the wild, users are advised to update to the latest version to secure against potential threats.', 'As workarounds, Palo Alto Networks is recommending that network access to Expedition is restricted to authorized users, hosts, or networks.', 'Also fixed by the American cybersecurity firm is a newly disclosed flaw in the RADIUS protocol called BlastRADIUS (CVE-2024-3596) that could allow a bad actor with capabilities to perform an adversary-in-the-middle (AitM) attack between Palo Alto Networks PAN-OS firewall and a RADIUS server to sidestep authentication.', 'The vulnerability then permits the attacker to "escalate privileges to \'superuser\' when RADIUS authentication is in use and either CHAP or PAP is selected in the RADIUS server profile," it said.', 'The following products are affected by the shortcomings:', 'It also noted that neither CHAP nor PAP should be used unless they are encapsulated by an encrypted tunnel since the authentication protocols do not offer Transport Layer Security (TLS). They are not vulnerable in cases where they are used in conjunction with a TLS tunnel.', "However, it's worth noting that PAN-OS firewalls configured to use EAP-TTLS with PAP as the authentication protocol for a RADIUS server are also not susceptible to the attack.", 'Struggling with developer resistance to security guidelines? Discover how Security Champions can change that dynamic. Register now.', 'Guard your business like a Fortune 500 with a fraction of the resources. Find out why All-in-One solutions are a game-changer.', 'Get the latest news, expert insights, exclusive resources, and strategies from industry leaders – all for free.'

