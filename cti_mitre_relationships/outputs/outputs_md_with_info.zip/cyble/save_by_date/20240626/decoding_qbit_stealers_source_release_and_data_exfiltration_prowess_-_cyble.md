---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Decoding QBit Stealer's Source Release And Data Exfiltration Prowess - Cyble"
Date: 2024-06-26
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0010"
ADD_INFORMATION_technique_ID: "T1048, T1048.002, T1567.004, T1020.001, T1052, T1048.003, T1011, T1011.001, T1567.001, T1537, T1041, T1048.001, T1567, T1029, T1567.003, T1020, T1030, T1567.002, T1052.001"
ADD_INFORMATION_technique: "Exfiltration Over Web Service, Exfiltration to Cloud Storage, Exfiltration Over Asymmetric Encrypted Non-C2 Protocol, Exfiltration to Text Storage Sites, Transfer Data to Cloud Account, Exfiltration Over Other Network Medium, Exfiltration Over Physical Medium, Exfiltration Over Alternative Protocol, Exfiltration Over Webhook, Automated Exfiltration, Exfiltration Over C2 Channel, Exfiltration Over Unencrypted Non-C2 Protocol, Traffic Duplication, Exfiltration over USB, Exfiltration Over Symmetric Encrypted Non-C2 Protocol, Exfiltration Over Bluetooth, Exfiltration to Code Repository, Data Transfer Size Limits, Scheduled Transfer"
ADD_INFORMATION_tactic: "EXFILTRATION"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0010"
ADD_INFORMATION_tactic_description: "The adversary is trying to steal data.Exfiltration consists of techniques that adversaries may use to steal data from your network. Once they’ve collected data, adversaries often package it to avoid detection while removing it. This can include compression and encryption. Techniques for getting data out of a target network typically include transferring it over their command and control channel or an alternate channel and may also include putting size limits on the transmission."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Decoding QBit Stealer's Source Release And Data Exfiltration Prowess - Cyble

**date**
26/06/2024

**url_news**
https://cyble.com/blog/decoding-qbit-stealers-source-release-and-data-exfiltration-prowess/

**cyble_category**
Infostealer

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Decoding qBit Stealers Source Release and Data Exfiltration Prowess Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

