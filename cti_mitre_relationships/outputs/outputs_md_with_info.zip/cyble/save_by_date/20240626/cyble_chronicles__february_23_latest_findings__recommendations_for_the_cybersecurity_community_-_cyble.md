---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Cyble Chronicles – February 23: Latest Findings & Recommendations For The Cybersecurity Community  - Cyble"
Date: 2024-06-26
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0012"
ADD_INFORMATION_technique_ID: "T1560.002, T1560.003, T1482, T1005, T1216.002, T1651, T1556.005, T1119, T1027.010, T1059.007, T1559.002, T1560, T1216, T1059.001, T1559, T1059, T1059.005, T1564.007, T1564.003, T1027, T1020, T1056.002, T1564, T1615, T1016, T1562, T1140, T1620, T1559.001, T1562.002, T1216.001"
ADD_INFORMATION_technique: "Component Object Model, SyncAppvPublishingServer, Impair Defenses, Obfuscated Files or Information, Cloud Administration Command, Hidden Window, Command Obfuscation, Automated Collection, Archive Collected Data, VBA Stomping, Data from Local System, Dynamic Data Exchange, Disable Windows Event Logging, Archive via Custom Method, GUI Input Capture, Command and Scripting Interpreter, Group Policy Discovery, Automated Exfiltration, Visual Basic, PubPrn, System Script Proxy Execution, Deobfuscate/Decode Files or Information, Hide Artifacts, System Network Configuration Discovery, Archive via Library, JavaScript, Reflective Code Loading, Domain Trust Discovery, Inter-Process Communication, Reversible Encryption, PowerShell"
ADD_INFORMATION_data_source: "SCRIPT"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0012"
ADD_INFORMATION_data_source_description: "A file or stream containing a list of commands, allowing them to be launched in sequence(Citation: Microsoft PowerShell Logging)(Citation: FireEye PowerShell Logging)(Citation: Microsoft AMSI)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Cyble Chronicles – February 23: Latest Findings & Recommendations For The Cybersecurity Community  - Cyble

**date**
26/06/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-february-23-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**
'https://cyble.com/blog/the-fate-of-the-criminalmw-group-endgame-or-a-new-rebranding-journey/', 'https://cyble.com/blog/asukastealer-a-revamped-version-of-the-observerstealer-advertised-as-malware-as-a-service/', 'https://thecyberexpress.com/decoding-tangerine-data-breach/', 'https://us06web.zoom.us/webinar/register/WN_PxsgvHqFTVinMZVLbX2PBQ#/registration'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles February 23: Latest Findings Recommendations for the Cybersecurity Community Recently, an enhanced version of the CriminalMW Android Banking Trojan was discovered, now available for rent at 5,000 per month on Telegram. This update includes new features like a unique overlay technique and targets 10 Brazilian banks using the PIX platform. Four threat actors, including SickoDevZ, have been linked to this malware. Law enforcement actions have led to the arrest of individuals associated with similar banking Trojans, including SickoDevZ. Despite these arrests, the emergence of a rebranding effort named WebDroid indicates that the CriminalMW Group continues to evolve, suggesting a larger network is still operational. Read the full analysis here. On February 2, 2024, Cyble Research Intelligence Labs CRIL discovered AsukaStealer, a MalwareasaService MaaS being marketed on a Russianlanguage cybercrime forum. This malware, in its version 0.9.7, is available for rent at USD 80 per month. Interestingly, AsukaStealer first made its appearance on another prominent Russian forum on January 24, 2024, under a different identity, showcasing its operators efforts to widely promote their malicious service. AsukaStealer, developed in C, is equipped with a range of functionalities and a userfriendly webbased control panel. It is adept at harvesting a variety of sensitive data including browser information, Discord and Telegram session details, credentials from FileZilla and Steam Desktop Authenticator, as well as data from crypto wallets and extensions. Additionally, it can capture screenshots from desktops. Further investigation suggests that AsukaStealer might be an evolved form of the previously known ObserverStealer malware, indicating its advanced and potentially more dangerous capabilities. Read the full analysis here. Tangerine, a major telecom operator, recently suffered a significant data breach affecting 232,000 customers. This incident, which took place on February 18, 2024, was only brought to the attention of Tangerines management two days later, on February 20. The breach resulted in the unauthorized disclosure of a substantial amount of personal customer data. The company issued a statement on February 21, 2024, detailing the extent of the data leak. Compromised information included customers full names, dates of birth, mobile and email contacts, postal addresses, and Tangerine account numbers. However, Tangerine assured that more sensitive data like credit/debit card details, drivers license numbers, ID documents, banking information, and passwords were not affected, as the company does not store such data. Read the complete article here. Join us on February 29, 2024, at 8:30 PM for an engaging and informative webinar: Navigating the Cyber Threat Landscape in 2024: Mastering Risk Scoring for Enhanced Security Posture. This session, led by the esteemed Ankit Sharma, Senior Director and Head of Solutions Engineering Sales, is meticulously designed to equip you with the knowledge and skills necessary to navigate the complexities of cyber threat risk scoring. Its an invaluable opportunity for those seeking to bolster their cybersecurity defenses with advanced strategies and insights. Attendees will gain insights into the latest trends and challenges in cyber threat evaluation alongside an exploration of cuttingedge methodologies and tools for risk assessment and scoring. Well also provide practical guidance on integrating risk scoring into your security strategy, supplemented by case studies and realworld applications that demonstrate the efficacy of these approaches in preempting and mitigating cyber threats. This session is tailormade for IT professionals, cybersecurity experts, risk management consultants, and CISOs keen on leveraging cyber threat risk scoring to enhance their organizations security posture. Attendees will also enjoy exclusive giveaways, including the latest issue of The Cyber Express, the newest Threat Landscape Report, and a threemonth Odin Subscription. Secure your spot for the webinar here Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

