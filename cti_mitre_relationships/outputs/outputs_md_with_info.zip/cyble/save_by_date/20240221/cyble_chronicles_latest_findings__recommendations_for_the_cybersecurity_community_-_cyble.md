---
CP Source: Cyble
CP Execution date:  2024-08-08
Headline: "Cyble Chronicles: Latest Findings & Recommendations For The Cybersecurity Community - Cyble"
Date: 2024-02-21
Category: ""

AI_technique_ID_1: "T1053.002"
AI_technique_1: "AT"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_1: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"


AI_software_ID_1: "S0575"
AI_technique_ID_1: "T1049; T1016; T1135; T1080; T1106; T1018; T1140; T1021.002; T1083; T1486; T1059.003; T1057; T1027; T1055.001; T1489; T1490"
AI_technique_1: "System Network Connections Discovery; System Network Configuration Discovery; Dynamic-link Library Injection; Native API; Process Discovery; Data Encrypted for Impact; Deobfuscate/Decode Files or Information; Service Stop; Taint Shared Content; Remote System Discovery; Windows Command Shell; File and Directory Discovery; Inhibit System Recovery; SMB/Windows Admin Shares; Obfuscated Files or Information; Network Share Discovery"
AI_software_1: "CONTI"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S0575"
AI_software_description_1: "Conti https://attack.mitre.org/software/S0575 is a RansomwareasaService RaaS that was first observed in December 2019. Conti https://attack.mitre.org/software/S0575 has been deployed via TrickBot https://attack.mitre.org/software/S0266 and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti https://attack.mitre.org/software/S0575 steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.Citation Cybereason Conti Jan 2021Citation CarbonBlack Conti July 2020Citation Cybleinc Conti January 2020"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0110"
AI_technique_ID_2: "T1053.002"
AI_technique_2: "At"
AI_software_2: "AT"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0110"
AI_software_description_2: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_2: "enterprise-attack"

---

**title**
Cyble Chronicles: Latest Findings & Recommendations For The Cybersecurity Community - Cyble

**date**
21/02/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles: Latest Findings Recommendations for the Cybersecurity Community Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

