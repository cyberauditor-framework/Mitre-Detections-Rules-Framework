---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Cyble Chronicles: Latest Findings & Recommendations For The Cybersecurity Community - Cyble"
Date: 2024-02-21
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Cyble Chronicles: Latest Findings & Recommendations For The Cybersecurity Community - Cyble

**date**
21/02/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles: Latest Findings Recommendations for the Cybersecurity Community Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

