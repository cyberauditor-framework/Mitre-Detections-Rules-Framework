---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Cyble Chronicles – January 25: Latest Findings & Recommendations For The Cybersecurity Community - Cyble"
Date: 2024-02-20
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0010"
ADD_INFORMATION_technique_ID: "T1048, T1048.002, T1567.004, T1020.001, T1052, T1048.003, T1011, T1011.001, T1567.001, T1537, T1041, T1048.001, T1567, T1029, T1567.003, T1020, T1030, T1567.002, T1052.001"
ADD_INFORMATION_technique: "Exfiltration Over Web Service, Exfiltration to Cloud Storage, Exfiltration Over Asymmetric Encrypted Non-C2 Protocol, Exfiltration to Text Storage Sites, Transfer Data to Cloud Account, Exfiltration Over Other Network Medium, Exfiltration Over Physical Medium, Exfiltration Over Alternative Protocol, Exfiltration Over Webhook, Automated Exfiltration, Exfiltration Over C2 Channel, Exfiltration Over Unencrypted Non-C2 Protocol, Traffic Duplication, Exfiltration over USB, Exfiltration Over Symmetric Encrypted Non-C2 Protocol, Exfiltration Over Bluetooth, Exfiltration to Code Repository, Data Transfer Size Limits, Scheduled Transfer"
ADD_INFORMATION_tactic: "EXFILTRATION"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0010"
ADD_INFORMATION_tactic_description: "The adversary is trying to steal data.Exfiltration consists of techniques that adversaries may use to steal data from your network. Once they’ve collected data, adversaries often package it to avoid detection while removing it. This can include compression and encryption. Techniques for getting data out of a target network typically include transferring it over their command and control channel or an alternate channel and may also include putting size limits on the transmission."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1585, T1586, T1586.001, T1585.001"
ADD_INFORMATION_technique: "Establish Accounts, Compromise Accounts, Social Media Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Cyble Chronicles – January 25: Latest Findings & Recommendations For The Cybersecurity Community - Cyble

**date**
20/02/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-january-25-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**
'https://cyble.com/blog/cyble-global-sensors-pick-up-persistent-exploitation-of-ivanti-connect-secure-vulnerabilities/', 'https://cyble.com/blog/threat-actors-target-us-asylum-seekers-with-metastealer-malware/', 'https://thecyberexpress.com/loandepot-cyberattack-exposes-millions-of-data/', 'https://www.brighttalk.com/webcast/10415/602964?bt'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles January 25: Latest Findings Recommendations for the Cybersecurity Community Cyble Global Sensor Intelligence CGSI has detected the continuous exploitation of recently revealed vulnerabilities in Ivanti Connect Secure ICS, formerly known as Pulse Connect Secure and Ivanti Policy Secure gateways. Ivanti issued a security alert on January 10, 2024, addressing vulnerabilities found in Ivanti Connect Secure ICS, namely CVE202346805 and CVE202421887. When CVE202421887 is combined with CVE202346805, unauthorized exploitation becomes possible without authentication, allowing a Threat Actor TA to create malicious requests, leading to the execution of arbitrary commands on the system. The Cybersecurity and Infrastructure Security Agency CISA also warned about these vulnerabilities. On the same day, Volexity revealed instances of realworld exploitation of the previous two vulnerabilities, facilitating unauthenticated remote code execution on Ivanti Connect Secure VPN devices. The TA utilized these exploits to exfiltrate configuration data, alter existing files, retrieve remote files, and establish a reverse tunnel from the ICS VPN appliance. Furthermore, a cybercriminal offered an exploit for sale on a forum for USD 30,000. This ongoing threat highlights the need for organizations to follow mitigation strategies, apply patches, and maintain vigilance in monitoring vulnerabilities to fortify their cybersecurity infrastructure. Read Cybles detailed analysis of this vulnerability here. Cyble Research and Intelligence Labs CRIL uncovered a malicious campaign targeting individuals seeking asylum in the US with MetaStealer malware. The campaign involves a ZIP archive file distributed via a URL or potentially through spam emails. Inside the ZIP file is a deceptive shortcut LNK file disguised as a PDF document. When executed, this LNK file triggers a VPN application, which uses DLL sideloading to load a hidden malicious DLL, both concealed within the ZIP. The loaded DLL drops an MSI installer, initiating the download of a deceptive PDF lure and a malware stealer known as MetaStealer, which connects to a CommandandControl CC server for data exfiltration. The attackers utilize social engineering tactics by disguising the lure as a legitimate I589, Application for Asylum and for Withholding of Removal PDF document, increasing the chances of users opening it. Once executed, MetaStealer collects sensitive information, manipulates Windows Defender settings to evade detection, and establishes communication with the CC server over encrypted HTTP connections. The multilayered attack strategy effectively conceals the malicious activities and enables the exfiltration of data. Read Cybles detailed analysis of this campaign here. LoanDepot, Inc., a prominent home lending solutions provider, disclosed a cyberattack in which an unauthorized third party accessed sensitive personal information of approximately 16.6 million individuals. In response, the company has taken swift action, notifying affected individuals and offering free credit monitoring and identity protection services. An ongoing investigation, conducted in collaboration with external forensics and security experts, aims to understand the extent of the breach and restore normal operations. CEO Frank Martell expressed regret over the incident, emphasizing the increasingly frequent and sophisticated nature of cyberattacks. The company is dedicated to resolving the situation and supporting affected customers. Substantial progress has been made in restoring loan origination and servicing systems, including customer portals. The companys ongoing efforts and collaboration with cybersecurity experts aim to bolster its defenses against future threats. Customers and stakeholders can stay informed through the dedicated microsite loandepot.cyberincidentupdate.com. Read The Cyber Express coverage of this incident here. The global supply chain is vulnerable to cyberattacks due to its diverse and multifaceted aspects. Cybersecurity supply chain risk management guidance is essential for businesses to protect themselves, their partners, and their consumers. They must assess cybersecurity risks at all levels of their organization and consider the vulnerabilities of all players involved in creating a product or service, particularly in light of increasing incidences of cyberattacks carried on supply chains. Threat Actors have shifted their tactics to compromise firms via their supply chains in an attempt to identify and exploit the weakest links, requiring organizations to reevaluate their cybersecurity approach accordingly. Join Kaustubh Medhe, VP Research and Threat Intelligence at Cyble, as he presents his findings and predictions at the CSA CloudBytes Webinar on January 31, 2024. Reserve your spot now Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

