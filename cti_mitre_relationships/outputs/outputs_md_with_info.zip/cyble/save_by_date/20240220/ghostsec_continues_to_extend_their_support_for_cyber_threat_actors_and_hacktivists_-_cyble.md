---
CP Source: Cyble
CP Execution date:  2024-08-08
Headline: "GhostSec Continues To Extend Their Support For Cyber Threat Actors And Hacktivists - Cyble"
Date: 2024-02-20
Category: ""

AI_technique_ID_1: "T1586.001"
AI_technique_1: "SOCIAL MEDIA ACCOUNTS"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1586/001"
AI_technique_description_1: "Adversaries may compromise social media accounts that can be used during targeting. For operations incorporating social engineering, the utilization of an online persona may be important. Rather than creating and cultivating social media profiles i.e. Social Media Accounts https://attack.mitre.org/techniques/T1585/001, adversaries may compromise existing social media accounts. Utilizing an existing persona may engender a level of trust in a potential victim if they have a relationship, or knowledge of, the compromised persona. A variety of methods exist for compromising social media accounts, such as gathering credentials via Phishing for Information https://attack.mitre.org/techniques/T1598, purchasing credentials from thirdparty sites, or by brute forcing credentials ex password reuse from breach credential dumps.Citation AnonHBGary Prior to compromising social media accounts, adversaries may conduct Reconnaissance to inform decisions about which accounts to compromise to further their operation. Personas may exist on a single site or across multiple sites ex Facebook, LinkedIn, Twitter, etc.. Compromised social media accounts may require additional development, this could include filling out or modifying profile information, further developing social networks, or incorporating photos. Adversaries can use a compromised social media profile to create new, or hijack existing, connections to targets of interest. These connections may be direct or may include trying to connect through others.Citation NEWSCASTER2014Citation BlackHatRobinSage Compromised profiles may be leveraged during other phases of the adversary lifecycle, such as during Initial Access ex Spearphishing via Service https://attack.mitre.org/techniques/T1566/003."
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1585.001"
AI_technique_2: "SOCIAL MEDIA ACCOUNTS"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1585/001"
AI_technique_description_2: "Adversaries may create and cultivate social media accounts that can be used during targeting. Adversaries can create social media accounts that can be used to build a persona to further operations. Persona development consists of the development of public information, presence, history and appropriate affiliations.Citation NEWSCASTER2014Citation BlackHatRobinSage For operations incorporating social engineering, the utilization of a persona on social media may be important. These personas may be fictitious or impersonate real people. The persona may exist on a single social media site or across multiple sites ex Facebook, LinkedIn, Twitter, etc.. Establishing a persona on social media may require development of additional documentation to make them seem real. This could include filling out profile information, developing social networks, or incorporating photos. Once a persona has been developed an adversary can use it to create connections to targets of interest. These connections may be direct or may include trying to connect through others.Citation NEWSCASTER2014Citation BlackHatRobinSage These accounts may be leveraged during other phases of the adversary lifecycle, such as during Initial Access ex Spearphishing via Service https://attack.mitre.org/techniques/T1566/003."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1593.001"
AI_technique_3: "SOCIAL MEDIA"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1593/001"
AI_technique_description_3: "Adversaries may search social media for information about victims that can be used during targeting. Social media sites may contain various information about a victim organization, such as business announcements as well as information about the roles, locations, and interests of staff. Adversaries may search in different social media sites depending on what information they seek to gather. Threat actors may passively harvest data from these sites, as well as use information gathered to create fake profilesgroups to elicit victims into revealing specific information i.e. Spearphishing Service https://attack.mitre.org/techniques/T1598/001.Citation Cyware Social Media Information from these sources may reveal opportunities for other forms of reconnaissance ex Phishing for Information https://attack.mitre.org/techniques/T1598 or Search Open Technical Databases https://attack.mitre.org/techniques/T1596, establishing operational resources ex Establish Accounts https://attack.mitre.org/techniques/T1585 or Compromise Accounts https://attack.mitre.org/techniques/T1586, andor initial access ex Spearphishing via Service https://attack.mitre.org/techniques/T1566/003."
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"
AI_technique_ID_4: "T1053.002"
AI_technique_4: "AT"
AI_technique_url_4: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_4: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_4: "False"
AI_technique_revoked_4: "False"
AI_matrix_domains_4: "enterprise-attack"


AI_tactic_ID_1: "TA0040"
AI_technique_ID_1: "T1565.002; T1561; T1529; T1657; T1486; T1561.001; T1491.002; T1565.003; T1496; T1531; T1499.003; T1498.002; T1490; T1561.002; T1499.004; T1491; T1491.001; T1485; T1499.002; T1498.001; T1499.001; T1565.001; T1498; T1495; T1489; T1565; T1499"
AI_technique_1: "Network Denial of Service; Firmware Corruption; Application Exhaustion Flood; Reflection Amplification; Account Access Removal; Data Encrypted for Impact; Direct Network Flood; Endpoint Denial of Service; Service Exhaustion Flood; Runtime Data Manipulation; Disk Structure Wipe; Inhibit System Recovery; Defacement; Data Destruction; Application or System Exploitation; External Defacement; OS Exhaustion Flood; Internal Defacement; Transmitted Data Manipulation; Service Stop; Stored Data Manipulation; Financial Theft; Disk Content Wipe; Disk Wipe; Data Manipulation; Resource Hijacking; System Shutdown/Reboot"
AI_tactic_1: "IMPACT"
AI_tactic_url_1: "https://attack.mitre.org/tactics/TA0040"
AI_tactic_description_1: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
AI_matrix_domains_1: "enterprise-attack"


AI_data_source_ID_1: "DS0019"
AI_technique_ID_1: "T1197; T1569; T1543.003; T1036.004; T1036; T1574; T1021.006; T1543.002; T1543.001; T1569.002; T1543; T1562.001; T1557; T1490; T1543.004; T1569.001; T1557.001; T1574.010; T1562; T1564; T1564.006; T1489; T1574.005; T1574.011"
AI_technique_1: "Service Execution; Masquerading; Launch Daemon; Launchctl; Create or Modify System Process; Masquerade Task or Service; Hijack Execution Flow; Executable Installer File Permissions Weakness; Systemd Service; Adversary-in-the-Middle; Services Registry Permissions Weakness; LLMNR/NBT-NS Poisoning and SMB Relay; Inhibit System Recovery; Hide Artifacts; Launch Agent; Windows Service; Service Stop; Impair Defenses; Run Virtual Instance; Windows Remote Management; System Services; BITS Jobs; Services File Permissions Weakness; Disable or Modify Tools"
AI_data_source_1: "SERVICE"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0019"
AI_data_source_description_1: "A computer process that is configured to execute continuously in the background and perform system tasks, in some cases before any user has logged inCitation Microsoft ServicesCitation Linux Services Run Levels"
AI_matrix_domains_1: "enterprise-attack"
AI_data_source_ID_2: "DS0021"
AI_technique_ID_2: "T1585.001; T1585; T1586.001; T1586"
AI_technique_2: "Social Media Accounts; Compromise Accounts; Establish Accounts"
AI_data_source_2: "PERSONA"
AI_data_source_url_2: "https://attack.mitre.org/datasources/DS0021"
AI_data_source_description_2: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
AI_matrix_domains_2: "enterprise-attack"
AI_data_source_ID_3: "DS0007"
AI_technique_ID_3: "T1485; T1204; T1612; T1036; T1564.006; T1036.005; T1525; T1204.003"
AI_technique_3: "Implant Internal Image; Masquerading; Run Virtual Instance; Build Image on Host; Match Legitimate Name or Location; User Execution; Data Destruction; Malicious Image"
AI_data_source_3: "IMAGE"
AI_data_source_url_3: "https://attack.mitre.org/datasources/DS0007"
AI_data_source_description_3: "A single file used to deploy a virtual machinebootable disk into an onpremise or thirdparty cloud environmentCitation Microsoft ImageCitation Amazon AMI"
AI_matrix_domains_3: "enterprise-attack"
AI_data_source_ID_4: "DS0036"
AI_technique_ID_4: "T1087.001; T1069.001; T1098; T1069.003; T1069; T1098.002; T1087.002; T1069.002"
AI_technique_4: "Cloud Groups; Permission Groups Discovery; Local Account; Local Groups; Domain Account; Domain Groups; Additional Email Delegate Permissions; Account Manipulation"
AI_data_source_4: "GROUP"
AI_data_source_url_4: "https://attack.mitre.org/datasources/DS0036"
AI_data_source_description_4: "A collection of multiple user accounts that share the same access rights to the computer andor network resources and have common security rightsCitation Amazon IAM Groups"
AI_matrix_domains_4: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1608.003; T1587.001; T1595; T1598.003; T1608.001; T1608.004; T1586.001; T1595.003; T1588.001; T1584.003; T1588; T1584.006; T1589; T1585; T1584.004; T1594; T1595.001; T1598.002; T1583.001; T1584; T1583.007; T1584.007; T1587; T1584.008; T1588.002; T1588.003; T1598.004; T1586; T1583; T1588.004; T1583.006; T1583.008; T1589.002; T1584.002; T1608.006; T1584.001; T1585.001; T1587.003; T1592; T1598; T1583.003; T1583.004; T1595.002; T1592.004; T1592.002; T1587.002; T1608.005; T1608; T1608.002; T1592.001; T1598.001"
AI_technique_1: "DNS Server; Upload Tool; Compromise Accounts; Digital Certificates; Serverless; Search Victim-Owned Websites; Develop Capabilities; Upload Malware; Obtain Capabilities; SEO Poisoning; Gather Victim Host Information; Drive-by Target; Spearphishing Voice; Server; Stage Capabilities; Domains; Active Scanning; Gather Victim Identity Information; Compromise Infrastructure; Email Addresses; Social Media Accounts; Spearphishing Attachment; Client Configurations; Spearphishing Link; Software; Establish Accounts; Malware; Phishing for Information; Acquire Infrastructure; Virtual Private Server; Scanning IP Blocks; Tool; Malvertising; Spearphishing Service; Network Devices; Code Signing Certificates; Wordlist Scanning; Hardware; Link Target; Web Services; Install Digital Certificate; Vulnerability Scanning"


AI_software_ID_1: "S0575"
AI_technique_ID_1: "T1049; T1016; T1135; T1080; T1106; T1018; T1140; T1021.002; T1083; T1486; T1059.003; T1057; T1027; T1055.001; T1489; T1490"
AI_technique_1: "System Network Connections Discovery; System Network Configuration Discovery; Dynamic-link Library Injection; Native API; Process Discovery; Data Encrypted for Impact; Deobfuscate/Decode Files or Information; Service Stop; Taint Shared Content; Remote System Discovery; Windows Command Shell; File and Directory Discovery; Inhibit System Recovery; SMB/Windows Admin Shares; Obfuscated Files or Information; Network Share Discovery"
AI_software_1: "CONTI"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S0575"
AI_software_description_1: "Conti https://attack.mitre.org/software/S0575 is a RansomwareasaService RaaS that was first observed in December 2019. Conti https://attack.mitre.org/software/S0575 has been deployed via TrickBot https://attack.mitre.org/software/S0266 and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti https://attack.mitre.org/software/S0575 steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.Citation Cybereason Conti Jan 2021Citation CarbonBlack Conti July 2020Citation Cybleinc Conti January 2020"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0039"
AI_technique_ID_2: "T1049; T1135; T1087.001; T1569.002; T1136.001; T1007; T1069.001; T1124; T1018; T1201; T1021.002; T1070.005; T1136.002; T1087.002; T1069.002"
AI_technique_2: "System Network Connections Discovery; System Time Discovery; Service Execution; Local Groups; Local Account; Domain Account; Domain Groups; System Service Discovery; Remote System Discovery; Network Share Connection Removal; Password Policy Discovery; SMB/Windows Admin Shares; Network Share Discovery"
AI_software_2: "NET"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0039"
AI_software_description_2: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0361"
AI_technique_ID_3: "T1564.004; T1570; T1140"
AI_technique_3: "NTFS File Attributes; Lateral Tool Transfer; Deobfuscate/Decode Files or Information"
AI_software_3: "EXPAND"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0361"
AI_software_description_3: "Expand https://attack.mitre.org/software/S0361 is a Windows utility used to expand one or more compressed CAB files.Citation Microsoft Expand Utility It has been used by BBSRAT https://attack.mitre.org/software/S0127 to decompress a CAB file into executable content.Citation Palo Alto Networks BBSRAT"
AI_matrix_domains_3: "enterprise-attack"
AI_software_ID_4: "S0183"
AI_technique_ID_4: "T1090.003; T1573.002"
AI_technique_4: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_4: "TOR"
AI_software_type_4: "tool"
AI_software_url_4: "https://attack.mitre.org/software/S0183"
AI_software_description_4: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_4: "enterprise-attack"
AI_software_ID_5: "S0110"
AI_technique_ID_5: "T1053.002"
AI_technique_5: "At"
AI_software_5: "AT"
AI_software_type_5: "tool"
AI_software_url_5: "https://attack.mitre.org/software/S0110"
AI_software_description_5: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_5: "enterprise-attack"

---

**title**
GhostSec Continues To Extend Their Support For Cyber Threat Actors And Hacktivists - Cyble

**date**
20/02/2024

**url_news**
https://cyble.com/blog/ghostsec-continues-to-extend-their-support-for-cyber-threat-actors-and-hacktivists/

**cyble_category**
Hacktivism

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog GhostSec Continues to Extend their Support for Cyber Threat Actors and Hacktivists Recently, notorious hacktivist group GhostSec unveiled their new project dubbed LowCostDatabase, with the goal of raising funds to support activists and hacktivists who have been operating under false identities or seeking asylum for their actions, which they believe are justified by a desire to fight for a noble cause. Figure 1: GhostSecs announcement for their new fundraiser project The group further stated that the offered databases were not publicly leaked ones but rather sourced from collaborators. The group also shared a Telegram handle for collaborating with them. At the time of investigation, the projects Telegram channel had 2,676 subscribers. Furthermore, the channel has already offered 28 datasets in exchange for amounts ranging from 40 to 70 USD, which impacts organizations based in India, Japan, Vietnam, Montenegro, Poland, Russia, South Africa, Switzerland, and Ukraine. The groups involvement in assisting activists in anonymizing their identities is not a new phenomenon. In December 2022, the group began their project NewBlood with the goal of sharing knowledge about hacking with newcomers who can participate in campaigns once they have the necessary skills. Later, the group also launched WeFreeInternet, a project aimed at offering free VPN services to Iranian activists. The group also indicated their plans to expand the service to other nations where the internet is restricted by the government. Figure 2:GostSecs WeFreeInternet Project The move was also acknowledged by another hacktivist collective ThreatSec. Figure 3: ThreatSec supporting GhostSecs WeFreeInternet project With the activities that the group alleges were for social causes, the group had leaked or offered Personally Identifiable Information PII multiple times. This data can be used by activists and other fraudsters for identity theft, a cybercrime activity in which the threat actor takes over the victims identity and conducts a range of fraudulent activities impersonating their identity. Figure 4: GhosSec leaking PIIs of the Users A similar belief can also be reflected in the groups Operational Security OPSEC recommendations for activists engaging in the campaigns, which encouraged them to ask friends/peers to make postings on their behalf on social media platforms to conceal their true identities. The recommendation also included tactics on how to safely use social media handles, censoring information in images, which can uncover identities, and removing metadata from them before posting. The selfproclaimed vigilante group GhostSec is known to be part of the Anonymous collective and has been active since 2015. Their operations gained momentum in 2015 when they claimed to have taken down hundreds of ISISaffiliated websites or social media accounts and supposedly obstructed potential terrorist attacks. The group used social media hashtags like GhostSec, GhostSecurity, or OpISIS to promote their activities and participated in the opisis hacktivist initiative against ISIS. The group has also been part of OpNigeria, as well as OpIsrael campaigns targeting the organizations in Nigeria and Israel, respectively. The group, along with ThreatSec, Stormous, BlackForums, and SeigedSec form the collective, The Five Families. Their Telegram channel was created on October 25, 2020, as the official channel of the GhostSec group. The group frequently utilizes its social media handles on Telegram and Twitter to promote its activities. They also have a presence on other social media websites, including Instagram, YouTube, BitChute, Medium, and Odysee. With an increased rate of cybercrime, the anonymity of threat actors will continue to pose a significant challenge for law enforcement agencies and cybersecurity professionals worldwide. The anonymity makes it difficult for professionals to attribute and keep track of their contemporary threat activities. The threat actors may switch to a new identity anytime that will subsequently hamper the threat assessments while the attack campaigns continue to flourish in the wild, leaving the organizations startled when subjected to an attack. Support to conceal identity, such as that offered by wellfunded hacktivist groups like GhostSec, can further exacerbate the challenge by encouraging malicious activities and potentially giving rise to various threats from statesponsored groups. Overall, the anonymity of threat actors is a significant challenge that will require a concerted international effort from law enforcement agencies and cyber security communities to mitigate the risks. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

