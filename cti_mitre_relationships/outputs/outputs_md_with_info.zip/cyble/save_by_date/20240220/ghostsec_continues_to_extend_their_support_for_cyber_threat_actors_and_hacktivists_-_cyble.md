---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "GhostSec Continues To Extend Their Support For Cyber Threat Actors And Hacktivists - Cyble"
Date: 2024-02-20
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1499.003, T1561, T1565.001, T1561.002, T1491.001, T1489, T1498.002, T1499, T1486, T1565, T1657, T1561.001, T1499.004, T1491.002, T1499.002, T1531, T1495, T1491, T1499.001, T1529, T1496, T1565.002, T1498.001, T1490, T1485, T1498, T1565.003"
ADD_INFORMATION_technique: "OS Exhaustion Flood, Defacement, Internal Defacement, Resource Hijacking, Endpoint Denial of Service, Application Exhaustion Flood, Runtime Data Manipulation, Disk Structure Wipe, Direct Network Flood, Service Stop, Transmitted Data Manipulation, Application or System Exploitation, Data Encrypted for Impact, Data Destruction, Firmware Corruption, Inhibit System Recovery, Disk Content Wipe, Reflection Amplification, Account Access Removal, Financial Theft, Disk Wipe, Stored Data Manipulation, Network Denial of Service, External Defacement, Service Exhaustion Flood, Data Manipulation, System Shutdown/Reboot"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1585, T1586, T1586.001, T1585.001"
ADD_INFORMATION_technique: "Establish Accounts, Compromise Accounts, Social Media Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
GhostSec Continues To Extend Their Support For Cyber Threat Actors And Hacktivists - Cyble

**date**
20/02/2024

**url_news**
https://cyble.com/blog/ghostsec-continues-to-extend-their-support-for-cyber-threat-actors-and-hacktivists/

**cyble_category**
Hacktivism

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog GhostSec Continues to Extend their Support for Cyber Threat Actors and Hacktivists Recently, notorious hacktivist group GhostSec unveiled their new project dubbed LowCostDatabase, with the goal of raising funds to support activists and hacktivists who have been operating under false identities or seeking asylum for their actions, which they believe are justified by a desire to fight for a noble cause. Figure 1: GhostSecs announcement for their new fundraiser project The group further stated that the offered databases were not publicly leaked ones but rather sourced from collaborators. The group also shared a Telegram handle for collaborating with them. At the time of investigation, the projects Telegram channel had 2,676 subscribers. Furthermore, the channel has already offered 28 datasets in exchange for amounts ranging from 40 to 70 USD, which impacts organizations based in India, Japan, Vietnam, Montenegro, Poland, Russia, South Africa, Switzerland, and Ukraine. The groups involvement in assisting activists in anonymizing their identities is not a new phenomenon. In December 2022, the group began their project NewBlood with the goal of sharing knowledge about hacking with newcomers who can participate in campaigns once they have the necessary skills. Later, the group also launched WeFreeInternet, a project aimed at offering free VPN services to Iranian activists. The group also indicated their plans to expand the service to other nations where the internet is restricted by the government. Figure 2:GostSecs WeFreeInternet Project The move was also acknowledged by another hacktivist collective ThreatSec. Figure 3: ThreatSec supporting GhostSecs WeFreeInternet project With the activities that the group alleges were for social causes, the group had leaked or offered Personally Identifiable Information PII multiple times. This data can be used by activists and other fraudsters for identity theft, a cybercrime activity in which the threat actor takes over the victims identity and conducts a range of fraudulent activities impersonating their identity. Figure 4: GhosSec leaking PIIs of the Users A similar belief can also be reflected in the groups Operational Security OPSEC recommendations for activists engaging in the campaigns, which encouraged them to ask friends/peers to make postings on their behalf on social media platforms to conceal their true identities. The recommendation also included tactics on how to safely use social media handles, censoring information in images, which can uncover identities, and removing metadata from them before posting. The selfproclaimed vigilante group GhostSec is known to be part of the Anonymous collective and has been active since 2015. Their operations gained momentum in 2015 when they claimed to have taken down hundreds of ISISaffiliated websites or social media accounts and supposedly obstructed potential terrorist attacks. The group used social media hashtags like GhostSec, GhostSecurity, or OpISIS to promote their activities and participated in the opisis hacktivist initiative against ISIS. The group has also been part of OpNigeria, as well as OpIsrael campaigns targeting the organizations in Nigeria and Israel, respectively. The group, along with ThreatSec, Stormous, BlackForums, and SeigedSec form the collective, The Five Families. Their Telegram channel was created on October 25, 2020, as the official channel of the GhostSec group. The group frequently utilizes its social media handles on Telegram and Twitter to promote its activities. They also have a presence on other social media websites, including Instagram, YouTube, BitChute, Medium, and Odysee. With an increased rate of cybercrime, the anonymity of threat actors will continue to pose a significant challenge for law enforcement agencies and cybersecurity professionals worldwide. The anonymity makes it difficult for professionals to attribute and keep track of their contemporary threat activities. The threat actors may switch to a new identity anytime that will subsequently hamper the threat assessments while the attack campaigns continue to flourish in the wild, leaving the organizations startled when subjected to an attack. Support to conceal identity, such as that offered by wellfunded hacktivist groups like GhostSec, can further exacerbate the challenge by encouraging malicious activities and potentially giving rise to various threats from statesponsored groups. Overall, the anonymity of threat actors is a significant challenge that will require a concerted international effort from law enforcement agencies and cyber security communities to mitigate the risks. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

