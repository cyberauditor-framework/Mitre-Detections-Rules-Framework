---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Cyble Recognized In Forrester's Attack Surface Management Solutions Landscape Q2 2024 Report  - Cyble"
Date: 2024-07-04
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Cyble Recognized In Forrester's Attack Surface Management Solutions Landscape Q2 2024 Report  - Cyble

**date**
04/07/2024

**url_news**
https://cyble.com/blog/cyble-recognized-in-forresters-attack-surface-management-solutions-landscape-q2-2024-report/

**cyble_category**
Annoucement

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Recognized in Forresters Attack Surface Management Solutions Landscape Q2 2024 Report Organizations need to eliminate digital risks, blind spots, and potential threats, and ensure effective detection and response. This is where Attack Surface Management ASM comes into play. ASM as a solution has evolved in the past 4 5 years with an aim to help security teams gain visibility into unknown technology assets. Initially, it focused into two areas: Today, the capabilities EASM and CASM have converged to provide a unified approach to managing an organizations entire attack surface and help organizations prioritize and remediate security gaps effectively. Organizations can leverage ASM to: Cyble has been recognized among 37 vendors in the Attack Surface Management Solutions Landscape Report Q2 2024 by Forrester. This recognition underscores our dedication to providing comprehensive ASM solutions to our customers. Recognition and Evaluation: The report provides an overview of the ASM solutions market, explores the value that security and risk SR professionals can expect from various vendors, and offers guidance on vendor options based on company size and market focus. Cybles Top Focus Areas: In the Forrester evaluation, each vendor was asked to highlight their top three focus areas for extended use cases. These use cases go beyond the core functions and represent the areas where the vendor wants to be recognized. Cyble chose to focus on Exposure Management, Threat Hunting and Investigations, and ThirdParty and Supply Chain Monitoring. Cyble sets itself apart in the ASM landscape through proactive and continuous monitoring and assessment of vulnerabilities and potential entry points that malicious actors could exploit for unauthorized system or network access. Cyble leverages advanced AI and ML techniques to provide realtime insights into potentially harmful links. By employing sophisticated AI and ML algorithms to detect phishing and suspicious URLs, Cyble helps minimize false positives through advanced content and sequence matching. Cyble delivers a comprehensive view of an organizations attack surface, enabling better decisionmaking and more effective risk management. Through our Attack Surface Management capabilities, we provide comprehensive solutions to secure every aspect of your attack surfaces, helping our customers secure their digital frontier and detect and respond effectively. Join the many organizations that trust Cyble to secure their digital assets and fortify their cybersecurity defenses. Schedule a demo today to see how Cyble can help protect your organization. And dont forget to download our latest report on the Attack Surface Management Solutions Landscape for Q2 2024 to discover additional details. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

