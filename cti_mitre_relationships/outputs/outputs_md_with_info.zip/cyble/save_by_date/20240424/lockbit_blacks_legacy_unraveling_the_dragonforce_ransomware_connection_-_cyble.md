---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "LOCKBIT Black's Legacy: Unraveling The DragonForce Ransomware Connection - Cyble"
Date: 2024-04-24
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1499.003, T1561, T1565.001, T1561.002, T1491.001, T1489, T1498.002, T1499, T1486, T1565, T1657, T1561.001, T1499.004, T1491.002, T1499.002, T1531, T1495, T1491, T1499.001, T1529, T1496, T1565.002, T1498.001, T1490, T1485, T1498, T1565.003"
ADD_INFORMATION_technique: "OS Exhaustion Flood, Defacement, Internal Defacement, Resource Hijacking, Endpoint Denial of Service, Application Exhaustion Flood, Runtime Data Manipulation, Disk Structure Wipe, Direct Network Flood, Service Stop, Transmitted Data Manipulation, Application or System Exploitation, Data Encrypted for Impact, Data Destruction, Firmware Corruption, Inhibit System Recovery, Disk Content Wipe, Reflection Amplification, Account Access Removal, Financial Theft, Disk Wipe, Stored Data Manipulation, Network Denial of Service, External Defacement, Service Exhaustion Flood, Data Manipulation, System Shutdown/Reboot"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1585, T1586, T1586.001, T1585.001"
ADD_INFORMATION_technique: "Establish Accounts, Compromise Accounts, Social Media Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
LOCKBIT Black's Legacy: Unraveling The DragonForce Ransomware Connection - Cyble

**date**
24/04/2024

**url_news**
https://cyble.com/blog/lockbit-blacks-legacy-unraveling-the-dragonforce-ransomware-connection/

**cyble_category**
Ransomware

**links**
'https://www.radware.com/security/ddos-knowledge-center/ddospedia/dragonforce-malaysia/', 'https://www.virustotal.com/gui/file/1250ba6f25fd60077f698a2617c15f89d58c1867339bfd9ee8ab19ce9943304b/detection', 'https://cyble.com/blog/alleged-builder-of-lockbit-black-ransomware-leaked/', 'https://cyble.com/blog/lockbit-3-0-ransomware-group-launches-new-version/'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog LOCKBIT Blacks Legacy: Unraveling the DragonForce Ransomware Connection DragonForce Ransomware emerged in November 2023. This group employs double extortion to target its victims, involving data exfiltration followed by encryption. If the victim fails to pay the ransom, the Threat Actors TAs behind this ransomware group leak the victims data on their leak site. The figure below shows the DragonForce ransomware leak site. Figure 1 DragonForce Leak Site There is also a hacktivist group called DragonForce based in Malaysia. During 2021 and 2022, they conducted various campaigns targeting government agencies and organizations across the Middle East and Asia. Additionally, in 2022, the group announced its intention to launch ransomware. However, due to limited information, it is challenging to determine whether the ransomware discovered is connected to this hacktivist group. DragonForce ransomware began extorting their victims in November 2023 by publishing victim details and their leak site URL on a cybercrime forum. This move was likely aimed at increasing the visibility of their attacks, as only a handful of ransomware groups utilize cybercrime forums for extortion. So far, DragonForce has publicly disclosed information about over 25 victims worldwide. The figure below shows the post on a cybercrime forum. Figure 2 Post on Cybercrime Forum The figure below shows the tor site used for leaking victims data. Figure 3 DragonForce data leak site CRIL recently found a DragonForce ransomware binary, which was based on LOCKBIT Black ransomware. LOCKBIT Black is a third variant of LOCKBIT ransomware, and we believe that the TAs behind the DragonForce ransomware leveraged the leaked builder of LOCKBIT Black ransomware to generate their binary. The figure below shows the leaked builder of LOCKBIT ransomware. Figure 4 Post Regarding Leaked LOCKBIT Builder Source: Cyble On September 2022, a user on X Twitter shared the download link of the LockBit ransomware builder. By using this builder, TA can customize the ransomware payload as per their requirements. This builder includes a config.json file to customize the payload according to the TAs preferences, allowing for features like encryption mode, filename encryption, impersonation, exclusion of specific files and folders from encryption, and languagebased exclusion of CIS countries. The configuration file also contains a ransom note template. Figure 5 Config.json file of LockBit Our comparison between a binary generated using the Leaked Builder of LOCKBIT ransomware and DragonForce ransomware revealed striking similarities in the code structure and functions. This observation strongly suggests that the DragonForce ransomware binary was likely created utilizing the leaked builder of LOCKBIT ransomware. The figure below shows the BinDiff results. Figure 6 BinDiff Analysis Upon execution, the ransomware terminates the following processes to allocate system resources for faster encryption. The ransomware also terminates the following services. Following encryption, the ransomware binary renames the files using a random string followed by .AoVOpni2N as the extension. The figure below displays the encrypted files. Figure 7 Encrypted Files Then, it drops a ransom note named AoVOpni2N.README.txt in each directory it parses. The figure below displays the ransom note. Figure 8 Ransom Note A complete analysis of LOCKBIT 3.0 can be found here. The discovery of DragonForce ransomware and its links to the leaked builder of LOCKBIT Black ransomware underscores the growing threat posed by the abuse of leaked malwarebuilding tools in cyberattacks. The accessibility of such tools enables TAs to customize and deploy ransomware payloads with ease, amplifying the risk landscape for organizations globally. The emergence of DragonForce ransomware, coupled with its utilization of double extortion tactics, highlights the evolving tactics employed by ransomware actors to maximize their impact and financial gain. We have listed some essential cybersecurity best practices that create the first line of control against attackers. We recommend that our readers follow the best practices given below: Safety Measures Needed to Prevent Ransomware Attacks Users Should Take the Following Steps After a Ransomware Attack Impact of Ransomware Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

