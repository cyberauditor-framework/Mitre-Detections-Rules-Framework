---
CP Source: Cyble
CP Execution date:  2024-08-08
Headline: "Cyble Chronicles – Dec 22nd: Latest Findings & Recommendations For The Cybersecurity Community - Cyble"
Date: 2024-05-07
Category: ""

AI_technique_ID_1: "T1566"
AI_technique_1: "PHISHING"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1566"
AI_technique_description_1: "Adversaries may send phishing messages to gain access to victim systems. All forms of phishing are electronically delivered social engineering. Phishing can be targeted, known as spearphishing. In spearphishing, a specific individual, company, or industry will be targeted by the adversary. More generally, adversaries can conduct nontargeted phishing, such as in mass malware spam campaigns. Adversaries may send victims emails containing malicious attachments or links, typically to execute malicious code on victim systems. Phishing may also be conducted via thirdparty services, like social media platforms. Phishing may also involve social engineering techniques, such as posing as a trusted source, as well as evasive techniques such as removing or manipulating emails or metadataheaders from compromised accounts being abused to send messages e.g., Email Hiding Rules https://attack.mitre.org/techniques/T1564/008.Citation Microsoft OAuth Spam 2022Citation Palo Alto Unit 42 VBA Infostealer 2014 Another way to accomplish this is by forging or spoofingCitation Proofpointspoof the identity of the sender which can be used to fool both the human recipient as well as automated security tools.Citation cyberproofdoublebounce Victims may also receive phishing messages that instruct them to call a phone number where they are directed to visit a malicious URL, download malware,Citation sygnia Luna MonthCitation CISA Remote Monitoring and Management Software or install adversaryaccessible remote management tools onto their computer i.e., User Execution https://attack.mitre.org/techniques/T1204.Citation Unit42 Luna Moth"
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1588.006"
AI_technique_2: "VULNERABILITIES"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1588/006"
AI_technique_description_2: "Adversaries may acquire information about vulnerabilities that can be used during targeting. A vulnerability is a weakness in computer hardware or software that can, potentially, be exploited by an adversary to cause unintended or unanticipated behavior to occur. Adversaries may find vulnerability information by searching open databases or gaining access to closed vulnerability databases.Citation National Vulnerability Database An adversary may monitor vulnerability disclosuresdatabases to understand the state of existing, as well as newly discovered, vulnerabilities. There is usually a delay between when a vulnerability is discovered and when it is made public. An adversary may target the systems of those known to conduct vulnerability research including commercial vendors. Knowledge of a vulnerability may cause an adversary to search for an existing exploit i.e. Exploits https://attack.mitre.org/techniques/T1588/005 or to attempt to develop one themselves i.e. Exploits https://attack.mitre.org/techniques/T1587/004."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1587.001"
AI_technique_3: "MALWARE"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1587/001"
AI_technique_description_3: "Adversaries may develop malware and malware components that can be used during targeting. Building malicious software can include the development of payloads, droppers, postcompromise tools, backdoors including backdoored images, packers, C2 protocols, and the creation of infected removable media. Adversaries may develop malware to support their operations, creating a means for maintaining control of remote machines, evading defenses, and executing postcompromise behaviors.Citation Mandiant APT1Citation Kaspersky SofacyCitation ActiveMalwareEnergyCitation FBI Flash FIN7 USB As with legitimate development efforts, different skill sets may be required for developing malware. The skills needed may be located inhouse, or may need to be contracted out. Use of a contractor may be considered an extension of that adversarys malware development capabilities, provided the adversary plays a role in shaping requirements and maintains a degree of exclusivity to the malware. Some aspects of malware development, such as C2 protocol development, may require adversaries to obtain additional infrastructure. For example, malware developed that will communicate with Twitter for C2, may require use of Web Services https://attack.mitre.org/techniques/T1583/006.Citation FireEye APT29"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"
AI_technique_ID_4: "T1588.001"
AI_technique_4: "MALWARE"
AI_technique_url_4: "https://attack.mitre.org/techniques/T1588/001"
AI_technique_description_4: "Adversaries may buy, steal, or download malware that can be used during targeting. Malicious software can include payloads, droppers, postcompromise tools, backdoors, packers, and C2 protocols. Adversaries may acquire malware to support their operations, obtaining a means for maintaining control of remote machines, evading defenses, and executing postcompromise behaviors. In addition to downloading free malware from the internet, adversaries may purchase these capabilities from thirdparty entities. Thirdparty entities can include technology companies that specialize in malware development, criminal marketplaces including MalwareasaService, or MaaS, or from individuals. In addition to purchasing malware, adversaries may steal and repurpose malware from thirdparty entities including other adversaries."
AI_technique_deprecated_4: "False"
AI_technique_revoked_4: "False"
AI_matrix_domains_4: "enterprise-attack"
AI_technique_ID_5: "T1588.002"
AI_technique_5: "TOOL"
AI_technique_url_5: "https://attack.mitre.org/techniques/T1588/002"
AI_technique_description_5: "Adversaries may buy, steal, or download software tools that can be used during targeting. Tools can be open or closed source, free or commercial. A tool can be used for malicious purposes by an adversary, but unlike malware were not intended to be used for those purposes ex PsExec https://attack.mitre.org/software/S0029. Tool acquisition can involve the procurement of commercial software licenses, including for red teaming tools such as Cobalt Strike https://attack.mitre.org/software/S0154. Commercial software may be obtained through purchase, stealing licenses or licensed copies of the software, or cracking trial versions.Citation Recorded Future Beacon 2019 Adversaries may obtain tools to support their operations, including to support execution of postcompromise behaviors. In addition to freely downloading or purchasing software, adversaries may steal software andor software licenses from thirdparty entities including other adversaries."
AI_technique_deprecated_5: "False"
AI_technique_revoked_5: "False"
AI_matrix_domains_5: "enterprise-attack"
AI_technique_ID_6: "T1053.002"
AI_technique_6: "AT"
AI_technique_url_6: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_6: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_6: "False"
AI_technique_revoked_6: "False"
AI_matrix_domains_6: "enterprise-attack"


AI_data_source_ID_1: "DS0021"
AI_technique_ID_1: "T1585.001; T1585; T1586.001; T1586"
AI_technique_1: "Social Media Accounts; Compromise Accounts; Establish Accounts"
AI_data_source_1: "PERSONA"
AI_data_source_url_1: "https://attack.mitre.org/datasources/DS0021"
AI_data_source_description_1: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
AI_matrix_domains_1: "enterprise-attack"
AI_data_source_ID_2: "DS0036"
AI_technique_ID_2: "T1087.001; T1069.001; T1098; T1069.003; T1069; T1098.002; T1087.002; T1069.002"
AI_technique_2: "Cloud Groups; Permission Groups Discovery; Local Account; Local Groups; Domain Account; Domain Groups; Additional Email Delegate Permissions; Account Manipulation"
AI_data_source_2: "GROUP"
AI_data_source_url_2: "https://attack.mitre.org/datasources/DS0036"
AI_data_source_description_2: "A collection of multiple user accounts that share the same access rights to the computer andor network resources and have common security rightsCitation Amazon IAM Groups"
AI_matrix_domains_2: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1608.003; T1587.001; T1595; T1598.003; T1608.001; T1608.004; T1586.001; T1595.003; T1588.001; T1584.003; T1588; T1584.006; T1589; T1585; T1584.004; T1594; T1595.001; T1598.002; T1583.001; T1584; T1583.007; T1584.007; T1587; T1584.008; T1588.002; T1588.003; T1598.004; T1586; T1583; T1588.004; T1583.006; T1583.008; T1589.002; T1584.002; T1608.006; T1584.001; T1585.001; T1587.003; T1592; T1598; T1583.003; T1583.004; T1595.002; T1592.004; T1592.002; T1587.002; T1608.005; T1608; T1608.002; T1592.001; T1598.001"
AI_technique_1: "DNS Server; Upload Tool; Compromise Accounts; Digital Certificates; Serverless; Search Victim-Owned Websites; Develop Capabilities; Upload Malware; Obtain Capabilities; SEO Poisoning; Gather Victim Host Information; Drive-by Target; Spearphishing Voice; Server; Stage Capabilities; Domains; Active Scanning; Gather Victim Identity Information; Compromise Infrastructure; Email Addresses; Social Media Accounts; Spearphishing Attachment; Client Configurations; Spearphishing Link; Software; Establish Accounts; Malware; Phishing for Information; Acquire Infrastructure; Virtual Private Server; Scanning IP Blocks; Tool; Malvertising; Spearphishing Service; Network Devices; Code Signing Certificates; Wordlist Scanning; Hardware; Link Target; Web Services; Install Digital Certificate; Vulnerability Scanning"
AI_platform_2: "NETWORK"
AI_technique_ID_2: "T1505.003; T1600.001; T1098.004; T1082; T1601; T1665; T1542.005; T1136.001; T1599.001; T1098; T1071; T1070; T1557; T1110.004; T1059; T1600.002; T1110; T1071.003; T1018; T1110.001; T1105; T1090; T1059.004; T1071.004; T1602; T1016; T1095; T1601.001; T1110.003; T1070.003; T1057; T1561.001; T1190; T1049; T1040; T1599; T1090.003; T1552.004; T1561.002; T1056.001; T1653; T1059.008; T1070.007; T1600; T1033; T1205.001; T1205; T1027; T1037.004; T1562.004; T1602.002; T1601.002; T1006; T1542.004; T1556.004; T1556; T1110.002; T1562; T1072; T1495; T1027.008; T1573; T1561; T1573.002; T1529; T1046; T1090.001; T1602.001; T1552; T1020; T1542; T1056; T1078.001; T1048.003; T1078.003; T1071.002; T1562.001; T1490; T1090.002; T1048; T1547; T1542.001; T1037; T1136; T1573.001; T1083; T1562.003; T1005; T1071.001; T1124; T1078; T1201; T1505; T1020.001"
AI_technique_2: "System Time Discovery; External Proxy; Mail Protocols; Internal Proxy; Password Guessing; Encrypted Channel; Data from Local System; Traffic Duplication; Clear Command History; Traffic Signaling; Default Accounts; Server Software Component; Port Knocking; Indicator Removal; System Network Connections Discovery; Pre-OS Boot; Unix Shell; Network Device Configuration Dump; Software Deployment Tools; Disk Wipe; Boot or Logon Autostart Execution; Proxy; Direct Volume Access; Firmware Corruption; Network Service Discovery; Network Address Translation Traversal; Network Sniffing; Web Protocols; Adversary-in-the-Middle; Weaken Encryption; Symmetric Cryptography; File and Directory Discovery; Downgrade System Image; Obfuscated Files or Information; Network Boundary Bridging; Boot or Logon Initialization Scripts; ROMMONkit; Valid Accounts; Data from Configuration Repository; Ingress Tool Transfer; System Owner/User Discovery; Power Settings; System Firmware; Password Policy Discovery; Keylogging; Private Keys; Process Discovery; SSH Authorized Keys; Asymmetric Cryptography; Impair Command History Logging; Disable or Modify Tools; System Network Configuration Discovery; Application Layer Protocol; Disable or Modify System Firewall; Disable Crypto Hardware; Exfiltration Over Unencrypted Non-C2 Protocol; Password Cracking; Unsecured Credentials; Disk Structure Wipe; Exploit Public-Facing Application; Inhibit System Recovery; SNMP (MIB Dump); Remote System Discovery; Stripped Payloads; Disk Content Wipe; File Transfer Protocols; Modify Authentication Process; Network Device CLI; Credential Stuffing; Brute Force; Hide Infrastructure; Local Account; TFTP Boot; Modify System Image; Input Capture; Create Account; Patch System Image; DNS; Web Shell; Impair Defenses; Network Device Authentication; Password Spraying; Account Manipulation; Clear Network Connection History and Configurations; Automated Exfiltration; System Information Discovery; Command and Scripting Interpreter; System Shutdown/Reboot; Reduce Key Space; Local Accounts; Multi-hop Proxy; Non-Application Layer Protocol; Exfiltration Over Alternative Protocol; RC Scripts"


AI_software_ID_1: "S0575"
AI_technique_ID_1: "T1049; T1016; T1135; T1080; T1106; T1018; T1140; T1021.002; T1083; T1486; T1059.003; T1057; T1027; T1055.001; T1489; T1490"
AI_technique_1: "System Network Connections Discovery; System Network Configuration Discovery; Dynamic-link Library Injection; Native API; Process Discovery; Data Encrypted for Impact; Deobfuscate/Decode Files or Information; Service Stop; Taint Shared Content; Remote System Discovery; Windows Command Shell; File and Directory Discovery; Inhibit System Recovery; SMB/Windows Admin Shares; Obfuscated Files or Information; Network Share Discovery"
AI_software_1: "CONTI"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S0575"
AI_software_description_1: "Conti https://attack.mitre.org/software/S0575 is a RansomwareasaService RaaS that was first observed in December 2019. Conti https://attack.mitre.org/software/S0575 has been deployed via TrickBot https://attack.mitre.org/software/S0266 and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti https://attack.mitre.org/software/S0575 steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.Citation Cybereason Conti Jan 2021Citation CarbonBlack Conti July 2020Citation Cybleinc Conti January 2020"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S1068"
AI_technique_ID_2: "T1112; T1486; T1082; T1561.001; T1548.002; T1070.001; T1222.001; T1047; T1490; T1491.001; T1570; T1083; T1033; T1087.002; T1069.002; T1135; T1018; T1134; T1059.003; T1489"
AI_technique_2: "Windows File and Directory Permissions Modification; Data Encrypted for Impact; Windows Management Instrumentation; Clear Windows Event Logs; Domain Groups; Bypass User Account Control; File and Directory Discovery; Inhibit System Recovery; Network Share Discovery; Internal Defacement; Service Stop; Domain Account; System Owner/User Discovery; Remote System Discovery; Windows Command Shell; Disk Content Wipe; Modify Registry; System Information Discovery; Access Token Manipulation; Lateral Tool Transfer"
AI_software_2: "BLACKCAT"
AI_software_type_2: "malware"
AI_software_url_2: "https://attack.mitre.org/software/S1068"
AI_software_description_2: "BlackCat https://attack.mitre.org/software/S1068 is ransomware written in Rust that has been offered via the RansomwareasaService RaaS model. First observed November 2021, BlackCat https://attack.mitre.org/software/S1068 has been used to target multiple sectors and organizations in various countries and regions in Africa, the Americas, Asia, Australia, and Europe.Citation Microsoft BlackCat Jun 2022Citation Sophos BlackCat Jul 2022Citation ACSC BlackCat Apr 2022"
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S0075"
AI_technique_ID_3: "T1012; T1552.002; T1112"
AI_technique_3: "Query Registry; Modify Registry; Credentials in Registry"
AI_software_3: "REG"
AI_software_type_3: "tool"
AI_software_url_3: "https://attack.mitre.org/software/S0075"
AI_software_description_3: "Reg https://attack.mitre.org/software/S0075 is a Windows utility used to interact with the Windows Registry. It can be used at the commandline interface to query, add, modify, and remove information. Citation Microsoft Reg Utilities such as Reg https://attack.mitre.org/software/S0075 are known to be used by persistent threats. Citation Windows Commands JPCERT"
AI_matrix_domains_3: "enterprise-attack"
AI_software_ID_4: "S0148"
AI_technique_ID_4: "T1566.001; T1036.004; T1547.001; T1036; T1102.001; T1112; T1082; T1057; T1053.005; T1113; T1115; T1548.002; T1497; T1219; T1106; T1070.004; T1218.011; T1204.002; T1056.001; T1573.001; T1518.001; T1553.002; T1120; T1083; T1071.001; T1033; T1119; T1559.002; T1571; T1070.009; T1124; T1553.004; T1518; T1059.003; T1105; T1027; T1568"
AI_technique_4: "System Time Discovery; Dynamic Data Exchange; Masquerading; Registry Run Keys / Startup Folder; Clipboard Data; Masquerade Task or Service; Security Software Discovery; Web Protocols; Clear Persistence; Non-Standard Port; Dead Drop Resolver; Rundll32; Bypass User Account Control; Symmetric Cryptography; File and Directory Discovery; Spearphishing Attachment; Obfuscated Files or Information; Peripheral Device Discovery; Install Root Certificate; Ingress Tool Transfer; Dynamic Resolution; System Owner/User Discovery; Virtualization/Sandbox Evasion; File Deletion; Windows Command Shell; Automated Collection; Keylogging; Native API; Modify Registry; Process Discovery; System Information Discovery; Code Signing; Screen Capture; Remote Access Software; Software Discovery; Scheduled Task; Malicious File"
AI_software_4: "RTM"
AI_software_type_4: "malware"
AI_software_url_4: "https://attack.mitre.org/software/S0148"
AI_software_description_4: "RTM https://attack.mitre.org/software/S0148 is custom malware written in Delphi. It is used by the group of the same name RTM https://attack.mitre.org/groups/G0048. Newer versions of the malware have been reported publicly as Redaman.Citation ESET RTM Feb 2017Citation Unit42 Redaman January 2019"
AI_matrix_domains_4: "enterprise-attack"
AI_software_ID_5: "S0039"
AI_technique_ID_5: "T1049; T1135; T1087.001; T1569.002; T1136.001; T1007; T1069.001; T1124; T1018; T1201; T1021.002; T1070.005; T1136.002; T1087.002; T1069.002"
AI_technique_5: "System Network Connections Discovery; System Time Discovery; Service Execution; Local Groups; Local Account; Domain Account; Domain Groups; System Service Discovery; Remote System Discovery; Network Share Connection Removal; Password Policy Discovery; SMB/Windows Admin Shares; Network Share Discovery"
AI_software_5: "NET"
AI_software_type_5: "tool"
AI_software_url_5: "https://attack.mitre.org/software/S0039"
AI_software_description_5: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_5: "enterprise-attack"
AI_software_ID_6: "S0097"
AI_technique_ID_6: "T1018"
AI_technique_6: "Remote System Discovery"
AI_software_6: "PING"
AI_software_type_6: "tool"
AI_software_url_6: "https://attack.mitre.org/software/S0097"
AI_software_description_6: "Ping https://attack.mitre.org/software/S0097 is an operating system utility commonly used to troubleshoot and verify network connections. Citation TechNet Ping"
AI_matrix_domains_6: "enterprise-attack"
AI_software_ID_7: "S0183"
AI_technique_ID_7: "T1090.003; T1573.002"
AI_technique_7: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_7: "TOR"
AI_software_type_7: "tool"
AI_software_url_7: "https://attack.mitre.org/software/S0183"
AI_software_description_7: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_7: "enterprise-attack"
AI_software_ID_8: "S0110"
AI_technique_ID_8: "T1053.002"
AI_technique_8: "At"
AI_software_8: "AT"
AI_software_type_8: "tool"
AI_software_url_8: "https://attack.mitre.org/software/S0110"
AI_software_description_8: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_8: "enterprise-attack"


AI_group_ID_1: "G0048"
AI_group_1: "RTM"
AI_technique_ID_1: "T1189; T1566.001; T1219; T1547.001; T1102.001; T1204.002; T1574.001"
AI_technique_1: "Dead Drop Resolver; Registry Run Keys / Startup Folder; Drive-by Compromise; Remote Access Software; DLL Search Order Hijacking; Spearphishing Attachment; Malicious File"
AI_group_aliases_1: "['RTM']"
AI_group_url_1: "https://attack.mitre.org/groups/G0048"
AI_group_description_1: "RTM https://attack.mitre.org/groups/G0048 is a cybercriminal group that has been active since at least 2015 and is primarily interested in users of remote banking systems in Russia and neighboring countries. The group uses a Trojan by the same name RTM https://attack.mitre.org/software/S0148. Citation ESET RTM Feb 2017"
AI_matrix_domains_1: "enterprise-attack"

---

**title**
Cyble Chronicles – Dec 22nd: Latest Findings & Recommendations For The Cybersecurity Community - Cyble

**date**
07/05/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-dec-22nd-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**
'https://cyble.com/resources/research-reports/', 'https://thecyberexpress.com/', 'https://cyble.com/resources/research-reports/', 'https://us06web.zoom.us/webinar/register/8017023856767/WN_CmOwMHzoR5Knv6Mk79dR-g#/registration', 'https://thecyberexpress.com/alphv-blackcat-website-unseized-threaten-fbi/'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles Dec 22nd: Latest Findings Recommendations for the Cybersecurity Community We hope youre having a wonderful Holiday season. Cyble is ready to wrap up 2023 with a bang You can access our Annual Threat landscape report here, next week, where we will cover all major events and observations in cyberspace across the surface, deep, and dark web. The Cyber Express has been working hard to ensure that you get the latest cybersecurity news in its trademark reporting style that many of you have come to enjoy. This newsletter covers one of their major findings regarding Law Enforcement Agencies taking action against a major Ransomware gang. We hope you are ready for our thought leadership sessions, with our senior leadership soon to host two major webinars on Supply Chain Risk and Navigating the Cyber Threat Landscape in 2024 we hope to see you there Before we close out 2023, wed like to leave you with some guidance on major scams, specific cybersecurity activity, and tips to secure yourself and your loved ones this holiday season. Brace yourself for a profound exploration of the cybersecurity landscape with the imminent release of Cyble Research Intelligence Labs Annual Threat Landscape report for 2023. This upcoming report promises an indepth analysis encompassing Hacktivism, Vulnerabilities, Malware, Cyberwarfare, Operational Technology, Industrial Control Technology, Ransomware, and other key spaces in cybersecurity. Our deep dive report aims to give readers a strategic understanding of prevailing threats while also anticipating future challenges and trends. This report will serve as your roadmap to comprehend, anticipate, and fortify yourself in an increasingly dynamic threat landscape. Stay tuned for a wealth of information, including valuable predictions shaping the cybersecurity landscape in 2024.Watch this space for more. Dont miss out on a unique opportunity to stay ahead in the everevolving cybersecurity landscape Register now for our upcoming webinar with Dipesh Kaura, a renowned cyber threat intelligence expert. Explore the 2024 cyber threat scenario in India and the SAARC region, understanding emerging threats, the latest in cyber threat intelligence tools, and effective risk mitigation strategies. Engage in interactive discussions with Dipesh during the QA session. This event is a mustattend for IT leaders, cybersecurity professionals, tech policymakers, and anyone keen on Indian/South Asian cyber threat dynamics. Secure your spot today to gain valuable insights and network with industry experts Register here. Earlier this week, the FBI announced that they had successfully taken over the ALPHV Ransomware groups website. ALPHV, also known as BlackCat, is one of the most prominent players in the ransomware threat landscape, targeting major organizations across the world. As of Q3 2023, the group had compromised over a thousand entities, of which nearly 75 were based in the United States. During this period, the ALPHV group collected nearly 300 Million in ransom payments, further underscoring their potency and scale.Within 24 hours of the US Department of Justice DOJ and FBI seizing their primary website, the ALPHV Ransomware group responded with a detailed message shared over the darkweb, discussing the chronology of events and repercussions of this seizure. However, in under 24 hours of this seizure, the group claims to have unseized their website, issuing menacing messages targeted at the FBI and DOJ. Click here to read more. As the holiday season approaches, cybercriminals are known to ramp up their activities, exploiting festive cheer to unleash a surge of scams and malware. With a known penchant for exploiting heightened online shopping and gifting activities, these malicious actors employ tactics such as deceptive gift voucherbased malware and phishing scams. Unwary individuals become prime targets, falling victim to fraudulent schemes amidst the holiday hustle. From enticing phishing emails to malicious websites, cybercriminals capitalize on the increased digital traffic, seeking to compromise personal and financial information. As we celebrate this holiday season, we must also remain vigilant and adopt secure online practices to safeguard against nefarious activities that tend to intensify during this festive period. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

