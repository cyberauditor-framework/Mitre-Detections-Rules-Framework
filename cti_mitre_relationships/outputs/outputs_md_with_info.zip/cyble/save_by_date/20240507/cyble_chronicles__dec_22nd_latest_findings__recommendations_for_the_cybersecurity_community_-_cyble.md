---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Cyble Chronicles – Dec 22nd: Latest Findings & Recommendations For The Cybersecurity Community - Cyble"
Date: 2024-05-07
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1585, T1586, T1586.001, T1585.001"
ADD_INFORMATION_technique: "Establish Accounts, Compromise Accounts, Social Media Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_group_ID: "G0048"
ADD_INFORMATION_group: "RTM"
ADD_INFORMATION_technique_ID: "T1219, T1574.001, T1566.001, T1547.001, T1102.001, T1204.002, T1189"
ADD_INFORMATION_technique: "Malicious File, Remote Access Software, Dead Drop Resolver, DLL Search Order Hijacking, Registry Run Keys / Startup Folder, Drive-by Compromise, Spearphishing Attachment"
ADD_INFORMATION_group_aliases: "RTM"
ADD_INFORMATION_group_url: "https://attack.mitre.org/groups/G0048"
ADD_INFORMATION_group_description: "RTM(https://attack.mitre.org/groups/G0048) is a cybercriminal group that has been active since at least 2015 and is primarily interested in users of remote banking systems in Russia and neighboring countries. The group uses a Trojan by the same name (RTM(https://attack.mitre.org/software/S0148)). (Citation: ESET RTM Feb 2017)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Cyble Chronicles – Dec 22nd: Latest Findings & Recommendations For The Cybersecurity Community - Cyble

**date**
07/05/2024

**url_news**
https://cyble.com/blog/cyble-chronicles-dec-22nd-latest-findings-recommendations-for-the-cybersecurity-community/

**cyble_category**
Annoucement

**links**
'https://cyble.com/resources/research-reports/', 'https://thecyberexpress.com/', 'https://cyble.com/resources/research-reports/', 'https://us06web.zoom.us/webinar/register/8017023856767/WN_CmOwMHzoR5Knv6Mk79dR-g#/registration', 'https://thecyberexpress.com/alphv-blackcat-website-unseized-threaten-fbi/'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Chronicles Dec 22nd: Latest Findings Recommendations for the Cybersecurity Community We hope youre having a wonderful Holiday season. Cyble is ready to wrap up 2023 with a bang You can access our Annual Threat landscape report here, next week, where we will cover all major events and observations in cyberspace across the surface, deep, and dark web. The Cyber Express has been working hard to ensure that you get the latest cybersecurity news in its trademark reporting style that many of you have come to enjoy. This newsletter covers one of their major findings regarding Law Enforcement Agencies taking action against a major Ransomware gang. We hope you are ready for our thought leadership sessions, with our senior leadership soon to host two major webinars on Supply Chain Risk and Navigating the Cyber Threat Landscape in 2024 we hope to see you there Before we close out 2023, wed like to leave you with some guidance on major scams, specific cybersecurity activity, and tips to secure yourself and your loved ones this holiday season. Brace yourself for a profound exploration of the cybersecurity landscape with the imminent release of Cyble Research Intelligence Labs Annual Threat Landscape report for 2023. This upcoming report promises an indepth analysis encompassing Hacktivism, Vulnerabilities, Malware, Cyberwarfare, Operational Technology, Industrial Control Technology, Ransomware, and other key spaces in cybersecurity. Our deep dive report aims to give readers a strategic understanding of prevailing threats while also anticipating future challenges and trends. This report will serve as your roadmap to comprehend, anticipate, and fortify yourself in an increasingly dynamic threat landscape. Stay tuned for a wealth of information, including valuable predictions shaping the cybersecurity landscape in 2024.Watch this space for more. Dont miss out on a unique opportunity to stay ahead in the everevolving cybersecurity landscape Register now for our upcoming webinar with Dipesh Kaura, a renowned cyber threat intelligence expert. Explore the 2024 cyber threat scenario in India and the SAARC region, understanding emerging threats, the latest in cyber threat intelligence tools, and effective risk mitigation strategies. Engage in interactive discussions with Dipesh during the QA session. This event is a mustattend for IT leaders, cybersecurity professionals, tech policymakers, and anyone keen on Indian/South Asian cyber threat dynamics. Secure your spot today to gain valuable insights and network with industry experts Register here. Earlier this week, the FBI announced that they had successfully taken over the ALPHV Ransomware groups website. ALPHV, also known as BlackCat, is one of the most prominent players in the ransomware threat landscape, targeting major organizations across the world. As of Q3 2023, the group had compromised over a thousand entities, of which nearly 75 were based in the United States. During this period, the ALPHV group collected nearly 300 Million in ransom payments, further underscoring their potency and scale.Within 24 hours of the US Department of Justice DOJ and FBI seizing their primary website, the ALPHV Ransomware group responded with a detailed message shared over the darkweb, discussing the chronology of events and repercussions of this seizure. However, in under 24 hours of this seizure, the group claims to have unseized their website, issuing menacing messages targeted at the FBI and DOJ. Click here to read more. As the holiday season approaches, cybercriminals are known to ramp up their activities, exploiting festive cheer to unleash a surge of scams and malware. With a known penchant for exploiting heightened online shopping and gifting activities, these malicious actors employ tactics such as deceptive gift voucherbased malware and phishing scams. Unwary individuals become prime targets, falling victim to fraudulent schemes amidst the holiday hustle. From enticing phishing emails to malicious websites, cybercriminals capitalize on the increased digital traffic, seeking to compromise personal and financial information. As we celebrate this holiday season, we must also remain vigilant and adopt secure online practices to safeguard against nefarious activities that tend to intensify during this festive period. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

