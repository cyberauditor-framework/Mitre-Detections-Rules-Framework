---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Uninterrupted Power Supply (UPS): A Silent Threat To Critical Infrastructure Resilience - Cyble"
Date: 2024-05-08
Category: ""

ADD_INFORMATION_technique_ID: "T1592.002"
ADD_INFORMATION_technique: "SOFTWARE"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1592/002"
ADD_INFORMATION_technique_description: "Adversaries may gather information about the victims host software that can be used during targeting. Information about installed software may include a variety of details such as types and versions on specific hosts, as well as the presence of additional components that might be indicative of added defensive protections (ex: antivirus, SIEMs, etc.).

Adversaries may gather this information in various ways, such as direct collection actions via Active Scanning(https://attack.mitre.org/techniques/T1595) (ex: listening ports, server banners, user agent strings) or Phishing for Information(https://attack.mitre.org/techniques/T1598). Adversaries may also compromise sites then include malicious content designed to collect host information from visitors.(Citation: ATT ScanBox) Information about the installed software may also be exposed to adversaries via online or other accessible data sets (ex: job postings, network maps, assessment reports, resumes, or purchase invoices). Gathering this information may reveal opportunities for other forms of reconnaissance (ex: Search Open Websites/Domains(https://attack.mitre.org/techniques/T1593) or Search Open Technical Databases(https://attack.mitre.org/techniques/T1596)), establishing operational resources (ex: Develop Capabilities(https://attack.mitre.org/techniques/T1587) or Obtain Capabilities(https://attack.mitre.org/techniques/T1588)), and/or for initial access (ex: Supply Chain Compromise(https://attack.mitre.org/techniques/T1195) or External Remote Services(https://attack.mitre.org/techniques/T1133))."
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0040"
ADD_INFORMATION_technique_ID: "T1499.003, T1561, T1565.001, T1561.002, T1491.001, T1489, T1498.002, T1499, T1486, T1565, T1657, T1561.001, T1499.004, T1491.002, T1499.002, T1531, T1495, T1491, T1499.001, T1529, T1496, T1565.002, T1498.001, T1490, T1485, T1498, T1565.003"
ADD_INFORMATION_technique: "OS Exhaustion Flood, Defacement, Internal Defacement, Resource Hijacking, Endpoint Denial of Service, Application Exhaustion Flood, Runtime Data Manipulation, Disk Structure Wipe, Direct Network Flood, Service Stop, Transmitted Data Manipulation, Application or System Exploitation, Data Encrypted for Impact, Data Destruction, Firmware Corruption, Inhibit System Recovery, Disk Content Wipe, Reflection Amplification, Account Access Removal, Financial Theft, Disk Wipe, Stored Data Manipulation, Network Denial of Service, External Defacement, Service Exhaustion Flood, Data Manipulation, System Shutdown/Reboot"
ADD_INFORMATION_tactic: "IMPACT"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0040"
ADD_INFORMATION_tactic_description: "The adversary is trying to manipulate, interrupt, or destroy your systems and data. Impact consists of techniques that adversaries use to disrupt availability or compromise integrity by manipulating business and operational processes. Techniques used for impact can include destroying or tampering with data. In some cases, business processes can look fine, but may have been altered to benefit the adversaries’ goals. These techniques might be used by adversaries to follow through on their end goal or to provide cover for a confidentiality breach."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0021"
ADD_INFORMATION_technique_ID: "T1585, T1586, T1586.001, T1585.001"
ADD_INFORMATION_technique: "Establish Accounts, Compromise Accounts, Social Media Accounts"
ADD_INFORMATION_data_source: "PERSONA"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0021"
ADD_INFORMATION_data_source_description: "A malicious online profile representing a user commonly used by adversaries to social engineer or otherwise target victims"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Uninterrupted Power Supply (UPS): A Silent Threat To Critical Infrastructure Resilience - Cyble

**date**
08/05/2024

**url_news**
https://cyble.com/blog/uninterrupted-power-supply-ups-a-silent-threat-to-critical-infrastructure-resilience/

**cyble_category**
Vulnerability

**links**
'https://www.cyberpower.com/global/en/product/sku/powerpanel_business_for_windows#downloads', 'https://www.cisa.gov/news-events/ics-advisories/icsa-24-123-01', 'https://www.cyberpower.com/in/en/product/series/powerpanel_business'

**body**
Report an Incident Talk to Sales We are Hiring Home Blog Uninterrupted Power Supply UPS: A Silent Threat to Critical Infrastructure Resilience UPS management software is employed by a broad spectrum of users, encompassing data centers, critical manufacturing sectors, healthcare facilities, educational institutions, government agencies, and beyond, to maintain uninterrupted missioncritical operations. The recent disclosure of multiple vulnerabilities within CyberPower PowerPanel Business Software has raised significant concerns regarding the security of critical infrastructure CI sectors. These vulnerabilities pose a serious risk to the integrity and reliability of CI systems, potentially exposing them to exploitation by malicious actors. The Cybersecurity and Infrastructure Security Agency CISA, a key entity within the United States government responsible for safeguarding critical infrastructure, has issued security alerts highlighting the heightened interest of hacktivist groups in targeting internetexposed Industrial Control Systems ICS devices. This revelation further amplifies the urgency surrounding the recent PowerPlay vulnerabilities. UPS management software such as PowerPanel is designed to provide advanced power management for Uninterrupted Power Supply, Power Distribution Unit, or Automatic Transfer Switch. PowerPanel UPS management software features realtime monitoring, remote management, event logging, automatic shutdown, scheduled maintenance, alarm notifications, energy management, multidevice support, user access control, and integration capabilities. These features enable organizations to efficiently monitor, control, and manage their UPS systems, ensuring continuous power availability, minimizing downtime, and optimizing energy usage. The table below provides details on the vulnerabilities impacting PowerPanel, a business management software: 4.9.0 and prior. The official vendor, CyberPower has released a patch that fixes these vulnerabilities. Link. The exploitation of the vulnerabilities in vulnerable PowerPanel could allow an attacker to potentially bypass authentication and obtain administrator privileges, which could be utilized for writing arbitrary files to the server for code execution, gaining access to sensitive information, impersonating any client to sending malicious data and gaining access to the testing or production server. If an attacker is able to manipulate UPS management software, the target organization might face severe consequences, including: Understanding the impact of a successful cyberattack via vulnerable UPS Management software, CRIL researchers investigation led to the discovery of over 600 internetexposed PowerPanel Business software. Given below are screenshots of the internet exposed PowerPanel Business applications. CRIL researchers have been closely monitoring hacktivist claims of targeting internetexposed Industrial Control System ICS devices. In past campaigns launched by hacktivist groups such as GhostSec, SigedSec, TeamOneFist, etc. cyberattacks on UPS systems have emerged as a key vector in such campaigns to cause mass disruptions and gather notoriety from such attacks. Even though the impact of such claims remains questionable, the exposure and direct access of UPS systems to an attacker is a deeply concerning scenario. The OpColombia campaign launched by SiegdSec in collaboration with GhostSec and multiple campaigns launched by TeamOneFist in response to the RussiaUkraine war in 2023 is a few notable incidents in which UPS systems manufactured by Schneider Electric, Powest, and APC were allegedly targeted. Figure 1 Powest UPS systems targeted during OpColombia Figure 2 Schneider and APC UPS targeted by Team OneFist CRIL researchers speculate that threat actors could soon leverage the critical vulnerabilities disclosed in PowerPanel in upcoming campaigns. With the potential for exploitation looming, urgent attention to patching and mitigation measures is imperative to preemptively thwart any attempts to exploit these weaknesses. Proactive steps such as monitoring for suspicious activities, implementing network segmentation, and enhancing user awareness can bolster defenses against potential attacks. https://www.cisa.gov/newsevents/icsadvisories/icsa2412301https://www.cyberpower.com/in/en/product/series/powerpanelbusiness Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

