---
CP Source: Cyble
CP Execution date:  2024-07-12
Headline: "Ransomware Menace Amplifies For Vulnerable Industrial Control Systems: Heightened Threats To Critical Infrastructure  - Cyble"
Date: 2024-05-23
Category: ""

ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "AT"
ADD_INFORMATION_technique_url: "https://attack.mitre.org/techniques/T1053/002"
ADD_INFORMATION_technique_description: "Adversaries may abuse the at(https://attack.mitre.org/software/S0110) utility to perform task scheduling for initial or recurring execution of malicious code. The at(https://attack.mitre.org/software/S0110) utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task(https://attack.mitre.org/techniques/T1053/005)s schtasks(https://attack.mitre.org/software/S0111) in Windows environments, using at(https://attack.mitre.org/software/S0110) requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group.

On Linux and macOS, at(https://attack.mitre.org/software/S0110) may be invoked by the superuser as well as any users added to the <code>at.allow</code> file. If the <code>at.allow</code> file does not exist, the <code>at.deny</code> file is checked. Every username not listed in <code>at.deny</code> is allowed to invoke at(https://attack.mitre.org/software/S0110). If the <code>at.deny</code> exists and is empty, global use of at(https://attack.mitre.org/software/S0110) is permitted. If neither file exists (which is often the baseline) only the superuser is allowed to use at(https://attack.mitre.org/software/S0110).(Citation: Linux at)

Adversaries may use at(https://attack.mitre.org/software/S0110) to execute programs at system startup or on a scheduled basis for Persistence(https://attack.mitre.org/tactics/TA0003). at(https://attack.mitre.org/software/S0110) can also be abused to conduct remote Execution(https://attack.mitre.org/tactics/TA0002) as part of Lateral Movement(https://attack.mitre.org/tactics/TA0008) and/or to run a process under the context of a specified account (such as SYSTEM).

In Linux environments, adversaries may also abuse at(https://attack.mitre.org/software/S0110) to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at(https://attack.mitre.org/software/S0110) may also be used for Privilege Escalation(https://attack.mitre.org/tactics/TA0004) if the binary is allowed to run as superuser via <code>sudo</code>.(Citation: GTFObins at)"
ADD_INFORMATION_technique_deprecated: "False"
ADD_INFORMATION_technique_revoked: "False"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_tactic_ID: "TA0001"
ADD_INFORMATION_technique_ID: "T1078.001, T1195.001, T1566.002, T1091, T1078.004, T1566.004, T1189, T1566, T1133, T1659, T1199, T1195, T1078, T1078.002, T1566.003, T1190, T1195.002, T1195.003, T1200, T1566.001, T1078.003"
ADD_INFORMATION_technique: "Content Injection, Valid Accounts, Domain Accounts, Drive-by Compromise, Compromise Software Supply Chain, Spearphishing Voice, Compromise Hardware Supply Chain, Exploit Public-Facing Application, Cloud Accounts, Spearphishing Attachment, Replication Through Removable Media, Compromise Software Dependencies and Development Tools, Supply Chain Compromise, Hardware Additions, External Remote Services, Spearphishing Link, Local Accounts, Trusted Relationship, Default Accounts, Phishing, Spearphishing via Service"
ADD_INFORMATION_tactic: "INITIAL ACCESS"
ADD_INFORMATION_tactic_url: "https://attack.mitre.org/tactics/TA0001"
ADD_INFORMATION_tactic_description: "The adversary is trying to get into your network.Initial Access consists of techniques that use various entry vectors to gain their initial foothold within a network. Techniques used to gain a foothold include targeted spearphishing and exploiting weaknesses on public-facing web servers. Footholds gained through initial access may allow for continued access, like valid accounts and use of external remote services, or may be limited-use due to changing passwords."
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_data_source_ID: "DS0012"
ADD_INFORMATION_technique_ID: "T1560.002, T1560.003, T1482, T1005, T1216.002, T1651, T1556.005, T1119, T1027.010, T1059.007, T1559.002, T1560, T1216, T1059.001, T1559, T1059, T1059.005, T1564.007, T1564.003, T1027, T1020, T1056.002, T1564, T1615, T1016, T1562, T1140, T1620, T1559.001, T1562.002, T1216.001"
ADD_INFORMATION_technique: "Component Object Model, SyncAppvPublishingServer, Impair Defenses, Obfuscated Files or Information, Cloud Administration Command, Hidden Window, Command Obfuscation, Automated Collection, Archive Collected Data, VBA Stomping, Data from Local System, Dynamic Data Exchange, Disable Windows Event Logging, Archive via Custom Method, GUI Input Capture, Command and Scripting Interpreter, Group Policy Discovery, Automated Exfiltration, Visual Basic, PubPrn, System Script Proxy Execution, Deobfuscate/Decode Files or Information, Hide Artifacts, System Network Configuration Discovery, Archive via Library, JavaScript, Reflective Code Loading, Domain Trust Discovery, Inter-Process Communication, Reversible Encryption, PowerShell"
ADD_INFORMATION_data_source: "SCRIPT"
ADD_INFORMATION_data_source_url: "https://attack.mitre.org/datasources/DS0012"
ADD_INFORMATION_data_source_description: "A file or stream containing a list of commands, allowing them to be launched in sequence(Citation: Microsoft PowerShell Logging)(Citation: FireEye PowerShell Logging)(Citation: Microsoft AMSI)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"

ADD_INFORMATION_platform: "PRE"
ADD_INFORMATION_technique_ID: "T1595.001, T1595, T1583.001, T1608.005, T1608.004, T1588.002, T1588, T1588.003, T1585, T1598.004, T1592, T1608.002, T1598.001, T1583.006, T1584.006, T1592.002, T1592.004, T1587.002, T1595.003, T1583.004, T1584.001, T1588.001, T1587.001, T1583.007, T1584.008, T1583, T1586, T1592.001, T1588.004, T1594, T1583.003, T1598, T1584.007, T1598.002, T1608.003, T1585.001, T1589, T1589.002, T1595.002, T1608, T1584.002, T1587.003, T1584, T1598.003, T1584.004, T1587, T1584.003, T1608.001, T1608.006, T1586.001, T1583.008"
ADD_INFORMATION_technique: "Acquire Infrastructure, Active Scanning, Stage Capabilities, Scanning IP Blocks, Domains, Install Digital Certificate, Server, Client Configurations, SEO Poisoning, Wordlist Scanning, Spearphishing Voice, Gather Victim Identity Information, Digital Certificates, Code Signing Certificates, Vulnerability Scanning, Malvertising, Search Victim-Owned Websites, Upload Malware, Spearphishing Attachment, Network Devices, Link Target, Upload Tool, Social Media Accounts, Spearphishing Service, Compromise Infrastructure, Phishing for Information, Spearphishing Link, Web Services, Malware, Virtual Private Server, Hardware, Tool, Obtain Capabilities, Drive-by Target, Serverless, Establish Accounts, Software, Gather Victim Host Information, Email Addresses, Compromise Accounts, Develop Capabilities, DNS Server"

ADD_INFORMATION_software_ID: "S0110"
ADD_INFORMATION_technique_ID: "T1053.002"
ADD_INFORMATION_technique: "At"
ADD_INFORMATION_software: "AT"
ADD_INFORMATION_software_type: "tool"
ADD_INFORMATION_software_url: "https://attack.mitre.org/software/S0110"
ADD_INFORMATION_software_description: "at(https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.(Citation: TechNet At)(Citation: Linux at)"
ADD_INFORMATION_matrix_domains: "enterprise-attack"
---

**title**
Ransomware Menace Amplifies For Vulnerable Industrial Control Systems: Heightened Threats To Critical Infrastructure  - Cyble

**date**
23/05/2024

**url_news**
https://cyble.com/blog/ransomware-menace-amplifies-for-vulnerable-industrial-control-systems-heightened-threats-to-critical-infrastructure/

**cyble_category**
Ransomware

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Ransomware Menace Amplifies for Vulnerable Industrial Control Systems: Heightened Threats to Critical Infrastructure The protection of Industrial Control Systems ICS has emerged as a significant concern across all sectors. The security challenges surrounding ICS environments and the essential measures needed to protect vital operations in every industry are undeniable. Since 2022, numerous cyberattacks exploiting loopholes in ICS environments have led to severe repercussions, impacting not just organizations but also critical national infrastructure. These incidents have disrupted public services and governance, underscoring the urgent need for robust security measures to safeguard against such threats. In a recent disclosure by a recently emerged ransomware group, Ransomhub, claimed an attack on the Spanish Abattoir, Matadero de Gijn. Considering the nature of business, the company depends on ICS for production and other operational requirements. Figure 1: Ransomhub posts on their DLS Ransomhub, besides making ambiguous claims to encrypt and exfiltrate over 400 GB of data in the detailed post and 15 GB in their initial description about the victim, claimed access to Gijns Supervisory Control and Data Acquisition SCADA system that controls the BioEnergy Plant. Ransomhub posted two screenshots revealing that they gained access to the Digestor controls and the Heating system of the Biogas plant and demonstrated persistence on these systems as latest as till May 18, 2024. Figure 2: SCADA system allegedly controlling the Digestor Tank operations of Gijns BioEnergy Plant Figure 3: SCADA system allegedly controlling the Heating Systems of Digestor Tank Ransomhub RansomwareasaService RaaS first emerged in February 2024, following a post by TA koley on the cybercrime forum RAMP. Basis the post, the locker is written in Golang and C and obfuscated using an asymmetric algorithm based on x25519 and an encryption algorithm in aes256, chacha20, and xchacha20 to ensure faster encryption. The RaaS restricts the ability to target organizations in CIS countries, Cuba, North Korea, and China, indicating ransomware groups proRussian ideology. Figure 4: TA koleys RaaS advertisement thread on the RAMP forum Since then, Ransomhub has claimed attacks on 68 organizations thus far, with the majority of attacks targeted towards the IT ITES sector and organizations in the United States Figure 5: Ransomhub threat profile Ransomhub has been quite active in hiring affiliates after its threat post on the RAMP forum and trying to poach ALPHV/BlackCat affiliates after their exit scam in March 2024. This was evident when it briefly started listing organizations earlier targeted by ALPHV/BlackCat on its DLS and subsequently deleted them. The same victims later emerged on LOCKBITs leak site, indicating that their RaaS has garnered little interest in the affiliate network. Ransomhub has made desperate attempts to gain visibility in the ransomware landscape by trying to take leverage from the Change Healthcare ransomware incident and is now claiming its attacks on SCADA systems. Figure 6: Ransomhubs claims of possessing Change Healthcare data in a post that was deleted later Further, Cyble Research Intelligence Labs CRIL has attributed Ransomhubs association with prominent Initial Access Brokers IABs on Russianlanguage cybercrime forums for buying compromised access, thus indicating their primary attack vector for infiltrating victims networks. The recent ransomware attack by RansomHub targeting SCADA systems serves as a stark warning for organizations exposing Industrial Control System ICS assets over the internet. This event highlights the increased interest of ransomware groups in compromising ICS environments, particularly in cases where numerous devices are linked through Virtual Network Computing VNC. The risk of similar attacks is significantly amplified in such setups, a concern highlighted by CRIL time and again. Our warnings about the security weaknesses in internetexposed ICS assets are now proving prescient, urging a critical reassessment of cybersecurity strategies to safeguard these crucial infrastructures from increasingly sophisticated cyber threats. Cyble researchers anticipate a potential increase in ransomware groups targeting OT environments and their components in the near future. This prediction aligns with the evolving landscape of cyber threats, especially in critical infrastructure sectors. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

