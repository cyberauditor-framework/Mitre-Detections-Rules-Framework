---
CP Source: Cyble
CP Execution date:  2024-08-08
Headline: "Cyble Recognized In Forrester's Attack Surface Management Solutions Landscape Q2 2024 Report  - Cyble"
Date: 2024-07-25
Category: ""

AI_technique_ID_1: "T1566"
AI_technique_1: "PHISHING"
AI_technique_url_1: "https://attack.mitre.org/techniques/T1566"
AI_technique_description_1: "Adversaries may send phishing messages to gain access to victim systems. All forms of phishing are electronically delivered social engineering. Phishing can be targeted, known as spearphishing. In spearphishing, a specific individual, company, or industry will be targeted by the adversary. More generally, adversaries can conduct nontargeted phishing, such as in mass malware spam campaigns. Adversaries may send victims emails containing malicious attachments or links, typically to execute malicious code on victim systems. Phishing may also be conducted via thirdparty services, like social media platforms. Phishing may also involve social engineering techniques, such as posing as a trusted source, as well as evasive techniques such as removing or manipulating emails or metadataheaders from compromised accounts being abused to send messages e.g., Email Hiding Rules https://attack.mitre.org/techniques/T1564/008.Citation Microsoft OAuth Spam 2022Citation Palo Alto Unit 42 VBA Infostealer 2014 Another way to accomplish this is by forging or spoofingCitation Proofpointspoof the identity of the sender which can be used to fool both the human recipient as well as automated security tools.Citation cyberproofdoublebounce Victims may also receive phishing messages that instruct them to call a phone number where they are directed to visit a malicious URL, download malware,Citation sygnia Luna MonthCitation CISA Remote Monitoring and Management Software or install adversaryaccessible remote management tools onto their computer i.e., User Execution https://attack.mitre.org/techniques/T1204.Citation Unit42 Luna Moth"
AI_technique_deprecated_1: "False"
AI_technique_revoked_1: "False"
AI_matrix_domains_1: "enterprise-attack"
AI_technique_ID_2: "T1588.006"
AI_technique_2: "VULNERABILITIES"
AI_technique_url_2: "https://attack.mitre.org/techniques/T1588/006"
AI_technique_description_2: "Adversaries may acquire information about vulnerabilities that can be used during targeting. A vulnerability is a weakness in computer hardware or software that can, potentially, be exploited by an adversary to cause unintended or unanticipated behavior to occur. Adversaries may find vulnerability information by searching open databases or gaining access to closed vulnerability databases.Citation National Vulnerability Database An adversary may monitor vulnerability disclosuresdatabases to understand the state of existing, as well as newly discovered, vulnerabilities. There is usually a delay between when a vulnerability is discovered and when it is made public. An adversary may target the systems of those known to conduct vulnerability research including commercial vendors. Knowledge of a vulnerability may cause an adversary to search for an existing exploit i.e. Exploits https://attack.mitre.org/techniques/T1588/005 or to attempt to develop one themselves i.e. Exploits https://attack.mitre.org/techniques/T1587/004."
AI_technique_deprecated_2: "False"
AI_technique_revoked_2: "False"
AI_matrix_domains_2: "enterprise-attack"
AI_technique_ID_3: "T1053.002"
AI_technique_3: "AT"
AI_technique_url_3: "https://attack.mitre.org/techniques/T1053/002"
AI_technique_description_3: "Adversaries may abuse the at https://attack.mitre.org/software/S0110 utility to perform task scheduling for initial or recurring execution of malicious code. The at https://attack.mitre.org/software/S0110 utility exists as an executable within Windows, Linux, and macOS for scheduling tasks at a specified time and date. Although deprecated in favor of Scheduled Task https://attack.mitre.org/techniques/T1053/005s schtasks https://attack.mitre.org/software/S0111 in Windows environments, using at https://attack.mitre.org/software/S0110 requires that the Task Scheduler service be running, and the user to be logged on as a member of the local Administrators group. On Linux and macOS, at https://attack.mitre.org/software/S0110 may be invoked by the superuser as well as any users added to the codeat.allowcode file. If the codeat.allowcode file does not exist, the codeat.denycode file is checked. Every username not listed in codeat.denycode is allowed to invoke at https://attack.mitre.org/software/S0110. If the codeat.denycode exists and is empty, global use of at https://attack.mitre.org/software/S0110 is permitted. If neither file exists which is often the baseline only the superuser is allowed to use at https://attack.mitre.org/software/S0110.Citation Linux at Adversaries may use at https://attack.mitre.org/software/S0110 to execute programs at system startup or on a scheduled basis for Persistence https://attack.mitre.org/tactics/TA0003. at https://attack.mitre.org/software/S0110 can also be abused to conduct remote Execution https://attack.mitre.org/tactics/TA0002 as part of Lateral Movement https://attack.mitre.org/tactics/TA0008 andor to run a process under the context of a specified account such as SYSTEM. In Linux environments, adversaries may also abuse at https://attack.mitre.org/software/S0110 to break out of restricted environments by using a task to spawn an interactive system shell or to run system commands. Similarly, at https://attack.mitre.org/software/S0110 may also be used for Privilege Escalation https://attack.mitre.org/tactics/TA0004 if the binary is allowed to run as superuser via codesudocode.Citation GTFObins at"
AI_technique_deprecated_3: "False"
AI_technique_revoked_3: "False"
AI_matrix_domains_3: "enterprise-attack"


AI_platform_1: "PRE"
AI_technique_ID_1: "T1608.003; T1587.001; T1595; T1598.003; T1608.001; T1608.004; T1586.001; T1595.003; T1588.001; T1584.003; T1588; T1584.006; T1589; T1585; T1584.004; T1594; T1595.001; T1598.002; T1583.001; T1584; T1583.007; T1584.007; T1587; T1584.008; T1588.002; T1588.003; T1598.004; T1586; T1583; T1588.004; T1583.006; T1583.008; T1589.002; T1584.002; T1608.006; T1584.001; T1585.001; T1587.003; T1592; T1598; T1583.003; T1583.004; T1595.002; T1592.004; T1592.002; T1587.002; T1608.005; T1608; T1608.002; T1592.001; T1598.001"
AI_technique_1: "DNS Server; Upload Tool; Compromise Accounts; Digital Certificates; Serverless; Search Victim-Owned Websites; Develop Capabilities; Upload Malware; Obtain Capabilities; SEO Poisoning; Gather Victim Host Information; Drive-by Target; Spearphishing Voice; Server; Stage Capabilities; Domains; Active Scanning; Gather Victim Identity Information; Compromise Infrastructure; Email Addresses; Social Media Accounts; Spearphishing Attachment; Client Configurations; Spearphishing Link; Software; Establish Accounts; Malware; Phishing for Information; Acquire Infrastructure; Virtual Private Server; Scanning IP Blocks; Tool; Malvertising; Spearphishing Service; Network Devices; Code Signing Certificates; Wordlist Scanning; Hardware; Link Target; Web Services; Install Digital Certificate; Vulnerability Scanning"
AI_platform_2: "NETWORK"
AI_technique_ID_2: "T1505.003; T1600.001; T1098.004; T1082; T1601; T1665; T1542.005; T1136.001; T1599.001; T1098; T1071; T1070; T1557; T1110.004; T1059; T1600.002; T1110; T1071.003; T1018; T1110.001; T1105; T1090; T1059.004; T1071.004; T1602; T1016; T1095; T1601.001; T1110.003; T1070.003; T1057; T1561.001; T1190; T1049; T1040; T1599; T1090.003; T1552.004; T1561.002; T1056.001; T1653; T1059.008; T1070.007; T1600; T1033; T1205.001; T1205; T1027; T1037.004; T1562.004; T1602.002; T1601.002; T1006; T1542.004; T1556.004; T1556; T1110.002; T1562; T1072; T1495; T1027.008; T1573; T1561; T1573.002; T1529; T1046; T1090.001; T1602.001; T1552; T1020; T1542; T1056; T1078.001; T1048.003; T1078.003; T1071.002; T1562.001; T1490; T1090.002; T1048; T1547; T1542.001; T1037; T1136; T1573.001; T1083; T1562.003; T1005; T1071.001; T1124; T1078; T1201; T1505; T1020.001"
AI_technique_2: "System Time Discovery; External Proxy; Mail Protocols; Internal Proxy; Password Guessing; Encrypted Channel; Data from Local System; Traffic Duplication; Clear Command History; Traffic Signaling; Default Accounts; Server Software Component; Port Knocking; Indicator Removal; System Network Connections Discovery; Pre-OS Boot; Unix Shell; Network Device Configuration Dump; Software Deployment Tools; Disk Wipe; Boot or Logon Autostart Execution; Proxy; Direct Volume Access; Firmware Corruption; Network Service Discovery; Network Address Translation Traversal; Network Sniffing; Web Protocols; Adversary-in-the-Middle; Weaken Encryption; Symmetric Cryptography; File and Directory Discovery; Downgrade System Image; Obfuscated Files or Information; Network Boundary Bridging; Boot or Logon Initialization Scripts; ROMMONkit; Valid Accounts; Data from Configuration Repository; Ingress Tool Transfer; System Owner/User Discovery; Power Settings; System Firmware; Password Policy Discovery; Keylogging; Private Keys; Process Discovery; SSH Authorized Keys; Asymmetric Cryptography; Impair Command History Logging; Disable or Modify Tools; System Network Configuration Discovery; Application Layer Protocol; Disable or Modify System Firewall; Disable Crypto Hardware; Exfiltration Over Unencrypted Non-C2 Protocol; Password Cracking; Unsecured Credentials; Disk Structure Wipe; Exploit Public-Facing Application; Inhibit System Recovery; SNMP (MIB Dump); Remote System Discovery; Stripped Payloads; Disk Content Wipe; File Transfer Protocols; Modify Authentication Process; Network Device CLI; Credential Stuffing; Brute Force; Hide Infrastructure; Local Account; TFTP Boot; Modify System Image; Input Capture; Create Account; Patch System Image; DNS; Web Shell; Impair Defenses; Network Device Authentication; Password Spraying; Account Manipulation; Clear Network Connection History and Configurations; Automated Exfiltration; System Information Discovery; Command and Scripting Interpreter; System Shutdown/Reboot; Reduce Key Space; Local Accounts; Multi-hop Proxy; Non-Application Layer Protocol; Exfiltration Over Alternative Protocol; RC Scripts"


AI_software_ID_1: "S0575"
AI_technique_ID_1: "T1049; T1016; T1135; T1080; T1106; T1018; T1140; T1021.002; T1083; T1486; T1059.003; T1057; T1027; T1055.001; T1489; T1490"
AI_technique_1: "System Network Connections Discovery; System Network Configuration Discovery; Dynamic-link Library Injection; Native API; Process Discovery; Data Encrypted for Impact; Deobfuscate/Decode Files or Information; Service Stop; Taint Shared Content; Remote System Discovery; Windows Command Shell; File and Directory Discovery; Inhibit System Recovery; SMB/Windows Admin Shares; Obfuscated Files or Information; Network Share Discovery"
AI_software_1: "CONTI"
AI_software_type_1: "malware"
AI_software_url_1: "https://attack.mitre.org/software/S0575"
AI_software_description_1: "Conti https://attack.mitre.org/software/S0575 is a RansomwareasaService RaaS that was first observed in December 2019. Conti https://attack.mitre.org/software/S0575 has been deployed via TrickBot https://attack.mitre.org/software/S0266 and used against major corporations and government agencies, particularly those in North America. As with other ransomware families, actors using Conti https://attack.mitre.org/software/S0575 steal sensitive files and information from compromised networks, and threaten to publish this data unless the ransom is paid.Citation Cybereason Conti Jan 2021Citation CarbonBlack Conti July 2020Citation Cybleinc Conti January 2020"
AI_matrix_domains_1: "enterprise-attack"
AI_software_ID_2: "S0039"
AI_technique_ID_2: "T1049; T1135; T1087.001; T1569.002; T1136.001; T1007; T1069.001; T1124; T1018; T1201; T1021.002; T1070.005; T1136.002; T1087.002; T1069.002"
AI_technique_2: "System Network Connections Discovery; System Time Discovery; Service Execution; Local Groups; Local Account; Domain Account; Domain Groups; System Service Discovery; Remote System Discovery; Network Share Connection Removal; Password Policy Discovery; SMB/Windows Admin Shares; Network Share Discovery"
AI_software_2: "NET"
AI_software_type_2: "tool"
AI_software_url_2: "https://attack.mitre.org/software/S0039"
AI_software_description_2: "The Net https://attack.mitre.org/software/S0039 utility is a component of the Windows operating system. It is used in commandline operations for control of users, groups, services, and network connections. Citation Microsoft Net Utility Net https://attack.mitre.org/software/S0039 has a great deal of functionality, Citation Savill 1999 much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through SMBWindows Admin Shares https://attack.mitre.org/techniques/T1021/002 using codenet usecode commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as codenet1 usercode."
AI_matrix_domains_2: "enterprise-attack"
AI_software_ID_3: "S1088"
AI_technique_ID_3: "T1071.002; T1204.002; T1105; T1053.005; T1659"
AI_technique_3: "File Transfer Protocols; Content Injection; Ingress Tool Transfer; Scheduled Task; Malicious File"
AI_software_3: "DISCO"
AI_software_type_3: "malware"
AI_software_url_3: "https://attack.mitre.org/software/S1088"
AI_software_description_3: "Disco https://attack.mitre.org/software/S1088 is a custom implant that has been used by MoustachedBouncer https://attack.mitre.org/groups/G1019 since at least 2020 including in campaigns using targeted malicious content injection for initial access and command and control.Citation MoustachedBouncer ESET August 2023"
AI_matrix_domains_3: "enterprise-attack"
AI_software_ID_4: "S0097"
AI_technique_ID_4: "T1018"
AI_technique_4: "Remote System Discovery"
AI_software_4: "PING"
AI_software_type_4: "tool"
AI_software_url_4: "https://attack.mitre.org/software/S0097"
AI_software_description_4: "Ping https://attack.mitre.org/software/S0097 is an operating system utility commonly used to troubleshoot and verify network connections. Citation TechNet Ping"
AI_matrix_domains_4: "enterprise-attack"
AI_software_ID_5: "S0183"
AI_technique_ID_5: "T1090.003; T1573.002"
AI_technique_5: "Asymmetric Cryptography; Multi-hop Proxy"
AI_software_5: "TOR"
AI_software_type_5: "tool"
AI_software_url_5: "https://attack.mitre.org/software/S0183"
AI_software_description_5: "Tor https://attack.mitre.org/software/S0183 is a software suite and network that provides increased anonymity on the Internet. It creates a multihop proxy network and utilizes multilayer encryption to protect both the message and routing information. Tor https://attack.mitre.org/software/S0183 utilizes Onion Routing, in which messages are encrypted with multiple layers of encryption at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. Citation Dingledine Tor The SecondGeneration Onion Router"
AI_matrix_domains_5: "enterprise-attack"
AI_software_ID_6: "S0110"
AI_technique_ID_6: "T1053.002"
AI_technique_6: "At"
AI_software_6: "AT"
AI_software_type_6: "tool"
AI_software_url_6: "https://attack.mitre.org/software/S0110"
AI_software_description_6: "at https://attack.mitre.org/software/S0110 is used to schedule tasks on a system to run at a specified date or time.Citation TechNet AtCitation Linux at"
AI_matrix_domains_6: "enterprise-attack"

---

**title**
Cyble Recognized In Forrester's Attack Surface Management Solutions Landscape Q2 2024 Report  - Cyble

**date**
25/07/2024

**url_news**
https://cyble.com/blog/cyble-recognized-in-forresters-attack-surface-management-solutions-landscape-q2-2024-report/

**cyble_category**
Annoucement

**links**


**body**
Report an Incident Talk to Sales We are Hiring Home Blog Cyble Recognized in Forresters Attack Surface Management Solutions Landscape Q2 2024 Report Organizations need to eliminate digital risks, blind spots, and potential threats, and ensure effective detection and response. This is where Attack Surface Management ASM comes into play. ASM as a solution has evolved in the past 4 5 years with an aim to help security teams gain visibility into unknown technology assets. Initially, it focused into two areas: Today, the capabilities EASM and CASM have converged to provide a unified approach to managing an organizations entire attack surface and help organizations prioritize and remediate security gaps effectively. Organizations can leverage ASM to: Cyble has been recognized among 37 vendors in the Attack Surface Management Solutions Landscape Report Q2 2024 by Forrester. This recognition underscores our dedication to providing comprehensive ASM solutions to our customers. Recognition and Evaluation: The report provides an overview of the ASM solutions market, explores the value that security and risk SR professionals can expect from various vendors, and offers guidance on vendor options based on company size and market focus. Cybles Top Focus Areas: In the Forrester evaluation, each vendor was asked to highlight their top three focus areas for extended use cases. These use cases go beyond the core functions and represent the areas where the vendor wants to be recognized. Cyble chose to focus on Exposure Management, Threat Hunting and Investigations, and ThirdParty and Supply Chain Monitoring. Cyble sets itself apart in the ASM landscape through proactive and continuous monitoring and assessment of vulnerabilities and potential entry points that malicious actors could exploit for unauthorized system or network access. Cyble leverages advanced AI and ML techniques to provide realtime insights into potentially harmful links. By employing sophisticated AI and ML algorithms to detect phishing and suspicious URLs, Cyble helps minimize false positives through advanced content and sequence matching. Cyble delivers a comprehensive view of an organizations attack surface, enabling better decisionmaking and more effective risk management. Through our Attack Surface Management capabilities, we provide comprehensive solutions to secure every aspect of your attack surfaces, helping our customers secure their digital frontier and detect and respond effectively. Join the many organizations that trust Cyble to secure their digital assets and fortify their cybersecurity defenses. Schedule a demo today to see how Cyble can help protect your organization. And dont forget to download our latest report on the Attack Surface Management Solutions Landscape for Q2 2024 to discover additional details. Subscribe now to keep reading and get access to the full archive. Type your email Subscribe Continue reading

